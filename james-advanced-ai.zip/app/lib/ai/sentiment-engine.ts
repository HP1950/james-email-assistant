
/**
 * Advanced Sentiment Analysis Engine for James AI
 * Real-time emotional intelligence for email processing
 */

export interface SentimentResult {
  sentiment: 'positive' | 'negative' | 'neutral' | 'mixed';
  score: number; // -1 to 1
  confidence: number; // 0 to 1
  emotions: EmotionMap;
  urgency: 'low' | 'normal' | 'high' | 'critical';
  tone: 'formal' | 'informal' | 'aggressive' | 'polite' | 'enthusiastic' | 'concerned' | 'neutral';
  intent: string; // request, complaint, inquiry, appreciation, etc.
  keyPhrases: string[];
  emotionalTriggers: string[];
}

export interface EmotionMap {
  joy: number;
  sadness: number;
  anger: number;
  fear: number;
  surprise: number;
  disgust: number;
  trust: number;
  anticipation: number;
}

export interface ContextualFactors {
  timeOfDay: string;
  dayOfWeek: string;
  senderRelationship: 'boss' | 'colleague' | 'client' | 'friend' | 'family' | 'unknown';
  emailThread: any[];
  previousInteractions: any[];
  userCurrentMood?: string;
}

export class SentimentAnalysisEngine {
  private confidenceThreshold: number = 0.7;
  private emotionKeywords: Map<string, EmotionMap> = new Map();
  private intentPatterns: Map<string, RegExp[]> = new Map();
  private urgencyIndicators: string[] = [];

  constructor() {
    this.initializeEmotionKeywords();
    this.initializeIntentPatterns();
    this.initializeUrgencyIndicators();
  }

  /**
   * Main sentiment analysis function
   */
  async analyzeSentiment(
    emailContent: string, 
    subject: string = '', 
    context?: ContextualFactors
  ): Promise<SentimentResult> {
    try {
      // Use LLM API for advanced sentiment analysis
      const llmResult = await this.performLLMSentimentAnalysis(emailContent, subject, context);
      
      // Enhance with rule-based analysis
      const ruleBasedResult = await this.performRuleBasedAnalysis(emailContent, subject);
      
      // Combine results with confidence weighting
      const combinedResult = this.combineAnalysisResults(llmResult, ruleBasedResult);
      
      // Apply contextual adjustments
      if (context) {
        return this.applyContextualAdjustments(combinedResult, context);
      }
      
      return combinedResult;
    } catch (error) {
      console.error('Sentiment analysis error:', error);
      return this.getFallbackSentiment(emailContent, subject);
    }
  }

  /**
   * LLM-powered sentiment analysis
   */
  private async performLLMSentimentAnalysis(
    content: string, 
    subject: string, 
    context?: ContextualFactors
  ): Promise<SentimentResult> {
    const prompt = this.buildSentimentPrompt(content, subject, context);
    
    try {
      const response = await fetch('/api/ai/sentiment-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, content, subject })
      });
      
      if (!response.ok) {
        throw new Error(`LLM API error: ${response.status}`);
      }
      
      const result = await response.json();
      return this.parseLLMSentimentResult(result);
    } catch (error) {
      console.error('LLM sentiment analysis failed:', error);
      throw error;
    }
  }

  /**
   * Rule-based sentiment analysis fallback
   */
  private async performRuleBasedAnalysis(content: string, subject: string): Promise<SentimentResult> {
    const fullText = `${subject} ${content}`.toLowerCase();
    
    // Emotion analysis
    const emotions = this.analyzeEmotions(fullText);
    
    // Sentiment scoring
    const sentimentScore = this.calculateSentimentScore(fullText, emotions);
    
    // Urgency detection
    const urgency = this.detectUrgency(fullText);
    
    // Tone analysis
    const tone = this.analyzeTone(fullText);
    
    // Intent classification
    const intent = this.classifyIntent(fullText);
    
    // Key phrase extraction
    const keyPhrases = this.extractKeyPhrases(fullText);
    
    return {
      sentiment: this.scoresToSentiment(sentimentScore),
      score: sentimentScore,
      confidence: 0.6, // Rule-based has lower confidence
      emotions,
      urgency,
      tone,
      intent,
      keyPhrases,
      emotionalTriggers: this.findEmotionalTriggers(fullText)
    };
  }

  /**
   * Initialize emotion keyword mappings
   */
  private initializeEmotionKeywords(): void {
    this.emotionKeywords.set('positive_joy', {
      joy: 0.8, sadness: 0.0, anger: 0.0, fear: 0.0,
      surprise: 0.2, disgust: 0.0, trust: 0.3, anticipation: 0.4
    });
    
    this.emotionKeywords.set('negative_anger', {
      joy: 0.0, sadness: 0.2, anger: 0.9, fear: 0.1,
      surprise: 0.1, disgust: 0.3, trust: 0.0, anticipation: 0.0
    });
    
    this.emotionKeywords.set('concern_fear', {
      joy: 0.0, sadness: 0.3, anger: 0.1, fear: 0.8,
      surprise: 0.2, disgust: 0.0, trust: 0.0, anticipation: 0.6
    });
    
    // Add more emotion mappings...
  }

  /**
   * Initialize intent detection patterns
   */
  private initializeIntentPatterns(): void {
    this.intentPatterns.set('request', [
      /could you please/i,
      /can you/i,
      /would you mind/i,
      /i need/i,
      /please provide/i
    ]);
    
    this.intentPatterns.set('complaint', [
      /disappointed/i,
      /unacceptable/i,
      /frustrated/i,
      /problem with/i,
      /not working/i
    ]);
    
    this.intentPatterns.set('inquiry', [
      /question about/i,
      /wondering if/i,
      /clarification on/i,
      /more information/i
    ]);
    
    this.intentPatterns.set('appreciation', [
      /thank you/i,
      /grateful/i,
      /appreciate/i,
      /excellent work/i
    ]);
  }

  /**
   * Initialize urgency indicators
   */
  private initializeUrgencyIndicators(): void {
    this.urgencyIndicators = [
      'urgent', 'asap', 'immediately', 'emergency', 'critical',
      'deadline', 'time-sensitive', 'priority', 'rush', 'important'
    ];
  }

  /**
   * Build sentiment analysis prompt for LLM
   */
  private buildSentimentPrompt(content: string, subject: string, context?: ContextualFactors): string {
    return `
    Analyze the emotional sentiment and intent of this email:
    
    Subject: "${subject}"
    Content: "${content}"
    
    ${context ? `Context: Sender relationship: ${context.senderRelationship}, Time: ${context.timeOfDay}` : ''}
    
    Please provide a detailed sentiment analysis including:
    1. Overall sentiment (positive/negative/neutral/mixed) with score (-1 to 1)
    2. Specific emotions (joy, sadness, anger, fear, surprise, disgust, trust, anticipation) as percentages
    3. Urgency level (low/normal/high/critical)
    4. Tone (formal/informal/aggressive/polite/enthusiastic/concerned/neutral)
    5. Intent classification (request/complaint/inquiry/appreciation/etc.)
    6. Key emotional phrases
    7. Confidence level (0-1)
    
    Respond in JSON format with the following structure:
    {
      "sentiment": "positive/negative/neutral/mixed",
      "score": -1.0 to 1.0,
      "confidence": 0.0 to 1.0,
      "emotions": {
        "joy": 0.0-1.0,
        "sadness": 0.0-1.0,
        "anger": 0.0-1.0,
        "fear": 0.0-1.0,
        "surprise": 0.0-1.0,
        "disgust": 0.0-1.0,
        "trust": 0.0-1.0,
        "anticipation": 0.0-1.0
      },
      "urgency": "low/normal/high/critical",
      "tone": "formal/informal/aggressive/polite/enthusiastic/concerned/neutral",
      "intent": "specific intent",
      "keyPhrases": ["phrase1", "phrase2"],
      "emotionalTriggers": ["trigger1", "trigger2"]
    }
    
    Respond with raw JSON only.
    `;
  }

  /**
   * Parse LLM sentiment analysis result
   */
  private parseLLMSentimentResult(result: any): SentimentResult {
    try {
      // The result should already be parsed JSON from the API
      if (result.result && typeof result.result === 'object') {
        return {
          sentiment: result.result.sentiment || 'neutral',
          score: result.result.score || 0.0,
          confidence: result.result.confidence || 0.7,
          emotions: result.result.emotions || this.getDefaultEmotions(),
          urgency: result.result.urgency || 'normal',
          tone: result.result.tone || 'neutral',
          intent: result.result.intent || 'unknown',
          keyPhrases: result.result.keyPhrases || [],
          emotionalTriggers: result.result.emotionalTriggers || []
        };
      }
      
      throw new Error('Invalid LLM result format');
    } catch (error) {
      console.error('Error parsing LLM sentiment result:', error);
      throw error;
    }
  }

  /**
   * Combine LLM and rule-based results
   */
  private combineAnalysisResults(llmResult: SentimentResult, ruleResult: SentimentResult): SentimentResult {
    // Weight LLM result more heavily due to higher accuracy
    const llmWeight = 0.8;
    const ruleWeight = 0.2;
    
    return {
      sentiment: llmResult.confidence > 0.7 ? llmResult.sentiment : ruleResult.sentiment,
      score: (llmResult.score * llmWeight) + (ruleResult.score * ruleWeight),
      confidence: Math.max(llmResult.confidence, ruleResult.confidence),
      emotions: this.combineEmotions(llmResult.emotions, ruleResult.emotions, llmWeight, ruleWeight),
      urgency: llmResult.urgency !== 'normal' ? llmResult.urgency : ruleResult.urgency,
      tone: llmResult.tone !== 'neutral' ? llmResult.tone : ruleResult.tone,
      intent: llmResult.intent || ruleResult.intent,
      keyPhrases: [...llmResult.keyPhrases, ...ruleResult.keyPhrases].slice(0, 10),
      emotionalTriggers: [...llmResult.emotionalTriggers, ...ruleResult.emotionalTriggers].slice(0, 8)
    };
  }

  /**
   * Apply contextual adjustments based on user patterns and relationships
   */
  private applyContextualAdjustments(result: SentimentResult, context: ContextualFactors): SentimentResult {
    let adjustedResult = { ...result };
    
    // Adjust based on sender relationship
    if (context.senderRelationship === 'boss') {
      // Emails from boss may seem more urgent
      if (adjustedResult.urgency === 'normal') {
        adjustedResult.urgency = 'high';
      }
    }
    
    // Adjust based on time context
    if (context.timeOfDay === 'late_night' || context.timeOfDay === 'early_morning') {
      // Messages sent at odd hours might be more urgent
      if (adjustedResult.urgency === 'normal') {
        adjustedResult.urgency = 'high';
      }
    }
    
    // Adjust based on previous interactions
    if (context.previousInteractions?.length > 0) {
      const recentNegative = context.previousInteractions
        .slice(-3)
        .some(interaction => interaction.sentiment === 'negative');
      
      if (recentNegative && adjustedResult.sentiment === 'neutral') {
        adjustedResult.score = Math.max(adjustedResult.score - 0.1, -1.0);
      }
    }
    
    return adjustedResult;
  }

  // Helper methods for rule-based analysis
  private analyzeEmotions(text: string): EmotionMap {
    const emotions: EmotionMap = this.getDefaultEmotions();
    
    // Simple keyword-based emotion detection
    const joyWords = ['happy', 'excited', 'great', 'excellent', 'wonderful', 'fantastic'];
    const angerWords = ['angry', 'frustrated', 'annoyed', 'disappointed', 'terrible'];
    const fearWords = ['worried', 'concerned', 'anxious', 'afraid', 'nervous'];
    const sadnessWords = ['sad', 'upset', 'depressed', 'down', 'unfortunate'];
    
    joyWords.forEach(word => {
      if (text.includes(word)) emotions.joy += 0.2;
    });
    
    angerWords.forEach(word => {
      if (text.includes(word)) emotions.anger += 0.3;
    });
    
    fearWords.forEach(word => {
      if (text.includes(word)) emotions.fear += 0.25;
    });
    
    sadnessWords.forEach(word => {
      if (text.includes(word)) emotions.sadness += 0.2;
    });
    
    // Normalize emotions to 0-1 range
    Object.keys(emotions).forEach(key => {
      emotions[key as keyof EmotionMap] = Math.min(emotions[key as keyof EmotionMap], 1.0);
    });
    
    return emotions;
  }

  private calculateSentimentScore(text: string, emotions: EmotionMap): number {
    const positiveScore = emotions.joy + emotions.trust + emotions.surprise * 0.5;
    const negativeScore = emotions.anger + emotions.sadness + emotions.fear + emotions.disgust;
    
    // Additional keyword-based scoring
    const positiveWords = ['good', 'great', 'excellent', 'perfect', 'amazing', 'wonderful'];
    const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'worst', 'failed'];
    
    let keywordScore = 0;
    positiveWords.forEach(word => {
      if (text.includes(word)) keywordScore += 0.1;
    });
    
    negativeWords.forEach(word => {
      if (text.includes(word)) keywordScore -= 0.15;
    });
    
    const finalScore = (positiveScore - negativeScore) + keywordScore;
    return Math.max(-1.0, Math.min(1.0, finalScore));
  }

  private detectUrgency(text: string): 'low' | 'normal' | 'high' | 'critical' {
    const criticalWords = ['emergency', 'critical', 'crisis'];
    const highWords = ['urgent', 'asap', 'immediately', 'deadline'];
    const normalWords = ['when you can', 'at your convenience'];
    
    for (const word of criticalWords) {
      if (text.includes(word)) return 'critical';
    }
    
    for (const word of highWords) {
      if (text.includes(word)) return 'high';
    }
    
    for (const word of normalWords) {
      if (text.includes(word)) return 'low';
    }
    
    return 'normal';
  }

  private analyzeTone(text: string): string {
    if (text.includes('please') || text.includes('thank you')) return 'polite';
    if (text.includes('!') && text.includes('great')) return 'enthusiastic';
    if (text.includes('unfortunately') || text.includes('however')) return 'concerned';
    if (text.match(/[A-Z]{3,}/)) return 'aggressive';
    if (text.includes('dear') || text.includes('sincerely')) return 'formal';
    if (text.includes('hey') || text.includes('yeah')) return 'informal';
    
    return 'neutral';
  }

  private classifyIntent(text: string): string {
    for (const [intent, patterns] of this.intentPatterns.entries()) {
      for (const pattern of patterns) {
        if (pattern.test(text)) {
          return intent;
        }
      }
    }
    
    return 'general';
  }

  private extractKeyPhrases(text: string): string[] {
    // Simple key phrase extraction
    const sentences = text.split(/[.!?]+/);
    const keyPhrases: string[] = [];
    
    sentences.forEach(sentence => {
      const trimmed = sentence.trim();
      if (trimmed.length > 10 && trimmed.length < 100) {
        // Look for sentences with emotional words
        const hasEmotionalWord = this.urgencyIndicators.some(word => 
          trimmed.toLowerCase().includes(word)
        );
        
        if (hasEmotionalWord || trimmed.includes('please') || trimmed.includes('need')) {
          keyPhrases.push(trimmed);
        }
      }
    });
    
    return keyPhrases.slice(0, 5);
  }

  private findEmotionalTriggers(text: string): string[] {
    const triggers: string[] = [];
    
    // Common emotional trigger phrases
    const triggerPatterns = [
      'i am disappointed',
      'this is unacceptable',
      'i am frustrated',
      'please help',
      'urgent matter',
      'time sensitive',
      'deadline approaching'
    ];
    
    triggerPatterns.forEach(pattern => {
      if (text.includes(pattern)) {
        triggers.push(pattern);
      }
    });
    
    return triggers;
  }

  private combineEmotions(emotions1: EmotionMap, emotions2: EmotionMap, weight1: number, weight2: number): EmotionMap {
    const combined: EmotionMap = {} as EmotionMap;
    
    Object.keys(emotions1).forEach(key => {
      const emotion = key as keyof EmotionMap;
      combined[emotion] = (emotions1[emotion] * weight1) + (emotions2[emotion] * weight2);
    });
    
    return combined;
  }

  private scoresToSentiment(score: number): 'positive' | 'negative' | 'neutral' | 'mixed' {
    if (score > 0.3) return 'positive';
    if (score < -0.3) return 'negative';
    if (Math.abs(score) < 0.1) return 'neutral';
    return 'mixed';
  }

  private getDefaultEmotions(): EmotionMap {
    return {
      joy: 0.0,
      sadness: 0.0,
      anger: 0.0,
      fear: 0.0,
      surprise: 0.0,
      disgust: 0.0,
      trust: 0.0,
      anticipation: 0.0
    };
  }

  private getFallbackSentiment(content: string, subject: string): SentimentResult {
    // Very basic fallback sentiment
    return {
      sentiment: 'neutral',
      score: 0.0,
      confidence: 0.3,
      emotions: this.getDefaultEmotions(),
      urgency: 'normal',
      tone: 'neutral',
      intent: 'unknown',
      keyPhrases: [],
      emotionalTriggers: []
    };
  }
}

/**
 * Sentiment Analysis Factory
 */
export class SentimentEngineFactory {
  private static instance: SentimentAnalysisEngine;
  
  static getInstance(): SentimentAnalysisEngine {
    if (!this.instance) {
      this.instance = new SentimentAnalysisEngine();
    }
    return this.instance;
  }
}
