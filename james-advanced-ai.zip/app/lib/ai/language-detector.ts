
/**
 * Advanced Multi-Language Detection System for James AI
 * Supports real-time language identification and cultural context understanding
 */

export interface LanguageDetectionResult {
  primaryLanguage: string;
  confidence: number;
  alternativeLanguages?: Array<{
    language: string;
    confidence: number;
  }>;
  culturalContext?: CulturalContext;
  writingStyle?: WritingStyle;
  translationNeeded?: boolean;
  suggestedResponseLanguage?: string;
}

export interface CulturalContext {
  region: string;
  formalityLevel: 'very_formal' | 'formal' | 'neutral' | 'informal' | 'very_informal';
  communicationStyle: 'direct' | 'indirect' | 'high_context' | 'low_context';
  timeOrientation: 'past' | 'present' | 'future';
  relationshipOrientation: 'individual' | 'group' | 'hierarchical';
}

export interface WritingStyle {
  complexity: 'simple' | 'moderate' | 'complex' | 'academic';
  tone: 'professional' | 'casual' | 'academic' | 'creative' | 'technical';
  vocabulary: 'basic' | 'intermediate' | 'advanced' | 'specialized';
  sentenceStructure: 'simple' | 'compound' | 'complex' | 'mixed';
}

export interface LanguageCapabilities {
  nativeSupport: string[];
  translationSupport: string[];
  culturalAwarenessSupport: string[];
  sentimentAnalysisSupport: string[];
}

export class AdvancedLanguageDetector {
  private supportedLanguages: Map<string, LanguageCapabilities> = new Map();
  private culturalPatterns: Map<string, CulturalContext> = new Map();
  private confidenceThreshold: number = 0.8;

  constructor() {
    this.initializeSupportedLanguages();
    this.initializeCulturalPatterns();
  }

  /**
   * Main language detection function
   */
  async detectLanguage(
    text: string,
    context?: {
      senderEmail?: string;
      previousEmails?: any[];
      userPreferredLanguage?: string;
    }
  ): Promise<LanguageDetectionResult> {
    try {
      // Use LLM API for advanced language detection
      const llmResult = await this.performLLMLanguageDetection(text, context);
      
      // Enhance with rule-based detection
      const ruleBasedResult = await this.performRuleBasedDetection(text);
      
      // Combine results
      const combinedResult = this.combineDetectionResults(llmResult, ruleBasedResult);
      
      // Add cultural context
      combinedResult.culturalContext = this.analyzeCulturalContext(
        combinedResult.primaryLanguage,
        text
      );
      
      // Analyze writing style
      combinedResult.writingStyle = this.analyzeWritingStyle(text, combinedResult.primaryLanguage);
      
      // Determine if translation is needed
      combinedResult.translationNeeded = this.needsTranslation(
        combinedResult.primaryLanguage,
        context?.userPreferredLanguage
      );
      
      // Suggest response language
      combinedResult.suggestedResponseLanguage = this.suggestResponseLanguage(
        combinedResult.primaryLanguage,
        context
      );
      
      return combinedResult;
    } catch (error) {
      console.error('Language detection error:', error);
      return this.getFallbackDetection(text);
    }
  }

  /**
   * LLM-powered language detection
   */
  private async performLLMLanguageDetection(
    text: string,
    context?: any
  ): Promise<LanguageDetectionResult> {
    const prompt = this.buildLanguageDetectionPrompt(text, context);
    
    try {
      const response = await fetch('/api/ai/language-detection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, text })
      });
      
      if (!response.ok) {
        throw new Error(`LLM API error: ${response.status}`);
      }
      
      const result = await response.json();
      return this.parseLLMLanguageResult(result);
    } catch (error) {
      console.error('LLM language detection failed:', error);
      throw error;
    }
  }

  /**
   * Rule-based language detection fallback
   */
  private async performRuleBasedDetection(text: string): Promise<LanguageDetectionResult> {
    // Character-based detection
    const characterAnalysis = this.analyzeCharacterSets(text);
    
    // Keyword-based detection
    const keywordAnalysis = this.analyzeKeywords(text);
    
    // Pattern-based detection
    const patternAnalysis = this.analyzePatterns(text);
    
    // Combine rule-based analyses
    const primaryLanguage = this.determinePrimaryLanguage([
      characterAnalysis,
      keywordAnalysis,
      patternAnalysis
    ]);
    
    return {
      primaryLanguage: primaryLanguage.language,
      confidence: primaryLanguage.confidence,
      alternativeLanguages: primaryLanguage.alternatives
    };
  }

  /**
   * Initialize supported languages and their capabilities
   */
  private initializeSupportedLanguages(): void {
    // Major languages with full support
    this.supportedLanguages.set('en', {
      nativeSupport: ['sentiment', 'intent', 'summary', 'translation'],
      translationSupport: ['es', 'fr', 'de', 'it', 'pt', 'nl', 'ru', 'ja', 'ko', 'zh'],
      culturalAwarenessSupport: ['us', 'uk', 'au', 'ca'],
      sentimentAnalysisSupport: ['advanced']
    });
    
    this.supportedLanguages.set('es', {
      nativeSupport: ['sentiment', 'intent', 'translation'],
      translationSupport: ['en', 'pt', 'fr', 'it'],
      culturalAwarenessSupport: ['es', 'mx', 'ar', 'co', 'pe', 'cl'],
      sentimentAnalysisSupport: ['advanced']
    });
    
    this.supportedLanguages.set('fr', {
      nativeSupport: ['sentiment', 'intent', 'translation'],
      translationSupport: ['en', 'es', 'de', 'it'],
      culturalAwarenessSupport: ['fr', 'ca', 'be', 'ch'],
      sentimentAnalysisSupport: ['intermediate']
    });
    
    this.supportedLanguages.set('de', {
      nativeSupport: ['sentiment', 'intent', 'translation'],
      translationSupport: ['en', 'fr', 'es', 'it'],
      culturalAwarenessSupport: ['de', 'at', 'ch'],
      sentimentAnalysisSupport: ['intermediate']
    });
    
    this.supportedLanguages.set('zh', {
      nativeSupport: ['translation'],
      translationSupport: ['en', 'ja', 'ko'],
      culturalAwarenessSupport: ['cn', 'tw', 'hk', 'sg'],
      sentimentAnalysisSupport: ['basic']
    });
    
    this.supportedLanguages.set('ja', {
      nativeSupport: ['translation'],
      translationSupport: ['en', 'zh', 'ko'],
      culturalAwarenessSupport: ['jp'],
      sentimentAnalysisSupport: ['basic']
    });
  }

  /**
   * Initialize cultural patterns for different regions
   */
  private initializeCulturalPatterns(): void {
    // English-speaking cultures
    this.culturalPatterns.set('en-US', {
      region: 'United States',
      formalityLevel: 'informal',
      communicationStyle: 'direct',
      timeOrientation: 'future',
      relationshipOrientation: 'individual'
    });
    
    this.culturalPatterns.set('en-UK', {
      region: 'United Kingdom',
      formalityLevel: 'formal',
      communicationStyle: 'indirect',
      timeOrientation: 'present',
      relationshipOrientation: 'individual'
    });
    
    // Spanish-speaking cultures
    this.culturalPatterns.set('es-ES', {
      region: 'Spain',
      formalityLevel: 'formal',
      communicationStyle: 'indirect',
      timeOrientation: 'present',
      relationshipOrientation: 'group'
    });
    
    this.culturalPatterns.set('es-MX', {
      region: 'Mexico',
      formalityLevel: 'very_formal',
      communicationStyle: 'high_context',
      timeOrientation: 'present',
      relationshipOrientation: 'hierarchical'
    });
    
    // Asian cultures
    this.culturalPatterns.set('ja-JP', {
      region: 'Japan',
      formalityLevel: 'very_formal',
      communicationStyle: 'high_context',
      timeOrientation: 'past',
      relationshipOrientation: 'hierarchical'
    });
    
    this.culturalPatterns.set('zh-CN', {
      region: 'China',
      formalityLevel: 'formal',
      communicationStyle: 'high_context',
      timeOrientation: 'past',
      relationshipOrientation: 'hierarchical'
    });
  }

  /**
   * Build language detection prompt for LLM
   */
  private buildLanguageDetectionPrompt(text: string, context?: any): string {
    return `
    Analyze the language and cultural context of this text:
    
    Text: "${text}"
    
    ${context?.senderEmail ? `Sender: ${context.senderEmail}` : ''}
    ${context?.userPreferredLanguage ? `User preferred language: ${context.userPreferredLanguage}` : ''}
    
    Please provide a comprehensive language analysis including:
    1. Primary language (ISO 639-1 code)
    2. Confidence level (0-1)
    3. Alternative possible languages with confidence scores
    4. Regional variant if applicable (e.g., en-US, es-MX)
    5. Formality level (very_formal/formal/neutral/informal/very_informal)
    6. Communication style (direct/indirect/high_context/low_context)
    7. Writing complexity (simple/moderate/complex/academic)
    8. Cultural indicators and context
    9. Whether translation to user's preferred language is recommended
    
    Respond in JSON format with the following structure:
    {
      "primaryLanguage": "language_code",
      "confidence": 0.0-1.0,
      "alternativeLanguages": [
        {"language": "code", "confidence": 0.0-1.0}
      ],
      "regionalVariant": "language-REGION",
      "formalityLevel": "formal/informal/etc",
      "communicationStyle": "direct/indirect/etc",
      "complexity": "simple/moderate/complex/academic",
      "culturalIndicators": ["indicator1", "indicator2"],
      "translationRecommended": true/false,
      "suggestedResponseLanguage": "language_code"
    }
    
    Respond with raw JSON only.
    `;
  }

  /**
   * Parse LLM language detection result
   */
  private parseLLMLanguageResult(result: any): LanguageDetectionResult {
    try {
      if (result.result && typeof result.result === 'object') {
        return {
          primaryLanguage: result.result.primaryLanguage || 'en',
          confidence: result.result.confidence || 0.7,
          alternativeLanguages: result.result.alternativeLanguages || [],
          translationNeeded: result.result.translationRecommended || false,
          suggestedResponseLanguage: result.result.suggestedResponseLanguage || 'en'
        };
      }
      
      throw new Error('Invalid LLM result format');
    } catch (error) {
      console.error('Error parsing LLM language result:', error);
      throw error;
    }
  }

  /**
   * Character set analysis for language detection
   */
  private analyzeCharacterSets(text: string): { language: string; confidence: number } {
    // Detect character sets
    const hasLatin = /[a-zA-Z]/.test(text);
    const hasCyrillic = /[а-яё]/i.test(text);
    const hasArabic = /[\u0600-\u06FF]/.test(text);
    const hasHiragana = /[\u3040-\u309F]/.test(text);
    const hasKatakana = /[\u30A0-\u30FF]/.test(text);
    const hasHanzi = /[\u4E00-\u9FFF]/.test(text);
    const hasKorean = /[\uAC00-\uD7AF]/.test(text);
    
    if (hasHiragana || hasKatakana) {
      return { language: 'ja', confidence: 0.9 };
    }
    
    if (hasKorean) {
      return { language: 'ko', confidence: 0.9 };
    }
    
    if (hasHanzi && !hasHiragana && !hasKatakana) {
      return { language: 'zh', confidence: 0.8 };
    }
    
    if (hasCyrillic) {
      return { language: 'ru', confidence: 0.8 };
    }
    
    if (hasArabic) {
      return { language: 'ar', confidence: 0.8 };
    }
    
    if (hasLatin) {
      return { language: 'en', confidence: 0.4 }; // Need more analysis for Latin scripts
    }
    
    return { language: 'en', confidence: 0.1 };
  }

  /**
   * Keyword-based language detection
   */
  private analyzeKeywords(text: string): { language: string; confidence: number } {
    const lowercaseText = text.toLowerCase();
    
    // Common words in different languages
    const languageKeywords = {
      'en': ['the', 'and', 'is', 'to', 'of', 'in', 'that', 'have', 'for', 'with'],
      'es': ['el', 'de', 'que', 'y', 'la', 'en', 'un', 'es', 'se', 'no'],
      'fr': ['le', 'de', 'et', 'un', 'il', 'être', 'et', 'en', 'avoir', 'que'],
      'de': ['der', 'die', 'und', 'in', 'den', 'von', 'zu', 'das', 'mit', 'sich'],
      'it': ['il', 'di', 'che', 'e', 'la', 'per', 'un', 'in', 'del', 'con'],
      'pt': ['o', 'de', 'que', 'e', 'do', 'da', 'em', 'um', 'para', 'é']
    };
    
    const scores: { [key: string]: number } = {};
    
    Object.entries(languageKeywords).forEach(([lang, keywords]) => {
      let matches = 0;
      keywords.forEach(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
        const match = lowercaseText.match(regex);
        if (match) matches += match.length;
      });
      scores[lang] = matches / keywords.length;
    });
    
    const topLanguage = Object.entries(scores).reduce((max, current) => 
      current[1] > max[1] ? current : max
    );
    
    return {
      language: topLanguage[0],
      confidence: Math.min(topLanguage[1] * 0.3, 0.8)
    };
  }

  /**
   * Pattern-based language detection
   */
  private analyzePatterns(text: string): { language: string; confidence: number } {
    // Language-specific patterns
    if (text.match(/\b(señor|señora|usted|buenos días|gracias)\b/i)) {
      return { language: 'es', confidence: 0.7 };
    }
    
    if (text.match(/\b(monsieur|madame|vous|bonjour|merci)\b/i)) {
      return { language: 'fr', confidence: 0.7 };
    }
    
    if (text.match(/\b(herr|frau|sie|guten tag|danke)\b/i)) {
      return { language: 'de', confidence: 0.7 };
    }
    
    // English patterns
    if (text.match(/\b(mr|mrs|ms|dear|sincerely|regards)\b/i)) {
      return { language: 'en', confidence: 0.6 };
    }
    
    return { language: 'en', confidence: 0.2 };
  }

  /**
   * Determine primary language from multiple analyses
   */
  private determinePrimaryLanguage(analyses: Array<{ language: string; confidence: number }>): {
    language: string;
    confidence: number;
    alternatives: Array<{ language: string; confidence: number }>;
  } {
    // Combine confidence scores
    const languageScores: { [key: string]: number } = {};
    
    analyses.forEach(analysis => {
      if (!languageScores[analysis.language]) {
        languageScores[analysis.language] = 0;
      }
      languageScores[analysis.language] += analysis.confidence;
    });
    
    // Sort by confidence
    const sortedLanguages = Object.entries(languageScores)
      .map(([language, confidence]) => ({ language, confidence: confidence / analyses.length }))
      .sort((a, b) => b.confidence - a.confidence);
    
    return {
      language: sortedLanguages[0].language,
      confidence: sortedLanguages[0].confidence,
      alternatives: sortedLanguages.slice(1, 4)
    };
  }

  /**
   * Combine LLM and rule-based detection results
   */
  private combineDetectionResults(
    llmResult: LanguageDetectionResult,
    ruleResult: LanguageDetectionResult
  ): LanguageDetectionResult {
    // Prefer LLM result if confidence is high
    if (llmResult.confidence > 0.8) {
      return llmResult;
    }
    
    // Use rule-based if LLM confidence is low
    if (llmResult.confidence < 0.5 && ruleResult.confidence > 0.6) {
      return ruleResult;
    }
    
    // Combine both results
    return {
      primaryLanguage: llmResult.primaryLanguage,
      confidence: Math.max(llmResult.confidence, ruleResult.confidence),
      alternativeLanguages: [
        ...(llmResult.alternativeLanguages || []),
        ...(ruleResult.alternativeLanguages || [])
      ].slice(0, 3)
    };
  }

  /**
   * Analyze cultural context based on language and content
   */
  private analyzeCulturalContext(language: string, text: string): CulturalContext {
    const defaultContext: CulturalContext = {
      region: 'unknown',
      formalityLevel: 'neutral',
      communicationStyle: 'direct',
      timeOrientation: 'present',
      relationshipOrientation: 'individual'
    };
    
    // Get base cultural pattern
    const culturalKey = `${language}-${this.detectRegion(text, language)}`;
    const baseContext = this.culturalPatterns.get(culturalKey) || 
                       this.culturalPatterns.get(language) || 
                       defaultContext;
    
    // Analyze formality level from text
    const formalityLevel = this.analyzeFormalityLevel(text, language);
    
    return {
      ...baseContext,
      formalityLevel
    };
  }

  /**
   * Analyze writing style
   */
  private analyzeWritingStyle(text: string, language: string): WritingStyle {
    // Analyze sentence complexity
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const avgWordsPerSentence = sentences.reduce((sum, sentence) => 
      sum + sentence.split(/\s+/).length, 0
    ) / sentences.length;
    
    let complexity: WritingStyle['complexity'] = 'simple';
    if (avgWordsPerSentence > 20) complexity = 'complex';
    else if (avgWordsPerSentence > 12) complexity = 'moderate';
    
    // Analyze vocabulary level
    const longWords = text.split(/\s+/).filter(word => word.length > 8).length;
    const totalWords = text.split(/\s+/).length;
    const longWordRatio = longWords / totalWords;
    
    let vocabulary: WritingStyle['vocabulary'] = 'basic';
    if (longWordRatio > 0.15) vocabulary = 'specialized';
    else if (longWordRatio > 0.1) vocabulary = 'advanced';
    else if (longWordRatio > 0.05) vocabulary = 'intermediate';
    
    return {
      complexity,
      tone: this.analyzeTone(text),
      vocabulary,
      sentenceStructure: avgWordsPerSentence > 15 ? 'complex' : 'simple'
    };
  }

  /**
   * Helper methods
   */
  private detectRegion(text: string, language: string): string {
    // Simple region detection based on spelling and terminology
    if (language === 'en') {
      if (text.includes('colour') || text.includes('favour')) return 'UK';
      if (text.includes('color') || text.includes('favor')) return 'US';
    }
    
    if (language === 'es') {
      if (text.includes('vos') || text.includes('che')) return 'AR';
      if (text.includes('güey') || text.includes('órale')) return 'MX';
    }
    
    return 'unknown';
  }

  private analyzeFormalityLevel(text: string, language: string): CulturalContext['formalityLevel'] {
    const formal = ['dear sir', 'yours sincerely', 'respectfully', 'distinguished'];
    const informal = ['hey', 'hi there', 'cheers', 'thanks'];
    
    const lowerText = text.toLowerCase();
    
    const formalCount = formal.filter(phrase => lowerText.includes(phrase)).length;
    const informalCount = informal.filter(phrase => lowerText.includes(phrase)).length;
    
    if (formalCount > informalCount * 2) return 'very_formal';
    if (formalCount > informalCount) return 'formal';
    if (informalCount > formalCount * 2) return 'very_informal';
    if (informalCount > formalCount) return 'informal';
    
    return 'neutral';
  }

  private analyzeTone(text: string): WritingStyle['tone'] {
    if (text.includes('research') || text.includes('study') || text.includes('analysis')) {
      return 'academic';
    }
    if (text.includes('specification') || text.includes('implementation')) {
      return 'technical';
    }
    if (text.includes('story') || text.includes('imagine') || text.includes('creative')) {
      return 'creative';
    }
    if (text.includes('meeting') || text.includes('proposal') || text.includes('business')) {
      return 'professional';
    }
    
    return 'casual';
  }

  private needsTranslation(detectedLanguage: string, userPreferredLanguage?: string): boolean {
    if (!userPreferredLanguage) return false;
    return detectedLanguage !== userPreferredLanguage;
  }

  private suggestResponseLanguage(detectedLanguage: string, context?: any): string {
    // Suggest responding in the same language as the email
    if (context?.userPreferredLanguage && 
        this.supportedLanguages.has(detectedLanguage)) {
      return detectedLanguage;
    }
    
    // Fall back to user's preferred language or English
    return context?.userPreferredLanguage || 'en';
  }

  private getFallbackDetection(text: string): LanguageDetectionResult {
    return {
      primaryLanguage: 'en',
      confidence: 0.3,
      alternativeLanguages: [],
      translationNeeded: false,
      suggestedResponseLanguage: 'en'
    };
  }

  /**
   * Public utility methods
   */
  public getSupportedLanguages(): string[] {
    return Array.from(this.supportedLanguages.keys());
  }

  public getLanguageCapabilities(language: string): LanguageCapabilities | undefined {
    return this.supportedLanguages.get(language);
  }

  public isLanguageSupported(language: string): boolean {
    return this.supportedLanguages.has(language);
  }
}

/**
 * Language Detection Factory
 */
export class LanguageDetectorFactory {
  private static instance: AdvancedLanguageDetector;
  
  static getInstance(): AdvancedLanguageDetector {
    if (!this.instance) {
      this.instance = new AdvancedLanguageDetector();
    }
    return this.instance;
  }
}
