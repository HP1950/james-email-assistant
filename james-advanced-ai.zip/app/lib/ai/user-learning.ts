
/**
 * Advanced User Learning System for James AI
 * Adaptive learning from user behavior, feedback, and patterns
 * Evolves from reactive to proactive intelligence
 */

export interface UserBehaviorPattern {
  id: string;
  userId: string;
  category: 'email_response' | 'scheduling' | 'priorities' | 'communication_style' | 'work_patterns' | 'preferences';
  patternKey: string;
  data: any;
  confidence: number;
  occurrences: number;
  lastObserved: Date;
  trend: 'increasing' | 'stable' | 'decreasing';
  significance: 'low' | 'medium' | 'high' | 'critical';
}

export interface LearningInsight {
  id: string;
  type: 'behavioral' | 'preference' | 'efficiency' | 'satisfaction';
  description: string;
  actionable: boolean;
  confidence: number;
  impact: 'low' | 'medium' | 'high';
  recommendedActions?: string[];
  validUntil?: Date;
}

export interface ProactiveRecommendation {
  id: string;
  type: 'email_action' | 'schedule_optimization' | 'workflow_improvement' | 'template_suggestion';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  description: string;
  reasoning: string;
  confidence: number;
  potentialBenefit: string;
  implementationComplexity: 'simple' | 'moderate' | 'complex';
  userApprovalRequired: boolean;
}

export interface LearningMetrics {
  totalPatterns: number;
  activePatterns: number;
  learningVelocity: number; // patterns learned per week
  predictionAccuracy: number;
  userSatisfactionTrend: number;
  proactiveSuccessRate: number;
}

export class UserLearningSystem {
  private userId: string;
  private learningDatabase: Map<string, UserBehaviorPattern> = new Map();
  private insights: Map<string, LearningInsight> = new Map();
  private recommendations: Map<string, ProactiveRecommendation> = new Map();
  private confidenceThreshold: number = 0.6;
  private minOccurrencesForPattern: number = 3;

  constructor(userId: string) {
    this.userId = userId;
    this.loadUserLearningData();
  }

  /**
   * Main learning function - processes new user interaction
   */
  async learnFromInteraction(interaction: {
    type: 'email_action' | 'feedback' | 'preference_change' | 'workflow_completion';
    data: any;
    context: any;
    timestamp: Date;
    outcome: 'positive' | 'negative' | 'neutral';
  }): Promise<void> {
    try {
      // Extract patterns from the interaction
      const extractedPatterns = await this.extractPatterns(interaction);
      
      // Update existing patterns or create new ones
      for (const pattern of extractedPatterns) {
        await this.updatePattern(pattern);
      }
      
      // Generate insights from updated patterns
      await this.generateInsights();
      
      // Create proactive recommendations
      await this.generateProactiveRecommendations();
      
      // Update learning metrics
      await this.updateLearningMetrics();
      
      // Persist learning data
      await this.persistLearningData();
      
    } catch (error) {
      console.error('Learning system error:', error);
    }
  }

  /**
   * Get personalized recommendations for user
   */
  async getPersonalizedRecommendations(context: {
    currentEmail?: any;
    timeOfDay?: string;
    dayOfWeek?: string;
    userMood?: string;
    workload?: 'light' | 'normal' | 'heavy';
  }): Promise<ProactiveRecommendation[]> {
    const contextualRecommendations: ProactiveRecommendation[] = [];
    
    // Analyze user patterns to generate contextual recommendations
    for (const [, recommendation] of this.recommendations) {
      if (this.isRecommendationRelevant(recommendation, context)) {
        // Adjust recommendation based on current context
        const adjustedRecommendation = await this.adjustRecommendationForContext(
          recommendation, 
          context
        );
        contextualRecommendations.push(adjustedRecommendation);
      }
    }
    
    // Sort by priority and confidence
    return contextualRecommendations
      .sort((a, b) => {
        const priorityWeight = { urgent: 4, high: 3, normal: 2, low: 1 };
        const priorityDiff = priorityWeight[b.priority] - priorityWeight[a.priority];
        if (priorityDiff !== 0) return priorityDiff;
        return b.confidence - a.confidence;
      })
      .slice(0, 5); // Return top 5 recommendations
  }

  /**
   * Predict user behavior based on learned patterns
   */
  async predictUserBehavior(scenario: {
    emailType?: string;
    senderType?: string;
    timeContext?: string;
    workloadContext?: string;
  }): Promise<{
    likelyAction: string;
    confidence: number;
    alternativeActions: Array<{ action: string; probability: number }>;
    reasoning: string;
  }> {
    // Find relevant patterns for the scenario
    const relevantPatterns = this.findRelevantPatterns(scenario);
    
    if (relevantPatterns.length === 0) {
      return {
        likelyAction: 'analyze_first',
        confidence: 0.3,
        alternativeActions: [
          { action: 'respond_immediately', probability: 0.2 },
          { action: 'schedule_response', probability: 0.3 }
        ],
        reasoning: 'Insufficient historical data for this scenario type'
      };
    }
    
    // Analyze patterns to predict most likely action
    const actionProbabilities = this.calculateActionProbabilities(relevantPatterns);
    const topAction = Object.entries(actionProbabilities)
      .sort(([,a], [,b]) => b - a)[0];
    
    const alternativeActions = Object.entries(actionProbabilities)
      .filter(([action]) => action !== topAction[0])
      .map(([action, probability]) => ({ action, probability }))
      .sort((a, b) => b.probability - a.probability)
      .slice(0, 3);
    
    return {
      likelyAction: topAction[0],
      confidence: topAction[1],
      alternativeActions,
      reasoning: this.generatePredictionReasoning(relevantPatterns, topAction[0])
    };
  }

  /**
   * Generate adaptive response suggestions based on learned style
   */
  async generateAdaptiveResponse(email: {
    from: string;
    subject: string;
    body: string;
    sentiment: any;
    urgency: string;
  }): Promise<{
    suggestedResponse: string;
    confidence: number;
    style: string;
    reasoning: string;
    alternatives?: string[];
  }> {
    // Analyze user's communication patterns with this sender
    const senderPatterns = this.getUserPatternsForSender(email.from);
    
    // Get user's general communication style
    const communicationStyle = this.getUserCommunicationStyle();
    
    // Adapt response based on learned patterns
    const responseStyle = this.determineResponseStyle(
      senderPatterns, 
      communicationStyle, 
      email.sentiment, 
      email.urgency
    );
    
    // Generate response using LLM with personalized context
    const response = await this.generatePersonalizedResponse(email, responseStyle);
    
    return response;
  }

  /**
   * Extract patterns from user interactions
   */
  private async extractPatterns(interaction: any): Promise<UserBehaviorPattern[]> {
    const patterns: UserBehaviorPattern[] = [];
    
    switch (interaction.type) {
      case 'email_action':
        patterns.push(...this.extractEmailActionPatterns(interaction));
        break;
      case 'feedback':
        patterns.push(...this.extractFeedbackPatterns(interaction));
        break;
      case 'preference_change':
        patterns.push(...this.extractPreferencePatterns(interaction));
        break;
      case 'workflow_completion':
        patterns.push(...this.extractWorkflowPatterns(interaction));
        break;
    }
    
    return patterns;
  }

  private extractEmailActionPatterns(interaction: any): UserBehaviorPattern[] {
    const patterns: UserBehaviorPattern[] = [];
    
    // Response time patterns
    if (interaction.data.responseTime) {
      patterns.push({
        id: `response_time_${interaction.data.emailId}`,
        userId: this.userId,
        category: 'email_response',
        patternKey: `response_time_${interaction.data.senderType}`,
        data: {
          timeToRespond: interaction.data.responseTime,
          timeOfDay: interaction.context.timeOfDay,
          dayOfWeek: interaction.context.dayOfWeek,
          urgency: interaction.data.urgency
        },
        confidence: 0.7,
        occurrences: 1,
        lastObserved: interaction.timestamp,
        trend: 'stable',
        significance: 'medium'
      });
    }
    
    // Response style patterns
    if (interaction.data.responseStyle) {
      patterns.push({
        id: `response_style_${interaction.data.emailId}`,
        userId: this.userId,
        category: 'communication_style',
        patternKey: `style_${interaction.data.senderRelationship}`,
        data: {
          style: interaction.data.responseStyle,
          formality: interaction.data.formality,
          length: interaction.data.responseLength,
          tone: interaction.data.tone
        },
        confidence: 0.8,
        occurrences: 1,
        lastObserved: interaction.timestamp,
        trend: 'stable',
        significance: 'high'
      });
    }
    
    return patterns;
  }

  private extractFeedbackPatterns(interaction: any): UserBehaviorPattern[] {
    const patterns: UserBehaviorPattern[] = [];
    
    // Satisfaction patterns
    patterns.push({
      id: `satisfaction_${Date.now()}`,
      userId: this.userId,
      category: 'preferences',
      patternKey: `satisfaction_${interaction.data.actionType}`,
      data: {
        rating: interaction.data.rating,
        actionType: interaction.data.actionType,
        context: interaction.context,
        feedback: interaction.data.feedback
      },
      confidence: 0.9,
      occurrences: 1,
      lastObserved: interaction.timestamp,
      trend: 'stable',
      significance: 'high'
    });
    
    return patterns;
  }

  private extractPreferencePatterns(interaction: any): UserBehaviorPattern[] {
    const patterns: UserBehaviorPattern[] = [];
    
    // Preference change patterns
    patterns.push({
      id: `preference_${interaction.data.key}`,
      userId: this.userId,
      category: 'preferences',
      patternKey: interaction.data.key,
      data: {
        oldValue: interaction.data.oldValue,
        newValue: interaction.data.newValue,
        reason: interaction.data.reason
      },
      confidence: 1.0,
      occurrences: 1,
      lastObserved: interaction.timestamp,
      trend: 'stable',
      significance: 'high'
    });
    
    return patterns;
  }

  private extractWorkflowPatterns(interaction: any): UserBehaviorPattern[] {
    const patterns: UserBehaviorPattern[] = [];
    
    // Work pattern analysis
    patterns.push({
      id: `workflow_${interaction.data.workflowType}`,
      userId: this.userId,
      category: 'work_patterns',
      patternKey: `efficiency_${interaction.data.workflowType}`,
      data: {
        completionTime: interaction.data.completionTime,
        stepsCompleted: interaction.data.stepsCompleted,
        efficiency: interaction.data.efficiency,
        timeOfDay: interaction.context.timeOfDay
      },
      confidence: 0.7,
      occurrences: 1,
      lastObserved: interaction.timestamp,
      trend: 'stable',
      significance: 'medium'
    });
    
    return patterns;
  }

  /**
   * Update existing pattern or create new one
   */
  private async updatePattern(newPattern: UserBehaviorPattern): Promise<void> {
    const existingPattern = this.learningDatabase.get(newPattern.patternKey);
    
    if (existingPattern) {
      // Update existing pattern
      existingPattern.occurrences += 1;
      existingPattern.lastObserved = newPattern.lastObserved;
      
      // Update confidence based on occurrences
      existingPattern.confidence = Math.min(
        existingPattern.confidence + (0.1 / Math.sqrt(existingPattern.occurrences)),
        0.95
      );
      
      // Merge data intelligently
      existingPattern.data = this.mergePatternData(existingPattern.data, newPattern.data);
      
      // Update trend analysis
      existingPattern.trend = this.analyzeTrend(existingPattern);
      
      // Update significance
      existingPattern.significance = this.calculateSignificance(existingPattern);
      
    } else {
      // Create new pattern
      this.learningDatabase.set(newPattern.patternKey, newPattern);
    }
  }

  /**
   * Generate actionable insights from patterns
   */
  private async generateInsights(): Promise<void> {
    // Clear old insights
    this.insights.clear();
    
    // Analyze patterns for insights
    for (const [, pattern] of this.learningDatabase) {
      if (pattern.confidence >= this.confidenceThreshold && 
          pattern.occurrences >= this.minOccurrencesForPattern) {
        
        const insights = await this.extractInsightsFromPattern(pattern);
        insights.forEach(insight => {
          this.insights.set(insight.id, insight);
        });
      }
    }
  }

  private async extractInsightsFromPattern(pattern: UserBehaviorPattern): Promise<LearningInsight[]> {
    const insights: LearningInsight[] = [];
    
    switch (pattern.category) {
      case 'email_response':
        if (pattern.patternKey.includes('response_time')) {
          const avgResponseTime = pattern.data.timeToRespond;
          if (avgResponseTime < 3600) { // Less than 1 hour
            insights.push({
              id: `fast_responder_${pattern.patternKey}`,
              type: 'behavioral',
              description: `You typically respond to ${pattern.patternKey.split('_')[2]} emails within ${Math.round(avgResponseTime / 60)} minutes`,
              actionable: true,
              confidence: pattern.confidence,
              impact: 'medium',
              recommendedActions: [
                'Continue prioritizing quick responses',
                'Consider templates for common responses'
              ]
            });
          }
        }
        break;
        
      case 'communication_style':
        insights.push({
          id: `communication_style_${pattern.patternKey}`,
          type: 'preference',
          description: `Your communication style with ${pattern.patternKey.split('_')[1]} contacts is ${pattern.data.style}`,
          actionable: true,
          confidence: pattern.confidence,
          impact: 'high',
          recommendedActions: [
            'Use similar tone for future emails to this contact type',
            'Create templates matching this style'
          ]
        });
        break;
        
      case 'work_patterns':
        if (pattern.data.efficiency > 0.8) {
          insights.push({
            id: `high_efficiency_${pattern.patternKey}`,
            type: 'efficiency',
            description: `You work most efficiently on ${pattern.patternKey.split('_')[1]} tasks at ${pattern.data.timeOfDay}`,
            actionable: true,
            confidence: pattern.confidence,
            impact: 'high',
            recommendedActions: [
              'Schedule similar tasks during this time period',
              'Block calendar for focused work during peak efficiency hours'
            ]
          });
        }
        break;
    }
    
    return insights;
  }

  /**
   * Generate proactive recommendations
   */
  private async generateProactiveRecommendations(): Promise<void> {
    this.recommendations.clear();
    
    // Analyze patterns and insights to generate recommendations
    const recommendations = await this.analyzeForProactiveOpportunities();
    
    recommendations.forEach(rec => {
      this.recommendations.set(rec.id, rec);
    });
  }

  private async analyzeForProactiveOpportunities(): Promise<ProactiveRecommendation[]> {
    const recommendations: ProactiveRecommendation[] = [];
    
    // Template suggestions based on frequent responses
    const frequentResponsePatterns = Array.from(this.learningDatabase.values())
      .filter(p => p.category === 'communication_style' && p.occurrences > 5);
    
    for (const pattern of frequentResponsePatterns) {
      recommendations.push({
        id: `template_suggestion_${pattern.patternKey}`,
        type: 'template_suggestion',
        priority: 'normal',
        description: `Create a template for your common ${pattern.data.style} responses to ${pattern.patternKey.split('_')[1]} contacts`,
        reasoning: `You've used similar ${pattern.data.style} responses ${pattern.occurrences} times`,
        confidence: pattern.confidence,
        potentialBenefit: 'Save 5-10 minutes per similar email',
        implementationComplexity: 'simple',
        userApprovalRequired: false
      });
    }
    
    // Schedule optimization recommendations
    const workPatterns = Array.from(this.learningDatabase.values())
      .filter(p => p.category === 'work_patterns' && p.data.efficiency > 0.7);
    
    if (workPatterns.length > 0) {
      const bestTimePattern = workPatterns
        .sort((a, b) => b.data.efficiency - a.data.efficiency)[0];
      
      recommendations.push({
        id: 'schedule_optimization',
        type: 'schedule_optimization',
        priority: 'high',
        description: `Block your calendar for important work during ${bestTimePattern.data.timeOfDay}`,
        reasoning: `Your efficiency is ${Math.round(bestTimePattern.data.efficiency * 100)}% higher during this time`,
        confidence: bestTimePattern.confidence,
        potentialBenefit: 'Increase overall productivity by 15-25%',
        implementationComplexity: 'moderate',
        userApprovalRequired: true
      });
    }
    
    return recommendations;
  }

  /**
   * Helper methods
   */
  private mergePatternData(existingData: any, newData: any): any {
    // Intelligent data merging based on data type
    if (typeof existingData === 'number' && typeof newData === 'number') {
      return (existingData + newData) / 2; // Average for numeric data
    }
    
    if (Array.isArray(existingData) && Array.isArray(newData)) {
      return [...existingData, ...newData].slice(-10); // Keep last 10 items
    }
    
    return { ...existingData, ...newData }; // Merge objects
  }

  private analyzeTrend(pattern: UserBehaviorPattern): 'increasing' | 'stable' | 'decreasing' {
    // Simple trend analysis based on recent occurrences
    const recentActivity = pattern.occurrences > 5 ? 'increasing' : 'stable';
    return recentActivity;
  }

  private calculateSignificance(pattern: UserBehaviorPattern): 'low' | 'medium' | 'high' | 'critical' {
    if (pattern.confidence > 0.9 && pattern.occurrences > 10) return 'critical';
    if (pattern.confidence > 0.8 && pattern.occurrences > 5) return 'high';
    if (pattern.confidence > 0.6 && pattern.occurrences > 3) return 'medium';
    return 'low';
  }

  private findRelevantPatterns(scenario: any): UserBehaviorPattern[] {
    return Array.from(this.learningDatabase.values()).filter(pattern => {
      // Match patterns based on scenario context
      if (scenario.emailType && pattern.data.emailType === scenario.emailType) return true;
      if (scenario.senderType && pattern.patternKey.includes(scenario.senderType)) return true;
      if (scenario.timeContext && pattern.data.timeOfDay === scenario.timeContext) return true;
      return false;
    });
  }

  private calculateActionProbabilities(patterns: UserBehaviorPattern[]): Record<string, number> {
    const actionCounts: Record<string, number> = {};
    let totalActions = 0;
    
    patterns.forEach(pattern => {
      const action = pattern.data.action || 'default_action';
      actionCounts[action] = (actionCounts[action] || 0) + pattern.occurrences;
      totalActions += pattern.occurrences;
    });
    
    const probabilities: Record<string, number> = {};
    Object.entries(actionCounts).forEach(([action, count]) => {
      probabilities[action] = count / totalActions;
    });
    
    return probabilities;
  }

  private generatePredictionReasoning(patterns: UserBehaviorPattern[], predictedAction: string): string {
    const totalOccurrences = patterns.reduce((sum, p) => sum + p.occurrences, 0);
    const relevantPattern = patterns.find(p => p.data.action === predictedAction);
    
    if (relevantPattern) {
      const percentage = Math.round((relevantPattern.occurrences / totalOccurrences) * 100);
      return `Based on ${totalOccurrences} similar situations, you chose "${predictedAction}" ${percentage}% of the time`;
    }
    
    return 'Prediction based on general behavior patterns';
  }

  private getUserPatternsForSender(senderEmail: string): UserBehaviorPattern[] {
    return Array.from(this.learningDatabase.values())
      .filter(p => p.data.senderEmail === senderEmail || 
                   p.patternKey.includes(this.getSenderType(senderEmail)));
  }

  private getSenderType(email: string): string {
    // Simple sender type classification
    if (email.includes('boss') || email.includes('manager')) return 'boss';
    if (email.includes('client') || email.includes('customer')) return 'client';
    return 'colleague';
  }

  private getUserCommunicationStyle(): any {
    const stylePatterns = Array.from(this.learningDatabase.values())
      .filter(p => p.category === 'communication_style');
    
    if (stylePatterns.length === 0) {
      return { style: 'professional', formality: 'formal', tone: 'neutral' };
    }
    
    // Aggregate communication style preferences
    const styles = stylePatterns.map(p => p.data.style);
    const mostCommonStyle = this.getMostFrequent(styles);
    
    return {
      style: mostCommonStyle,
      formality: 'formal', // Default
      tone: 'professional'
    };
  }

  private determineResponseStyle(senderPatterns: UserBehaviorPattern[], userStyle: any, sentiment: any, urgency: string): any {
    // Adapt response style based on learned patterns and context
    let responseStyle = { ...userStyle };
    
    // Adjust for urgency
    if (urgency === 'high' || urgency === 'critical') {
      responseStyle.tone = 'urgent';
      responseStyle.length = 'concise';
    }
    
    // Adjust for sentiment
    if (sentiment.sentiment === 'negative') {
      responseStyle.tone = 'empathetic';
      responseStyle.formality = 'formal';
    }
    
    // Adjust based on sender patterns
    if (senderPatterns.length > 0) {
      const predominantPattern = senderPatterns
        .sort((a, b) => b.confidence - a.confidence)[0];
      responseStyle.style = predominantPattern.data.style;
    }
    
    return responseStyle;
  }

  private async generatePersonalizedResponse(email: any, style: any): Promise<any> {
    // This would call the LLM API with personalized context
    const prompt = this.buildPersonalizedResponsePrompt(email, style);
    
    try {
      const response = await fetch('/api/ai/generate-response', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt, 
          email, 
          style,
          userId: this.userId 
        })
      });
      
      const result = await response.json();
      
      return {
        suggestedResponse: result.response,
        confidence: result.confidence || 0.7,
        style: style.style,
        reasoning: result.reasoning || 'Generated based on learned communication patterns',
        alternatives: result.alternatives || []
      };
    } catch (error) {
      console.error('Error generating personalized response:', error);
      return {
        suggestedResponse: 'Thank you for your email. I will review this and get back to you soon.',
        confidence: 0.3,
        style: 'professional',
        reasoning: 'Fallback response due to generation error'
      };
    }
  }

  private buildPersonalizedResponsePrompt(email: any, style: any): string {
    return `
    Generate a personalized email response based on the user's learned communication style:
    
    Original Email:
    From: ${email.from}
    Subject: ${email.subject}
    Body: ${email.body}
    
    User's Communication Style:
    - Style: ${style.style}
    - Formality: ${style.formality}
    - Tone: ${style.tone}
    - Length preference: ${style.length || 'moderate'}
    
    Email Context:
    - Sentiment: ${email.sentiment?.sentiment}
    - Urgency: ${email.urgency}
    
    Please generate a response that matches the user's learned communication patterns while appropriately addressing the email content.
    `;
  }

  private getMostFrequent(array: string[]): string {
    const frequency: Record<string, number> = {};
    array.forEach(item => {
      frequency[item] = (frequency[item] || 0) + 1;
    });
    
    return Object.entries(frequency)
      .sort(([,a], [,b]) => b - a)[0]?.[0] || array[0];
  }

  private isRecommendationRelevant(recommendation: ProactiveRecommendation, context: any): boolean {
    // Simple relevance check based on context
    return true; // For now, all recommendations are considered relevant
  }

  private async adjustRecommendationForContext(
    recommendation: ProactiveRecommendation,
    context: any
  ): Promise<ProactiveRecommendation> {
    // Adjust recommendation based on current context
    return { ...recommendation }; // For now, return unchanged
  }

  private async loadUserLearningData(): Promise<void> {
    // Load user learning data from database
    // This would be implemented with actual database calls
    console.log(`Loading learning data for user ${this.userId}`);
  }

  private async persistLearningData(): Promise<void> {
    // Persist learning data to database
    // This would be implemented with actual database calls
    console.log(`Persisting learning data for user ${this.userId}`);
  }

  private async updateLearningMetrics(): Promise<void> {
    // Update learning metrics
    // This would calculate and store performance metrics
    console.log('Updating learning metrics');
  }

  /**
   * Public methods for accessing learning data
   */
  public getActivePatternsCount(): number {
    return Array.from(this.learningDatabase.values())
      .filter(p => p.confidence >= this.confidenceThreshold).length;
  }

  public getLearningInsights(): LearningInsight[] {
    return Array.from(this.insights.values());
  }

  public getLearningMetrics(): LearningMetrics {
    const patterns = Array.from(this.learningDatabase.values());
    const activePatterns = patterns.filter(p => p.confidence >= this.confidenceThreshold);
    
    return {
      totalPatterns: patterns.length,
      activePatterns: activePatterns.length,
      learningVelocity: this.calculateLearningVelocity(patterns),
      predictionAccuracy: 0.75, // Would be calculated from actual predictions
      userSatisfactionTrend: 0.8, // Would be calculated from feedback
      proactiveSuccessRate: 0.65 // Would be calculated from recommendation acceptance
    };
  }

  private calculateLearningVelocity(patterns: UserBehaviorPattern[]): number {
    // Calculate patterns learned per week
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const recentPatterns = patterns.filter(p => p.lastObserved > oneWeekAgo);
    return recentPatterns.length;
  }
}

/**
 * User Learning Factory
 */
export class UserLearningFactory {
  private static instances: Map<string, UserLearningSystem> = new Map();
  
  static getInstance(userId: string): UserLearningSystem {
    if (!this.instances.has(userId)) {
      this.instances.set(userId, new UserLearningSystem(userId));
    }
    return this.instances.get(userId)!;
  }
}
