
/**
 * Database Seeding Script
 * Creates initial data including test account
 */

import { PrismaClient } from '@prisma/client';
import bcryptjs from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seeding...');
  
  try {
    // Create test user account
    const testEmail = 'john@doe.com';
    const testPassword = 'johndoe123';
    
    // Check if test user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: testEmail }
    });

    if (!existingUser) {
      const hashedPassword = await bcryptjs.hash(testPassword, 12);
      
      const testUser = await prisma.user.create({
        data: {
          email: testEmail,
          password: hashedPassword,
          name: 'John Doe',
          fullName: 'John Doe',
          isActive: true
        }
      });

      // Create user profile
      await prisma.userProfile.create({
        data: {
          userId: testUser.id,
          timezone: 'America/New_York',
          language: 'en',
          communicationStyle: 'professional',
          responseSpeed: 'balanced',
          aiPersonality: 'professional',
          proactiveLevel: 4,
          confidenceThreshold: 0.8,
          workingHours: {
            start: "09:00",
            end: "18:00",
            timezone: "America/New_York"
          },
          workingDays: ["monday", "tuesday", "wednesday", "thursday", "friday"]
        }
      });

      // Create sample SMTP configuration
      await prisma.smtpConfig.create({
        data: {
          userId: testUser.id,
          email: testEmail,
          host: 'smtp.gmail.com',
          port: 587,
          username: testEmail,
          password: 'app_password_placeholder', // User would need to update this
          useSSL: false,
          useTLS: true,
          isDefault: true,
          isActive: false // Disabled by default until user configures
        }
      });

      console.log(`✅ Test user created: ${testEmail}`);
    } else {
      console.log(`ℹ️  Test user already exists: ${testEmail}`);
    }

    // Create default task components
    const taskComponents = [
      {
        name: 'sentiment_analysis_engine',
        category: 'sentiment_analysis',
        version: '2.0.0',
        definition: {
          description: 'Advanced sentiment analysis with emotional intelligence',
          capabilities: [
            'emotion_detection',
            'urgency_assessment', 
            'tone_analysis',
            'intent_classification',
            'cultural_context_analysis'
          ],
          parameters: {
            confidence_threshold: 0.7,
            emotion_categories: ['joy', 'sadness', 'anger', 'fear', 'surprise', 'disgust', 'trust', 'anticipation'],
            urgency_levels: ['low', 'normal', 'high', 'critical'],
            supported_languages: ['en', 'es', 'fr', 'de', 'pt', 'it']
          }
        },
        dependencies: ['language_detector'],
        isActive: true
      },
      {
        name: 'language_detection_system',
        category: 'language_detection',
        version: '2.0.0',
        definition: {
          description: 'Multi-language detection with cultural context understanding',
          capabilities: [
            'language_identification',
            'cultural_analysis',
            'formality_assessment',
            'regional_variant_detection',
            'writing_style_analysis'
          ],
          parameters: {
            supported_languages: ['en', 'es', 'fr', 'de', 'pt', 'it', 'ja', 'ko', 'zh', 'ru'],
            confidence_threshold: 0.8,
            cultural_indicators: true,
            regional_detection: true
          }
        },
        dependencies: [],
        isActive: true
      },
      {
        name: 'response_generation_engine',
        category: 'email_processing',
        version: '2.0.0',
        definition: {
          description: 'Personalized email response generation with style adaptation',
          capabilities: [
            'response_composition',
            'style_adaptation',
            'personalization',
            'template_suggestion',
            'multi_language_support'
          ],
          parameters: {
            response_styles: ['professional', 'friendly', 'formal', 'casual', 'diplomatic'],
            personalization_level: 'high',
            template_integration: true,
            multi_language: true
          }
        },
        dependencies: ['sentiment_analysis_engine', 'language_detection_system'],
        isActive: true
      },
      {
        name: 'user_learning_system',
        category: 'machine_learning',
        version: '2.0.0',
        definition: {
          description: 'Adaptive learning from user behavior and preferences',
          capabilities: [
            'pattern_recognition',
            'behavior_analysis',
            'preference_learning',
            'proactive_suggestions',
            'performance_optimization'
          ],
          parameters: {
            learning_rate: 0.1,
            pattern_threshold: 3,
            confidence_adjustment: true,
            proactive_recommendations: true
          }
        },
        dependencies: [],
        isActive: true
      },
      {
        name: 'meta_transformer_coordinator',
        category: 'agent_coordination',
        version: '2.0.0',
        definition: {
          description: 'Meta-Transformer Loop coordination and agent management',
          capabilities: [
            'agent_coordination',
            'role_rotation',
            'critique_management',
            'performance_monitoring',
            'session_optimization'
          ],
          parameters: {
            max_iterations: 5,
            confidence_threshold: 0.8,
            role_rotation_enabled: true,
            critique_integration: true,
            timeout_handling: 30000
          }
        },
        dependencies: ['sentiment_analysis_engine', 'language_detection_system', 'response_generation_engine'],
        isActive: true
      }
    ];

    for (const component of taskComponents) {
      await prisma.taskComponent.upsert({
        where: { name: component.name },
        create: component,
        update: {
          version: component.version,
          definition: component.definition,
          dependencies: component.dependencies,
          isActive: component.isActive
        }
      });
    }

    console.log(`✅ Created/updated ${taskComponents.length} task components`);

    // Create sample proactive patterns
    const proactivePatterns = [
      {
        patternType: 'email_frequency',
        patternKey: 'morning_email_peak',
        data: {
          pattern: 'High email volume between 9-11 AM',
          frequency: 'daily',
          peak_hours: ['09:00', '10:00', '11:00'],
          volume_multiplier: 2.3
        },
        confidence: 0.85,
        isActive: true,
        timesMatched: 15,
        nextOccurrence: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
        probability: 0.9
      },
      {
        patternType: 'response_time',
        patternKey: 'quick_response_pattern',
        data: {
          pattern: 'User responds to urgent emails within 30 minutes',
          avg_response_time: 1800, // 30 minutes in seconds
          urgency_types: ['high', 'critical'],
          success_rate: 0.92
        },
        confidence: 0.78,
        isActive: true,
        timesMatched: 8,
        probability: 0.85
      },
      {
        patternType: 'communication_style',
        patternKey: 'professional_tone_preference',
        data: {
          pattern: 'User prefers professional tone for business emails',
          tone_preferences: {
            business: 'professional',
            personal: 'friendly',
            urgent: 'direct'
          },
          formality_level: 'high'
        },
        confidence: 0.92,
        isActive: true,
        timesMatched: 23,
        probability: 0.95
      }
    ];

    for (const pattern of proactivePatterns) {
      await prisma.proactivePattern.upsert({
        where: {
          id: `pattern_${pattern.patternKey}`
        },
        create: {
          id: `pattern_${pattern.patternKey}`,
          ...pattern
        },
        update: pattern
      });
    }

    console.log(`✅ Created/updated ${proactivePatterns.length} proactive patterns`);

    console.log('🎉 Database seeding completed successfully!');
    console.log('\n📋 Summary:');
    console.log(`   • Test account: john@doe.com / johndoe123`);
    console.log(`   • Task components: ${taskComponents.length}`);
    console.log(`   • Proactive patterns: ${proactivePatterns.length}`);
    console.log('\n🔐 Note: Test account credentials are for testing only and should not be disclosed to users.');

  } catch (error) {
    console.error('❌ Seeding failed:', error);
    throw error;
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
