
/**
 * Email Inbox Component with AI Analysis
 */
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Mail, 
  Search, 
  Filter, 
  RefreshCw,
  Heart,
  Globe,
  Clock,
  AlertTriangle,
  Star,
  Archive,
  Trash2,
  Reply,
  Forward,
  MoreHorizontal
} from 'lucide-react';

interface Email {
  id: string;
  from: {
    name: string;
    email: string;
  };
  subject: string;
  preview: string;
  date: string;
  isRead: boolean;
  isImportant: boolean;
  sentiment?: {
    sentiment: string;
    confidence: number;
    emotions?: any;
    urgency: string;
  };
  language?: {
    primaryLanguage: string;
    confidence: number;
  };
  aiAnalysis?: {
    category: string;
    priority: string;
    tags: string[];
  };
}

export function EmailInbox() {
  const [emails, setEmails] = useState<Email[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [filterBy, setFilterBy] = useState('all');

  useEffect(() => {
    loadEmails();
  }, []);

  const loadEmails = async () => {
    setIsLoading(true);
    try {
      // Simulate loading emails with AI analysis
      const mockEmails: Email[] = [
        {
          id: '1',
          from: { name: 'Sarah Johnson', email: 'sarah.johnson@company.com' },
          subject: 'Project Update - Q4 Milestones',
          preview: 'Hi team, I wanted to share our progress on the Q4 milestones. We\'ve completed 85% of our targets...',
          date: '2 hours ago',
          isRead: false,
          isImportant: true,
          sentiment: {
            sentiment: 'positive',
            confidence: 0.87,
            emotions: { joy: 0.6, trust: 0.8 },
            urgency: 'normal'
          },
          language: {
            primaryLanguage: 'en',
            confidence: 0.95
          },
          aiAnalysis: {
            category: 'project',
            priority: 'high',
            tags: ['project-update', 'milestone', 'progress']
          }
        },
        {
          id: '2',
          from: { name: 'Mike Chen', email: 'mike.chen@client.com' },
          subject: 'URGENT: Server Issues Need Immediate Attention',
          preview: 'We are experiencing critical server issues that are affecting our production environment...',
          date: '4 hours ago',
          isRead: false,
          isImportant: true,
          sentiment: {
            sentiment: 'negative',
            confidence: 0.92,
            emotions: { fear: 0.7, anger: 0.3 },
            urgency: 'critical'
          },
          language: {
            primaryLanguage: 'en',
            confidence: 0.98
          },
          aiAnalysis: {
            category: 'support',
            priority: 'urgent',
            tags: ['urgent', 'server', 'production-issue']
          }
        },
        {
          id: '3',
          from: { name: 'Maria García', email: 'maria.garcia@partner.es' },
          subject: 'Propuesta de colaboración',
          preview: 'Estimado equipo, nos complace presentar una propuesta de colaboración estratégica...',
          date: '1 day ago',
          isRead: true,
          isImportant: false,
          sentiment: {
            sentiment: 'positive',
            confidence: 0.75,
            emotions: { anticipation: 0.6, trust: 0.4 },
            urgency: 'normal'
          },
          language: {
            primaryLanguage: 'es',
            confidence: 0.96
          },
          aiAnalysis: {
            category: 'business',
            priority: 'normal',
            tags: ['partnership', 'proposal', 'spanish']
          }
        },
        {
          id: '4',
          from: { name: 'Alex Thompson', email: 'alex@newsletter.com' },
          subject: 'Weekly AI Industry Newsletter',
          preview: 'This week in AI: New developments in natural language processing, exciting funding rounds...',
          date: '2 days ago',
          isRead: true,
          isImportant: false,
          sentiment: {
            sentiment: 'neutral',
            confidence: 0.68,
            emotions: { anticipation: 0.3, joy: 0.2 },
            urgency: 'low'
          },
          language: {
            primaryLanguage: 'en',
            confidence: 0.94
          },
          aiAnalysis: {
            category: 'newsletter',
            priority: 'low',
            tags: ['newsletter', 'ai-industry', 'weekly-digest']
          }
        }
      ];

      setEmails(mockEmails);
      setSelectedEmail(mockEmails[0]);
    } catch (error) {
      console.error('Failed to load emails:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600 bg-green-100';
      case 'negative': return 'text-red-600 bg-red-100';
      case 'neutral': return 'text-gray-600 bg-gray-100';
      case 'mixed': return 'text-purple-600 bg-purple-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'normal': return 'text-blue-600 bg-blue-100';
      case 'low': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const filteredEmails = emails.filter(email => {
    const matchesSearch = email.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         email.from.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filterBy === 'unread') return !email.isRead && matchesSearch;
    if (filterBy === 'important') return email.isImportant && matchesSearch;
    if (filterBy === 'urgent') return email.sentiment?.urgency === 'critical' && matchesSearch;
    return matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Inbox</h1>
          <p className="text-gray-600 mt-2">
            AI-enhanced email management with sentiment analysis and smart categorization
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={loadEmails} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search emails..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex gap-2">
              <Button
                variant={filterBy === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterBy('all')}
              >
                All
              </Button>
              <Button
                variant={filterBy === 'unread' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterBy('unread')}
              >
                Unread
              </Button>
              <Button
                variant={filterBy === 'important' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterBy('important')}
              >
                Important
              </Button>
              <Button
                variant={filterBy === 'urgent' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterBy('urgent')}
              >
                Urgent
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Email List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Messages ({filteredEmails.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-0">
                {filteredEmails.map((email) => (
                  <div
                    key={email.id}
                    className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
                      selectedEmail?.id === email.id ? 'bg-blue-50 border-blue-200' : ''
                    } ${!email.isRead ? 'font-semibold bg-blue-50/30' : ''}`}
                    onClick={() => setSelectedEmail(email)}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {email.from.name}
                        </p>
                        <p className="text-xs text-gray-500 truncate">
                          {email.from.email}
                        </p>
                      </div>
                      <div className="flex items-center space-x-1 ml-2">
                        {email.isImportant && (
                          <Star className="h-3 w-3 text-yellow-500 fill-current" />
                        )}
                        {email.sentiment?.urgency === 'critical' && (
                          <AlertTriangle className="h-3 w-3 text-red-500" />
                        )}
                      </div>
                    </div>
                    
                    <h3 className="text-sm font-medium text-gray-900 mb-1 truncate">
                      {email.subject}
                    </h3>
                    
                    <p className="text-xs text-gray-600 line-clamp-2 mb-2">
                      {email.preview}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-1">
                        {email.sentiment && (
                          <Badge 
                            variant="secondary" 
                            className={`text-xs ${getSentimentColor(email.sentiment.sentiment)}`}
                          >
                            <Heart className="h-2 w-2 mr-1" />
                            {email.sentiment.sentiment}
                          </Badge>
                        )}
                        {email.language && email.language.primaryLanguage !== 'en' && (
                          <Badge variant="secondary" className="text-xs">
                            <Globe className="h-2 w-2 mr-1" />
                            {email.language.primaryLanguage}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 text-gray-400 mr-1" />
                        <span className="text-xs text-gray-500">{email.date}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Email Detail */}
        <div className="lg:col-span-2">
          {selectedEmail ? (
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-xl mb-2">
                      {selectedEmail.subject}
                    </CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>From: {selectedEmail.from.name} &lt;{selectedEmail.from.email}&gt;</span>
                      <span>{selectedEmail.date}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Reply className="h-4 w-4 mr-1" />
                      Reply
                    </Button>
                    <Button variant="outline" size="sm">
                      <Forward className="h-4 w-4 mr-1" />
                      Forward
                    </Button>
                    <Button variant="outline" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                {/* AI Analysis Bar */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 p-4 bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-1">
                      <Heart className="h-4 w-4 mr-1 text-purple-600" />
                      <span className="text-sm font-medium">Sentiment</span>
                    </div>
                    <Badge 
                      className={getSentimentColor(selectedEmail.sentiment?.sentiment || 'neutral')}
                    >
                      {selectedEmail.sentiment?.sentiment} 
                      ({Math.round((selectedEmail.sentiment?.confidence || 0) * 100)}%)
                    </Badge>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-1">
                      <AlertTriangle className="h-4 w-4 mr-1 text-orange-600" />
                      <span className="text-sm font-medium">Urgency</span>
                    </div>
                    <Badge 
                      className={getUrgencyColor(selectedEmail.sentiment?.urgency || 'normal')}
                    >
                      {selectedEmail.sentiment?.urgency}
                    </Badge>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-1">
                      <Globe className="h-4 w-4 mr-1 text-blue-600" />
                      <span className="text-sm font-medium">Language</span>
                    </div>
                    <Badge variant="secondary">
                      {selectedEmail.language?.primaryLanguage} 
                      ({Math.round((selectedEmail.language?.confidence || 0) * 100)}%)
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="prose max-w-none">
                  <p className="whitespace-pre-wrap text-gray-900">
                    {selectedEmail.preview}
                  </p>
                </div>
                
                {/* AI Analysis Details */}
                {selectedEmail.aiAnalysis && (
                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <h4 className="text-sm font-medium text-gray-900 mb-3">AI Analysis</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Category:</span>
                        <Badge variant="outline">{selectedEmail.aiAnalysis.category}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Priority:</span>
                        <Badge 
                          variant="outline"
                          className={selectedEmail.aiAnalysis.priority === 'urgent' ? 'text-red-600 border-red-200' : 
                                    selectedEmail.aiAnalysis.priority === 'high' ? 'text-orange-600 border-orange-200' : 
                                    'text-blue-600 border-blue-200'}
                        >
                          {selectedEmail.aiAnalysis.priority}
                        </Badge>
                      </div>
                      <div className="flex items-start justify-between">
                        <span className="text-sm text-gray-600">Tags:</span>
                        <div className="flex flex-wrap gap-1">
                          {selectedEmail.aiAnalysis.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Action Buttons */}
                <div className="flex items-center justify-between mt-6 pt-6 border-t border-gray-200">
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Archive className="h-4 w-4 mr-1" />
                      Archive
                    </Button>
                    <Button variant="outline" size="sm">
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                  
                  <Button>
                    Generate AI Response
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="h-full flex items-center justify-center">
              <CardContent className="text-center">
                <Mail className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-900 mb-2">
                  Select an Email
                </p>
                <p className="text-gray-600">
                  Choose an email from the list to view its AI analysis and content
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
