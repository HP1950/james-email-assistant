
/**
 * Email Composer with AI Assistance
 * Real-time AI suggestions, sentiment analysis, and response generation
 */
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  Send, 
  Save, 
  Brain, 
  Zap, 
  Heart, 
  Globe,
  Lightbulb,
  AlertCircle,
  CheckCircle,
  RefreshCw,
  Wand2,
  Target,
  Clock,
  Users
} from 'lucide-react';

interface AIAnalysis {
  sentiment: {
    sentiment: string;
    confidence: number;
    tone: string;
    emotions: any;
  };
  language: {
    primaryLanguage: string;
    confidence: number;
    formalityLevel: string;
  };
  suggestions: string[];
  score: number;
  improvements: string[];
}

interface EmailDraft {
  to: string;
  cc: string;
  bcc: string;
  subject: string;
  body: string;
}

export function EmailComposer() {
  const [draft, setDraft] = useState<EmailDraft>({
    to: '',
    cc: '',
    bcc: '',
    subject: '',
    body: ''
  });
  
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [showAiSuggestions, setShowAiSuggestions] = useState(true);
  const [analysisProgress, setAnalysisProgress] = useState(0);

  // AI Analysis debounced effect
  useEffect(() => {
    const timer = setTimeout(() => {
      if (draft.subject || draft.body) {
        analyzeEmail();
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [draft.subject, draft.body]);

  const analyzeEmail = async () => {
    if (!draft.subject && !draft.body) return;
    
    setIsAnalyzing(true);
    setAnalysisProgress(0);
    
    try {
      // Simulate analysis progress
      const progressTimer = setInterval(() => {
        setAnalysisProgress(prev => Math.min(prev + 20, 90));
      }, 200);

      // Perform sentiment analysis
      const sentimentResponse = await fetch('/api/ai/sentiment-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: draft.body,
          subject: draft.subject
        })
      });

      const sentimentResult = await sentimentResponse.json();

      // Perform language detection
      const languageResponse = await fetch('/api/ai/language-detection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: `${draft.subject} ${draft.body}`
        })
      });

      const languageResult = await languageResponse.json();

      clearInterval(progressTimer);
      setAnalysisProgress(100);

      // Generate AI analysis
      const analysis: AIAnalysis = {
        sentiment: sentimentResult.result || {
          sentiment: 'neutral',
          confidence: 0.5,
          tone: 'neutral',
          emotions: {}
        },
        language: languageResult.result || {
          primaryLanguage: 'en',
          confidence: 0.7,
          formalityLevel: 'neutral'
        },
        suggestions: generateSuggestions(sentimentResult.result, languageResult.result),
        score: calculateEmailScore(sentimentResult.result, languageResult.result),
        improvements: generateImprovements(sentimentResult.result, languageResult.result)
      };

      setAiAnalysis(analysis);
    } catch (error) {
      console.error('AI analysis error:', error);
    } finally {
      setIsAnalyzing(false);
      setTimeout(() => setAnalysisProgress(0), 1000);
    }
  };

  const generateSuggestions = (sentiment: any, language: any): string[] => {
    const suggestions = [];
    
    if (sentiment?.sentiment === 'negative') {
      suggestions.push('Consider using more positive language to improve tone');
    }
    
    if (sentiment?.urgency === 'high' && !draft.subject.includes('URGENT')) {
      suggestions.push('Add urgency indicators to the subject line');
    }
    
    if (language?.formalityLevel === 'informal' && draft.to.includes('@company.com')) {
      suggestions.push('Consider using more formal language for business communication');
    }
    
    if (draft.body.length < 50) {
      suggestions.push('Add more context to improve message clarity');
    }
    
    if (!draft.body.includes('thank') && !draft.body.includes('please')) {
      suggestions.push('Add polite expressions to enhance professionalism');
    }

    return suggestions;
  };

  const calculateEmailScore = (sentiment: any, language: any): number => {
    let score = 50; // Base score
    
    if (sentiment?.confidence > 0.8) score += 20;
    if (language?.confidence > 0.9) score += 15;
    if (draft.subject.length > 5 && draft.subject.length < 60) score += 10;
    if (draft.body.length > 100) score += 10;
    if (sentiment?.sentiment === 'positive') score += 15;
    if (language?.formalityLevel === 'formal') score += 10;
    
    return Math.min(score, 100);
  };

  const generateImprovements = (sentiment: any, language: any): string[] => {
    const improvements = [];
    
    if (sentiment?.confidence < 0.7) {
      improvements.push('Clarify your message intent to improve sentiment detection');
    }
    
    if (draft.subject.length < 5) {
      improvements.push('Add a more descriptive subject line');
    }
    
    if (draft.body.length < 100) {
      improvements.push('Provide more details to enhance message completeness');
    }
    
    return improvements;
  };

  const generateAiResponse = async () => {
    if (!draft.to || !draft.subject) {
      alert('Please fill in recipient and subject fields');
      return;
    }

    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/ai/generate-response', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: {
            to: draft.to,
            subject: draft.subject,
            body: draft.body,
            sentiment: aiAnalysis?.sentiment,
            urgency: aiAnalysis?.sentiment?.urgency || 'normal'
          },
          style: {
            style: 'professional',
            formality: 'formal',
            tone: 'helpful'
          }
        })
      });

      const result = await response.json();
      
      if (result.response) {
        setDraft(prev => ({
          ...prev,
          subject: result.subject || prev.subject,
          body: result.response
        }));
      }
    } catch (error) {
      console.error('AI response generation error:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSendEmail = async () => {
    if (!draft.to || !draft.subject || !draft.body) {
      alert('Please fill in all required fields');
      return;
    }

    setIsSending(true);
    try {
      // Here you would integrate with your email sending service
      // For demo purposes, we'll simulate sending
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      alert('Email sent successfully!');
      setDraft({
        to: '',
        cc: '',
        bcc: '',
        subject: '',
        body: ''
      });
      setAiAnalysis(null);
    } catch (error) {
      console.error('Send email error:', error);
      alert('Failed to send email');
    } finally {
      setIsSending(false);
    }
  };

  const applySuggestion = (suggestion: string) => {
    // Simple implementation - in a real app, this would be more sophisticated
    if (suggestion.includes('subject line')) {
      setDraft(prev => ({
        ...prev,
        subject: `[IMPORTANT] ${prev.subject}`
      }));
    } else if (suggestion.includes('positive language')) {
      setDraft(prev => ({
        ...prev,
        body: prev.body.replace(/unfortunately/gi, 'however')
                      .replace(/problem/gi, 'challenge')
                      .replace(/can\'t/gi, 'cannot currently')
      }));
    } else if (suggestion.includes('polite expressions')) {
      setDraft(prev => ({
        ...prev,
        body: `Thank you for your message. ${prev.body}\n\nBest regards,`
      }));
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600 bg-green-100 border-green-200';
      case 'negative': return 'text-red-600 bg-red-100 border-red-200';
      case 'neutral': return 'text-gray-600 bg-gray-100 border-gray-200';
      case 'mixed': return 'text-purple-600 bg-purple-100 border-purple-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Compose Email</h1>
        <p className="text-gray-600 mt-2">
          Create emails with AI-powered sentiment analysis, language detection, and smart suggestions
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Email Composer */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Brain className="mr-2 h-5 w-5 text-blue-600" />
                  New Message
                </CardTitle>
                
                {isAnalyzing && (
                  <div className="flex items-center space-x-2">
                    <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
                    <span className="text-sm text-blue-600">AI Analyzing...</span>
                  </div>
                )}
              </div>
              
              {analysisProgress > 0 && (
                <div className="mt-2">
                  <Progress value={analysisProgress} className="w-full" />
                </div>
              )}
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Recipients */}
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">
                    To *
                  </label>
                  <Input
                    type="email"
                    placeholder="recipient@example.com"
                    value={draft.to}
                    onChange={(e) => setDraft(prev => ({ ...prev, to: e.target.value }))}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">
                      CC
                    </label>
                    <Input
                      type="email"
                      placeholder="cc@example.com"
                      value={draft.cc}
                      onChange={(e) => setDraft(prev => ({ ...prev, cc: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">
                      BCC
                    </label>
                    <Input
                      type="email"
                      placeholder="bcc@example.com"
                      value={draft.bcc}
                      onChange={(e) => setDraft(prev => ({ ...prev, bcc: e.target.value }))}
                    />
                  </div>
                </div>
              </div>

              {/* Subject */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">
                  Subject *
                </label>
                <Input
                  placeholder="Enter email subject"
                  value={draft.subject}
                  onChange={(e) => setDraft(prev => ({ ...prev, subject: e.target.value }))}
                />
              </div>

              {/* Message Body */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">
                  Message *
                </label>
                <Textarea
                  placeholder="Type your message here..."
                  value={draft.body}
                  onChange={(e) => setDraft(prev => ({ ...prev, body: e.target.value }))}
                  className="min-h-[300px]"
                />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-4 border-t">
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    onClick={generateAiResponse}
                    disabled={isAnalyzing || !draft.to || !draft.subject}
                  >
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generate AI Content
                  </Button>
                  
                  <Button variant="outline">
                    <Save className="mr-2 h-4 w-4" />
                    Save Draft
                  </Button>
                </div>

                <Button 
                  onClick={handleSendEmail}
                  disabled={isSending || !draft.to || !draft.subject || !draft.body}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isSending ? (
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="mr-2 h-4 w-4" />
                  )}
                  {isSending ? 'Sending...' : 'Send Email'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Analysis Panel */}
        <div className="lg:col-span-1">
          <div className="space-y-4">
            {/* Email Score */}
            {aiAnalysis && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Target className="mr-2 h-5 w-5 text-green-600" />
                    Email Score
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900 mb-2">
                      {aiAnalysis.score}/100
                    </div>
                    <Progress value={aiAnalysis.score} className="mb-3" />
                    <p className="text-sm text-gray-600">
                      {aiAnalysis.score >= 80 ? 'Excellent' :
                       aiAnalysis.score >= 60 ? 'Good' :
                       aiAnalysis.score >= 40 ? 'Fair' : 'Needs Improvement'}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* AI Analysis Results */}
            {aiAnalysis && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Brain className="mr-2 h-5 w-5 text-purple-600" />
                    AI Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Sentiment */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <Heart className="mr-1 h-4 w-4 text-purple-600" />
                        <span className="text-sm font-medium">Sentiment</span>
                      </div>
                      <Badge className={getSentimentColor(aiAnalysis.sentiment.sentiment)}>
                        {aiAnalysis.sentiment.sentiment}
                      </Badge>
                    </div>
                    <div className="text-xs text-gray-600">
                      Confidence: {Math.round(aiAnalysis.sentiment.confidence * 100)}%
                    </div>
                  </div>

                  {/* Language */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <Globe className="mr-1 h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium">Language</span>
                      </div>
                      <Badge variant="secondary">
                        {aiAnalysis.language.primaryLanguage}
                      </Badge>
                    </div>
                    <div className="text-xs text-gray-600">
                      Formality: {aiAnalysis.language.formalityLevel}
                    </div>
                  </div>

                  {/* Tone */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <Users className="mr-1 h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium">Tone</span>
                      </div>
                      <Badge variant="outline">
                        {aiAnalysis.sentiment.tone}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* AI Suggestions */}
            {aiAnalysis && aiAnalysis.suggestions.length > 0 && showAiSuggestions && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Lightbulb className="mr-2 h-5 w-5 text-yellow-600" />
                    AI Suggestions
                  </CardTitle>
                  <CardDescription>
                    Recommendations to improve your email
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {aiAnalysis.suggestions.map((suggestion, index) => (
                    <Alert key={index} className="border-blue-200 bg-blue-50">
                      <Zap className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-sm">
                        <div className="flex items-start justify-between">
                          <span>{suggestion}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => applySuggestion(suggestion)}
                            className="ml-2 text-blue-600 hover:text-blue-700"
                          >
                            Apply
                          </Button>
                        </div>
                      </AlertDescription>
                    </Alert>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Improvements */}
            {aiAnalysis && aiAnalysis.improvements.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <AlertCircle className="mr-2 h-5 w-5 text-orange-600" />
                    Improvements
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {aiAnalysis.improvements.map((improvement, index) => (
                    <div key={index} className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-orange-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-700">{improvement}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Clock className="mr-2 h-5 w-5 text-gray-600" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-start"
                  onClick={() => setShowAiSuggestions(!showAiSuggestions)}
                >
                  <Lightbulb className="mr-2 h-4 w-4" />
                  {showAiSuggestions ? 'Hide' : 'Show'} AI Suggestions
                </Button>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-start"
                  onClick={analyzeEmail}
                  disabled={isAnalyzing}
                >
                  <RefreshCw className={`mr-2 h-4 w-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
                  Re-analyze Email
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
