
/**
 * Dashboard Overview Component
 * Shows email statistics, AI insights, and recent activity
 */
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Mail, 
  TrendingUp, 
  Brain, 
  Clock, 
  Heart, 
  Globe, 
  Zap,
  Activity,
  CheckCircle,
  ArrowRight,
  BarChart3,
  Users
} from 'lucide-react';
import Link from 'next/link';

export function DashboardOverview() {
  const [stats, setStats] = useState({
    totalEmails: 0,
    processedToday: 0,
    avgResponseTime: '2.5 hours',
    sentimentAccuracy: 95,
    languagesDetected: 3,
    aiConfidence: 87
  });

  const [recentActivity, setRecentActivity] = useState([
    {
      id: '1',
      type: 'email_processed',
      description: 'Analyzed email from Sarah Johnson',
      sentiment: 'positive',
      confidence: 0.92,
      timestamp: '2 minutes ago'
    },
    {
      id: '2',
      type: 'response_generated',
      description: 'Generated response for project update',
      sentiment: 'professional',
      confidence: 0.87,
      timestamp: '15 minutes ago'
    },
    {
      id: '3',
      type: 'pattern_learned',
      description: 'Learned new communication pattern',
      sentiment: 'neutral',
      confidence: 0.78,
      timestamp: '1 hour ago'
    }
  ]);

  useEffect(() => {
    // Simulate loading stats
    const timer = setTimeout(() => {
      setStats({
        totalEmails: 142,
        processedToday: 23,
        avgResponseTime: '2.3 hours',
        sentimentAccuracy: 95,
        languagesDetected: 3,
        aiConfidence: 87
      });
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">
          Monitor your AI-powered email intelligence and system performance
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Emails</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalEmails}</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +12% from last week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Processed Today</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.processedToday}</div>
            <p className="text-xs text-muted-foreground">
              <CheckCircle className="inline h-3 w-3 mr-1 text-green-500" />
              All with AI analysis
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgResponseTime}</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="inline h-3 w-3 mr-1 text-green-500" />
              15min faster than average
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">AI Confidence</CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.aiConfidence}%</div>
            <Progress value={stats.aiConfidence} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* AI Performance */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Brain className="mr-2 h-5 w-5 text-blue-600" />
              AI System Performance
            </CardTitle>
            <CardDescription>
              Real-time status of your AI agents and processing engines
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <Heart className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">Sentiment Analysis</p>
                    <p className="text-sm text-gray-600">Emotional intelligence engine</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="default" className="bg-green-100 text-green-800">
                    {stats.sentimentAccuracy}% accurate
                  </Badge>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-purple-100 p-2 rounded-lg">
                    <Globe className="h-4 w-4 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium">Language Detection</p>
                    <p className="text-sm text-gray-600">Multi-language processing</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="secondary">
                    {stats.languagesDetected} languages detected
                  </Badge>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-2 rounded-lg">
                    <Users className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">Meta-Transformer Loop</p>
                    <p className="text-sm text-gray-600">Agent coordination system</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="default" className="bg-blue-100 text-blue-800">
                    5 iterations avg
                  </Badge>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-orange-100 p-2 rounded-lg">
                    <Zap className="h-4 w-4 text-orange-600" />
                  </div>
                  <div>
                    <p className="font-medium">Proactive Learning</p>
                    <p className="text-sm text-gray-600">Pattern recognition system</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="secondary">
                    23 patterns learned
                  </Badge>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t">
              <Link href="/dashboard/agents">
                <Button variant="outline" className="w-full">
                  View Detailed AI Analytics
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="mr-2 h-5 w-5 text-green-600" />
              Recent Activity
            </CardTitle>
            <CardDescription>
              Latest AI processing and learning events
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    {activity.type === 'email_processed' && (
                      <div className="bg-blue-100 p-1 rounded-full">
                        <Mail className="h-3 w-3 text-blue-600" />
                      </div>
                    )}
                    {activity.type === 'response_generated' && (
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                    )}
                    {activity.type === 'pattern_learned' && (
                      <div className="bg-purple-100 p-1 rounded-full">
                        <Brain className="h-3 w-3 text-purple-600" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {activity.description}
                    </p>
                    <div className="flex items-center mt-1">
                      <Badge 
                        variant="secondary" 
                        className="text-xs"
                      >
                        {Math.round(activity.confidence * 100)}% confidence
                      </Badge>
                      <span className="text-xs text-gray-500 ml-2">
                        {activity.timestamp}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t mt-4">
              <Button variant="ghost" size="sm" className="w-full">
                View All Activity
                <ArrowRight className="ml-2 h-3 w-3" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Zap className="mr-2 h-5 w-5 text-yellow-600" />
            Quick Actions
          </CardTitle>
          <CardDescription>
            Frequently used features and AI-powered shortcuts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/dashboard/compose">
              <Button variant="outline" className="w-full h-20 flex-col">
                <Mail className="h-6 w-6 mb-2" />
                Compose with AI
              </Button>
            </Link>
            
            <Link href="/dashboard/inbox">
              <Button variant="outline" className="w-full h-20 flex-col">
                <BarChart3 className="h-6 w-6 mb-2" />
                Analyze Emails
              </Button>
            </Link>
            
            <Button variant="outline" className="w-full h-20 flex-col">
              <Brain className="h-6 w-6 mb-2" />
              AI Insights
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
