
/**
 * Landing Page for James AI
 */

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Brain, 
  Zap, 
  Globe, 
  Heart, 
  Shield, 
  Cpu, 
  ArrowRight, 
  CheckCircle,
  MessageSquare,
  TrendingUp,
  Users,
  Lightbulb
} from 'lucide-react';
import Link from 'next/link';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <nav className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-xl">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">James AI</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link href="/auth/signin">
              <Button variant="ghost" className="text-gray-600 hover:text-gray-900">
                Sign In
              </Button>
            </Link>
            <Link href="/auth/signup">
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                Get Started
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Lightbulb className="w-4 h-4" />
            <span>Enterprise AI Email Assistant</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Meet <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">James AI</span>
            <br />
            Your Advanced Email Intelligence
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Experience the future of email management with sophisticated AI that understands emotions, 
            learns from your behavior, and evolves from reactive to proactive assistance.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Link href="/auth/signup">
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 px-8 py-6 text-lg">
                Start Free Trial
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="px-8 py-6 text-lg">
              Watch Demo
            </Button>
          </div>

          {/* Key Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">95%</div>
              <div className="text-sm text-gray-600">Accuracy Rate</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">12+</div>
              <div className="text-sm text-gray-600">Languages</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">3x</div>
              <div className="text-sm text-gray-600">Faster Responses</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">24/7</div>
              <div className="text-sm text-gray-600">AI Monitoring</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Enterprise-Grade AI Features
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Built with sophisticated AI architecture that goes far beyond simple automation
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300">
            <CardContent className="p-0">
              <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">Meta-Transformer Loop</h3>
              <p className="text-gray-600 mb-4">
                Advanced AI agents (Doer, Critic, Observer) that work together, critiquing and improving each other's decisions for superior results.
              </p>
              <div className="flex items-center text-blue-600 text-sm font-medium">
                <CheckCircle className="w-4 h-4 mr-2" />
                Enterprise AI Architecture
              </div>
            </CardContent>
          </Card>

          <Card className="p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300">
            <CardContent className="p-0">
              <div className="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Heart className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">Emotional Intelligence</h3>
              <p className="text-gray-600 mb-4">
                Real sentiment analysis that understands emotions, urgency levels, cultural context, and communication styles for truly intelligent responses.
              </p>
              <div className="flex items-center text-purple-600 text-sm font-medium">
                <CheckCircle className="w-4 h-4 mr-2" />
                Advanced Sentiment Analysis
              </div>
            </CardContent>
          </Card>

          <Card className="p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300">
            <CardContent className="p-0">
              <div className="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Globe className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">Multi-Language Mastery</h3>
              <p className="text-gray-600 mb-4">
                Sophisticated language detection with cultural context understanding, supporting 12+ languages with regional variations.
              </p>
              <div className="flex items-center text-green-600 text-sm font-medium">
                <CheckCircle className="w-4 h-4 mr-2" />
                Cultural Context Awareness
              </div>
            </CardContent>
          </Card>

          <Card className="p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300">
            <CardContent className="p-0">
              <div className="bg-orange-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">Proactive Intelligence</h3>
              <p className="text-gray-600 mb-4">
                Learns your communication patterns, predicts needs, and evolves from reactive responses to proactive assistance.
              </p>
              <div className="flex items-center text-orange-600 text-sm font-medium">
                <CheckCircle className="w-4 h-4 mr-2" />
                Adaptive Learning System
              </div>
            </CardContent>
          </Card>

          <Card className="p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300">
            <CardContent className="p-0">
              <div className="bg-indigo-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">SMTP Freedom</h3>
              <p className="text-gray-600 mb-4">
                Works with any email provider - Gmail, Outlook, custom domains. No API restrictions or rate limits to hold you back.
              </p>
              <div className="flex items-center text-indigo-600 text-sm font-medium">
                <CheckCircle className="w-4 h-4 mr-2" />
                Universal Email Support
              </div>
            </CardContent>
          </Card>

          <Card className="p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300">
            <CardContent className="p-0">
              <div className="bg-red-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Cpu className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">Real-Time Processing</h3>
              <p className="text-gray-600 mb-4">
                WebSocket-powered real-time communication with comprehensive logging, monitoring, and safety mechanisms.
              </p>
              <div className="flex items-center text-red-600 text-sm font-medium">
                <CheckCircle className="w-4 h-4 mr-2" />
                Enterprise Monitoring
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Architecture Section */}
      <section className="bg-gray-50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Sophisticated AI Architecture
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Not just another email tool - this is enterprise-grade AI that thinks, learns, and adapts
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <MessageSquare className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">Doer Agent</h3>
              <p className="text-gray-600">
                Primary execution agent that analyzes emails, generates responses, and makes intelligent decisions based on context and user patterns.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">Critic Agent</h3>
              <p className="text-gray-600">
                Quality assurance agent that evaluates, critiques, and improves the work of other agents, ensuring high-quality outputs.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-900">Observer Agent</h3>
              <p className="text-gray-600">
                Monitoring and learning agent that recognizes patterns, provides insights, and enables proactive intelligence features.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Ready to Experience Advanced AI?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Join users who have transformed their email experience with truly intelligent automation.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/auth/signup">
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 px-8 py-6 text-lg">
                Start Your Free Trial
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link href="/auth/signin">
              <Button size="lg" variant="outline" className="px-8 py-6 text-lg">
                Sign In to Continue
              </Button>
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 mt-4">
            No credit card required • Enterprise-grade security • 24/7 support
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-xl">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">James AI</span>
            </div>
            
            <div className="text-sm text-gray-400">
              © 2024 James AI. Advanced Email Intelligence Platform.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
