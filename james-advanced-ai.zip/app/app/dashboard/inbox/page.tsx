
/**
 * Inbox Page - Email Management with AI Analysis
 */

import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../api/auth/[...nextauth]/route';
import { DashboardLayout } from '@/components/dashboard/dashboard-layout';
import { EmailInbox } from '@/components/email/email-inbox';

export default async function InboxPage() {
  const session = await getServerSession(authOptions);
  
  if (!session) {
    redirect('/auth/signin');
  }

  return (
    <DashboardLayout>
      <EmailInbox />
    </DashboardLayout>
  );
}
