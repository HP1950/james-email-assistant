
/**
 * Compose Email Page with AI Assistance
 */

import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../api/auth/[...nextauth]/route';
import { DashboardLayout } from '@/components/dashboard/dashboard-layout';
import { EmailComposer } from '@/components/email/email-composer';

export default async function ComposePage() {
  const session = await getServerSession(authOptions);
  
  if (!session) {
    redirect('/auth/signin');
  }

  return (
    <DashboardLayout>
      <EmailComposer />
    </DashboardLayout>
  );
}
