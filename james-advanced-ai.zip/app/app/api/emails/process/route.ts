
/**
 * Email Processing API Route
 * Main entry point for processing emails through the AI agent system
 */
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { emailData, processingOptions } = await request.json();

    if (!emailData || !emailData.subject || !emailData.body) {
      return NextResponse.json(
        { error: 'Email data is required (subject and body)' },
        { status: 400 }
      );
    }

    // Get user
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      include: { userProfile: true }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Create or find email record
    let email = await prisma.email.findUnique({
      where: { messageId: emailData.messageId || `generated_${Date.now()}` }
    });

    if (!email) {
      email = await prisma.email.create({
        data: {
          userId: user.id,
          messageId: emailData.messageId || `generated_${Date.now()}`,
          subject: emailData.subject,
          body: emailData.body,
          fromEmail: emailData.from?.email || emailData.fromEmail || 'unknown@example.com',
          fromName: emailData.from?.name || emailData.fromName || 'Unknown Sender',
          toEmails: emailData.to ? emailData.to.map((t: any) => t.email || t) : [user.email],
          ccEmails: emailData.cc ? emailData.cc.map((c: any) => c.email || c) : [],
          bccEmails: emailData.bcc ? emailData.bcc.map((b: any) => b.email || b) : [],
          bodyHtml: emailData.bodyHtml,
          sentAt: emailData.date ? new Date(emailData.date) : new Date(),
          processingStatus: 'processing'
        }
      });
    }

    // Process email through AI agent system
    const processingResult = await processEmailThroughAgents(email, user, processingOptions);

    // Update email with processing results
    await prisma.email.update({
      where: { id: email.id },
      data: {
        processingStatus: 'processed',
        processedBy: 'meta_transformer_loop',
        confidenceScore: processingResult.overallConfidence,
        language: processingResult.language?.primaryLanguage,
        priority: processingResult.priority || 'normal',
        category: processingResult.category || 'general',
        tags: processingResult.tags || []
      }
    });

    // Store sentiment analysis if available
    if (processingResult.sentiment) {
      await prisma.emailSentiment.upsert({
        where: { emailId: email.id },
        create: {
          emailId: email.id,
          sentiment: processingResult.sentiment.sentiment,
          score: processingResult.sentiment.score,
          confidence: processingResult.sentiment.confidence,
          emotions: processingResult.sentiment.emotions || {},
          urgency: processingResult.sentiment.urgency || 'normal',
          tone: processingResult.sentiment.tone || 'neutral',
          intent: processingResult.sentiment.intent
        },
        update: {
          sentiment: processingResult.sentiment.sentiment,
          score: processingResult.sentiment.score,
          confidence: processingResult.sentiment.confidence,
          emotions: processingResult.sentiment.emotions || {},
          urgency: processingResult.sentiment.urgency || 'normal',
          tone: processingResult.sentiment.tone || 'neutral',
          intent: processingResult.sentiment.intent
        }
      });
    }

    // Store analysis results
    if (processingResult.analyses && processingResult.analyses.length > 0) {
      for (const analysis of processingResult.analyses) {
        await prisma.emailAnalysis.create({
          data: {
            emailId: email.id,
            analysisType: analysis.type,
            agentId: analysis.agentId,
            result: analysis.result || {},
            confidence: analysis.confidence || 0.5,
            processingTime: analysis.processingTime,
            critiques: analysis.critiques || null,
            observations: analysis.observations || null
          }
        });
      }
    }

    // Store suggested response if generated
    if (processingResult.suggestedResponse) {
      await prisma.emailResponse.create({
        data: {
          emailId: email.id,
          subject: processingResult.suggestedResponse.subject,
          body: processingResult.suggestedResponse.response,
          generatedBy: 'doer_agent',
          confidence: processingResult.suggestedResponse.confidence || 0.7,
          reasoning: processingResult.suggestedResponse.reasoning,
          status: 'draft',
          requiresReview: true
        }
      });
    }

    return NextResponse.json({
      success: true,
      emailId: email.id,
      processingResults: {
        sentiment: processingResult.sentiment,
        language: processingResult.language,
        priority: processingResult.priority,
        category: processingResult.category,
        suggestedResponse: processingResult.suggestedResponse,
        agentInsights: processingResult.insights,
        sessionId: processingResult.sessionId,
        overallConfidence: processingResult.overallConfidence,
        processingTime: processingResult.processingTime
      }
    });

  } catch (error) {
    console.error('Email processing error:', error);
    return NextResponse.json(
      { 
        error: 'Email processing failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

async function processEmailThroughAgents(email: any, user: any, options: any = {}) {
  const startTime = Date.now();
  const results = {
    sentiment: null as any,
    language: null as any,
    priority: 'normal',
    category: 'general',
    suggestedResponse: null as any,
    insights: [] as any[],
    analyses: [] as any[],
    sessionId: null as any,
    overallConfidence: 0.0,
    processingTime: 0,
    tags: [] as string[]
  };

  try {
    // Create agent session
    const sessionResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/ai/agent-session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'create_session',
        sessionData: {
          type: 'email_processing',
          context: {
            emailId: email.id,
            processingOptions: options
          },
          goals: ['analyze_sentiment', 'detect_language', 'assess_priority', 'generate_response']
        },
        emailId: email.id
      })
    });

    const sessionResult = sessionResponse.ok ? await sessionResponse.json() : null;
    results.sessionId = sessionResult?.session?.id;

    // Phase 1: Sentiment Analysis
    const sentimentResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/ai/sentiment-analysis`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: email.body,
        subject: email.subject
      })
    });

    if (sentimentResponse.ok) {
      const sentimentResult = await sentimentResponse.json();
      results.sentiment = sentimentResult.result;
      results.analyses.push({
        type: 'sentiment',
        agentId: 'sentiment_analyzer',
        result: sentimentResult.result,
        confidence: sentimentResult.result?.confidence || 0.5,
        processingTime: 1500
      });

      // Update priority based on sentiment
      if (results.sentiment?.urgency === 'critical' || results.sentiment?.urgency === 'high') {
        results.priority = 'high';
      }
    }

    // Phase 2: Language Detection
    const languageResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/ai/language-detection`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: `${email.subject} ${email.body}`
      })
    });

    if (languageResponse.ok) {
      const languageResult = await languageResponse.json();
      results.language = languageResult.result;
      results.analyses.push({
        type: 'language',
        agentId: 'language_detector',
        result: languageResult.result,
        confidence: languageResult.result?.confidence || 0.5,
        processingTime: 1000
      });
    }

    // Phase 3: Category Classification
    results.category = classifyEmailCategory(email, results.sentiment);

    // Phase 4: Generate Response (if requested)
    if (options.generateResponse !== false) {
      const responseResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/ai/generate-response`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: {
            from: email.fromEmail,
            subject: email.subject,
            body: email.body,
            sentiment: results.sentiment,
            urgency: results.sentiment?.urgency
          },
          style: {
            style: user.userProfile?.aiPersonality || 'professional',
            formality: 'formal',
            tone: 'neutral'
          },
          userId: user.id
        })
      });

      if (responseResponse.ok) {
        const responseResult = await responseResponse.json();
        results.suggestedResponse = responseResult;
        results.analyses.push({
          type: 'response_generation',
          agentId: 'response_generator',
          result: responseResult,
          confidence: responseResult.confidence || 0.7,
          processingTime: 2500
        });
      }
    }

    // Phase 5: Generate Insights
    results.insights = generateInsights(email, results);

    // Phase 6: Generate Tags
    results.tags = generateTags(email, results);

    // Calculate overall confidence
    const confidences = results.analyses
      .map(a => a.confidence)
      .filter(c => c > 0);
    
    results.overallConfidence = confidences.length > 0 
      ? confidences.reduce((sum, c) => sum + c, 0) / confidences.length 
      : 0.5;

    results.processingTime = Date.now() - startTime;

    return results;

  } catch (error) {
    console.error('Agent processing error:', error);
    results.processingTime = Date.now() - startTime;
    return results;
  }
}

function classifyEmailCategory(email: any, sentiment: any): string {
  const subject = email.subject.toLowerCase();
  const body = email.body.toLowerCase();
  
  // Business categories
  if (subject.includes('meeting') || subject.includes('schedule') || body.includes('calendar')) {
    return 'meeting';
  }
  
  if (subject.includes('invoice') || subject.includes('payment') || body.includes('billing')) {
    return 'financial';
  }
  
  if (subject.includes('urgent') || sentiment?.urgency === 'high' || sentiment?.urgency === 'critical') {
    return 'urgent';
  }
  
  if (subject.includes('project') || body.includes('deadline') || body.includes('task')) {
    return 'project';
  }
  
  if (sentiment?.intent === 'complaint' || sentiment?.sentiment === 'negative') {
    return 'support';
  }
  
  if (sentiment?.intent === 'inquiry' || subject.includes('question') || body.includes('?')) {
    return 'inquiry';
  }
  
  return 'general';
}

function generateInsights(email: any, results: any): string[] {
  const insights = [];
  
  if (results.sentiment?.confidence > 0.8) {
    insights.push(`High confidence sentiment analysis: ${results.sentiment.sentiment}`);
  }
  
  if (results.language?.confidence > 0.9) {
    insights.push(`Language detected with high confidence: ${results.language.primaryLanguage}`);
  }
  
  if (results.sentiment?.urgency === 'high' || results.sentiment?.urgency === 'critical') {
    insights.push('Email marked as high priority based on urgency indicators');
  }
  
  if (results.sentiment?.emotions) {
    const dominantEmotion = Object.entries(results.sentiment.emotions)
      .sort(([,a], [,b]) => (b as number) - (a as number))[0];
    
    if (dominantEmotion && dominantEmotion[1] > 0.3) {
      insights.push(`Dominant emotion detected: ${dominantEmotion[0]}`);
    }
  }
  
  if (results.suggestedResponse?.confidence > 0.8) {
    insights.push('High-quality response generated with strong confidence');
  }
  
  return insights;
}

function generateTags(email: any, results: any): string[] {
  const tags = [];
  
  // Add sentiment tags
  if (results.sentiment) {
    tags.push(results.sentiment.sentiment);
    if (results.sentiment.urgency !== 'normal') {
      tags.push(results.sentiment.urgency);
    }
  }
  
  // Add language tags
  if (results.language) {
    tags.push(results.language.primaryLanguage);
    if (results.language.formalityLevel) {
      tags.push(results.language.formalityLevel);
    }
  }
  
  // Add category tags
  tags.push(results.category);
  
  // Add content-based tags
  const subject = email.subject.toLowerCase();
  const body = email.body.toLowerCase();
  
  if (subject.includes('re:') || body.includes('reply')) {
    tags.push('reply');
  }
  
  if (subject.includes('fwd:') || body.includes('forward')) {
    tags.push('forwarded');
  }
  
  if (body.includes('attachment') || body.includes('attached')) {
    tags.push('has-attachment');
  }
  
  return [...new Set(tags)]; // Remove duplicates
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const emailId = searchParams.get('emailId');

    if (!emailId) {
      return NextResponse.json(
        { error: 'Email ID is required' },
        { status: 400 }
      );
    }

    // Get processing results for specific email
    const email = await prisma.email.findUnique({
      where: { id: emailId },
      include: {
        sentiment: true,
        aiAnalysis: true,
        responses: {
          where: { status: 'draft' },
          orderBy: { createdAt: 'desc' },
          take: 1
        }
      }
    });

    if (!email) {
      return NextResponse.json(
        { error: 'Email not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      email: {
        id: email.id,
        subject: email.subject,
        fromEmail: email.fromEmail,
        processingStatus: email.processingStatus,
        priority: email.priority,
        category: email.category,
        tags: email.tags,
        confidenceScore: email.confidenceScore
      },
      sentiment: email.sentiment,
      analyses: email.aiAnalysis,
      suggestedResponse: email.responses[0] || null
    });

  } catch (error) {
    console.error('Get processing results error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to retrieve processing results',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
