
/**
 * Agent Session Management API
 * Handles Meta-Transformer Loop sessions and agent coordination
 */
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { action, sessionData, emailId } = await request.json();

    switch (action) {
      case 'create_session':
        return await createAgentSession(session.user.email, sessionData, emailId);
      
      case 'process_email':
        return await processEmailWithAgents(session.user.email, emailId);
      
      case 'get_session_status':
        return await getSessionStatus(sessionData.sessionId);
      
      default:
        return NextResponse.json(
          { error: 'Invalid action' },
          { status: 400 }
        );
    }

  } catch (error) {
    console.error('Agent session error:', error);
    return NextResponse.json(
      { 
        error: 'Agent session operation failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

async function createAgentSession(userEmail: string, sessionData: any, emailId?: string) {
  try {
    // Get user
    const user = await prisma.user.findUnique({
      where: { email: userEmail },
      include: { userProfile: true }
    });

    if (!user) {
      throw new Error('User not found');
    }

    // Create new agent session
    const agentSession = await prisma.agentSession.create({
      data: {
        userId: user.id,
        sessionType: sessionData.type || 'email_processing',
        status: 'active',
        currentAgent: 'doer',
        loopIteration: 0,
        maxIterations: sessionData.maxIterations || 5,
        context: sessionData.context || {},
        goals: sessionData.goals || ['analyze_email', 'generate_response'],
        constraints: sessionData.constraints || {}
      }
    });

    // Log session creation
    await prisma.systemLog.create({
      data: {
        level: 'info',
        category: 'agent',
        message: 'Agent session created',
        details: {
          sessionId: agentSession.id,
          sessionType: agentSession.sessionType,
          emailId
        },
        userId: user.id,
        sessionId: agentSession.id,
        emailId
      }
    });

    return NextResponse.json({
      success: true,
      session: {
        id: agentSession.id,
        status: agentSession.status,
        currentAgent: agentSession.currentAgent,
        goals: agentSession.goals
      }
    });

  } catch (error) {
    console.error('Create session error:', error);
    throw error;
  }
}

async function processEmailWithAgents(userEmail: string, emailId: string) {
  try {
    // Get user and email
    const user = await prisma.user.findUnique({
      where: { email: userEmail },
      include: { 
        userProfile: true,
        learningData: {
          where: { category: 'email_patterns' },
          take: 10
        }
      }
    });

    const email = await prisma.email.findUnique({
      where: { id: emailId },
      include: {
        sentiment: true,
        aiAnalysis: true
      }
    });

    if (!user || !email) {
      throw new Error('User or email not found');
    }

    // Create agent session for email processing
    const agentSession = await prisma.agentSession.create({
      data: {
        userId: user.id,
        sessionType: 'email_processing',
        status: 'active',
        currentAgent: 'doer',
        context: {
          emailId: email.id,
          userPreferences: user.userProfile,
          learningPatterns: user.learningData
        },
        goals: ['analyze_sentiment', 'detect_language', 'generate_response']
      }
    });

    // Start Meta-Transformer Loop simulation
    const results = await simulateMetaTransformerLoop(agentSession.id, email, user);

    // Update session status
    await prisma.agentSession.update({
      where: { id: agentSession.id },
      data: {
        status: 'completed',
        completedAt: new Date(),
        totalActions: results.actions.length,
        successActions: results.actions.filter(a => a.status === 'completed').length
      }
    });

    return NextResponse.json({
      success: true,
      sessionId: agentSession.id,
      results: {
        sentiment: results.sentiment,
        language: results.language,
        suggestedResponse: results.response,
        agentActions: results.actions.map(a => ({
          agent: a.agentType,
          action: a.actionType,
          confidence: a.confidence,
          status: a.status
        })),
        sessionInsights: results.insights
      }
    });

  } catch (error) {
    console.error('Process email error:', error);
    throw error;
  }
}

async function simulateMetaTransformerLoop(sessionId: string, email: any, user: any) {
  const actions: any[] = [];
  const results = {
    sentiment: null as any,
    language: null as any,
    response: null as any,
    actions: [] as any[],
    insights: [] as any[]
  };

  try {
    // Phase 1: Doer Agent - Analyze Email
    const doerAction = await prisma.agentAction.create({
      data: {
        sessionId,
        emailId: email.id,
        agentType: 'doer',
        actionType: 'analyze',
        input: {
          email: {
            subject: email.subject,
            body: email.body,
            fromEmail: email.fromEmail
          }
        },
        status: 'executing'
      }
    });

    // Simulate sentiment analysis
    const sentimentResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/ai/sentiment-analysis`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: email.body,
        subject: email.subject
      })
    });

    const sentimentResult = sentimentResponse.ok ? await sentimentResponse.json() : null;
    results.sentiment = sentimentResult?.result;

    // Simulate language detection
    const languageResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/ai/language-detection`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: `${email.subject} ${email.body}`
      })
    });

    const languageResult = languageResponse.ok ? await languageResponse.json() : null;
    results.language = languageResult?.result;

    // Update doer action
    await prisma.agentAction.update({
      where: { id: doerAction.id },
      data: {
        output: {
          sentiment: results.sentiment,
          language: results.language
        },
        status: 'completed',
        confidence: 0.8,
        completedAt: new Date(),
        executionTime: 1500
      }
    });

    actions.push(doerAction);

    // Phase 2: Critic Agent - Evaluate Analysis
    const criticAction = await prisma.agentAction.create({
      data: {
        sessionId,
        emailId: email.id,
        agentType: 'critic',
        actionType: 'critique',
        input: {
          targetAction: doerAction.id,
          analysisResults: {
            sentiment: results.sentiment,
            language: results.language
          }
        },
        status: 'executing'
      }
    });

    // Simulate critique
    const critique = {
      score: 0.85,
      feedback: 'Analysis quality is good with high confidence levels',
      shouldContinue: true,
      suggestions: []
    };

    await prisma.agentAction.update({
      where: { id: criticAction.id },
      data: {
        output: critique,
        status: 'completed',
        confidence: 0.9,
        completedAt: new Date(),
        executionTime: 800
      }
    });

    // Create critique record
    await prisma.agentCritique.create({
      data: {
        sessionId,
        actionId: doerAction.id,
        criticAgent: 'critic',
        targetAgent: 'doer',
        critiqueType: 'quality',
        score: critique.score,
        feedback: critique.feedback,
        confidence: 0.9
      }
    });

    actions.push(criticAction);

    // Phase 3: Observer Agent - Generate Insights
    const observerAction = await prisma.agentAction.create({
      data: {
        sessionId,
        emailId: email.id,
        agentType: 'observer',
        actionType: 'observe',
        input: {
          sessionData: {
            actions: [doerAction.id, criticAction.id],
            results: {
              sentiment: results.sentiment,
              language: results.language
            }
          }
        },
        status: 'executing'
      }
    });

    const observations = {
      patterns: ['User receives emails primarily in English', 'Professional tone is preferred'],
      insights: ['Email processing efficiency is high', 'Sentiment analysis confidence is strong'],
      recommendations: ['Continue current analysis approach', 'Consider template suggestions']
    };

    await prisma.agentAction.update({
      where: { id: observerAction.id },
      data: {
        output: observations,
        status: 'completed',
        confidence: 0.75,
        completedAt: new Date(),
        executionTime: 1200
      }
    });

    actions.push(observerAction);
    results.insights = observations;

    // Phase 4: Generate Response (Doer Agent)
    if (critique.shouldContinue) {
      const responseAction = await prisma.agentAction.create({
        data: {
          sessionId,
          emailId: email.id,
          agentType: 'doer',
          actionType: 'compose',
          input: {
            email: {
              subject: email.subject,
              body: email.body,
              sentiment: results.sentiment,
              language: results.language
            },
            userStyle: user.userProfile || {}
          },
          status: 'executing'
        }
      });

      // Generate response
      const responseResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/ai/generate-response`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: {
            from: email.fromEmail,
            subject: email.subject,
            body: email.body,
            sentiment: results.sentiment,
            urgency: results.sentiment?.urgency
          },
          style: {
            style: 'professional',
            formality: 'formal',
            tone: 'neutral'
          },
          userId: user.id
        })
      });

      const responseResult = responseResponse.ok ? await responseResponse.json() : null;
      results.response = responseResult;

      await prisma.agentAction.update({
        where: { id: responseAction.id },
        data: {
          output: responseResult,
          status: 'completed',
          confidence: responseResult?.confidence || 0.7,
          completedAt: new Date(),
          executionTime: 2000
        }
      });

      actions.push(responseAction);
    }

    results.actions = actions;
    return results;

  } catch (error) {
    console.error('Meta-Transformer Loop error:', error);
    
    // Mark any pending actions as failed
    await prisma.agentAction.updateMany({
      where: {
        sessionId,
        status: 'executing'
      },
      data: {
        status: 'failed',
        error: error instanceof Error ? error.message : 'Unknown error',
        completedAt: new Date()
      }
    });

    results.actions = actions;
    return results;
  }
}

async function getSessionStatus(sessionId: string) {
  try {
    const session = await prisma.agentSession.findUnique({
      where: { id: sessionId },
      include: {
        actions: {
          orderBy: { startedAt: 'desc' }
        },
        messages: {
          orderBy: { createdAt: 'desc' }
        },
        critiques: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!session) {
      throw new Error('Session not found');
    }

    return NextResponse.json({
      success: true,
      session: {
        id: session.id,
        status: session.status,
        currentAgent: session.currentAgent,
        loopIteration: session.loopIteration,
        maxIterations: session.maxIterations,
        totalActions: session.totalActions,
        successActions: session.successActions,
        startedAt: session.startedAt,
        completedAt: session.completedAt,
        recentActions: session.actions.slice(0, 5),
        recentMessages: session.messages.slice(0, 5),
        recentCritiques: session.critiques.slice(0, 3)
      }
    });

  } catch (error) {
    console.error('Get session status error:', error);
    throw error;
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('sessionId');

    if (sessionId) {
      return await getSessionStatus(sessionId);
    }

    // Get user's recent agent sessions
    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      throw new Error('User not found');
    }

    const recentSessions = await prisma.agentSession.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 10,
      select: {
        id: true,
        sessionType: true,
        status: true,
        currentAgent: true,
        totalActions: true,
        successActions: true,
        startedAt: true,
        completedAt: true
      }
    });

    return NextResponse.json({
      success: true,
      sessions: recentSessions
    });

  } catch (error) {
    console.error('Get sessions error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to retrieve sessions',
        details: error.message 
      },
      { status: 500 }
    );
  }
}
