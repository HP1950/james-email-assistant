
/**
 * Sentiment Analysis API Route
 * Powered by LLM for advanced emotional intelligence
 */
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { prompt, content, subject } = await request.json();
    
    if (!content) {
      return NextResponse.json(
        { error: 'Email content is required' },
        { status: 400 }
      );
    }

    // Call LLM API for sentiment analysis
    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [
          {
            role: 'user',
            content: prompt || `
              Analyze the emotional sentiment and intent of this email:
              
              Subject: "${subject || ''}"
              Content: "${content}"
              
              Please provide a detailed sentiment analysis including:
              1. Overall sentiment (positive/negative/neutral/mixed) with score (-1 to 1)
              2. Specific emotions (joy, sadness, anger, fear, surprise, disgust, trust, anticipation) as percentages
              3. Urgency level (low/normal/high/critical)
              4. Tone (formal/informal/aggressive/polite/enthusiastic/concerned/neutral)
              5. Intent classification (request/complaint/inquiry/appreciation/etc.)
              6. Key emotional phrases
              7. Confidence level (0-1)
              
              Respond in JSON format with the following structure:
              {
                "sentiment": "positive/negative/neutral/mixed",
                "score": -1.0 to 1.0,
                "confidence": 0.0 to 1.0,
                "emotions": {
                  "joy": 0.0-1.0,
                  "sadness": 0.0-1.0,
                  "anger": 0.0-1.0,
                  "fear": 0.0-1.0,
                  "surprise": 0.0-1.0,
                  "disgust": 0.0-1.0,
                  "trust": 0.0-1.0,
                  "anticipation": 0.0-1.0
                },
                "urgency": "low/normal/high/critical",
                "tone": "formal/informal/aggressive/polite/enthusiastic/concerned/neutral",
                "intent": "specific intent",
                "keyPhrases": ["phrase1", "phrase2"],
                "emotionalTriggers": ["trigger1", "trigger2"]
              }
              
              Respond with raw JSON only.
            `
          }
        ],
        max_tokens: 2000,
        temperature: 0.3,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      throw new Error(`LLM API error: ${response.status}`);
    }

    const llmResult = await response.json();
    const sentimentData = JSON.parse(llmResult.choices[0]?.message?.content || '{}');

    // Validate and structure the response
    const result = {
      result: {
        sentiment: sentimentData.sentiment || 'neutral',
        score: sentimentData.score || 0.0,
        confidence: sentimentData.confidence || 0.7,
        emotions: sentimentData.emotions || {
          joy: 0.0,
          sadness: 0.0,
          anger: 0.0,
          fear: 0.0,
          surprise: 0.0,
          disgust: 0.0,
          trust: 0.0,
          anticipation: 0.0
        },
        urgency: sentimentData.urgency || 'normal',
        tone: sentimentData.tone || 'neutral',
        intent: sentimentData.intent || 'unknown',
        keyPhrases: sentimentData.keyPhrases || [],
        emotionalTriggers: sentimentData.emotionalTriggers || []
      },
      success: true,
      processingTime: Date.now()
    };

    return NextResponse.json(result);

  } catch (error) {
    console.error('Sentiment analysis error:', error);
    
    return NextResponse.json(
      {
        error: 'Sentiment analysis failed',
        details: error.message,
        result: {
          sentiment: 'neutral',
          score: 0.0,
          confidence: 0.3,
          emotions: {
            joy: 0.0, sadness: 0.0, anger: 0.0, fear: 0.0,
            surprise: 0.0, disgust: 0.0, trust: 0.0, anticipation: 0.0
          },
          urgency: 'normal',
          tone: 'neutral',
          intent: 'unknown',
          keyPhrases: [],
          emotionalTriggers: []
        }
      },
      { status: 500 }
    );
  }
}
