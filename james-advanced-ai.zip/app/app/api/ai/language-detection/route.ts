
/**
 * Language Detection API Route
 * Advanced multi-language detection with cultural context
 */
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { prompt, text } = await request.json();
    
    if (!text) {
      return NextResponse.json(
        { error: 'Text content is required' },
        { status: 400 }
      );
    }

    // Call LLM API for language detection
    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [
          {
            role: 'user',
            content: prompt || `
              Analyze the language and cultural context of this text:
              
              Text: "${text}"
              
              Please provide a comprehensive language analysis including:
              1. Primary language (ISO 639-1 code)
              2. Confidence level (0-1)
              3. Alternative possible languages with confidence scores
              4. Regional variant if applicable (e.g., en-US, es-MX)
              5. Formality level (very_formal/formal/neutral/informal/very_informal)
              6. Communication style (direct/indirect/high_context/low_context)
              7. Writing complexity (simple/moderate/complex/academic)
              8. Cultural indicators and context
              9. Whether translation to user's preferred language is recommended
              
              Respond in JSON format with the following structure:
              {
                "primaryLanguage": "language_code",
                "confidence": 0.0-1.0,
                "alternativeLanguages": [
                  {"language": "code", "confidence": 0.0-1.0}
                ],
                "regionalVariant": "language-REGION",
                "formalityLevel": "formal/informal/etc",
                "communicationStyle": "direct/indirect/etc",
                "complexity": "simple/moderate/complex/academic",
                "culturalIndicators": ["indicator1", "indicator2"],
                "translationRecommended": true/false,
                "suggestedResponseLanguage": "language_code"
              }
              
              Respond with raw JSON only.
            `
          }
        ],
        max_tokens: 1500,
        temperature: 0.2,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      throw new Error(`LLM API error: ${response.status}`);
    }

    const llmResult = await response.json();
    const languageData = JSON.parse(llmResult.choices[0]?.message?.content || '{}');

    // Validate and structure the response
    const result = {
      result: {
        primaryLanguage: languageData.primaryLanguage || 'en',
        confidence: languageData.confidence || 0.7,
        alternativeLanguages: languageData.alternativeLanguages || [],
        regionalVariant: languageData.regionalVariant || languageData.primaryLanguage,
        formalityLevel: languageData.formalityLevel || 'neutral',
        communicationStyle: languageData.communicationStyle || 'direct',
        complexity: languageData.complexity || 'moderate',
        culturalIndicators: languageData.culturalIndicators || [],
        translationRecommended: languageData.translationRecommended || false,
        suggestedResponseLanguage: languageData.suggestedResponseLanguage || 'en'
      },
      success: true,
      processingTime: Date.now()
    };

    return NextResponse.json(result);

  } catch (error) {
    console.error('Language detection error:', error);
    
    return NextResponse.json(
      {
        error: 'Language detection failed',
        details: error.message,
        result: {
          primaryLanguage: 'en',
          confidence: 0.3,
          alternativeLanguages: [],
          regionalVariant: 'en-US',
          formalityLevel: 'neutral',
          communicationStyle: 'direct',
          complexity: 'moderate',
          culturalIndicators: [],
          translationRecommended: false,
          suggestedResponseLanguage: 'en'
        }
      },
      { status: 500 }
    );
  }
}
