
/**
 * Generate Response API Route
 * Personalized email response generation using user learning patterns
 */
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { prompt, email, style, userId } = await request.json();
    
    if (!email || !email.subject || !email.body) {
      return NextResponse.json(
        { error: 'Email data is required (subject and body)' },
        { status: 400 }
      );
    }

    // Build personalized response prompt
    const responsePrompt = prompt || `
      Generate a personalized email response based on the user's communication style and the email context:
      
      Original Email:
      From: ${email.from || 'Unknown'}
      Subject: ${email.subject}
      Body: ${email.body}
      
      User's Communication Style:
      - Style: ${style?.style || 'professional'}
      - Formality: ${style?.formality || 'formal'}
      - Tone: ${style?.tone || 'neutral'}
      - Length preference: ${style?.length || 'moderate'}
      
      Email Context:
      - Sentiment: ${email.sentiment?.sentiment || 'neutral'}
      - Urgency: ${email.urgency || 'normal'}
      - Intent: ${email.sentiment?.intent || 'unknown'}
      
      Please generate a response that:
      1. Matches the user's learned communication patterns
      2. Appropriately addresses the email content and intent
      3. Maintains the right level of formality and tone
      4. Is contextually appropriate for the urgency level
      5. Includes a proper subject line (Re: original subject)
      
      Provide multiple response alternatives (2-3) with different approaches.
      
      Respond in JSON format:
      {
        "response": "main response text",
        "subject": "Re: subject line",
        "confidence": 0.0-1.0,
        "reasoning": "explanation of why this response was chosen",
        "alternatives": [
          {
            "response": "alternative response text",
            "approach": "description of approach",
            "confidence": 0.0-1.0
          }
        ],
        "tone_analysis": {
          "detected_tone": "tone of original email",
          "response_tone": "tone of generated response",
          "appropriateness": 0.0-1.0
        }
      }
      
      Respond with raw JSON only.
    `;

    // Call LLM API for response generation
    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [
          {
            role: 'user',
            content: responsePrompt
          }
        ],
        max_tokens: 3000,
        temperature: 0.4,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      throw new Error(`LLM API error: ${response.status}`);
    }

    const llmResult = await response.json();
    const responseData = JSON.parse(llmResult.choices[0]?.message?.content || '{}');

    // Validate and structure the response
    const result = {
      response: responseData.response || 'Thank you for your email. I will review this and get back to you shortly.',
      subject: responseData.subject || `Re: ${email.subject}`,
      confidence: responseData.confidence || 0.7,
      reasoning: responseData.reasoning || 'Generated based on communication patterns and email context',
      alternatives: responseData.alternatives || [],
      toneAnalysis: responseData.tone_analysis || {
        detected_tone: 'neutral',
        response_tone: 'professional',
        appropriateness: 0.8
      },
      success: true,
      processingTime: Date.now(),
      userId
    };

    return NextResponse.json(result);

  } catch (error) {
    console.error('Response generation error:', error);
    
    return NextResponse.json(
      {
        error: 'Response generation failed',
        details: error.message,
        response: 'Thank you for your email. I will review this and get back to you shortly.',
        subject: `Re: ${request.body?.email?.subject || 'Your Email'}`,
        confidence: 0.3,
        reasoning: 'Fallback response due to generation error',
        alternatives: [],
        success: false
      },
      { status: 500 }
    );
  }
}
