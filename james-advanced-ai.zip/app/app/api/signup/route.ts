
/**
 * User Signup API Route
 * Creates new user accounts with proper password hashing
 */
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import bcryptjs from 'bcryptjs';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const { email, password, fullName, name } = await request.json();
    
    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email format' },
        { status: 400 }
      );
    }

    // Validate password strength
    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters long' },
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 409 }
      );
    }

    // Hash password
    const hashedPassword = await bcryptjs.hash(password, 12);

    // Create user with transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          email,
          password: hashedPassword,
          name: name || fullName,
          fullName: fullName || name,
          isActive: true
        }
      });

      // Create default user profile
      const userProfile = await tx.userProfile.create({
        data: {
          userId: user.id,
          timezone: 'UTC',
          language: 'en',
          communicationStyle: 'formal',
          responseSpeed: 'balanced',
          aiPersonality: 'professional',
          proactiveLevel: 3,
          confidenceThreshold: 0.7,
          workingHours: {
            start: "09:00",
            end: "17:00",
            timezone: "UTC"
          },
          workingDays: ["monday", "tuesday", "wednesday", "thursday", "friday"]
        }
      });

      // Create initial task components for the user
      await tx.taskComponent.createMany({
        data: [
          {
            name: 'email_sentiment_analysis',
            category: 'sentiment_analysis',
            definition: {
              description: 'Analyze email sentiment and emotional content',
              capabilities: ['emotion_detection', 'urgency_assessment', 'tone_analysis']
            },
            isActive: true
          },
          {
            name: 'email_language_detection',
            category: 'language_detection',
            definition: {
              description: 'Detect language and cultural context of emails',
              capabilities: ['language_identification', 'cultural_analysis', 'formality_assessment']
            },
            isActive: true
          },
          {
            name: 'email_response_generation',
            category: 'email_processing',
            definition: {
              description: 'Generate contextual email responses',
              capabilities: ['response_composition', 'style_adaptation', 'personalization']
            },
            isActive: true
          }
        ],
        skipDuplicates: true
      });

      return { user, userProfile };
    });

    // Log user creation
    await prisma.systemLog.create({
      data: {
        level: 'info',
        category: 'auth',
        message: 'New user account created',
        details: {
          userId: result.user.id,
          email: result.user.email,
          registrationTime: new Date()
        },
        userId: result.user.id
      }
    });

    return NextResponse.json({
      success: true,
      message: 'User created successfully',
      user: {
        id: result.user.id,
        email: result.user.email,
        name: result.user.name,
        createdAt: result.user.createdAt
      }
    });

  } catch (error) {
    console.error('Signup error:', error);
    
    return NextResponse.json(
      { 
        error: 'Failed to create user account',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
