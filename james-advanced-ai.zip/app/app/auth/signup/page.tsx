
/**
 * Sign Up Page for James AI
 */

import { SignUpForm } from '@/components/auth/signup-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, Shield, Cpu, Lightbulb } from 'lucide-react';

export default function SignUpPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-3 rounded-xl">
            <Brain className="w-8 h-8 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">
          Join James AI
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Experience the future of intelligent email management
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">Create your account</CardTitle>
            <CardDescription className="text-center">
              Get started with advanced AI email assistance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <SignUpForm />
          </CardContent>
        </Card>

        {/* Value Proposition */}
        <div className="mt-8 space-y-4">
          <h3 className="text-lg font-semibold text-center text-gray-900">
            Why Choose James AI?
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-start space-x-3 p-4 bg-white/60 backdrop-blur-sm rounded-lg border border-blue-100">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Brain className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-sm text-gray-900">Meta-Transformer AI Loop</p>
                <p className="text-xs text-gray-600">Advanced AI agents that critique and improve each other's work for superior results</p>
              </div>
            </div>

            <div className="flex items-start space-x-3 p-4 bg-white/60 backdrop-blur-sm rounded-lg border border-purple-100">
              <div className="bg-purple-100 p-2 rounded-lg">
                <Lightbulb className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-medium text-sm text-gray-900">Proactive Intelligence</p>
                <p className="text-xs text-gray-600">Learns your patterns and evolves from reactive to proactive assistance</p>
              </div>
            </div>

            <div className="flex items-start space-x-3 p-4 bg-white/60 backdrop-blur-sm rounded-lg border border-green-100">
              <div className="bg-green-100 p-2 rounded-lg">
                <Shield className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-sm text-gray-900">SMTP Freedom</p>
                <p className="text-xs text-gray-600">No API restrictions - works with any email provider including Gmail, Outlook, and custom domains</p>
              </div>
            </div>

            <div className="flex items-start space-x-3 p-4 bg-white/60 backdrop-blur-sm rounded-lg border border-orange-100">
              <div className="bg-orange-100 p-2 rounded-lg">
                <Cpu className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <p className="font-medium text-sm text-gray-900">Enterprise-Grade AI</p>
                <p className="text-xs text-gray-600">Real sentiment analysis, multi-language support, and cultural context understanding</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
