
/**
 * Sign In Page for James AI
 */

import { SignInForm } from '@/components/auth/signin-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, Zap, Globe, Heart } from 'lucide-react';

export default function SignInPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-xl">
            <Brain className="w-8 h-8 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">
          Welcome to James AI
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Advanced Email Assistant with Emotional Intelligence
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">Sign in to your account</CardTitle>
            <CardDescription className="text-center">
              Access your intelligent email assistant
            </CardDescription>
          </CardHeader>
          <CardContent>
            <SignInForm />
          </CardContent>
        </Card>

        {/* Features Overview */}
        <div className="mt-8 space-y-4">
          <h3 className="text-lg font-semibold text-center text-gray-900">
            Enterprise AI Features
          </h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-3 p-3 bg-white/60 backdrop-blur-sm rounded-lg border border-blue-100">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Heart className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-sm text-gray-900">Sentiment Analysis</p>
                <p className="text-xs text-gray-600">Emotional intelligence</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-white/60 backdrop-blur-sm rounded-lg border border-purple-100">
              <div className="bg-purple-100 p-2 rounded-lg">
                <Globe className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-medium text-sm text-gray-900">Multi-Language</p>
                <p className="text-xs text-gray-600">Global support</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-white/60 backdrop-blur-sm rounded-lg border border-green-100">
              <div className="bg-green-100 p-2 rounded-lg">
                <Zap className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-sm text-gray-900">Proactive AI</p>
                <p className="text-xs text-gray-600">Learns & adapts</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-white/60 backdrop-blur-sm rounded-lg border border-orange-100">
              <div className="bg-orange-100 p-2 rounded-lg">
                <Brain className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <p className="font-medium text-sm text-gray-900">Meta-AI Loop</p>
                <p className="text-xs text-gray-600">Advanced reasoning</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
