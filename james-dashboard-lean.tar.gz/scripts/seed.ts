
import { PrismaClient, Sentiment, Priority, TaskStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Create demo admin user
  const hashedPassword = await bcrypt.hash('johndoe123', 12);
  
  const demoUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      name: 'John Doe',
      password: hashedPassword,
      role: 'ADMIN',
      timezone: 'America/New_York',
      language: 'en',
      theme: 'dark',
      voiceEnabled: true,
      notificationsEnabled: true,
      aiSummaryEnabled: true,
      voiceToTextEnabled: true,
      autoTranslateEnabled: false,
      smartPriorityEnabled: true,
      twoFactorEnabled: false,
      encryptionEnabled: true,
    },
  });

  console.log('✅ Created demo user:', demoUser.email);

  // Create sample emails with AI analysis
  const sampleEmails = [
    {
      gmailId: `demo_email_1_${Date.now()}`,
      threadId: `thread_1_${Date.now()}`,
      subject: 'Quarterly Business Review - Q4 2024 Results',
      snippet: 'Please find attached our Q4 2024 business review with key metrics and strategic initiatives...',
      body: 'Dear Team,\n\nI hope this email finds you well. Please find attached our comprehensive Q4 2024 business review document. The report includes detailed analysis of our key performance metrics, revenue growth, customer acquisition costs, and strategic initiatives for the upcoming quarter.\n\nKey highlights:\n- 35% revenue growth YoY\n- Customer satisfaction score of 4.8/5\n- Successful launch of 3 new product features\n- Expansion into 2 new markets\n\nPlease review the document and come prepared with questions for our meeting on Friday.\n\nBest regards,\nSarah Johnson\nVP of Operations',
      fromAddress: 'sarah.johnson@company.com',
      fromName: 'Sarah Johnson',
      toAddresses: ['john@doe.com'],
      isRead: false,
      isStarred: true,
      isImportant: true,
      sentiment: Sentiment.POSITIVE,
      priority: Priority.HIGH,
      confidence: 0.92,
      category: 'Business',
      tags: ['quarterly-review', 'metrics', 'strategy'],
      aiSummary: 'Q4 2024 business review with strong performance metrics: 35% revenue growth, 4.8/5 customer satisfaction, 3 new features launched, and expansion into 2 new markets. Meeting scheduled for Friday.',
      extractedTasks: ['Review Q4 business document', 'Prepare questions for Friday meeting'],
      receivedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    },
    {
      gmailId: `demo_email_2_${Date.now()}`,
      threadId: `thread_2_${Date.now()}`,
      subject: 'Urgent: Server Performance Issues - Action Required',
      snippet: 'We are experiencing critical server performance issues affecting user experience...',
      body: 'URGENT ALERT\n\nOur monitoring systems have detected critical performance degradation on our primary application servers. Current response times are 300% above normal levels, affecting user experience significantly.\n\nImmediate action required:\n1. Escalate to DevOps team\n2. Implement emergency scaling procedures\n3. Prepare customer communication\n4. Monitor system recovery\n\nPlease respond with ETA for resolution.\n\nTechnical details:\n- CPU utilization: 95%\n- Memory usage: 89%\n- Database query time: +2000ms average\n- Active user sessions: 12,000+\n\nRegards,\nMike Chen\nSenior DevOps Engineer',
      fromAddress: 'mike.chen@company.com',
      fromName: 'Mike Chen',
      toAddresses: ['john@doe.com'],
      isRead: false,
      isStarred: true,
      isImportant: true,
      sentiment: Sentiment.NEGATIVE,
      priority: Priority.URGENT,
      confidence: 0.97,
      category: 'Technical',
      tags: ['urgent', 'server-issues', 'devops', 'performance'],
      aiSummary: 'Critical server performance issues with 300% slower response times, high CPU/memory usage, and slow database queries affecting 12,000+ users. Immediate DevOps action required.',
      extractedTasks: ['Escalate to DevOps team', 'Implement emergency scaling', 'Prepare customer communication', 'Monitor system recovery'],
      receivedAt: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
    },
    {
      gmailId: `demo_email_3_${Date.now()}`,
      threadId: `thread_3_${Date.now()}`,
      subject: 'Re: Coffee Chat Next Week?',
      snippet: 'Thanks for reaching out! I would love to catch up over coffee...',
      body: 'Hi John,\n\nThanks for reaching out! I would love to catch up over coffee next week. It\'s been too long since we last connected.\n\nI\'m free Tuesday afternoon after 2 PM or Wednesday morning before 11 AM. There\'s a great new coffee shop called "The Grind" that opened downtown - have you been there yet?\n\nLooking forward to hearing about your new role and sharing some exciting updates on my end as well.\n\nBest,\nEmily',
      fromAddress: 'emily.watson@email.com',
      fromName: 'Emily Watson',
      toAddresses: ['john@doe.com'],
      isRead: true,
      isStarred: false,
      isImportant: false,
      sentiment: Sentiment.POSITIVE,
      priority: Priority.LOW,
      confidence: 0.89,
      category: 'Personal',
      tags: ['coffee-chat', 'personal', 'meeting'],
      aiSummary: 'Emily is available for coffee next week - Tuesday after 2 PM or Wednesday before 11 AM. Suggests "The Grind" coffee shop downtown.',
      extractedTasks: ['Schedule coffee meeting with Emily'],
      receivedAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
    },
    {
      gmailId: `demo_email_4_${Date.now()}`,
      threadId: `thread_4_${Date.now()}`,
      subject: 'Weekly Newsletter: AI & Technology Trends',
      snippet: 'Discover the latest breakthroughs in artificial intelligence and emerging technologies...',
      body: 'AI & Tech Weekly - Issue #47\n\nThis Week\'s Highlights:\n\n🤖 ARTIFICIAL INTELLIGENCE\n- OpenAI announces GPT-5 with multimodal capabilities\n- Google\'s Gemini Ultra shows 15% improvement in reasoning tasks\n- Meta releases open-source AI model for code generation\n\n💻 TECHNOLOGY TRENDS\n- Quantum computing breakthrough: 1000-qubit processor unveiled\n- Edge computing adoption grows 67% in enterprise sector\n- 5G rollout reaches 85% coverage in major metropolitan areas\n\n📊 INDUSTRY INSIGHTS\n- AI investment reaches $50B in Q4 2024\n- 73% of companies plan AI integration within 12 months\n- Cybersecurity spending increases 23% YoY\n\nFull articles and analysis available on our platform.\n\nStay curious,\nTech Insights Team',
      fromAddress: 'newsletter@techinsights.com',
      fromName: 'Tech Insights',
      toAddresses: ['john@doe.com'],
      isRead: false,
      isStarred: false,
      isImportant: false,
      sentiment: Sentiment.NEUTRAL,
      priority: Priority.LOW,
      confidence: 0.85,
      category: 'Newsletter',
      tags: ['newsletter', 'ai', 'technology', 'trends'],
      aiSummary: 'Weekly tech newsletter covering AI advances (GPT-5, Gemini Ultra), quantum computing breakthrough, edge computing growth, and industry investment trends.',
      extractedTasks: [],
      receivedAt: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
    },
    {
      gmailId: `demo_email_5_${Date.now()}`,
      threadId: `thread_5_${Date.now()}`,
      subject: 'Project Proposal: AI-Powered Customer Service Enhancement',
      snippet: 'I am excited to present our proposal for implementing AI-powered customer service solutions...',
      body: 'Dear John,\n\nI am excited to present our comprehensive proposal for implementing AI-powered customer service enhancement solutions for your organization.\n\nProject Overview:\nOur AI-driven customer service platform will revolutionize how your team handles customer inquiries, reducing response times by 60% while increasing satisfaction scores.\n\nKey Features:\n• Intelligent ticket routing and prioritization\n• Natural language processing for sentiment analysis\n• Automated response suggestions with 90% accuracy\n• Real-time analytics and performance dashboards\n• Seamless integration with existing CRM systems\n\nExpected Outcomes:\n- 60% reduction in average response time\n- 40% increase in customer satisfaction scores\n- 25% reduction in operational costs\n- 99.9% system uptime guarantee\n\nImplementation Timeline: 12 weeks\nInvestment: $75,000 initial setup + $2,500/month subscription\n\nI would love to schedule a call to discuss how this solution can transform your customer service operations.\n\nBest regards,\nDr. Amanda Rodriguez\nAI Solutions Architect\nInnovateTech Solutions',
      fromAddress: 'amanda.rodriguez@innovatetech.com',
      fromName: 'Dr. Amanda Rodriguez',
      toAddresses: ['john@doe.com'],
      isRead: false,
      isStarred: false,
      isImportant: true,
      sentiment: Sentiment.POSITIVE,
      priority: Priority.MEDIUM,
      confidence: 0.94,
      category: 'Business',
      tags: ['proposal', 'ai', 'customer-service', 'project'],
      aiSummary: 'AI customer service enhancement proposal promising 60% faster response times, 40% higher satisfaction, 25% cost reduction. 12-week implementation, $75K setup + $2.5K/month.',
      extractedTasks: ['Review AI customer service proposal', 'Schedule call with Amanda Rodriguez'],
      receivedAt: new Date(Date.now() - 8 * 60 * 60 * 1000), // 8 hours ago
    }
  ];

  for (const emailData of sampleEmails) {
    await prisma.email.create({
      data: {
        ...emailData,
        userId: demoUser.id,
      },
    });
  }

  console.log('✅ Created sample emails with AI analysis');

  // Create sample contacts with relationship intelligence
  const sampleContacts = [
    {
      email: 'sarah.johnson@company.com',
      name: 'Sarah Johnson',
      company: 'TechCorp Inc.',
      title: 'VP of Operations',
      phone: '+1 (555) 123-4567',
      interactionCount: 47,
      lastInteraction: new Date(Date.now() - 2 * 60 * 60 * 1000),
      responseTime: 45, // 45 minutes average
      sentiment: 0.8,
      importance: 0.9,
      linkedinUrl: 'https://linkedin.com/in/sarahjohnson',
      communicationStyle: 'Direct and data-driven',
      preferredTime: 'Morning (9-11 AM)',
      topics: ['business-strategy', 'operations', 'metrics', 'quarterly-reviews'],
    },
    {
      email: 'mike.chen@company.com',
      name: 'Mike Chen',
      company: 'TechCorp Inc.',
      title: 'Senior DevOps Engineer',
      phone: '+1 (555) 234-5678',
      interactionCount: 23,
      lastInteraction: new Date(Date.now() - 30 * 60 * 1000),
      responseTime: 15, // 15 minutes average
      sentiment: 0.6,
      importance: 0.85,
      communicationStyle: 'Technical and urgent',
      preferredTime: 'Anytime',
      topics: ['devops', 'server-issues', 'performance', 'monitoring'],
    },
    {
      email: 'emily.watson@email.com',
      name: 'Emily Watson',
      company: 'Freelance Designer',
      title: 'UX/UI Designer',
      interactionCount: 12,
      lastInteraction: new Date(Date.now() - 4 * 60 * 60 * 1000),
      responseTime: 120, // 2 hours average
      sentiment: 0.9,
      importance: 0.4,
      communicationStyle: 'Friendly and casual',
      preferredTime: 'Afternoon (2-5 PM)',
      topics: ['design', 'coffee', 'personal', 'networking'],
    },
    {
      email: 'amanda.rodriguez@innovatetech.com',
      name: 'Dr. Amanda Rodriguez',
      company: 'InnovateTech Solutions',
      title: 'AI Solutions Architect',
      phone: '+1 (555) 345-6789',
      interactionCount: 5,
      lastInteraction: new Date(Date.now() - 8 * 60 * 60 * 1000),
      responseTime: 90, // 1.5 hours average
      sentiment: 0.75,
      importance: 0.7,
      linkedinUrl: 'https://linkedin.com/in/amanda-rodriguez-ai',
      communicationStyle: 'Professional and thorough',
      preferredTime: 'Business hours',
      topics: ['ai', 'machine-learning', 'proposals', 'consulting'],
    }
  ];

  for (const contactData of sampleContacts) {
    await prisma.contact.create({
      data: {
        ...contactData,
        userId: demoUser.id,
      },
    });
  }

  console.log('✅ Created sample contacts with relationship intelligence');

  // Create sample tasks
  const sampleTasks = [
    {
      title: 'Review Q4 business document',
      description: 'Review the comprehensive Q4 2024 business review document from Sarah Johnson',
      status: TaskStatus.PENDING,
      priority: Priority.HIGH,
      dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
      isAiGenerated: true,
      aiContext: 'Generated from email: Quarterly Business Review - Q4 2024 Results',
    },
    {
      title: 'Escalate server issues to DevOps team',
      description: 'Critical server performance issues need immediate DevOps attention',
      status: TaskStatus.IN_PROGRESS,
      priority: Priority.URGENT,
      dueDate: new Date(Date.now() + 60 * 60 * 1000), // 1 hour
      isAiGenerated: true,
      aiContext: 'Generated from email: Urgent: Server Performance Issues - Action Required',
    },
    {
      title: 'Schedule coffee meeting with Emily',
      description: 'Schedule coffee chat for Tuesday after 2 PM or Wednesday before 11 AM',
      status: TaskStatus.PENDING,
      priority: Priority.LOW,
      dueDate: new Date(Date.now() + 48 * 60 * 60 * 1000), // 2 days
      isAiGenerated: true,
      aiContext: 'Generated from email: Re: Coffee Chat Next Week?',
    }
  ];

  for (const taskData of sampleTasks) {
    await prisma.task.create({
      data: {
        ...taskData,
        userId: demoUser.id,
      },
    });
  }

  console.log('✅ Created sample tasks');

  // Create sample analytics data for the past 7 days
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    date.setHours(0, 0, 0, 0);

    await prisma.userAnalytics.create({
      data: {
        userId: demoUser.id,
        date,
        emailsReceived: Math.floor(Math.random() * 20) + 10,
        emailsSent: Math.floor(Math.random() * 15) + 5,
        emailsRead: Math.floor(Math.random() * 18) + 8,
        avgResponseTime: Math.floor(Math.random() * 60) + 30,
        tasksCreated: Math.floor(Math.random() * 5) + 1,
        tasksCompleted: Math.floor(Math.random() * 4) + 1,
        workflowsRun: Math.floor(Math.random() * 3),
        timeSavedMinutes: Math.floor(Math.random() * 120) + 60,
        aiActionsUsed: Math.floor(Math.random() * 10) + 5,
        voiceCommandsUsed: Math.floor(Math.random() * 8),
      },
    });
  }

  console.log('✅ Created sample analytics data');

  // Create sample workflow
  await prisma.workflow.create({
    data: {
      userId: demoUser.id,
      name: 'High Priority Email Processor',
      description: 'Automatically process and route high priority emails',
      isActive: true,
      triggers: {
        type: 'email_received',
        conditions: {
          priority: ['HIGH', 'URGENT'],
          sentiment: ['NEGATIVE', 'VERY_NEGATIVE']
        }
      },
      actions: {
        notify: true,
        autoTag: ['urgent-review'],
        createTask: true,
        escalate: true
      },
      conditions: {
        businessHours: true,
        excludeSpam: true
      },
      totalRuns: 15,
      successRuns: 14,
      lastRun: new Date(Date.now() - 30 * 60 * 1000),
    },
  });

  console.log('✅ Created sample workflow');

  // Create some audit logs
  const auditActions = [
    { action: 'user_login', resource: 'auth', details: { ip: '192.168.1.100' } },
    { action: 'email_read', resource: 'email', resourceId: 'demo_email_1', details: {} },
    { action: 'workflow_executed', resource: 'workflow', details: { workflowName: 'High Priority Email Processor' } },
    { action: 'task_created', resource: 'task', details: { source: 'ai_extraction' } }
  ];

  for (const audit of auditActions) {
    await prisma.auditLog.create({
      data: {
        userId: demoUser.id,
        action: audit.action,
        resource: audit.resource,
        resourceId: audit.resourceId,
        details: audit.details,
        ipAddress: '192.168.1.100',
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      },
    });
  }

  console.log('✅ Created audit logs');

  console.log('🎉 Database seed completed successfully!');
  console.log('\n📧 Demo Account:');
  console.log('Email: john@doe.com');
  console.log('Password: johndoe123');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
