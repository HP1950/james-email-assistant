
import { PrismaClient } from '@prisma/client';
import { 
  JobType, 
  JobPriority, 
  DropScheduleType, 
  BatchPriority,
  SuppressionScope,
  SuppressionReason,
  SuppressionSource,
  EmailProvider,
  ProviderHealthStatus,
  WarmupStatus,
  AdvancedTriggerType,
  AutomationStepType,
  ReportType
} from '../lib/types';

const prisma = new PrismaClient();

async function seedAdvancedFeatures() {
  console.log('🌱 Seeding advanced email marketing features...');

  try {
    // Get demo user
    const demoUser = await prisma.user.findUnique({
      where: { email: 'john@doe.com' }
    });

    if (!demoUser) {
      console.error('Demo user not found. Please run the main seed first.');
      return;
    }

    // 1. Seed Job Schedulers
    console.log('📅 Creating job schedulers...');
    const jobSchedulers = await Promise.all([
      prisma.jobScheduler.create({
        data: {
          userId: demoUser.id,
          name: 'Daily Campaign Processor',
          description: 'Process and send daily newsletter campaigns',
          jobType: JobType.EMAIL_CAMPAIGN,
          cronExpression: '0 9 * * *',
          timezone: 'UTC',
          priority: JobPriority.HIGH,
          config: {
            campaignTypes: ['newsletter', 'promotional'],
            maxEmailsPerRun: 10000
          },
          maxRetries: 3,
          retryDelay: 5,
          timeout: 300,
          isActive: true,
          nextRunAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
        }
      }),
      prisma.jobScheduler.create({
        data: {
          userId: demoUser.id,
          name: 'Bounce Processing',
          description: 'Process email bounces and update suppression lists',
          jobType: JobType.BOUNCE_PROCESSING,
          cronExpression: '*/15 * * * *',
          timezone: 'UTC',
          priority: JobPriority.NORMAL,
          config: {
            batchSize: 1000,
            processSoftBounces: true,
            suppressAfterBounces: 3
          },
          maxRetries: 2,
          retryDelay: 10,
          timeout: 180,
          isActive: true,
          nextRunAt: new Date(Date.now() + 15 * 60 * 1000)
        }
      }),
      prisma.jobScheduler.create({
        data: {
          userId: demoUser.id,
          name: 'List Cleanup',
          description: 'Clean up inactive subscribers and maintain list hygiene',
          jobType: JobType.LIST_CLEANUP,
          cronExpression: '0 2 * * 0',
          timezone: 'UTC',
          priority: JobPriority.LOW,
          config: {
            inactiveDays: 180,
            removeUnengaged: true,
            minEngagementScore: 10
          },
          maxRetries: 2,
          retryDelay: 30,
          timeout: 600,
          isActive: true,
          nextRunAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
        }
      })
    ]);

    // Create some job executions for demo
    for (const job of jobSchedulers) {
      await Promise.all([
        prisma.jobExecution.create({
          data: {
            jobId: job.id,
            status: 'COMPLETED',
            startedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
            completedAt: new Date(Date.now() - 2 * 60 * 60 * 1000 + 45000),
            runtime: 45000,
            triggeredBy: 'cron',
            attempt: 1
          }
        }),
        prisma.jobExecution.create({
          data: {
            jobId: job.id,
            status: 'COMPLETED',
            startedAt: new Date(Date.now() - 26 * 60 * 60 * 1000),
            completedAt: new Date(Date.now() - 26 * 60 * 60 * 1000 + 38000),
            runtime: 38000,
            triggeredBy: 'cron',
            attempt: 1
          }
        })
      ]);
    }

    // 2. Seed Spin-Text Templates
    console.log('⚡ Creating spin-text templates...');
    const spinTextTemplates = await Promise.all([
      prisma.spinTextTemplate.create({
        data: {
          userId: demoUser.id,
          name: 'Welcome Email Subject Lines',
          description: 'Dynamic subject line variations for welcome emails',
          category: 'subject-lines',
          originalText: 'Welcome to our newsletter!',
          spinTextContent: '{Welcome|Hello|Greetings} to our {newsletter|community|platform}!',
          variationsData: [
            'Welcome to our newsletter!',
            'Welcome to our community!',
            'Welcome to our platform!',
            'Hello to our newsletter!',
            'Hello to our community!',
            'Hello to our platform!',
            'Greetings to our newsletter!',
            'Greetings to our community!',
            'Greetings to our platform!'
          ],
          maxVariations: 50,
          qualityScore: 87.5,
          usageCount: 156,
          spamScoreChecked: true,
          averageSpamScore: 2.1
        }
      }),
      prisma.spinTextTemplate.create({
        data: {
          userId: demoUser.id,
          name: 'Product Launch Announcement',
          description: 'Dynamic content for product launch emails',
          category: 'full-emails',
          originalText: 'We are excited to announce our new product launch.',
          spinTextContent: 'We are {excited|thrilled|delighted} to {announce|introduce|unveil} our {new|latest|revolutionary} product {launch|release|debut}.',
          variationsData: [
            'We are excited to announce our new product launch.',
            'We are excited to announce our latest product launch.',
            'We are excited to announce our revolutionary product launch.',
            'We are excited to introduce our new product release.',
            'We are thrilled to announce our new product launch.',
            'We are delighted to unveil our latest product debut.'
          ],
          maxVariations: 50,
          qualityScore: 92.0,
          usageCount: 89,
          spamScoreChecked: true,
          averageSpamScore: 1.8,
          aiOptimized: true,
          aiOptimizedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
        }
      }),
      prisma.spinTextTemplate.create({
        data: {
          userId: demoUser.id,
          name: 'Call-to-Action Variations',
          description: 'Dynamic CTA button text variations',
          category: 'call-to-action',
          originalText: 'Click here to learn more',
          spinTextContent: '{Click here|Learn more|Discover|Find out} {to learn more|for details|about this|now}',
          variationsData: [
            'Click here to learn more',
            'Click here for details',
            'Click here about this',
            'Click here now',
            'Learn more to learn more',
            'Learn more for details',
            'Discover about this',
            'Find out now'
          ],
          maxVariations: 25,
          qualityScore: 75.5,
          usageCount: 234,
          spamScoreChecked: true,
          averageSpamScore: 3.2
        }
      })
    ]);

    // Create variations for spin-text templates
    for (const template of spinTextTemplates) {
      const variations = template.variationsData as string[];
      for (let i = 0; i < variations.length; i++) {
        await prisma.spinTextVariation.create({
          data: {
            templateId: template.id,
            variationIndex: i,
            content: variations[i],
            usageCount: Math.floor(Math.random() * 50),
            deliveryRate: 0.92 + Math.random() * 0.06,
            openRate: 0.15 + Math.random() * 0.15,
            clickRate: 0.02 + Math.random() * 0.05,
            spamScore: Math.random() * 4
          }
        });
      }
    }

    // 3. Seed Global Suppression Lists
    console.log('🛡️ Creating suppression lists...');
    const suppressionLists = await Promise.all([
      prisma.globalSuppressionList.create({
        data: {
          userId: demoUser.id,
          name: 'Hard Bounces',
          description: 'Emails that have hard bounced',
          scope: SuppressionScope.USER,
          autoAddBounces: true,
          autoAddComplaints: false,
          autoAddUnsubscribes: false,
          appliedToAllLists: true,
          suppressionCount: 245
        }
      }),
      prisma.globalSuppressionList.create({
        data: {
          userId: demoUser.id,
          name: 'Spam Complaints',
          description: 'Emails that filed spam complaints',
          scope: SuppressionScope.USER,
          autoAddBounces: false,
          autoAddComplaints: true,
          autoAddUnsubscribes: false,
          appliedToAllLists: true,
          suppressionCount: 67
        }
      }),
      prisma.globalSuppressionList.create({
        data: {
          name: 'Global Blocklist',
          description: 'System-wide suppressed domains and emails',
          isGlobal: true,
          scope: SuppressionScope.GLOBAL,
          autoAddBounces: true,
          autoAddComplaints: true,
          autoAddUnsubscribes: false,
          appliedToAllLists: true,
          suppressionCount: 1205
        }
      })
    ]);

    // Create suppression entries
    const suppressedEmails = [
      'bounced@example.com',
      'invalid@domain.invalid',
      'complaint@test.com',
      'noreply@spam.com',
      'blocked@email.net'
    ];

    for (let i = 0; i < suppressedEmails.length; i++) {
      const email = suppressedEmails[i];
      const listIndex = i % suppressionLists.length;
      const reasons = [SuppressionReason.HARD_BOUNCE, SuppressionReason.COMPLAINT, SuppressionReason.SPAM_TRAP];
      
      await prisma.suppressionEntry.create({
        data: {
          suppressionListId: suppressionLists[listIndex].id,
          email,
          reason: reasons[i % reasons.length],
          reasonDetail: `Automatically added due to ${reasons[i % reasons.length].toLowerCase()}`,
          sourceType: SuppressionSource.BOUNCE_HANDLER,
          isProcessed: true,
          processedAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000)
        }
      });
    }

    // 4. Seed Email Service Providers
    console.log('📧 Creating email service providers...');
    const emailProviders = await Promise.all([
      prisma.emailServiceProvider.create({
        data: {
          userId: demoUser.id,
          name: 'SendGrid Primary',
          provider: EmailProvider.SENDGRID,
          apiKey: 'SG.demo_key_1234567890abcdef',
          region: 'us-east-1',
          isActive: true,
          isPrimary: true,
          priority: 1,
          dailyLimit: 100000,
          hourlyLimit: 10000,
          perMinuteLimit: 600,
          sendingDomains: ['mail.example.com', 'newsletter.example.com'],
          trackingDomain: 'track.example.com',
          enableTracking: true,
          enableBounceHandling: true,
          enableComplaintHandling: true,
          totalEmailsSent: 1250000,
          totalDelivered: 1225000,
          totalBounced: 15000,
          reputation: 98.2,
          healthStatus: ProviderHealthStatus.HEALTHY,
          lastHealthCheck: new Date()
        }
      }),
      prisma.emailServiceProvider.create({
        data: {
          userId: demoUser.id,
          name: 'Mailgun Backup',
          provider: EmailProvider.MAILGUN,
          apiKey: 'key-demo1234567890abcdef',
          region: 'us',
          isActive: true,
          isPrimary: false,
          priority: 2,
          dailyLimit: 50000,
          hourlyLimit: 5000,
          perMinuteLimit: 300,
          sendingDomains: ['backup.example.com'],
          enableTracking: true,
          enableBounceHandling: true,
          enableComplaintHandling: true,
          totalEmailsSent: 340000,
          totalDelivered: 335000,
          totalBounced: 3200,
          reputation: 97.8,
          healthStatus: ProviderHealthStatus.HEALTHY,
          lastHealthCheck: new Date(Date.now() - 2 * 60 * 60 * 1000)
        }
      })
    ]);

    // Create provider health logs
    for (const provider of emailProviders) {
      for (let i = 0; i < 5; i++) {
        await prisma.providerHealthLog.create({
          data: {
            providerId: provider.id,
            status: ProviderHealthStatus.HEALTHY,
            responseTime: 150 + Math.random() * 100,
            deliveryTest: true,
            authTest: true,
            quotaTest: true,
            deliveryRate: 0.95 + Math.random() * 0.04,
            bounceRate: Math.random() * 0.02,
            reputation: 95 + Math.random() * 4,
            checkedAt: new Date(Date.now() - i * 60 * 60 * 1000)
          }
        });
      }
    }

    // 5. Seed IP Warmup Plans
    console.log('🔥 Creating IP warmup plans...');
    const warmupPlans = await Promise.all([
      prisma.iPWarmupPlan.create({
        data: {
          userId: demoUser.id,
          providerId: emailProviders[0].id,
          name: 'New Dedicated IP Warmup',
          description: 'Warming up newly assigned dedicated IP',
          ipAddress: '192.168.1.100',
          domain: 'mail.example.com',
          startDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
          duration: 30,
          dailyVolumeIncrease: 1.5,
          maxDailyVolume: 10000,
          startingVolume: 50,
          status: WarmupStatus.ACTIVE,
          isActive: true,
          currentDay: 15,
          currentVolume: 2500,
          totalEmailsSent: 18750,
          deliveryRate: 97.8,
          bounceRate: 1.2,
          complaintRate: 0.1,
          reputationScore: 85.5
        }
      }),
      prisma.iPWarmupPlan.create({
        data: {
          userId: demoUser.id,
          providerId: emailProviders[1].id,
          name: 'Secondary IP Warmup',
          description: 'Backup IP warmup plan',
          ipAddress: '192.168.1.101',
          domain: 'backup.example.com',
          startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          duration: 21,
          dailyVolumeIncrease: 2.0,
          maxDailyVolume: 5000,
          startingVolume: 25,
          status: WarmupStatus.PLANNED,
          isActive: false,
          currentDay: 0,
          currentVolume: 0,
          totalEmailsSent: 0,
          deliveryRate: 0,
          bounceRate: 0,
          complaintRate: 0,
          reputationScore: 0
        }
      })
    ]);

    // Create daily logs for active warmup plan
    const activeWarmup = warmupPlans[0];
    for (let day = 1; day <= activeWarmup.currentDay; day++) {
      const plannedVolume = Math.floor(activeWarmup.startingVolume * Math.pow(activeWarmup.dailyVolumeIncrease, day - 1));
      const actualVolume = plannedVolume + Math.floor((Math.random() - 0.5) * plannedVolume * 0.1);
      
      await prisma.iPWarmupDailyLog.create({
        data: {
          warmupPlanId: activeWarmup.id,
          day,
          date: new Date(Date.now() - (activeWarmup.currentDay - day) * 24 * 60 * 60 * 1000),
          plannedVolume,
          actualVolume,
          emailsSent: actualVolume,
          emailsDelivered: Math.floor(actualVolume * 0.978),
          emailsBounced: Math.floor(actualVolume * 0.012),
          emailsComplained: Math.floor(actualVolume * 0.001),
          deliveryRate: 97.8,
          bounceRate: 1.2,
          complaintRate: 0.1,
          status: 'COMPLETED',
          completedAt: new Date(Date.now() - (activeWarmup.currentDay - day) * 24 * 60 * 60 * 1000 + 4 * 60 * 60 * 1000)
        }
      });
    }

    // 6. Seed Daily Drop Schedulers
    console.log('📅 Creating daily drop schedulers...');
    const dropSchedulers = await Promise.all([
      prisma.dailyDropScheduler.create({
        data: {
          userId: demoUser.id,
          name: 'Newsletter Drop Scheduler',
          description: 'Scheduled delivery for daily newsletters',
          scheduleType: DropScheduleType.DAILY,
          timeSlots: [
            { hour: 9, minute: 0, timezone: 'America/New_York', maxEmails: 5000 },
            { hour: 13, minute: 0, timezone: 'America/Chicago', maxEmails: 3000 },
            { hour: 17, minute: 0, timezone: 'America/Los_Angeles', maxEmails: 4000 }
          ],
          maxDailyEmails: 50000,
          maxHourlyEmails: 5000,
          batchSize: 100,
          batchDelay: 60,
          optimizeForTimezone: true,
          optimizeForEngagement: true,
          totalEmailsQueued: 12500,
          totalEmailsSent: 11800,
          averageDeliveryTime: 45,
          isActive: true
        }
      }),
      prisma.dailyDropScheduler.create({
        data: {
          userId: demoUser.id,
          name: 'Promotional Campaign Scheduler',
          description: 'High-volume promotional email delivery',
          scheduleType: DropScheduleType.WEEKLY,
          timeSlots: [
            { hour: 10, minute: 0, timezone: 'UTC', maxEmails: 10000 },
            { hour: 14, minute: 0, timezone: 'UTC', maxEmails: 8000 },
            { hour: 18, minute: 0, timezone: 'UTC', maxEmails: 7000 }
          ],
          maxDailyEmails: 100000,
          maxHourlyEmails: 10000,
          batchSize: 250,
          batchDelay: 30,
          optimizeForTimezone: false,
          optimizeForEngagement: true,
          totalEmailsQueued: 45000,
          totalEmailsSent: 43200,
          averageDeliveryTime: 32,
          isActive: true
        }
      })
    ]);

    // 7. Seed Advanced Automations
    console.log('🤖 Creating advanced automations...');
    const advancedAutomations = await Promise.all([
      prisma.advancedAutomation.create({
        data: {
          userId: demoUser.id,
          name: 'Advanced Welcome Series',
          description: 'Sophisticated welcome sequence with conditional branching',
          category: 'welcome',
          workflowData: {
            nodes: [
              { id: 'trigger', type: 'TRIGGER', position: { x: 100, y: 100 } },
              { id: 'welcome', type: 'EMAIL', position: { x: 100, y: 200 } },
              { id: 'wait1', type: 'WAIT', position: { x: 100, y: 300 } },
              { id: 'condition1', type: 'CONDITION', position: { x: 100, y: 400 } },
              { id: 'email2a', type: 'EMAIL', position: { x: 50, y: 500 } },
              { id: 'email2b', type: 'EMAIL', position: { x: 150, y: 500 } }
            ],
            connections: [
              { from: 'trigger', to: 'welcome' },
              { from: 'welcome', to: 'wait1' },
              { from: 'wait1', to: 'condition1' },
              { from: 'condition1', to: 'email2a' },
              { from: 'condition1', to: 'email2b' }
            ]
          },
          triggerType: AdvancedTriggerType.LIST_JOIN,
          triggerConditions: { listId: 'demo-list-1' },
          allowMultipleEntries: false,
          goalType: 'email_open',
          goalValue: 2,
          isActive: true,
          isPublished: true,
          version: 1,
          totalEntries: 1250,
          activeParticipants: 89,
          completedParticipants: 1089,
          conversionRate: 0.742
        }
      }),
      prisma.advancedAutomation.create({
        data: {
          userId: demoUser.id,
          name: 'Re-engagement Campaign',
          description: 'Win back inactive subscribers with personalized content',
          category: 'reengagement',
          workflowData: {
            nodes: [
              { id: 'trigger', type: 'TRIGGER', position: { x: 100, y: 100 } },
              { id: 'segment', type: 'CONDITION', position: { x: 100, y: 200 } },
              { id: 'email1', type: 'EMAIL', position: { x: 100, y: 300 } },
              { id: 'wait', type: 'WAIT', position: { x: 100, y: 400 } },
              { id: 'final', type: 'EMAIL', position: { x: 100, y: 500 } }
            ]
          },
          triggerType: AdvancedTriggerType.BEHAVIOR_SCORE,
          triggerConditions: { minInactiveDays: 30, maxEngagementScore: 10 },
          allowMultipleEntries: false,
          goalType: 'link_click',
          goalValue: 1,
          isActive: true,
          isPublished: true,
          version: 2,
          totalEntries: 567,
          activeParticipants: 45,
          completedParticipants: 432,
          conversionRate: 0.234
        }
      })
    ]);

    // Create automation steps
    const welcomeAutomation = advancedAutomations[0];
    const automationSteps = await Promise.all([
      prisma.automationStep.create({
        data: {
          automationId: welcomeAutomation.id,
          stepId: 'welcome-email',
          stepType: AutomationStepType.EMAIL,
          name: 'Welcome Email',
          config: { templateId: 'welcome-template', delayHours: 0 },
          totalExecutions: 1250,
          successfulExecutions: 1245,
          averageExecutionTime: 1200
        }
      }),
      prisma.automationStep.create({
        data: {
          automationId: welcomeAutomation.id,
          stepId: 'wait-3-days',
          stepType: AutomationStepType.WAIT,
          name: 'Wait 3 Days',
          config: { waitDays: 3 },
          totalExecutions: 1245,
          successfulExecutions: 1245,
          averageExecutionTime: 500
        }
      }),
      prisma.automationStep.create({
        data: {
          automationId: welcomeAutomation.id,
          stepId: 'engagement-check',
          stepType: AutomationStepType.CONDITION,
          name: 'Check Engagement',
          config: { condition: 'opened_welcome_email' },
          totalExecutions: 1245,
          successfulExecutions: 1210,
          averageExecutionTime: 800
        }
      })
    ]);

    // 8. Seed Custom Reports
    console.log('📊 Creating custom reports...');
    const customReports = await Promise.all([
      prisma.customReport.create({
        data: {
          userId: demoUser.id,
          name: 'Weekly Campaign Performance',
          description: 'Comprehensive weekly performance analytics',
          type: ReportType.CAMPAIGN_PERFORMANCE,
          dataSource: { campaigns: 'all', timeframe: 'last_7_days' },
          metrics: ['sent', 'delivered', 'opened', 'clicked', 'unsubscribed'],
          dimensions: ['campaign_type', 'send_date'],
          filters: { status: 'sent' },
          charts: [
            { type: 'line', metric: 'open_rate', title: 'Open Rate Trend' },
            { type: 'bar', metric: 'click_rate', title: 'Click Rate by Campaign' }
          ],
          layout: { columns: 2, sections: ['summary', 'trends', 'details'] },
          isScheduled: true,
          scheduleConfig: { cron: '0 8 * * 1', timezone: 'UTC' },
          recipients: ['admin@example.com'],
          emailOnCompletion: true,
          lastGenerated: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          generationTime: 3500,
          dataSize: 156789
        }
      }),
      prisma.customReport.create({
        data: {
          userId: demoUser.id,
          name: 'Deliverability Dashboard',
          description: 'Monitor email deliverability metrics and reputation',
          type: ReportType.DELIVERABILITY,
          dataSource: { providers: 'all', timeframe: 'last_30_days' },
          metrics: ['delivery_rate', 'bounce_rate', 'complaint_rate', 'reputation'],
          dimensions: ['provider', 'domain', 'ip_address'],
          filters: {},
          charts: [
            { type: 'gauge', metric: 'delivery_rate', title: 'Overall Delivery Rate' },
            { type: 'area', metric: 'reputation', title: 'Sender Reputation Trend' }
          ],
          layout: { columns: 1, sections: ['overview', 'provider_breakdown'] },
          isScheduled: false,
          recipients: [],
          emailOnCompletion: false,
          lastGenerated: new Date(Date.now() - 6 * 60 * 60 * 1000),
          generationTime: 2800,
          dataSize: 89456
        }
      })
    ]);

    // Create report executions
    for (const report of customReports) {
      await Promise.all([
        prisma.reportExecution.create({
          data: {
            reportId: report.id,
            status: 'COMPLETED',
            startedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
            completedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 + 3500),
            generationTime: 3500,
            triggeredBy: 'scheduled',
            version: 1
          }
        }),
        prisma.reportExecution.create({
          data: {
            reportId: report.id,
            status: 'COMPLETED',
            startedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
            completedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000 + 2900),
            generationTime: 2900,
            triggeredBy: 'scheduled',
            version: 1
          }
        })
      ]);
    }

    console.log('✅ Advanced features seeding completed successfully!');
    console.log(`
📊 Summary:
- Job Schedulers: ${jobSchedulers.length}
- Spin-Text Templates: ${spinTextTemplates.length}
- Suppression Lists: ${suppressionLists.length}
- Email Providers: ${emailProviders.length}
- IP Warmup Plans: ${warmupPlans.length}
- Drop Schedulers: ${dropSchedulers.length}
- Advanced Automations: ${advancedAutomations.length}
- Custom Reports: ${customReports.length}
    `);

  } catch (error) {
    console.error('❌ Error seeding advanced features:', error);
    throw error;
  }
}

// Run if called directly
if (require.main === module) {
  seedAdvancedFeatures()
    .catch((error) => {
      console.error(error);
      process.exit(1);
    })
    .finally(async () => {
      await prisma.$disconnect();
    });
}

export { seedAdvancedFeatures };
