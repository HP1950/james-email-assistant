
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function seedEmailMarketing() {
  console.log('🌱 Seeding email marketing data...');

  try {
    // Find the demo user
    const demoUser = await prisma.user.findUnique({
      where: { email: 'john@doe.com' },
    });

    if (!demoUser) {
      console.log('Demo user not found. Please run the main seed script first.');
      return;
    }

    console.log('Found demo user:', demoUser.email);

    // Create email lists
    const lists = await Promise.all([
      prisma.emailList.create({
        data: {
          userId: demoUser.id,
          name: 'Newsletter Subscribers',
          description: 'Main newsletter list for all subscribers',
          type: 'STANDARD',
          doubleOptIn: true,
          welcomeEmail: true,
          subscriberCount: 0,
          activeCount: 0,
          engagementRate: 0,
          growthRate: 12.5,
          tags: ['newsletter', 'general'],
        },
      }),
      prisma.emailList.create({
        data: {
          userId: demoUser.id,
          name: 'VIP Customers',
          description: 'High-value customers and premium subscribers',
          type: 'STANDARD',
          doubleOptIn: false,
          welcomeEmail: true,
          subscriberCount: 0,
          activeCount: 0,
          engagementRate: 0,
          growthRate: 8.3,
          tags: ['vip', 'premium'],
        },
      }),
      prisma.emailList.create({
        data: {
          userId: demoUser.id,
          name: 'Product Updates',
          description: 'Users interested in product announcements and updates',
          type: 'STANDARD',
          doubleOptIn: true,
          welcomeEmail: false,
          subscriberCount: 0,
          activeCount: 0,
          engagementRate: 0,
          growthRate: 15.2,
          tags: ['product', 'updates'],
        },
      }),
    ]);

    console.log(`✅ Created ${lists.length} email lists`);

    // Create subscribers for each list
    const subscribers = [];
    const sampleSubscribers = [
      { email: 'alice.johnson@example.com', firstName: 'Alice', lastName: 'Johnson', company: 'Tech Corp' },
      { email: 'bob.smith@example.com', firstName: 'Bob', lastName: 'Smith', company: 'Design Studio' },
      { email: 'carol.davis@example.com', firstName: 'Carol', lastName: 'Davis', company: 'Marketing Inc' },
      { email: 'david.wilson@example.com', firstName: 'David', lastName: 'Wilson', company: 'Startup LLC' },
      { email: 'eve.brown@example.com', firstName: 'Eve', lastName: 'Brown', company: 'Consulting Group' },
      { email: 'frank.jones@example.com', firstName: 'Frank', lastName: 'Jones', company: 'Enterprise Solutions' },
      { email: 'grace.miller@example.com', firstName: 'Grace', lastName: 'Miller', company: 'Creative Agency' },
      { email: 'henry.garcia@example.com', firstName: 'Henry', lastName: 'Garcia', company: 'Development Co' },
    ];

    for (const list of lists) {
      const listSubscribers = [];
      const subscriberCount = Math.floor(Math.random() * 6) + 3; // 3-8 subscribers per list
      
      for (let i = 0; i < subscriberCount; i++) {
        const subscriberData = sampleSubscribers[i % sampleSubscribers.length];
        const subscriber = await prisma.listSubscriber.create({
          data: {
            listId: list.id,
            email: `${subscriberData.email.split('@')[0]}.${list.name.toLowerCase().replace(/\s+/g, '')}@example.com`,
            firstName: subscriberData.firstName,
            lastName: subscriberData.lastName,
            company: subscriberData.company,
            status: Math.random() > 0.1 ? 'CONFIRMED' : 'PENDING', // 90% confirmed
            source: 'seed',
            confirmedAt: Math.random() > 0.1 ? new Date() : null,
            totalOpens: Math.floor(Math.random() * 50),
            totalClicks: Math.floor(Math.random() * 20),
            engagementScore: Math.random() * 100,
            gdprConsent: true,
            gdprConsentAt: new Date(),
          },
        });
        listSubscribers.push(subscriber);
        subscribers.push(subscriber);
      }

      // Update list counts
      const activeCount = listSubscribers.filter(s => s.status === 'CONFIRMED').length;
      await prisma.emailList.update({
        where: { id: list.id },
        data: {
          subscriberCount: listSubscribers.length,
          activeCount,
          engagementRate: Math.random() * 40 + 20, // 20-60%
        },
      });
    }

    console.log(`✅ Created ${subscribers.length} subscribers across all lists`);

    // Create email templates
    const templates = await Promise.all([
      prisma.emailTemplate.create({
        data: {
          userId: demoUser.id,
          name: 'Welcome Email',
          description: 'Welcome new subscribers to your mailing list',
          category: 'Welcome',
          subject: 'Welcome to our newsletter!',
          preheader: 'Thanks for joining our community',
          htmlContent: `
            <html>
              <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #333;">Welcome to our newsletter!</h1>
                <p>Hi {{firstName}},</p>
                <p>Thank you for subscribing to our newsletter. We're excited to have you on board!</p>
                <p>You'll receive updates about:</p>
                <ul>
                  <li>Product announcements</li>
                  <li>Industry insights</li>
                  <li>Exclusive offers</li>
                </ul>
                <p>Best regards,<br>The Team</p>
              </body>
            </html>
          `,
          textContent: 'Welcome to our newsletter! Thank you for subscribing.',
          isPublic: false,
          isSystem: false,
          tags: ['welcome', 'onboarding'],
          usageCount: 0,
          isMobileOptimized: true,
        },
      }),
      prisma.emailTemplate.create({
        data: {
          userId: demoUser.id,
          name: 'Monthly Newsletter',
          description: 'Monthly newsletter template with updates and insights',
          category: 'Newsletter',
          subject: 'Your monthly update from {{companyName}}',
          preheader: 'Latest news and insights from our team',
          htmlContent: `
            <html>
              <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #333;">Monthly Newsletter</h1>
                <p>Hi {{firstName}},</p>
                <p>Here's what's new this month:</p>
                <h2>Latest Updates</h2>
                <p>{{content}}</p>
                <h2>Featured Article</h2>
                <p>{{featuredArticle}}</p>
                <p>Thanks for reading!</p>
              </body>
            </html>
          `,
          textContent: 'Monthly Newsletter - {{content}}',
          isPublic: false,
          isSystem: false,
          tags: ['newsletter', 'monthly'],
          usageCount: 5,
          isMobileOptimized: true,
        },
      }),
      prisma.emailTemplate.create({
        data: {
          userId: demoUser.id,
          name: 'Product Announcement',
          description: 'Announce new products or features to your audience',
          category: 'Announcement',
          subject: 'Introducing {{productName}} - You\'ll love this!',
          preheader: 'Check out our latest product',
          htmlContent: `
            <html>
              <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #333;">Exciting News!</h1>
                <p>Hi {{firstName}},</p>
                <p>We're thrilled to announce {{productName}}!</p>
                <p>{{productDescription}}</p>
                <div style="text-align: center; margin: 30px 0;">
                  <a href="{{productUrl}}" style="background: #007cba; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px;">Learn More</a>
                </div>
                <p>Best regards,<br>The Team</p>
              </body>
            </html>
          `,
          textContent: 'Introducing {{productName}} - {{productDescription}}',
          isPublic: false,
          isSystem: false,
          tags: ['product', 'announcement'],
          usageCount: 2,
          isMobileOptimized: true,
        },
      }),
    ]);

    console.log(`✅ Created ${templates.length} email templates`);

    // Create sample campaigns
    const campaigns = await Promise.all([
      prisma.campaign.create({
        data: {
          userId: demoUser.id,
          listId: lists[0].id,
          templateId: templates[1].id,
          name: 'November Newsletter',
          subject: 'Your monthly update from Gmail Assistant',
          preheader: 'Latest features and productivity tips',
          fromName: 'Gmail Assistant Team',
          fromEmail: 'newsletter@gmailassistant.com',
          htmlContent: templates[1].htmlContent,
          textContent: templates[1].textContent,
          type: 'STANDARD',
          status: 'SENT',
          recipientCount: 150,
          sentCount: 150,
          deliveredCount: 148,
          openCount: 89,
          clickCount: 23,
          unsubscribeCount: 2,
          bounceCount: 2,
          complaintCount: 0,
          openRate: 60.1,
          clickRate: 15.5,
          unsubscribeRate: 1.3,
          bounceRate: 1.3,
          deliveryRate: 98.7,
          sentAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
        },
      }),
      prisma.campaign.create({
        data: {
          userId: demoUser.id,
          listId: lists[1].id,
          templateId: templates[2].id,
          name: 'AI Features Launch',
          subject: 'Introducing AI-Powered Email Management',
          preheader: 'Revolutionary features that will transform your workflow',
          fromName: 'Gmail Assistant Team',
          fromEmail: 'announcements@gmailassistant.com',
          htmlContent: templates[2].htmlContent,
          textContent: templates[2].textContent,
          type: 'STANDARD',
          status: 'SENT',
          recipientCount: 85,
          sentCount: 85,
          deliveredCount: 84,
          openCount: 67,
          clickCount: 34,
          unsubscribeCount: 1,
          bounceCount: 1,
          complaintCount: 0,
          openRate: 79.8,
          clickRate: 40.5,
          unsubscribeRate: 1.2,
          bounceRate: 1.2,
          deliveryRate: 98.8,
          sentAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
        },
      }),
      prisma.campaign.create({
        data: {
          userId: demoUser.id,
          listId: lists[0].id,
          name: 'December Newsletter',
          subject: 'Year-end recap and what\'s coming in 2024',
          preheader: 'Thank you for an amazing year!',
          fromName: 'Gmail Assistant Team',
          fromEmail: 'newsletter@gmailassistant.com',
          htmlContent: '<p>Content coming soon...</p>',
          type: 'STANDARD',
          status: 'DRAFT',
          recipientCount: 152,
          sentCount: 0,
          deliveredCount: 0,
          openCount: 0,
          clickCount: 0,
          unsubscribeCount: 0,
          bounceCount: 0,
          complaintCount: 0,
          openRate: 0,
          clickRate: 0,
          unsubscribeRate: 0,
          bounceRate: 0,
          deliveryRate: 0,
          scheduledAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
        },
      }),
    ]);

    console.log(`✅ Created ${campaigns.length} campaigns`);

    // Create marketing automation
    const automation = await prisma.marketingAutomation.create({
      data: {
        userId: demoUser.id,
        listId: lists[0].id,
        name: 'Welcome Series',
        description: 'Automated welcome email sequence for new subscribers',
        type: 'WELCOME_SERIES',
        trigger: {
          type: 'list_join',
          conditions: {
            listId: lists[0].id,
          },
        },
        workflow: {
          steps: [
            {
              id: 'welcome-email',
              type: 'email',
              config: {
                subject: 'Welcome to our community!',
                templateId: templates[0].id,
                delay: { days: 0, hours: 0 },
              },
              connections: ['follow-up'],
            },
            {
              id: 'follow-up',
              type: 'email',
              config: {
                subject: 'Getting started guide',
                delay: { days: 3, hours: 0 },
              },
              connections: [],
            },
          ],
        },
        isActive: true,
        subscriberCount: 25,
        completedCount: 18,
        activeCount: 7,
      },
    });

    // Create automation emails
    await Promise.all([
      prisma.automationEmail.create({
        data: {
          automationId: automation.id,
          stepNumber: 1,
          name: 'Welcome Email',
          subject: 'Welcome to our community!',
          fromName: 'Gmail Assistant Team',
          fromEmail: 'welcome@gmailassistant.com',
          htmlContent: templates[0].htmlContent,
          textContent: templates[0].textContent,
          templateId: templates[0].id,
          delayDays: 0,
          delayHours: 0,
          sentCount: 25,
          openCount: 22,
          clickCount: 8,
          openRate: 88.0,
          clickRate: 32.0,
        },
      }),
      prisma.automationEmail.create({
        data: {
          automationId: automation.id,
          stepNumber: 2,
          name: 'Getting Started Guide',
          subject: 'Getting the most out of Gmail Assistant',
          fromName: 'Gmail Assistant Team',
          fromEmail: 'support@gmailassistant.com',
          htmlContent: '<p>Getting started guide content...</p>',
          delayDays: 3,
          delayHours: 0,
          sentCount: 18,
          openCount: 14,
          clickCount: 6,
          openRate: 77.8,
          clickRate: 33.3,
        },
      }),
    ]);

    console.log('✅ Created marketing automation with emails');

    // Create compliance records
    await prisma.complianceRecord.create({
      data: {
        userId: demoUser.id,
        type: 'GDPR',
        email: 'alice.johnson@example.com',
        listId: lists[0].id,
        action: 'opt-in',
        method: 'web_form',
        ipAddress: '192.168.1.100',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        evidence: {
          timestamp: new Date().toISOString(),
          form_url: 'https://example.com/subscribe',
          consent_text: 'I agree to receive marketing emails',
        },
        legalBasis: 'consent',
      },
    });

    console.log('✅ Created compliance records');

    console.log('🎉 Email marketing seed data created successfully!');
    console.log('📊 Summary:');
    console.log(`   • ${lists.length} email lists`);
    console.log(`   • ${subscribers.length} subscribers`);
    console.log(`   • ${templates.length} email templates`);
    console.log(`   • ${campaigns.length} campaigns`);
    console.log(`   • 1 marketing automation`);

  } catch (error) {
    console.error('❌ Error seeding email marketing data:', error);
    throw error;
  }
}

if (require.main === module) {
  seedEmailMarketing()
    .catch((e) => {
      console.error(e);
      process.exit(1);
    })
    .finally(async () => {
      await prisma.$disconnect();
    });
}

export default seedEmailMarketing;
