
// Global Suppression System
import { PrismaClient } from '@prisma/client';
import { 
  SuppressionReason, 
  SuppressionSource, 
  SuppressionScope,
  GlobalSuppressionListData,
  SuppressionEntryData 
} from './types';

const prisma = new PrismaClient();

export class SuppressionManager {
  // Add email to suppression list
  static async addSuppression(data: {
    email: string;
    reason: SuppressionReason;
    reasonDetail?: string;
    sourceType: SuppressionSource;
    sourceCampaignId?: string;
    sourceListId?: string;
    sourceAutomationId?: string;
    evidence?: any;
    ipAddress?: string;
    userAgent?: string;
    gdprRequest?: boolean;
    legalBasis?: string;
    suppressionListId?: string;
    userId?: string;
  }): Promise<SuppressionEntryData> {
    // Get or create default suppression list
    let suppressionListId = data.suppressionListId;
    
    if (!suppressionListId) {
      const defaultList = await this.getOrCreateDefaultSuppressionList(data.userId);
      suppressionListId = defaultList.id;
    }
    
    // Check if email is already suppressed
    const existing = await prisma.suppressionEntry.findFirst({
      where: {
        suppressionListId,
        email: data.email
      }
    });
    
    if (existing) {
      // Update existing entry with new information
      return await prisma.suppressionEntry.update({
        where: { id: existing.id },
        data: {
          reason: data.reason,
          reasonDetail: data.reasonDetail,
          sourceType: data.sourceType,
          sourceCampaignId: data.sourceCampaignId,
          sourceListId: data.sourceListId,
          sourceAutomationId: data.sourceAutomationId,
          evidence: data.evidence,
          processedAt: new Date()
        }
      }) as SuppressionEntryData;
    }
    
    // Create new suppression entry
    const entry = await prisma.suppressionEntry.create({
      data: {
        suppressionListId,
        email: data.email,
        reason: data.reason,
        reasonDetail: data.reasonDetail,
        sourceType: data.sourceType,
        sourceCampaignId: data.sourceCampaignId,
        sourceListId: data.sourceListId,
        sourceAutomationId: data.sourceAutomationId,
        evidence: data.evidence,
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
        gdprRequest: data.gdprRequest || false,
        legalBasis: data.legalBasis
      }
    }) as SuppressionEntryData;
    
    // Update suppression list counts
    await this.updateSuppressionListCounts(suppressionListId);
    
    // Apply suppression across lists if configured
    await this.applyCrossListSuppression(suppressionListId, data.email);
    
    return entry;
  }
  
  // Check if email is suppressed
  static async isEmailSuppressed(email: string, userId?: string): Promise<{
    isSuppressed: boolean;
    reason?: SuppressionReason;
    suppressionDate?: Date;
    suppressionList?: string;
  }> {
    // Check global suppressions first
    const globalSuppression = await prisma.suppressionEntry.findFirst({
      where: {
        email,
        suppressionList: { isGlobal: true }
      },
      include: { suppressionList: true }
    });
    
    if (globalSuppression) {
      return {
        isSuppressed: true,
        reason: globalSuppression.reason,
        suppressionDate: globalSuppression.createdAt,
        suppressionList: globalSuppression.suppressionList.name
      };
    }
    
    // Check user-specific suppressions
    if (userId) {
      const userSuppression = await prisma.suppressionEntry.findFirst({
        where: {
          email,
          suppressionList: { userId }
        },
        include: { suppressionList: true }
      });
      
      if (userSuppression) {
        return {
          isSuppressed: true,
          reason: userSuppression.reason,
          suppressionDate: userSuppression.createdAt,
          suppressionList: userSuppression.suppressionList.name
        };
      }
    }
    
    return { isSuppressed: false };
  }
  
  // Filter email list against suppressions
  static async filterEmailList(emails: string[], userId?: string): Promise<{
    allowed: string[];
    suppressed: Array<{
      email: string;
      reason: SuppressionReason;
      suppressionList: string;
    }>;
  }> {
    const allowed: string[] = [];
    const suppressed: Array<{ email: string; reason: SuppressionReason; suppressionList: string }> = [];
    
    for (const email of emails) {
      const suppressionCheck = await this.isEmailSuppressed(email, userId);
      
      if (suppressionCheck.isSuppressed) {
        suppressed.push({
          email,
          reason: suppressionCheck.reason!,
          suppressionList: suppressionCheck.suppressionList!
        });
      } else {
        allowed.push(email);
      }
    }
    
    return { allowed, suppressed };
  }
  
  // Create suppression list
  static async createSuppressionList(data: {
    userId?: string;
    name: string;
    description?: string;
    isGlobal?: boolean;
    scope?: SuppressionScope;
    autoAddBounces?: boolean;
    autoAddComplaints?: boolean;
    autoAddUnsubscribes?: boolean;
    appliedToAllLists?: boolean;
    specificLists?: string[];
  }): Promise<GlobalSuppressionListData> {
    return await prisma.globalSuppressionList.create({
      data: {
        userId: data.userId,
        name: data.name,
        description: data.description,
        isGlobal: data.isGlobal || false,
        scope: data.scope || SuppressionScope.USER,
        autoAddBounces: data.autoAddBounces || true,
        autoAddComplaints: data.autoAddComplaints || true,
        autoAddUnsubscribes: data.autoAddUnsubscribes || true,
        appliedToAllLists: data.appliedToAllLists || false,
        specificLists: data.specificLists || []
      }
    }) as GlobalSuppressionListData;
  }
  
  // Process bounce and add to suppression
  static async processBounce(bounceData: {
    email: string;
    bounceType: 'HARD' | 'SOFT';
    reason?: string;
    campaignId?: string;
    messageId?: string;
  }): Promise<void> {
    // Add hard bounces to suppression immediately
    if (bounceData.bounceType === 'HARD') {
      await this.addSuppression({
        email: bounceData.email,
        reason: SuppressionReason.HARD_BOUNCE,
        reasonDetail: bounceData.reason,
        sourceType: SuppressionSource.BOUNCE_HANDLER,
        sourceCampaignId: bounceData.campaignId,
        evidence: {
          bounceType: bounceData.bounceType,
          messageId: bounceData.messageId,
          processedAt: new Date()
        }
      });
    }
    
    // Track soft bounces and suppress after threshold
    if (bounceData.bounceType === 'SOFT') {
      await this.trackSoftBounce(bounceData.email, bounceData.campaignId);
    }
  }
  
  // Process complaint and add to suppression
  static async processComplaint(complaintData: {
    email: string;
    complaintType?: string;
    source?: string;
    campaignId?: string;
    messageId?: string;
  }): Promise<void> {
    await this.addSuppression({
      email: complaintData.email,
      reason: SuppressionReason.COMPLAINT,
      reasonDetail: complaintData.complaintType,
      sourceType: SuppressionSource.COMPLAINT_HANDLER,
      sourceCampaignId: complaintData.campaignId,
      evidence: {
        complaintType: complaintData.complaintType,
        source: complaintData.source,
        messageId: complaintData.messageId,
        processedAt: new Date()
      }
    });
  }
  
  // Bulk import suppressions
  static async bulkImportSuppressions(data: {
    suppressionListId: string;
    emails: Array<{
      email: string;
      reason?: SuppressionReason;
      reasonDetail?: string;
    }>;
    sourceType?: SuppressionSource;
  }): Promise<{
    imported: number;
    duplicates: number;
    errors: string[];
  }> {
    let imported = 0;
    let duplicates = 0;
    const errors: string[] = [];
    
    for (const emailData of data.emails) {
      try {
        const existing = await prisma.suppressionEntry.findFirst({
          where: {
            suppressionListId: data.suppressionListId,
            email: emailData.email
          }
        });
        
        if (existing) {
          duplicates++;
          continue;
        }
        
        await prisma.suppressionEntry.create({
          data: {
            suppressionListId: data.suppressionListId,
            email: emailData.email,
            reason: emailData.reason || SuppressionReason.MANUAL,
            reasonDetail: emailData.reasonDetail,
            sourceType: data.sourceType || SuppressionSource.IMPORT
          }
        });
        
        imported++;
      } catch (error: any) {
        errors.push(`${emailData.email}: ${error.message}`);
      }
    }
    
    // Update list counts
    await this.updateSuppressionListCounts(data.suppressionListId);
    
    return { imported, duplicates, errors };
  }
  
  // Export suppressions
  static async exportSuppressions(
    suppressionListId: string, 
    format: 'csv' | 'json' = 'csv'
  ): Promise<string> {
    const suppressions = await prisma.suppressionEntry.findMany({
      where: { suppressionListId },
      include: { suppressionList: true }
    });
    
    if (format === 'json') {
      return JSON.stringify(suppressions, null, 2);
    }
    
    // CSV format
    const headers = ['email', 'reason', 'reason_detail', 'source_type', 'created_at'];
    const rows = suppressions.map(s => [
      s.email,
      s.reason,
      s.reasonDetail || '',
      s.sourceType,
      s.createdAt.toISOString()
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  }
  
  // Merge suppression lists
  static async mergeSuppressionLists(
    sourceListId: string,
    targetListId: string,
    deleteSource = false
  ): Promise<{
    merged: number;
    duplicates: number;
  }> {
    const sourceSuppressions = await prisma.suppressionEntry.findMany({
      where: { suppressionListId: sourceListId }
    });
    
    let merged = 0;
    let duplicates = 0;
    
    for (const suppression of sourceSuppressions) {
      const existing = await prisma.suppressionEntry.findFirst({
        where: {
          suppressionListId: targetListId,
          email: suppression.email
        }
      });
      
      if (existing) {
        duplicates++;
        continue;
      }
      
      await prisma.suppressionEntry.create({
        data: {
          suppressionListId: targetListId,
          email: suppression.email,
          reason: suppression.reason,
          reasonDetail: suppression.reasonDetail,
          sourceType: suppression.sourceType,
          sourceCampaignId: suppression.sourceCampaignId,
          sourceListId: suppression.sourceListId,
          sourceAutomationId: suppression.sourceAutomationId,
          evidence: suppression.evidence,
          ipAddress: suppression.ipAddress,
          userAgent: suppression.userAgent,
          gdprRequest: suppression.gdprRequest,
          legalBasis: suppression.legalBasis
        }
      });
      
      merged++;
    }
    
    if (deleteSource) {
      await prisma.globalSuppressionList.delete({
        where: { id: sourceListId }
      });
    }
    
    // Update target list counts
    await this.updateSuppressionListCounts(targetListId);
    
    return { merged, duplicates };
  }
  
  // Remove suppression (for GDPR compliance)
  static async removeSuppression(
    email: string,
    suppressionListId?: string,
    reason = 'GDPR Request'
  ): Promise<void> {
    const whereClause = suppressionListId 
      ? { email, suppressionListId }
      : { email };
    
    await prisma.suppressionEntry.deleteMany({
      where: whereClause
    });
    
    // Log the removal for compliance
    await prisma.complianceRecord.create({
      data: {
        type: 'GDPR',
        email,
        action: 'suppression_removal',
        method: 'manual',
        evidence: { reason, processedAt: new Date() }
      }
    });
  }
  
  // Helper methods
  private static async getOrCreateDefaultSuppressionList(userId?: string): Promise<GlobalSuppressionListData> {
    let list = await prisma.globalSuppressionList.findFirst({
      where: {
        userId,
        name: 'Default Suppression List'
      }
    });
    
    if (!list) {
      list = await this.createSuppressionList({
        userId,
        name: 'Default Suppression List',
        description: 'Auto-created default suppression list',
        autoAddBounces: true,
        autoAddComplaints: true,
        autoAddUnsubscribes: true
      });
    }
    
    return list as GlobalSuppressionListData;
  }
  
  private static async updateSuppressionListCounts(suppressionListId: string): Promise<void> {
    const count = await prisma.suppressionEntry.count({
      where: { suppressionListId }
    });
    
    await prisma.globalSuppressionList.update({
      where: { id: suppressionListId },
      data: {
        suppressionCount: count,
        lastUpdated: new Date()
      }
    });
  }
  
  private static async applyCrossListSuppression(suppressionListId: string, email: string): Promise<void> {
    const suppressionList = await prisma.globalSuppressionList.findUnique({
      where: { id: suppressionListId }
    });
    
    if (!suppressionList?.appliedToAllLists) return;
    
    // Apply to specific lists or all lists for the user
    const targetLists = suppressionList.specificLists.length > 0
      ? suppressionList.specificLists
      : (await prisma.emailList.findMany({
          where: { userId: suppressionList.userId },
          select: { id: true }
        })).map(list => list.id);
    
    // Update subscriber status across target lists
    await prisma.listSubscriber.updateMany({
      where: {
        email,
        listId: { in: targetLists }
      },
      data: { status: 'SUPPRESSED' }
    });
  }
  
  private static async trackSoftBounce(email: string, campaignId?: string): Promise<void> {
    // Implementation for tracking soft bounces and applying suppression after threshold
    // This would typically involve counting soft bounces over a time period
    
    const softBounceCount = await prisma.emailBounce.count({
      where: {
        email,
        bounceType: 'SOFT',
        bouncedAt: {
          gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Last 30 days
        }
      }
    });
    
    // Suppress after 3 soft bounces
    if (softBounceCount >= 3) {
      await this.addSuppression({
        email,
        reason: SuppressionReason.SOFT_BOUNCE,
        reasonDetail: `${softBounceCount} soft bounces in 30 days`,
        sourceType: SuppressionSource.BOUNCE_HANDLER,
        sourceCampaignId: campaignId
      });
    }
  }
}
