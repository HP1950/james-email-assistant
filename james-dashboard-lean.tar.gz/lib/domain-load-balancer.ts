
import nodemailer from 'nodemailer';

export interface DomainConfig {
  id: string;
  domain: string;
  jamesEmail: string; // james1@domain1.com, james2@domain2.com, etc.
  currentLoad: number; // Current daily email count
  maxCapacity: number; // Max emails per day (3000 for Hostinger Business)
  smtpConfig: {
    host: string;
    port: number;
    secure: boolean;
    auth: {
      user: string;
      pass: string;
    };
  };
  isActive: boolean;
  lastReset: Date; // When daily counter was last reset
}

export interface UserDomainAssignment {
  userId: string;
  userEmail: string;
  assignedDomain: string;
  assignedJamesEmail: string;
  createdAt: Date;
  emailCount: number; // Daily email count for this user
}

export class DomainLoadBalancer {
  private domains: DomainConfig[] = [];
  private userAssignments: Map<string, UserDomainAssignment> = new Map();
  
  constructor() {
    this.initializeDefaultDomains();
    this.startDailyResetScheduler();
  }

  // Initialize your 5 domains - UPDATE THESE WITH YOUR ACTUAL DOMAINS
  private initializeDefaultDomains() {
    const defaultDomains = [
      'domain1.com', // Replace with your actual domains
      'domain2.com',
      'domain3.com', 
      'domain4.com',
      'domain5.com'
    ];

    this.domains = defaultDomains.map((domain, index) => ({
      id: `domain-${index + 1}`,
      domain,
      jamesEmail: `james${index + 1}@${domain}`,
      currentLoad: 0,
      maxCapacity: 3000, // Hostinger Business plan limit
      smtpConfig: {
        host: 'smtp.hostinger.com', // Update with your SMTP host
        port: 587,
        secure: false,
        auth: {
          user: `james${index + 1}@${domain}`,
          pass: `your-password-${index + 1}` // UPDATE WITH ACTUAL PASSWORDS
        }
      },
      isActive: true,
      lastReset: new Date()
    }));
  }

  // Get domain with lowest current load
  getOptimalDomain(): DomainConfig | null {
    const activeDomains = this.domains.filter(d => d.isActive);
    
    if (activeDomains.length === 0) {
      return null;
    }

    // Sort by current load (ascending) and return domain with capacity
    const sortedDomains = activeDomains
      .filter(d => d.currentLoad < d.maxCapacity - 200) // Leave 200 email buffer
      .sort((a, b) => a.currentLoad - b.currentLoad);

    return sortedDomains.length > 0 ? sortedDomains[0] : null;
  }

  // Assign user to optimal domain
  async assignUserToDomain(userId: string, userEmail: string): Promise<UserDomainAssignment | null> {
    // Check if user is already assigned
    const existingAssignment = this.userAssignments.get(userId);
    if (existingAssignment) {
      return existingAssignment;
    }

    // Get optimal domain
    const optimalDomain = this.getOptimalDomain();
    if (!optimalDomain) {
      console.error('No available domains for new user assignment');
      return null;
    }

    // Create user assignment
    const assignment: UserDomainAssignment = {
      userId,
      userEmail,
      assignedDomain: optimalDomain.domain,
      assignedJamesEmail: optimalDomain.jamesEmail,
      createdAt: new Date(),
      emailCount: 0
    };

    // Store assignment
    this.userAssignments.set(userId, assignment);
    
    console.log(`✅ User ${userEmail} assigned to domain: ${optimalDomain.domain}`);
    return assignment;
  }

  // Get user's assigned domain
  getUserDomainAssignment(userId: string): UserDomainAssignment | null {
    return this.userAssignments.get(userId) || null;
  }

  // Track email usage for load balancing
  async trackEmailSent(userId: string): Promise<void> {
    const assignment = this.userAssignments.get(userId);
    if (!assignment) {
      console.error(`No domain assignment found for user: ${userId}`);
      return;
    }

    // Increment user email count
    assignment.emailCount++;

    // Increment domain load
    const domain = this.domains.find(d => d.domain === assignment.assignedDomain);
    if (domain) {
      domain.currentLoad++;
      
      // Log if approaching capacity
      if (domain.currentLoad > domain.maxCapacity * 0.9) {
        console.warn(`⚠️ Domain ${domain.domain} approaching capacity: ${domain.currentLoad}/${domain.maxCapacity}`);
      }
    }
  }

  // Get SMTP transporter for user's assigned domain
  async getSMTPTransporter(userId: string): Promise<nodemailer.Transporter | null> {
    const assignment = this.userAssignments.get(userId);
    if (!assignment) {
      console.error(`No domain assignment found for user: ${userId}`);
      return null;
    }

    const domain = this.domains.find(d => d.domain === assignment.assignedDomain);
    if (!domain) {
      console.error(`Domain configuration not found: ${assignment.assignedDomain}`);
      return null;
    }

    try {
      const transporter = nodemailer.createTransport({
        host: domain.smtpConfig.host,
        port: domain.smtpConfig.port,
        secure: domain.smtpConfig.secure,
        auth: domain.smtpConfig.auth
      });

      // Verify connection
      await transporter.verify();
      return transporter;
    } catch (error) {
      console.error(`SMTP connection failed for domain ${domain.domain}:`, error);
      return null;
    }
  }

  // Reset daily counters (runs at midnight)
  private resetDailyCounters(): void {
    const now = new Date();
    
    // Reset domain load counters
    this.domains.forEach(domain => {
      domain.currentLoad = 0;
      domain.lastReset = now;
    });

    // Reset user email counters
    this.userAssignments.forEach(assignment => {
      assignment.emailCount = 0;
    });

    console.log(`🔄 Daily counters reset at ${now.toISOString()}`);
  }

  // Schedule daily reset at midnight
  private startDailyResetScheduler(): void {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);

    const msUntilMidnight = tomorrow.getTime() - now.getTime();

    // Set initial timeout to midnight
    setTimeout(() => {
      this.resetDailyCounters();
      
      // Then set interval for every 24 hours
      setInterval(() => {
        this.resetDailyCounters();
      }, 24 * 60 * 60 * 1000);
    }, msUntilMidnight);

    console.log(`📅 Daily reset scheduler started. Next reset: ${tomorrow.toISOString()}`);
  }

  // Get load balancing statistics
  getLoadStats(): { domains: DomainConfig[], totalUsers: number, totalEmails: number } {
    const totalUsers = this.userAssignments.size;
    const totalEmails = this.domains.reduce((sum, domain) => sum + domain.currentLoad, 0);

    return {
      domains: this.domains.map(d => ({...d})), // Return copy
      totalUsers,
      totalEmails
    };
  }

  // Test all domain connections
  async testAllDomainConnections(): Promise<{[key: string]: boolean}> {
    const results: {[key: string]: boolean} = {};

    for (const domain of this.domains) {
      try {
        const transporter = nodemailer.createTransport(domain.smtpConfig);
        await transporter.verify();
        results[domain.domain] = true;
        console.log(`✅ Domain connection verified: ${domain.domain}`);
      } catch (error) {
        results[domain.domain] = false;
        console.error(`❌ Domain connection failed: ${domain.domain}`, error);
      }
    }

    return results;
  }

  // Update domain configuration (for setup UI)
  updateDomainConfig(domainId: string, updates: Partial<DomainConfig>): boolean {
    const domainIndex = this.domains.findIndex(d => d.id === domainId);
    if (domainIndex === -1) {
      return false;
    }

    this.domains[domainIndex] = { ...this.domains[domainIndex], ...updates };
    console.log(`✅ Domain config updated: ${domainId}`);
    return true;
  }

  // Add new domain (for scaling beyond 5)
  addDomain(domainConfig: DomainConfig): boolean {
    const existing = this.domains.find(d => d.domain === domainConfig.domain);
    if (existing) {
      console.error(`Domain already exists: ${domainConfig.domain}`);
      return false;
    }

    this.domains.push(domainConfig);
    console.log(`✅ New domain added: ${domainConfig.domain}`);
    return true;
  }

  // Remove domain (for maintenance)
  removeDomain(domainId: string): boolean {
    const index = this.domains.findIndex(d => d.id === domainId);
    if (index === -1) {
      return false;
    }

    // Check if any users are assigned to this domain
    const affectedUsers = Array.from(this.userAssignments.values())
      .filter(assignment => assignment.assignedDomain === this.domains[index].domain);

    if (affectedUsers.length > 0) {
      console.error(`Cannot remove domain ${domainId}: ${affectedUsers.length} users assigned`);
      return false;
    }

    this.domains.splice(index, 1);
    console.log(`✅ Domain removed: ${domainId}`);
    return true;
  }

  // Rebalance users across domains (for optimization)
  async rebalanceUsers(): Promise<void> {
    console.log('🔄 Starting user rebalancing...');
    
    const assignments = Array.from(this.userAssignments.values());
    const domainsPerUser = Math.ceil(assignments.length / this.domains.length);
    
    let domainIndex = 0;
    let usersInCurrentDomain = 0;

    // Clear current assignments
    assignments.forEach(assignment => {
      if (usersInCurrentDomain >= domainsPerUser && domainIndex < this.domains.length - 1) {
        domainIndex++;
        usersInCurrentDomain = 0;
      }

      const newDomain = this.domains[domainIndex];
      assignment.assignedDomain = newDomain.domain;
      assignment.assignedJamesEmail = newDomain.jamesEmail;
      
      usersInCurrentDomain++;
    });

    console.log(`✅ Rebalanced ${assignments.length} users across ${this.domains.length} domains`);
  }
}

// Singleton instance
export const domainLoadBalancer = new DomainLoadBalancer();
