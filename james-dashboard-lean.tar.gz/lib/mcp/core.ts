
/**
 * Model Context Protocol (MCP) Core Implementation
 * Lightweight MCP-inspired architecture for James Email Specialist
 */

export interface MCPAdapter {
  id: string;
  name: string;
  version: string;
  capabilities: string[];
  initialize(): Promise<void>;
  execute(input: MCPRequest): Promise<MCPResponse>;
  healthCheck(): Promise<boolean>;
}

export interface MCPRequest {
  id: string;
  type: string;
  payload: any;
  context?: MCPContext;
}

export interface MCPResponse {
  id: string;
  success: boolean;
  data?: any;
  error?: string;
  context?: MCPContext;
}

export interface MCPContext {
  userId: string;
  sessionId: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export class MCPRegistry {
  private adapters: Map<string, MCPAdapter> = new Map();
  
  register(adapter: MCPAdapter): void {
    this.adapters.set(adapter.id, adapter);
  }
  
  unregister(adapterId: string): void {
    this.adapters.delete(adapterId);
  }
  
  getAdapter(adapterId: string): MCPAdapter | undefined {
    return this.adapters.get(adapterId);
  }
  
  getAllAdapters(): MCPAdapter[] {
    return Array.from(this.adapters.values());
  }
  
  getAdaptersByCapability(capability: string): MCPAdapter[] {
    return Array.from(this.adapters.values()).filter(
      adapter => adapter.capabilities.includes(capability)
    );
  }
}

export class MCPOrchestrator {
  private registry: MCPRegistry;
  
  constructor() {
    this.registry = new MCPRegistry();
  }
  
  async execute(request: MCPRequest): Promise<MCPResponse> {
    const adapter = this.registry.getAdapter(request.type);
    
    if (!adapter) {
      return {
        id: request.id,
        success: false,
        error: `No adapter found for type: ${request.type}`
      };
    }
    
    try {
      const response = await adapter.execute(request);
      return response;
    } catch (error) {
      return {
        id: request.id,
        success: false,
        error: `Adapter execution failed: ${error}`
      };
    }
  }
  
  getRegistry(): MCPRegistry {
    return this.registry;
  }
}

// Global MCP instance
export const mcpOrchestrator = new MCPOrchestrator();
