// Basic types to resolve TypeScript errors

export type BatchPriority = 'low' | 'medium' | 'high';
export type DropScheduleType = 'immediate' | 'scheduled' | 'recurring';
export type WarmupStatus = 'pending' | 'active' | 'completed' | 'failed';
export type JobType = 'email' | 'analysis' | 'cleanup';
export type JobPriority = 'low' | 'medium' | 'high';
export type ProviderHealthStatus = 'healthy' | 'degraded' | 'down';
export type EmailProvider = 'smtp' | 'sendgrid' | 'ses';
export type ReportExecutionStatus = 'pending' | 'running' | 'completed' | 'failed';
export type ReportType = 'daily' | 'weekly' | 'monthly';
export type SuppressionScope = 'global' | 'domain' | 'user';

// Stub interfaces
export interface User {
  id: string;
  email: string;
  name?: string;
}

export interface EmailRule {
  id: string;
  name: string;
  conditions: any;
}

export interface EmailDraft {
  id: string;
  subject: string;
  content: string;
}