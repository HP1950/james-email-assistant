
/**
 * Gmail API Client for James Email Specialist
 * Handles Gmail integration for inbox management
 */

import { google } from 'googleapis';
import { prisma } from '@/lib/prisma';

export interface GmailMessage {
  id: string;
  threadId: string;
  snippet: string;
  payload: {
    headers: Array<{ name: string; value: string }>;
    body: { data?: string };
    parts?: Array<{ body: { data?: string } }>;
  };
  internalDate: string;
}

export interface ProcessedEmail {
  id: string;
  messageId: string;
  threadId: string;
  subject: string;
  from: string;
  to: string;
  body: string;
  receivedAt: Date;
  labels: string[];
  snippet: string;
}

export class GmailClient {
  private auth: any;
  private gmail: any;
  
  constructor(accessToken: string) {
    this.auth = new google.auth.OAuth2();
    this.auth.setCredentials({ access_token: accessToken });
    this.gmail = google.gmail({ version: 'v1', auth: this.auth });
  }

  /**
   * Fetch recent emails from Gmail
   */
  async fetchRecentEmails(maxResults: number = 50): Promise<ProcessedEmail[]> {
    try {
      // Get list of message IDs
      const listResponse = await this.gmail.users.messages.list({
        userId: 'me',
        maxResults,
        q: 'in:inbox',
      });

      const messages = listResponse.data.messages || [];
      const processedEmails: ProcessedEmail[] = [];

      // Fetch full message details for each email
      for (const message of messages) {
        try {
          const fullMessage = await this.gmail.users.messages.get({
            userId: 'me',
            id: message.id,
          });

          const processed = this.processGmailMessage(fullMessage.data);
          if (processed) {
            processedEmails.push(processed);
          }
        } catch (error) {
          console.error(`Error fetching message ${message.id}:`, error);
        }
      }

      return processedEmails;
    } catch (error) {
      console.error('Error fetching Gmail messages:', error);
      throw new Error('Failed to fetch emails from Gmail');
    }
  }

  /**
   * Process Gmail message into our format
   */
  private processGmailMessage(message: GmailMessage): ProcessedEmail | null {
    try {
      const headers = message.payload.headers;
      const subject = this.getHeader(headers, 'Subject') || '';
      const from = this.getHeader(headers, 'From') || '';
      const to = this.getHeader(headers, 'To') || '';
      
      // Extract email body
      const body = this.extractEmailBody(message.payload);
      
      return {
        id: message.id,
        messageId: this.getHeader(headers, 'Message-ID') || message.id,
        threadId: message.threadId,
        subject,
        from: this.extractEmailAddress(from),
        to: this.extractEmailAddress(to),
        body,
        receivedAt: new Date(parseInt(message.internalDate)),
        labels: [], // Will be populated by Gmail labels if needed
        snippet: message.snippet || body.substring(0, 150)
      };
    } catch (error) {
      console.error('Error processing Gmail message:', error);
      return null;
    }
  }

  /**
   * Extract header value by name
   */
  private getHeader(headers: Array<{ name: string; value: string }>, name: string): string | undefined {
    return headers.find(h => h.name.toLowerCase() === name.toLowerCase())?.value;
  }

  /**
   * Extract email address from "Name <email@domain.com>" format
   */
  private extractEmailAddress(address: string): string {
    const match = address.match(/<(.+?)>/);
    return match ? match[1] : address.split(' ')[0];
  }

  /**
   * Extract email body from Gmail message payload
   */
  private extractEmailBody(payload: any): string {
    // Handle simple text body
    if (payload.body && payload.body.data) {
      return Buffer.from(payload.body.data, 'base64').toString('utf-8');
    }

    // Handle multipart messages
    if (payload.parts) {
      for (const part of payload.parts) {
        if (part.mimeType === 'text/plain' && part.body && part.body.data) {
          return Buffer.from(part.body.data, 'base64').toString('utf-8');
        }
      }
      
      // Fallback to HTML content if no plain text
      for (const part of payload.parts) {
        if (part.mimeType === 'text/html' && part.body && part.body.data) {
          const html = Buffer.from(part.body.data, 'base64').toString('utf-8');
          // Simple HTML stripping - in production, use a proper HTML parser
          return html.replace(/<[^>]*>/g, '').trim();
        }
      }
    }

    return '';
  }

  /**
   * Mark email as read
   */
  async markAsRead(messageId: string): Promise<void> {
    await this.gmail.users.messages.modify({
      userId: 'me',
      id: messageId,
      resource: {
        removeLabelIds: ['UNREAD']
      }
    });
  }

  /**
   * Add labels to email
   */
  async addLabels(messageId: string, labelIds: string[]): Promise<void> {
    await this.gmail.users.messages.modify({
      userId: 'me',
      id: messageId,
      resource: {
        addLabelIds: labelIds
      }
    });
  }

  /**
   * Archive email
   */
  async archiveEmail(messageId: string): Promise<void> {
    await this.gmail.users.messages.modify({
      userId: 'me',
      id: messageId,
      resource: {
        removeLabelIds: ['INBOX']
      }
    });
  }

  /**
   * Get user's Gmail labels
   */
  async getLabels(): Promise<Array<{ id: string; name: string }>> {
    try {
      const response = await this.gmail.users.labels.list({
        userId: 'me'
      });
      
      return response.data.labels.map((label: any) => ({
        id: label.id,
        name: label.name
      }));
    } catch (error) {
      console.error('Error fetching Gmail labels:', error);
      return [];
    }
  }
}

/**
 * Get Gmail client for user
 */
export async function getGmailClientForUser(userId: string): Promise<GmailClient | null> {
  try {
    // Get user's Gmail access token from database
    const account = await prisma.account.findFirst({
      where: {
        userId,
        provider: 'google'
      }
    });

    if (!account?.access_token) {
      console.error('No Gmail access token found for user:', userId);
      return null;
    }

    return new GmailClient(account.access_token);
  } catch (error) {
    console.error('Error creating Gmail client:', error);
    return null;
  }
}
