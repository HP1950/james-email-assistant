
import { Sentiment, Priority, TaskStatus } from './types';

// WebSocket Authentication Types
export interface WebSocketAuthToken {
  userId: string;
  sessionId: string;
  email: string;
  name?: string;
  role?: string;
  iat: number;
  exp: number;
}

// WebSocket Event Types
export interface WebSocketEventMap {
  // Connection Events
  'connection': { userId: string; sessionId: string; timestamp: Date };
  'disconnect': { userId: string; sessionId: string; reason: string; timestamp: Date };
  'heartbeat': { userId: string; timestamp: Date };
  
  // Authentication Events
  'auth:success': { userId: string; user: any };
  'auth:error': { error: string };
  'auth:required': {};
  
  // Email Events
  'email:new': EmailRealtimeUpdate;
  'email:updated': EmailRealtimeUpdate;
  'email:processed': EmailProcessingUpdate;
  'email:status': EmailStatusUpdate;
  'email:sync': EmailSyncStatus;
  
  // AI Processing Events
  'ai:analysis:start': AIAnalysisStart;
  'ai:analysis:complete': AIAnalysisComplete;
  'ai:analysis:error': AIAnalysisError;
  'ai:suggestion:new': AISuggestionUpdate;
  
  // Activity Events
  'activity:new': ActivityFeedUpdate;
  'activity:bulk': ActivityFeedUpdate[];
  
  // Notification Events
  'notification:new': NotificationUpdate;
  'notification:read': { notificationId: string; userId: string };
  'notification:settings': NotificationSettings;
  
  // Collaboration Events
  'collaboration:user:join': UserPresenceUpdate;
  'collaboration:user:leave': UserPresenceUpdate;
  'collaboration:email:share': EmailCollaborationUpdate;
  'collaboration:typing': TypingIndicator;
  
  // System Events
  'system:status': SystemStatusUpdate;
  'system:maintenance': MaintenanceUpdate;
  'system:performance': PerformanceMetrics;
  
  // Error Events
  'error': WebSocketError;
  'rate_limit': RateLimitUpdate;
}

// Base Interfaces
export interface BaseRealtimeEvent {
  id: string;
  userId: string;
  timestamp: Date;
  type: keyof WebSocketEventMap;
}

export interface EmailRealtimeUpdate extends BaseRealtimeEvent {
  email: {
    id: string;
    gmailId: string;
    subject: string;
    fromAddress: string;
    fromName?: string;
    isRead: boolean;
    isStarred: boolean;
    priority?: Priority;
    sentiment?: Sentiment;
    category?: string;
    aiSummary?: string;
    receivedAt: Date;
  };
  action: 'created' | 'updated' | 'read' | 'starred' | 'archived' | 'deleted';
}

export interface EmailProcessingUpdate extends BaseRealtimeEvent {
  emailId: string;
  stage: 'parsing' | 'ai_analysis' | 'categorization' | 'task_extraction' | 'completed';
  progress: number; // 0-100
  message: string;
  estimatedTimeRemaining?: number; // seconds
}

export interface EmailStatusUpdate extends BaseRealtimeEvent {
  emailId: string;
  status: {
    isRead: boolean;
    isStarred: boolean;
    isArchived: boolean;
    priority?: Priority;
    category?: string;
  };
}

export interface EmailSyncStatus extends BaseRealtimeEvent {
  status: 'syncing' | 'completed' | 'error';
  progress: number;
  newEmails: number;
  updatedEmails: number;
  errors?: string[];
  lastSyncAt: Date;
}

export interface AIAnalysisStart extends BaseRealtimeEvent {
  analysisId: string;
  emailId: string;
  analysisType: string[];
  estimatedDuration: number;
}

export interface AIAnalysisComplete extends BaseRealtimeEvent {
  analysisId: string;
  emailId: string;
  results: {
    sentiment?: Sentiment;
    priority?: Priority;
    category?: string;
    summary?: string;
    extractedTasks?: string[];
    confidence: number;
  };
  processingTime: number;
}

export interface AIAnalysisError extends BaseRealtimeEvent {
  analysisId: string;
  emailId: string;
  error: string;
  retryAttempt: number;
  maxRetries: number;
}

export interface AISuggestionUpdate extends BaseRealtimeEvent {
  emailId: string;
  suggestions: {
    replies: string[];
    actions: string[];
    followUps: string[];
  };
  confidence: number;
}

export interface ActivityFeedUpdate extends BaseRealtimeEvent {
  activity: {
    id: string;
    type: 'email_received' | 'email_sent' | 'email_read' | 'task_created' | 'ai_analysis' | 'workflow_run';
    description: string;
    metadata: any;
    createdAt: Date;
  };
}

export interface NotificationUpdate extends BaseRealtimeEvent {
  notification: {
    id: string;
    title: string;
    message: string;
    type: 'email' | 'task' | 'system' | 'collaboration';
    priority: 'low' | 'medium' | 'high' | 'urgent';
    actionUrl?: string;
    expiresAt?: Date;
  };
}

export interface NotificationSettings {
  emailNotifications: boolean;
  pushNotifications: boolean;
  priorityThreshold: Priority;
  quietHours: { start: string; end: string };
  enabledTypes: string[];
}

export interface UserPresenceUpdate extends BaseRealtimeEvent {
  user: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
  };
  status: 'online' | 'away' | 'busy' | 'offline';
  lastSeen: Date;
  currentPage?: string;
}

export interface EmailCollaborationUpdate extends BaseRealtimeEvent {
  emailId: string;
  action: 'shared' | 'unshared' | 'permission_changed';
  collaborator: {
    id: string;
    name: string;
    email: string;
    role: string;
  };
}

export interface TypingIndicator extends BaseRealtimeEvent {
  emailId: string;
  isTyping: boolean;
  location: 'reply' | 'comment' | 'note';
}

export interface SystemStatusUpdate extends BaseRealtimeEvent {
  status: 'operational' | 'degraded' | 'maintenance' | 'outage';
  services: {
    email: 'online' | 'offline' | 'degraded';
    ai: 'online' | 'offline' | 'degraded';
    database: 'online' | 'offline' | 'degraded';
    websocket: 'online' | 'offline' | 'degraded';
  };
  message?: string;
}

export interface MaintenanceUpdate extends BaseRealtimeEvent {
  scheduled: boolean;
  startTime: Date;
  endTime: Date;
  affectedServices: string[];
  description: string;
}

export interface PerformanceMetrics extends BaseRealtimeEvent {
  metrics: {
    responseTime: number;
    throughput: number;
    errorRate: number;
    activeConnections: number;
    memoryUsage: number;
    cpuUsage: number;
  };
}

export interface WebSocketError extends BaseRealtimeEvent {
  error: {
    code: string;
    message: string;
    stack?: string;
    context?: any;
  };
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface RateLimitUpdate extends BaseRealtimeEvent {
  limit: number;
  remaining: number;
  resetTime: Date;
  retryAfter: number;
}

// Connection Management
export interface WebSocketConnection {
  id: string;
  userId: string;
  sessionId: string;
  connectedAt: Date;
  lastHeartbeat: Date;
  subscriptions: string[];
  metadata: {
    userAgent: string;
    ipAddress: string;
    page: string;
  };
}

export interface WebSocketSubscription {
  id: string;
  pattern: string;
  filters?: {
    emailId?: string;
    userId?: string;
    type?: string[];
  };
  createdAt: Date;
}

// Client State Management
export interface WebSocketState {
  connected: boolean;
  connecting: boolean;
  authenticated: boolean;
  connectionId?: string;
  lastHeartbeat?: Date;
  reconnectAttempts: number;
  maxReconnectAttempts: number;
  subscriptions: WebSocketSubscription[];
  error?: string;
}

export interface RealtimeEmailState {
  emails: { [id: string]: EmailRealtimeUpdate['email'] };
  processing: { [emailId: string]: EmailProcessingUpdate };
  syncing: boolean;
  lastSync?: Date;
}

export interface ActivityItem {
  id: string;
  type: 'email_received' | 'email_sent' | 'email_read' | 'task_created' | 'ai_analysis' | 'workflow_run';
  description: string;
  metadata: any;
  createdAt: Date;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'email' | 'task' | 'system' | 'collaboration';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  actionUrl?: string;
  expiresAt?: Date;
}

export interface UserPresence {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface CollaboratorInfo {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface RealtimeActivityState {
  activities: ActivityItem[];
  unreadCount: number;
  lastUpdate?: Date;
}

export interface RealtimeNotificationState {
  notifications: NotificationItem[];
  unreadCount: number;
  settings: NotificationSettings;
}

export interface RealtimeCollaborationState {
  onlineUsers: UserPresence[];
  typingUsers: { [emailId: string]: string[] };
  sharedEmails: { [emailId: string]: CollaboratorInfo[] };
}

// Event Handlers
export type WebSocketEventHandler<T extends keyof WebSocketEventMap> = (
  data: WebSocketEventMap[T]
) => void;

export interface WebSocketEventHandlers {
  'connection'?: WebSocketEventHandler<'connection'>;
  'disconnect'?: WebSocketEventHandler<'disconnect'>;
  'heartbeat'?: WebSocketEventHandler<'heartbeat'>;
  'auth:success'?: WebSocketEventHandler<'auth:success'>;
  'auth:error'?: WebSocketEventHandler<'auth:error'>;
  'auth:required'?: WebSocketEventHandler<'auth:required'>;
  'email:new'?: WebSocketEventHandler<'email:new'>;
  'email:updated'?: WebSocketEventHandler<'email:updated'>;
  'email:processed'?: WebSocketEventHandler<'email:processed'>;
  'email:status'?: WebSocketEventHandler<'email:status'>;
  'email:sync'?: WebSocketEventHandler<'email:sync'>;
  'ai:analysis:start'?: WebSocketEventHandler<'ai:analysis:start'>;
  'ai:analysis:complete'?: WebSocketEventHandler<'ai:analysis:complete'>;
  'ai:analysis:error'?: WebSocketEventHandler<'ai:analysis:error'>;
  'ai:suggestion:new'?: WebSocketEventHandler<'ai:suggestion:new'>;
  'activity:new'?: WebSocketEventHandler<'activity:new'>;
  'activity:bulk'?: WebSocketEventHandler<'activity:bulk'>;
  'notification:new'?: WebSocketEventHandler<'notification:new'>;
  'notification:read'?: WebSocketEventHandler<'notification:read'>;
  'notification:settings'?: WebSocketEventHandler<'notification:settings'>;
  'collaboration:user:join'?: WebSocketEventHandler<'collaboration:user:join'>;
  'collaboration:user:leave'?: WebSocketEventHandler<'collaboration:user:leave'>;
  'collaboration:email:share'?: WebSocketEventHandler<'collaboration:email:share'>;
  'collaboration:typing'?: WebSocketEventHandler<'collaboration:typing'>;
  'system:status'?: WebSocketEventHandler<'system:status'>;
  'system:maintenance'?: WebSocketEventHandler<'system:maintenance'>;
  'system:performance'?: WebSocketEventHandler<'system:performance'>;
  'error'?: WebSocketEventHandler<'error'>;
  'rate_limit'?: WebSocketEventHandler<'rate_limit'>;
}

// Configuration
export interface WebSocketConfig {
  url: string;
  path: string;
  timeout: number;
  reconnectInterval: number;
  maxReconnectAttempts: number;
  heartbeatInterval: number;
  authentication: {
    enabled: boolean;
    tokenRefreshInterval: number;
  };
  compression: boolean;
  debug: boolean;
}
