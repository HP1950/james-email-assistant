

import nodemailer from 'nodemailer';
import { defaultEmailConfig, GmailAccount, findGmailAccountByEmail } from './email-config';
import { domainLoadBalancer, UserDomainAssignment } from './domain-load-balancer';

export interface ForwardedEmail {
  from: string;
  to: string;
  subject: string;
  body: string;
  originalGmailAccount?: string;
  messageId: string;
  inReplyTo?: string;
  references?: string;
}

export interface EmailReply {
  to: string;
  subject: string;
  body: string;
  originalGmailAccount: string;
  inReplyTo?: string;
  references?: string;
}

export class EmailProcessor {
  private config = defaultEmailConfig;

  // Register new user and assign to optimal domain
  async registerUser(userId: string, userEmail: string): Promise<UserDomainAssignment | null> {
    try {
      const assignment = await domainLoadBalancer.assignUserToDomain(userId, userEmail);
      if (assignment) {
        console.log(`✅ User registered: ${userEmail} → ${assignment.assignedJamesEmail}`);
        return assignment;
      }
      return null;
    } catch (error) {
      console.error('Error registering user:', error);
      return null;
    }
  }

  // Get user's James email address for forwarding setup
  getUserJamesEmail(userId: string): string | null {
    const assignment = domainLoadBalancer.getUserDomainAssignment(userId);
    return assignment ? assignment.assignedJamesEmail : null;
  }

  // Get domain load balancing statistics
  getDomainStats() {
    return domainLoadBalancer.getLoadStats();
  }

  // Parse forwarded email headers to identify original Gmail account
  parseForwardedEmail(emailHeaders: any, emailBody: string): ForwardedEmail {
    const forwarded: ForwardedEmail = {
      from: emailHeaders.from,
      to: emailHeaders.to,
      subject: emailHeaders.subject,
      body: emailBody,
      messageId: emailHeaders.messageId,
      inReplyTo: emailHeaders.inReplyTo,
      references: emailHeaders.references
    };

    // Method 1: Check X-Forwarded-For header
    if (emailHeaders['x-forwarded-for']) {
      forwarded.originalGmailAccount = emailHeaders['x-forwarded-for'];
    }
    
    // Method 2: Parse Gmail forwarding pattern from subject or body
    else if (emailHeaders.subject && emailHeaders.subject.includes('Fwd:')) {
      forwarded.originalGmailAccount = this.extractGmailFromForwardedContent(emailBody);
    }
    
    // Method 3: Check custom forwarding headers Gmail might add
    else if (emailHeaders['x-gmail-original-recipient']) {
      forwarded.originalGmailAccount = emailHeaders['x-gmail-original-recipient'];
    }

    // Method 4: Parse from forwarded message content
    else {
      forwarded.originalGmailAccount = this.extractGmailFromForwardedContent(emailBody);
    }

    return forwarded;
  }

  // Extract original Gmail account from forwarded email content
  private extractGmailFromForwardedContent(emailBody: string): string | undefined {
    // Look for patterns like "---------- Forwarded message ----------"
    // followed by "To: something@gmail.com"
    
    const forwardedPattern = /---------- Forwarded message ----------([\s\S]*?)To:\s*([^\n\r]+)/i;
    const match = emailBody.match(forwardedPattern);
    
    if (match && match[2]) {
      const toLine = match[2].trim();
      const gmailMatch = toLine.match(/([a-zA-Z0-9._%+-]+@gmail\.com)/);
      if (gmailMatch) {
        return gmailMatch[1];
      }
    }

    // Alternative pattern: Look for "Sent to: email@gmail.com"
    const sentToPattern = /Sent to:\s*([a-zA-Z0-9._%+-]+@gmail\.com)/i;
    const sentToMatch = emailBody.match(sentToPattern);
    if (sentToMatch) {
      return sentToMatch[1];
    }

    return undefined;
  }

  // Generate AI reply based on email content and user preferences
  async generateReply(email: ForwardedEmail, userPreferences?: any): Promise<string> {
    // This is where James's AI would generate the reply
    // For now, we'll create a template response
    
    const senderName = this.extractNameFromEmail(email.from);
    const isReply = email.subject.toLowerCase().includes('re:');
    
    let replyTemplate = '';
    
    if (userPreferences?.voiceType === 'professional') {
      replyTemplate = isReply 
        ? `Thank you for your follow-up message. I'll review this and get back to you shortly.`
        : `Thank you for reaching out. I've received your message and will respond accordingly.`;
    } else if (userPreferences?.voiceType === 'friendly') {
      replyTemplate = isReply
        ? `Hi ${senderName}! Thanks for getting back to me. Let me take a look at this and I'll get back to you soon.`
        : `Hi ${senderName}! Thanks for your message. I'll take care of this for you.`;
    } else if (userPreferences?.voiceType === 'warm') {
      replyTemplate = isReply
        ? `Hello ${senderName}, I appreciate you taking the time to follow up. I'll review this carefully and respond soon.`
        : `Hello ${senderName}, thank you for reaching out to me. I value your message and will respond thoughtfully.`;
    } else { // energetic
      replyTemplate = isReply
        ? `Hey ${senderName}! Great to hear back from you! I'm on it and will get back to you with an awesome response!`
        : `Hey ${senderName}! Thanks for the message! I'm excited to help you out and will get back to you soon!`;
    }

    return replyTemplate;
  }

  // Send reply using original Gmail account SMTP with domain load balancing
  async sendReply(reply: EmailReply, userId?: string): Promise<boolean> {
    try {
      // Find the original Gmail account
      const gmailAccount = findGmailAccountByEmail(reply.originalGmailAccount, this.config);
      
      if (!gmailAccount) {
        console.error(`Gmail account not found: ${reply.originalGmailAccount}`);
        return false;
      }

      // Create SMTP transporter for this specific Gmail account
      const transporter = nodemailer.createTransport({
        host: gmailAccount.smtp.host,
        port: gmailAccount.smtp.port,
        secure: gmailAccount.smtp.secure,
        auth: gmailAccount.smtp.auth
      });

      // Prepare email options
      const mailOptions = {
        from: `${gmailAccount.displayName} <${gmailAccount.email}>`,
        to: reply.to,
        subject: reply.subject,
        html: reply.body,
        inReplyTo: reply.inReplyTo,
        references: reply.references
      };

      // Send the email
      const result = await transporter.sendMail(mailOptions);
      console.log(`Reply sent successfully from ${gmailAccount.email}:`, result.messageId);
      
      // Track email usage for domain load balancing
      if (userId) {
        await domainLoadBalancer.trackEmailSent(userId);
      }
      
      return true;
    } catch (error) {
      console.error('Error sending reply:', error);
      return false;
    }
  }

  // Process incoming forwarded email and send reply
  async processAndReply(emailData: any, userPreferences?: any, userId?: string): Promise<boolean> {
    try {
      // 1. Parse the forwarded email
      const forwardedEmail = this.parseForwardedEmail(emailData.headers, emailData.body);
      
      if (!forwardedEmail.originalGmailAccount) {
        console.error('Could not determine original Gmail account');
        return false;
      }

      // 2. Generate AI reply
      const replyContent = await this.generateReply(forwardedEmail, userPreferences);

      // 3. Prepare reply object
      const reply: EmailReply = {
        to: forwardedEmail.from,
        subject: forwardedEmail.subject.startsWith('Re:') 
          ? forwardedEmail.subject 
          : `Re: ${forwardedEmail.subject}`,
        body: replyContent,
        originalGmailAccount: forwardedEmail.originalGmailAccount,
        inReplyTo: forwardedEmail.messageId,
        references: forwardedEmail.references 
          ? `${forwardedEmail.references} ${forwardedEmail.messageId}`
          : forwardedEmail.messageId
      };

      // 4. Send reply using original Gmail SMTP
      return await this.sendReply(reply, userId);

    } catch (error) {
      console.error('Error processing and replying to email:', error);
      return false;
    }
  }

  // Helper function to extract name from email address
  private extractNameFromEmail(email: string): string {
    const match = email.match(/^([^<]+)<([^>]+)>$/);
    if (match) {
      return match[1].trim().replace(/"/g, '');
    }
    
    // If no name found, use the part before @
    const atIndex = email.indexOf('@');
    if (atIndex > 0) {
      return email.substring(0, atIndex);
    }
    
    return 'there';
  }

  // Test connection to all Gmail accounts
  async testConnections(): Promise<{[key: string]: boolean}> {
    const results: {[key: string]: boolean} = {};
    
    for (const account of this.config.gmailAccounts) {
      try {
        const transporter = nodemailer.createTransport({
          host: account.smtp.host,
          port: account.smtp.port,
          secure: account.smtp.secure,
          auth: account.smtp.auth
        });

        await transporter.verify();
        results[account.email] = true;
        console.log(`✅ Connection verified for ${account.email}`);
      } catch (error) {
        results[account.email] = false;
        console.error(`❌ Connection failed for ${account.email}:`, error);
      }
    }

    return results;
  }

  // Test all domain connections for load balancing
  async testDomainConnections(): Promise<{[key: string]: boolean}> {
    return await domainLoadBalancer.testAllDomainConnections();
  }

  // Get comprehensive system status for trial monitoring
  async getSystemStatus(): Promise<{
    gmailAccounts: {[key: string]: boolean};
    domains: {[key: string]: boolean};
    loadStats: any;
    totalUsers: number;
    totalEmailsToday: number;
  }> {
    const [gmailResults, domainResults] = await Promise.all([
      this.testConnections(),
      this.testDomainConnections()
    ]);

    const loadStats = domainLoadBalancer.getLoadStats();

    return {
      gmailAccounts: gmailResults,
      domains: domainResults,
      loadStats,
      totalUsers: loadStats.totalUsers,
      totalEmailsToday: loadStats.totalEmails
    };
  }

  // Send welcome email to new trial user
  async sendWelcomeEmail(userId: string, userEmail: string): Promise<boolean> {
    try {
      const assignment = domainLoadBalancer.getUserDomainAssignment(userId);
      if (!assignment) {
        console.error('No domain assignment found for user');
        return false;
      }

      const transporter = await domainLoadBalancer.getSMTPTransporter(userId);
      if (!transporter) {
        console.error('Could not get SMTP transporter for user');
        return false;
      }

      const welcomeEmail = {
        from: `James Assistant <${assignment.assignedJamesEmail}>`,
        to: userEmail,
        subject: 'Welcome to James - Your Email Assistant!',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2>🤖 Welcome to James!</h2>
            <p>Hi there! I'm James, your new email assistant.</p>
            
            <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3>📧 Your James Email Address:</h3>
              <p><strong>${assignment.assignedJamesEmail}</strong></p>
              <p>Forward your Gmail accounts to this address and I'll handle the rest!</p>
            </div>

            <h3>🚀 Getting Started:</h3>
            <ol>
              <li><strong>Set up Gmail forwarding:</strong> Forward your Gmail to ${assignment.assignedJamesEmail}</li>
              <li><strong>Configure your Gmail App Password:</strong> Generate app passwords for each Gmail account</li>
              <li><strong>Test the system:</strong> Send a test email and watch me reply!</li>
            </ol>

            <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <h4>🎤 Voice Commands:</h4>
              <p>Try saying: "Hello James", "Check my emails", or "Help me compose an email"</p>
            </div>

            <p>Need help? Just reply to this email and I'll assist you!</p>
            
            <p>Best regards,<br>
            James - Your Email Assistant</p>
          </div>
        `
      };

      await transporter.sendMail(welcomeEmail);
      
      // Track this email
      await domainLoadBalancer.trackEmailSent(userId);
      
      console.log(`✅ Welcome email sent to ${userEmail}`);
      return true;
    } catch (error) {
      console.error('Error sending welcome email:', error);
      return false;
    }
  }
}
