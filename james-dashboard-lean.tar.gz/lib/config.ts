

// 🎛️ Easy Toggle Configuration
// Change these values to enable/disable features instantly

export const appConfig = {
  // Authentication - Set to true to enable sign-up/sign-in requirements
  requireAuth: false,  // 👈 Toggle this to enable auth later
  
  // Features
  features: {
    voiceCommands: true,     // ✅ ACTIVE - Full voice recognition & response
    mcpArchitecture: false,  // Coming soon  
    gmailSync: false,        // Coming soon
    advancedCompose: false,  // Coming soon
  },
  
  // App Settings
  app: {
    name: 'Gmail Assistant',
    version: '1.0.0',
    isDevelopment: process.env.NODE_ENV === 'development',
  },
  
  // Future: Easy auth toggle
  auth: {
    enableSignup: true,
    enableGoogleOAuth: false,
    enableMagicLinks: false,
  }
};

// 📝 Usage Examples:
// - Set requireAuth: true → Enables full authentication system
// - Set features.voiceCommands: true → Enables voice features  
// - Set auth.enableGoogleOAuth: true → Adds Google login
