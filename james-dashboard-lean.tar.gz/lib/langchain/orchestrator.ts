
/**
 * LangChain Orchestration Layer for James
 * Provides AI-powered chains, agents, and memory management
 */

import { ChatOpenAI } from "@langchain/openai";
import { PromptTemplate } from "@langchain/core/prompts";
import { LLMChain } from "langchain/chains";
import { ConversationSummaryMemory } from "langchain/memory";
import { BufferMemory } from "langchain/memory";

export interface JamesAgent {
  id: string;
  name: string;
  description: string;
  model: ChatOpenAI;
  memory: BufferMemory | ConversationSummaryMemory;
  chain: LLMChain;
}

export interface JamesChain {
  id: string;
  name: string;
  steps: string[];
  execute(input: any): Promise<any>;
}

export class JamesOrchestrator {
  private agents: Map<string, JamesAgent> = new Map();
  private chains: Map<string, JamesChain> = new Map();
  private globalMemory: ConversationSummaryMemory;
  
  constructor() {
    // Initialize with OpenAI model (will use ABACUSAI_API_KEY)
    const model = new ChatOpenAI({
      temperature: 0.7,
      modelName: "gpt-4o-mini",
      openAIApiKey: process.env.ABACUSAI_API_KEY,
    });
    
    this.globalMemory = new ConversationSummaryMemory({
      llm: model,
      memoryKey: "chat_history",
      returnMessages: true,
    });
  }
  
  // Email Priority Analysis Agent
  async createEmailPriorityAgent(): Promise<JamesAgent> {
    const model = new ChatOpenAI({
      temperature: 0.3,
      modelName: "gpt-4o-mini",
      openAIApiKey: process.env.ABACUSAI_API_KEY,
    });
    
    const memory = new BufferMemory({
      memoryKey: "priority_history",
      returnMessages: true,
    });
    
    const prompt = PromptTemplate.fromTemplate(`
      You are James, an expert email priority analyzer. Analyze the following email and determine its priority level.
      
      Consider:
      - Sender importance (based on past interactions)
      - Content urgency indicators
      - Deadline mentions
      - Business context
      - Action items required
      
      Email Details:
      From: {sender}
      Subject: {subject}
      Content: {content}
      Thread History: {thread_history}
      
      Previous Interactions: {priority_history}
      
      Respond with:
      - Priority Level (Critical/High/Medium/Low)
      - Reasoning (brief explanation)
      - Suggested Action (reply/forward/archive/etc.)
      - Time Sensitivity (immediate/today/this week/no deadline)
    `);
    
    const chain = new LLMChain({
      llm: model,
      prompt: prompt,
      memory: memory,
    });
    
    const agent: JamesAgent = {
      id: "email-priority-agent",
      name: "Email Priority Analyzer",
      description: "Analyzes email priority and suggests actions",
      model,
      memory,
      chain
    };
    
    this.agents.set(agent.id, agent);
    return agent;
  }
  
  // Adaptive Tone Drafting Agent
  async createAdaptiveToneAgent(): Promise<JamesAgent> {
    const model = new ChatOpenAI({
      temperature: 0.8,
      modelName: "gpt-4o-mini", 
      openAIApiKey: process.env.ABACUSAI_API_KEY,
    });
    
    const memory = new BufferMemory({
      memoryKey: "tone_history",
      returnMessages: true,
    });
    
    const prompt = PromptTemplate.fromTemplate(`
      You are James, an adaptive email drafting specialist. Draft a response that matches the user's communication style and the context of the conversation.
      
      User's Past Email Style: {user_style}
      Recipient Relationship: {relationship}
      Email Thread Context: {thread_context}
      Sentiment of Received Email: {received_sentiment}
      
      Original Email to Respond To:
      From: {original_sender}
      Subject: {original_subject}
      Content: {original_content}
      
      User's Response Intent: {response_intent}
      Desired Tone: {desired_tone}
      
      Previous Drafting History: {tone_history}
      
      Draft a response that:
      - Matches the user's established communication style
      - Responds appropriately to the sentiment and context
      - Maintains the desired professional/casual tone
      - Addresses all key points from the original email
      - Includes appropriate next steps or call-to-action
      
      Format your response as:
      Subject: [suggested subject]
      Body: [email body]
      Tone Analysis: [explanation of tone choices]
    `);
    
    const chain = new LLMChain({
      llm: model,
      prompt: prompt,
      memory: memory,
    });
    
    const agent: JamesAgent = {
      id: "adaptive-tone-agent", 
      name: "Adaptive Tone Drafter",
      description: "Creates contextually appropriate email drafts",
      model,
      memory,
      chain
    };
    
    this.agents.set(agent.id, agent);
    return agent;
  }
  
  // Email Analysis Chain
  async createEmailAnalysisChain(): Promise<JamesChain> {
    const chain: JamesChain = {
      id: "email-analysis-chain",
      name: "Comprehensive Email Analysis",
      steps: [
        "sentiment_analysis",
        "priority_determination", 
        "action_item_extraction",
        "context_enrichment",
        "response_strategy"
      ],
      execute: async (input: {
        email: any;
        context: any;
        user_preferences: any;
      }) => {
        // Step 1: Sentiment Analysis
        const sentimentAgent = this.agents.get("email-priority-agent");
        const sentimentResult = await sentimentAgent?.chain.call({
          sender: input.email.from,
          subject: input.email.subject,
          content: input.email.body,
          thread_history: input.context.thread_history || "",
          priority_history: "",
        });
        
        // Step 2: Adaptive Response Generation
        const toneAgent = this.agents.get("adaptive-tone-agent");
        const responseResult = await toneAgent?.chain.call({
          user_style: input.user_preferences.communication_style || "professional",
          relationship: input.context.sender_relationship || "unknown",
          thread_context: input.context.thread_history || "",
          received_sentiment: sentimentResult?.text || "",
          original_sender: input.email.from,
          original_subject: input.email.subject,
          original_content: input.email.body,
          response_intent: input.user_preferences.response_intent || "acknowledge",
          desired_tone: input.user_preferences.desired_tone || "professional",
          tone_history: "",
        });
        
        return {
          sentiment_analysis: sentimentResult,
          suggested_response: responseResult,
          recommendations: {
            priority: "high", // Extracted from sentiment analysis
            actions: ["reply", "flag"], 
            timing: "today"
          }
        };
      }
    };
    
    this.chains.set(chain.id, chain);
    return chain;
  }
  
  async getAgent(agentId: string): Promise<JamesAgent | undefined> {
    return this.agents.get(agentId);
  }
  
  async getChain(chainId: string): Promise<JamesChain | undefined> {
    return this.chains.get(chainId);
  }
  
  async executeChain(chainId: string, input: any): Promise<any> {
    const chain = this.chains.get(chainId);
    if (!chain) {
      throw new Error(`Chain ${chainId} not found`);
    }
    
    return await chain.execute(input);
  }
}

// Global orchestrator instance
export const jamesOrchestrator = new JamesOrchestrator();
