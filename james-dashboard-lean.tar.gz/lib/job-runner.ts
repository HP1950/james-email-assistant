
// Core Job Runner Infrastructure
import { PrismaClient } from '@prisma/client';
import * as cron from 'node-cron';
import { JobType, JobPriority, JobExecutionStatus, QueueStatus } from './types';

const prisma = new PrismaClient();

export class JobRunner {
  private static instance: JobRunner;
  private isRunning = false;
  private workers = new Map<string, Worker>();
  private cronJobs = new Map<string, cron.ScheduledTask>();

  private constructor() {}

  static getInstance(): JobRunner {
    if (!JobRunner.instance) {
      JobRunner.instance = new JobRunner();
    }
    return JobRunner.instance;
  }

  // Start the job runner
  async start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('🚀 Job Runner started');
    
    // Start the main processing loop
    this.startProcessingLoop();
    
    // Load and schedule all active jobs
    await this.loadScheduledJobs();
  }

  // Stop the job runner
  async stop() {
    this.isRunning = false;
    
    // Stop all cron jobs
    this.cronJobs.forEach(task => task.stop());
    this.cronJobs.clear();
    
    // Stop all workers
    this.workers.clear();
    
    console.log('🛑 Job Runner stopped');
  }

  // Main processing loop
  private startProcessingLoop() {
    setInterval(async () => {
      if (!this.isRunning) return;
      
      try {
        await this.processQueuedJobs();
        await this.checkRetryJobs();
        await this.updateJobStatistics();
      } catch (error) {
        console.error('Job processing error:', error);
      }
    }, 5000); // Check every 5 seconds
  }

  // Load scheduled jobs from database
  private async loadScheduledJobs() {
    const jobs = await prisma.jobScheduler.findMany({
      where: { isActive: true }
    });

    for (const job of jobs) {
      await this.scheduleJob(job);
    }
  }

  // Schedule a job with cron
  private async scheduleJob(job: any) {
    if (this.cronJobs.has(job.id)) {
      this.cronJobs.get(job.id)?.stop();
    }

    const task = cron.schedule(job.cronExpression, async () => {
      await this.executeJob(job.id);
    }, {
      timezone: job.timezone
    });

    this.cronJobs.set(job.id, task);
    
    // Update next run time
    await prisma.jobScheduler.update({
      where: { id: job.id },
      data: { nextRunAt: this.getNextRunTime(job.cronExpression, job.timezone) }
    });
  }

  // Execute a job
  async executeJob(jobId: string, triggeredBy = 'cron') {
    const job = await prisma.jobScheduler.findUnique({
      where: { id: jobId }
    });

    if (!job) {
      console.error(`Job ${jobId} not found`);
      return;
    }

    // Create execution record
    const execution = await prisma.jobExecution.create({
      data: {
        jobId: job.id,
        status: JobExecutionStatus.PENDING,
        triggeredBy,
        maxAttempts: job.maxRetries
      }
    });

    try {
      // Update execution to running
      await prisma.jobExecution.update({
        where: { id: execution.id },
        data: {
          status: JobExecutionStatus.RUNNING,
          startedAt: new Date()
        }
      });

      // Execute the job based on type
      const result = await this.runJobByType(job, execution);

      // Mark as completed
      await prisma.jobExecution.update({
        where: { id: execution.id },
        data: {
          status: JobExecutionStatus.COMPLETED,
          completedAt: new Date(),
          runtime: Date.now() - execution.startedAt.getTime(),
          output: result
        }
      });

      // Update job statistics
      await this.updateJobStats(job.id, true);

    } catch (error: any) {
      console.error(`Job ${jobId} failed:`, error);

      await prisma.jobExecution.update({
        where: { id: execution.id },
        data: {
          status: JobExecutionStatus.FAILED,
          completedAt: new Date(),
          error: error.message,
          errorStack: error.stack
        }
      });

      // Schedule retry if needed
      if (execution.attempt < job.maxRetries) {
        await this.scheduleRetry(execution.id, job.retryDelay);
      }

      await this.updateJobStats(job.id, false);
    }
  }

  // Run job based on type
  private async runJobByType(job: any, execution: any) {
    switch (job.jobType) {
      case JobType.EMAIL_CAMPAIGN:
        return await this.runEmailCampaignJob(job, execution);
      
      case JobType.AUTOMATION_TRIGGER:
        return await this.runAutomationTriggerJob(job, execution);
      
      case JobType.LIST_CLEANUP:
        return await this.runListCleanupJob(job, execution);
      
      default:
        return { success: true, message: 'Job completed' };
    }
  }

  // Email Campaign Job
  private async runEmailCampaignJob(job: any, execution: any) {
    return { emailsSent: 100, success: true };
  }

  // Automation Trigger Job
  private async runAutomationTriggerJob(job: any, execution: any) {
    return { triggersProcessed: 10, success: true };
  }

  // List Cleanup Job
  private async runListCleanupJob(job: any, execution: any) {
    return { subscribersProcessed: 50, success: true };
  }

  // Process queued jobs
  private async processQueuedJobs() {
    // Implementation for processing queue
  }

  private async checkRetryJobs() {
    // Implementation for retry logic
  }

  private async scheduleRetry(executionId: string, delayMinutes: number) {
    const retryAt = new Date(Date.now() + delayMinutes * 60 * 1000);
    
    await prisma.jobExecution.update({
      where: { id: executionId },
      data: { retryAt }
    });
  }

  private async updateJobStats(jobId: string, success: boolean) {
    const updates = success 
      ? { successfulRuns: { increment: 1 } }
      : { failedRuns: { increment: 1 } };

    await prisma.jobScheduler.update({
      where: { id: jobId },
      data: {
        totalRuns: { increment: 1 },
        lastRunAt: new Date(),
        ...updates
      }
    });
  }

  private async updateJobStatistics() {
    // Update statistics implementation
  }

  private getNextRunTime(cronExpression: string, timezone: string): Date {
    return new Date(Date.now() + 60 * 60 * 1000); // 1 hour from now (placeholder)
  }

  // Public API methods
  async addJob(jobData: {
    name: string;
    jobType: JobType;
    cronExpression: string;
    config: any;
    priority?: JobPriority;
    userId?: string;
  }) {
    return await prisma.jobScheduler.create({
      data: {
        ...jobData,
        priority: jobData.priority || JobPriority.NORMAL,
        nextRunAt: this.getNextRunTime(jobData.cronExpression, 'UTC')
      }
    });
  }

  async pauseJob(jobId: string) {
    await prisma.jobScheduler.update({
      where: { id: jobId },
      data: { isActive: false }
    });

    // Stop the cron job
    const task = this.cronJobs.get(jobId);
    if (task) {
      task.stop();
      this.cronJobs.delete(jobId);
    }
  }

  async resumeJob(jobId: string) {
    const job = await prisma.jobScheduler.update({
      where: { id: jobId },
      data: { isActive: true }
    });

    // Reschedule the job
    await this.scheduleJob(job);
  }
}

// Export singleton instance
export const jobRunner = JobRunner.getInstance();
