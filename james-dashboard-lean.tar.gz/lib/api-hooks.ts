
/**
 * James Email Assistant - React Hooks for API Calls
 */

import { useState, useEffect, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { apiClient } from './api-client';

// Generic API hook
export function useApiCall<T = any>(
  apiFunction: () => Promise<any>,
  dependencies: any[] = []
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const execute = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiFunction();
      if (response.success) {
        setData(response.data);
      } else {
        setError(response.error || 'API call failed');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  }, dependencies);

  return { data, loading, error, execute, refetch: execute };
}

// Inbox hooks
export function useInboxSummary() {
  const { data: session } = useSession();
  
  return useApiCall(() => {
    if (session?.accessToken) {
      apiClient.setToken(session.accessToken);
    }
    return apiClient.getInboxSummary();
  }, [session]);
}

export function useInboxSync() {
  const { data: session } = useSession();
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const syncInbox = useCallback(async () => {
    setSyncing(true);
    setError(null);

    try {
      if (session?.accessToken) {
        apiClient.setToken(session.accessToken);
      }
      
      const response = await apiClient.syncInbox();
      
      if (!response.success) {
        setError(response.error || 'Sync failed');
      }
      
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Sync failed';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setSyncing(false);
    }
  }, [session]);

  return { syncInbox, syncing, error };
}

// Tone analysis hooks
export function useToneAnalysis() {
  const { data: session } = useSession();
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const analyzeTone = useCallback(async (content: string, context?: string) => {
    setAnalyzing(true);
    setError(null);

    try {
      if (session?.accessToken) {
        apiClient.setToken(session.accessToken);
      }
      
      const response = await apiClient.analyzeTone(content, context);
      
      if (!response.success) {
        setError(response.error || 'Analysis failed');
      }
      
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Analysis failed';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setAnalyzing(false);
    }
  }, [session]);

  return { analyzeTone, analyzing, error };
}

export function useDraftGeneration() {
  const { data: session } = useSession();
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateDraft = useCallback(async (
    context: string,
    tonePreference?: string,
    keyPoints: string[] = []
  ) => {
    setGenerating(true);
    setError(null);

    try {
      if (session?.accessToken) {
        apiClient.setToken(session.accessToken);
      }
      
      const response = await apiClient.generateDraft(context, tonePreference, keyPoints);
      
      if (!response.success) {
        setError(response.error || 'Generation failed');
      }
      
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Generation failed';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setGenerating(false);
    }
  }, [session]);

  return { generateDraft, generating, error };
}

// Attachment processing hooks
export function useAttachmentProcessing() {
  const { data: session } = useSession();
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processAttachment = useCallback(async (
    file: File,
    threadId?: string,
    messageId?: string,
    processImmediately: boolean = true
  ) => {
    setProcessing(true);
    setError(null);

    try {
      if (session?.accessToken) {
        apiClient.setToken(session.accessToken);
      }
      
      const response = await apiClient.processAttachment(file, threadId, messageId, processImmediately);
      
      if (!response.success) {
        setError(response.error || 'Processing failed');
      }
      
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Processing failed';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setProcessing(false);
    }
  }, [session]);

  return { processAttachment, processing, error };
}

export function useAttachmentInsights(attachmentIds: string[] = [], timeRange: string = '30d') {
  const { data: session } = useSession();
  
  return useApiCall(() => {
    if (session?.accessToken) {
      apiClient.setToken(session.accessToken);
    }
    return apiClient.getAttachmentInsights(attachmentIds, timeRange);
  }, [session, attachmentIds.join(','), timeRange]);
}

// Context intelligence hooks
export function useContextInsights(threadIds: string[] = [], timeframe: string = '7d') {
  const { data: session } = useSession();
  
  return useApiCall(() => {
    if (session?.accessToken) {
      apiClient.setToken(session.accessToken);
    }
    return apiClient.getContextInsights(threadIds, timeframe);
  }, [session, threadIds.join(','), timeframe]);
}

// Health check hook
export function useHealthCheck() {
  return useApiCall(() => apiClient.healthCheck(), []);
}
