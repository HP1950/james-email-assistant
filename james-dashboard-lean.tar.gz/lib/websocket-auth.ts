
import { getToken } from 'next-auth/jwt';
import { NextRequest } from 'next/server';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.NEXTAUTH_SECRET || 'your-secret-key';

export interface WebSocketAuthToken {
  userId: string;
  sessionId: string;
  email: string;
  name?: string;
  role?: string;
  iat: number;
  exp: number;
}

export async function generateWebSocketToken(userId: string, sessionId: string, userData: any): Promise<string> {
  const payload: Omit<WebSocketAuthToken, 'iat' | 'exp'> = {
    userId,
    sessionId,
    email: userData.email,
    name: userData.name,
    role: userData.role,
  };

  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: '24h',
    issuer: 'gmail-assistant',
    audience: 'websocket',
  });
}

export async function verifyWebSocketToken(token: string): Promise<WebSocketAuthToken | null> {
  try {
    const decoded = jwt.verify(token, JWT_SECRET, {
      issuer: 'gmail-assistant',
      audience: 'websocket',
    }) as WebSocketAuthToken;

    return decoded;
  } catch (error) {
    console.error('WebSocket token verification failed:', error);
    return null;
  }
}

export async function authenticateWebSocketFromRequest(req: NextRequest): Promise<WebSocketAuthToken | null> {
  try {
    // Try to get token from NextAuth JWT
    const nextAuthToken = await getToken({ 
      req, 
      secret: JWT_SECRET,
      raw: false 
    });

    if (!nextAuthToken || !nextAuthToken.id) {
      return null;
    }

    // Generate a WebSocket-specific token
    const sessionId = generateSessionId();
    const wsToken = await generateWebSocketToken(
      nextAuthToken.id as string,
      sessionId,
      nextAuthToken
    );

    return await verifyWebSocketToken(wsToken);
  } catch (error) {
    console.error('WebSocket authentication from request failed:', error);
    return null;
  }
}

export function generateSessionId(): string {
  return `ws_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}

export async function refreshWebSocketToken(currentToken: string): Promise<string | null> {
  try {
    const decoded = await verifyWebSocketToken(currentToken);
    if (!decoded) {
      return null;
    }

    // Check if token is close to expiration (within 1 hour)
    const timeUntilExpiry = decoded.exp * 1000 - Date.now();
    if (timeUntilExpiry > 3600000) { // 1 hour
      return currentToken; // Token is still valid for a while
    }

    // Generate new token with same data but fresh expiration
    return await generateWebSocketToken(decoded.userId, decoded.sessionId, decoded);
  } catch (error) {
    console.error('WebSocket token refresh failed:', error);
    return null;
  }
}

export function extractTokenFromQuery(query: string): string | null {
  try {
    const params = new URLSearchParams(query);
    return params.get('token');
  } catch (error) {
    return null;
  }
}

export function extractTokenFromHeaders(headers: { [key: string]: any }): string | null {
  const authHeader = headers.authorization || headers.Authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  return null;
}
