
// Spin-Text Engine for Dynamic Content Variations
import { PrismaClient } from '@prisma/client';
import { SpinTextTemplateData } from './types';

const prisma = new PrismaClient();

export class SpinTextEngine {
  // Parse spin-text and generate variations
  static parseSpinText(spinText: string): string[] {
    const variations: string[] = [];
    
    // Handle nested spin-text with proper parsing
    const spinRegex = /\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}/g;
    
    function generateVariations(text: string, maxVariations = 50): string[] {
      const results: string[] = [];
      const matches = [...text.matchAll(spinRegex)];
      
      if (matches.length === 0) {
        return [text];
      }
      
      function processMatch(currentText: string, matchIndex: number): string[] {
        if (matchIndex >= matches.length) {
          return [currentText];
        }
        
        const match = matches[matchIndex];
        const spinContent = match[1];
        const options = SpinTextEngine.parseSpinOptions(spinContent);
        
        const results: string[] = [];
        
        for (const option of options) {
          const newText = currentText.replace(match[0], option);
          const remainingResults = processMatch(newText, matchIndex + 1);
          results.push(...remainingResults);
          
          if (results.length >= maxVariations) break;
        }
        
        return results;
      }
      
      return processMatch(text, 0);
    }
    
    return generateVariations(spinText, 50);
  }
  
  // Parse spin options from content
  static parseSpinOptions(content: string): string[] {
    // Split by pipe (|) but handle nested structures
    const options: string[] = [];
    let currentOption = '';
    let depth = 0;
    
    for (let i = 0; i < content.length; i++) {
      const char = content[i];
      
      if (char === '{') {
        depth++;
        currentOption += char;
      } else if (char === '}') {
        depth--;
        currentOption += char;
      } else if (char === '|' && depth === 0) {
        options.push(currentOption.trim());
        currentOption = '';
      } else {
        currentOption += char;
      }
    }
    
    // Add the last option
    if (currentOption.trim()) {
      options.push(currentOption.trim());
    }
    
    return options;
  }
  
  // Create spin-text template
  static async createTemplate(templateData: {
    userId: string;
    name: string;
    description?: string;
    category?: string;
    originalText: string;
    spinTextContent: string;
    maxVariations?: number;
  }): Promise<SpinTextTemplateData> {
    // Generate variations
    const variations = this.parseSpinText(templateData.spinTextContent);
    
    // Calculate quality metrics
    const qualityScore = this.calculateQualityScore(variations);
    
    const template = await prisma.spinTextTemplate.create({
      data: {
        ...templateData,
        variationsData: variations,
        maxVariations: templateData.maxVariations || 50,
        qualityScore,
        preserveFormatting: true
      }
    });
    
    // Create individual variation records
    await this.createVariationRecords(template.id, variations);
    
    return template as SpinTextTemplateData;
  }
  
  // Create variation records for tracking
  static async createVariationRecords(templateId: string, variations: string[]) {
    const variationRecords = variations.map((content, index) => ({
      templateId,
      variationIndex: index,
      content
    }));
    
    await prisma.spinTextVariation.createMany({
      data: variationRecords
    });
  }
  
  // Calculate quality score based on variations
  static calculateQualityScore(variations: string[]): number {
    if (variations.length === 0) return 0;
    
    // Factors for quality scoring
    const uniqueness = this.calculateUniqueness(variations);
    const lengthVariety = this.calculateLengthVariety(variations);
    const readability = this.calculateReadability(variations);
    
    return (uniqueness * 0.4 + lengthVariety * 0.3 + readability * 0.3) * 100;
  }
  
  private static calculateUniqueness(variations: string[]): number {
    const uniqueVariations = new Set(variations);
    return uniqueVariations.size / variations.length;
  }
  
  private static calculateLengthVariety(variations: string[]): number {
    if (variations.length === 0) return 0;
    
    const lengths = variations.map(v => v.length);
    const avgLength = lengths.reduce((sum, len) => sum + len, 0) / lengths.length;
    const variance = lengths.reduce((sum, len) => sum + Math.pow(len - avgLength, 2), 0) / lengths.length;
    
    return Math.min(Math.sqrt(variance) / avgLength, 1);
  }
  
  private static calculateReadability(variations: string[]): number {
    // Simple readability score based on word complexity
    let totalScore = 0;
    
    for (const variation of variations) {
      const words = variation.split(/\s+/);
      const avgWordLength = words.reduce((sum, word) => sum + word.length, 0) / words.length;
      const score = Math.max(0, 1 - (avgWordLength - 5) / 10); // Optimal word length around 5 chars
      totalScore += score;
    }
    
    return totalScore / variations.length;
  }
  
  // Test variations for spam score
  static async testVariationsForSpam(templateId: string): Promise<void> {
    const template = await prisma.spinTextTemplate.findUnique({
      where: { id: templateId },
      include: { variations: true }
    });
    
    if (!template) return;
    
    // Update template spam check status
    const avgSpamScore = 2.5; // Placeholder
    
    await prisma.spinTextTemplate.update({
      where: { id: templateId },
      data: {
        spamScoreChecked: true,
        averageSpamScore: avgSpamScore
      }
    });
  }
  
  // Optimize template with AI
  static async optimizeWithAI(templateId: string): Promise<void> {
    await prisma.spinTextTemplate.update({
      where: { id: templateId },
      data: {
        aiOptimized: true,
        aiOptimizedAt: new Date(),
        aiSuggestions: { optimized: true }
      }
    });
  }
}
