
/**
 * James Email Specialist Initialization
 * Sets up all MCP adapters and LangChain capabilities
 */

import { mcpOrchestrator } from '@/lib/mcp/core';
import { jamesOrchestrator } from '@/lib/langchain/orchestrator';
import { InboxManagementAdapter } from '@/lib/adapters/inbox-management';
import { AdaptiveToneAdapter } from '@/lib/adapters/adaptive-tone';
import { JAMES_CONFIG } from './config';

export class JamesInitializer {
  private static instance: JamesInitializer;
  private initialized = false;

  private constructor() {}

  public static getInstance(): JamesInitializer {
    if (!JamesInitializer.instance) {
      JamesInitializer.instance = new JamesInitializer();
    }
    return JamesInitializer.instance;
  }

  /**
   * Initialize James Email Specialist with all capabilities
   * Following the priority order: Quick Wins → Mid-term → Long-term
   */
  public async initialize(): Promise<void> {
    if (this.initialized) {
      console.log('James already initialized');
      return;
    }

    console.log(`Initializing ${JAMES_CONFIG.name} v${JAMES_CONFIG.version}...`);

    try {
      // Phase 1: Quick Wins - Immediate value capabilities
      await this.initializeQuickWins();
      
      // Phase 2: LangChain Orchestration
      await this.initializeLangChainCapabilities();
      
      // Phase 3: Integration and Testing
      await this.validateCapabilities();

      this.initialized = true;
      console.log(`${JAMES_CONFIG.name} initialization complete!`);
      
      // Log success metrics targets
      console.log('Success Metrics Targets:', JAMES_CONFIG.success_metrics);

    } catch (error) {
      console.error('James initialization failed:', error);
      throw new Error(`Failed to initialize James: ${error}`);
    }
  }

  /**
   * Phase 1: Initialize Quick Wins capabilities
   */
  private async initializeQuickWins(): Promise<void> {
    console.log('Phase 1: Initializing Quick Wins...');

    // 1. Proactive Inbox Management
    const inboxAdapter = new InboxManagementAdapter();
    await inboxAdapter.initialize();
    mcpOrchestrator.getRegistry().register(inboxAdapter);
    console.log('✓ Proactive Inbox Management adapter registered');

    // 2. Adaptive Tone Drafting
    const toneAdapter = new AdaptiveToneAdapter();
    await toneAdapter.initialize();
    mcpOrchestrator.getRegistry().register(toneAdapter);
    console.log('✓ Adaptive Tone Drafting adapter registered');

    console.log('Quick Wins initialization complete');
  }

  /**
   * Phase 2: Initialize LangChain orchestration capabilities
   */
  private async initializeLangChainCapabilities(): Promise<void> {
    console.log('Phase 2: Initializing LangChain capabilities...');

    // Create AI agents
    await jamesOrchestrator.createEmailPriorityAgent();
    console.log('✓ Email Priority Agent created');

    await jamesOrchestrator.createAdaptiveToneAgent();
    console.log('✓ Adaptive Tone Agent created');

    // Create analysis chains
    await jamesOrchestrator.createEmailAnalysisChain();
    console.log('✓ Email Analysis Chain created');

    console.log('LangChain capabilities initialization complete');
  }

  /**
   * Phase 3: Validate all capabilities are working
   */
  private async validateCapabilities(): Promise<void> {
    console.log('Phase 3: Validating capabilities...');

    // Check MCP adapters
    const adapters = mcpOrchestrator.getRegistry().getAllAdapters();
    console.log(`✓ ${adapters.length} MCP adapters registered`);

    for (const adapter of adapters) {
      const isHealthy = await adapter.healthCheck();
      if (!isHealthy) {
        throw new Error(`Adapter ${adapter.name} failed health check`);
      }
      console.log(`✓ ${adapter.name} health check passed`);
    }

    // Check LangChain agents
    const priorityAgent = await jamesOrchestrator.getAgent("email-priority-agent");
    const toneAgent = await jamesOrchestrator.getAgent("adaptive-tone-agent");
    const analysisChain = await jamesOrchestrator.getChain("email-analysis-chain");

    if (!priorityAgent || !toneAgent || !analysisChain) {
      throw new Error('LangChain capabilities not properly initialized');
    }

    console.log('✓ All capabilities validated successfully');
  }

  /**
   * Get initialization status
   */
  public getStatus(): {
    initialized: boolean;
    adapters: string[];
    capabilities: string[];
    config: typeof JAMES_CONFIG;
  } {
    const adapters = mcpOrchestrator.getRegistry().getAllAdapters();
    
    return {
      initialized: this.initialized,
      adapters: adapters.map(a => a.name),
      capabilities: adapters.flatMap(a => a.capabilities),
      config: JAMES_CONFIG
    };
  }

  /**
   * Reinitialize James (useful for development/testing)
   */
  public async reinitialize(): Promise<void> {
    this.initialized = false;
    await this.initialize();
  }
}

// Export singleton instance
export const jamesInitializer = JamesInitializer.getInstance();

// Auto-initialize when module is imported (for server startup)
if (typeof window === 'undefined') {
  // Only auto-initialize on server side
  jamesInitializer.initialize().catch(console.error);
}
