
/**
 * James Attachment Processor
 * Advanced document analysis, image processing, and insight extraction
 */

export interface AttachmentMetadata {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  uploadedAt: Date;
  processedAt?: Date;
  userId: string;
  threadId?: string;
  messageId?: string;
}

export interface DocumentAnalysis {
  id: string;
  attachmentId: string;
  documentType: 'pdf' | 'docx' | 'xlsx' | 'pptx' | 'txt' | 'csv' | 'other';
  extractedText: string;
  pageCount?: number;
  wordCount: number;
  language: string;
  summary: string;
  keyTopics: string[];
  actionItems: ActionItemExtraction[];
  decisions: DecisionExtraction[];
  financialData: FinancialDataExtraction[];
  dates: DateExtraction[];
  contacts: ContactExtraction[];
  technicalSpecs: TechnicalSpecExtraction[];
  confidenceScore: number;
  processingTime: number;
}

export interface ImageAnalysis {
  id: string;
  attachmentId: string;
  imageType: 'screenshot' | 'chart' | 'diagram' | 'photo' | 'document_scan' | 'other';
  dimensions: { width: number; height: number };
  extractedText?: string; // OCR results
  visualDescription: string;
  detectedObjects: DetectedObject[];
  chartData?: ChartDataExtraction;
  diagramAnalysis?: DiagramAnalysis;
  brandingElements: BrandingElement[];
  confidenceScore: number;
  processingTime: number;
}

export interface ActionItemExtraction {
  id: string;
  description: string;
  assignee?: string;
  dueDate?: Date;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'in_progress' | 'completed';
  source: 'document_text' | 'table' | 'annotation';
  context: string;
  confidence: number;
}

export interface DecisionExtraction {
  id: string;
  decision: string;
  decisionMaker?: string;
  rationale?: string;
  impact: 'high' | 'medium' | 'low';
  category: 'strategic' | 'operational' | 'financial' | 'technical' | 'other';
  relatedTo: string[];
  confidence: number;
}

export interface FinancialDataExtraction {
  id: string;
  type: 'budget' | 'cost' | 'revenue' | 'expense' | 'investment' | 'other';
  amount: number;
  currency: string;
  period?: string;
  category?: string;
  context: string;
  confidence: number;
}

export interface DateExtraction {
  id: string;
  date: Date;
  type: 'deadline' | 'meeting' | 'milestone' | 'launch' | 'event' | 'other';
  description: string;
  importance: 'high' | 'medium' | 'low';
  context: string;
  confidence: number;
}

export interface ContactExtraction {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  company?: string;
  role?: string;
  context: string;
  confidence: number;
}

export interface TechnicalSpecExtraction {
  id: string;
  category: 'requirements' | 'specifications' | 'api' | 'configuration' | 'other';
  title: string;
  description: string;
  technicalDetails: Record<string, any>;
  priority: 'critical' | 'important' | 'nice_to_have';
  confidence: number;
}

export interface DetectedObject {
  id: string;
  type: string;
  label: string;
  confidence: number;
  boundingBox?: { x: number; y: number; width: number; height: number };
  description?: string;
}

export interface ChartDataExtraction {
  chartType: 'line' | 'bar' | 'pie' | 'scatter' | 'area' | 'other';
  title?: string;
  xAxisLabel?: string;
  yAxisLabel?: string;
  dataPoints: Array<{
    label: string;
    value: number | string;
    category?: string;
  }>;
  trends: string[];
  insights: string[];
  confidence: number;
}

export interface DiagramAnalysis {
  diagramType: 'flowchart' | 'organization' | 'network' | 'process' | 'architecture' | 'other';
  elements: Array<{
    id: string;
    type: 'node' | 'connection' | 'label' | 'group';
    text?: string;
    position?: { x: number; y: number };
    properties: Record<string, any>;
  }>;
  relationships: Array<{
    from: string;
    to: string;
    type: string;
    label?: string;
  }>;
  insights: string[];
  confidence: number;
}

export interface BrandingElement {
  id: string;
  type: 'logo' | 'color_scheme' | 'font' | 'watermark' | 'header' | 'footer';
  description: string;
  properties: Record<string, any>;
  confidence: number;
}

export interface AttachmentInsights {
  attachmentId: string;
  overallSummary: string;
  keyInsights: string[];
  actionRequiredItems: ActionItemExtraction[];
  importantDates: DateExtraction[];
  financialImplications: FinancialDataExtraction[];
  stakeholders: ContactExtraction[];
  riskFactors: string[];
  opportunities: string[];
  recommendedActions: string[];
  relatedDocuments: string[];
  confidenceScore: number;
  processingMetadata: {
    processingTime: number;
    algorithmsUsed: string[];
    dataQuality: 'excellent' | 'good' | 'fair' | 'poor';
  };
}

export class JamesAttachmentProcessor {
  private supportedTypes = {
    documents: ['pdf', 'docx', 'xlsx', 'pptx', 'txt', 'csv', 'rtf', 'odt'],
    images: ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'tiff', 'svg'],
    archives: ['zip', 'rar', '7z', 'tar', 'gz']
  };

  private ocrEngine = 'tesseract'; // Could be upgraded to Google Vision API
  private documentEngine = 'pdfjs'; // Could be upgraded to Azure Form Recognizer
  private imageAnalysisEngine = 'opencv'; // Could be upgraded to GPT-4V

  /**
   * Main attachment processing orchestrator
   */
  async processAttachment(
    attachmentBuffer: Buffer,
    metadata: AttachmentMetadata
  ): Promise<AttachmentInsights> {
    const startTime = Date.now();
    
    try {
      const fileExtension = this.extractFileExtension(metadata.filename);
      const processingStrategy = this.determineProcessingStrategy(fileExtension, metadata.mimeType);
      
      let documentAnalysis: DocumentAnalysis | null = null;
      let imageAnalysis: ImageAnalysis | null = null;
      
      // Process based on file type
      switch (processingStrategy) {
        case 'document':
          documentAnalysis = await this.processDocument(attachmentBuffer, metadata);
          break;
        case 'image':
          imageAnalysis = await this.processImage(attachmentBuffer, metadata);
          break;
        case 'hybrid':
          // Some files like PDFs can contain both text and images
          documentAnalysis = await this.processDocument(attachmentBuffer, metadata);
          imageAnalysis = await this.extractImagesFromDocument(attachmentBuffer, metadata);
          break;
        default:
          throw new Error(`Unsupported file type: ${fileExtension}`);
      }

      // Generate comprehensive insights
      const insights = await this.generateInsights(documentAnalysis, imageAnalysis, metadata);
      
      const processingTime = Date.now() - startTime;
      insights.processingMetadata.processingTime = processingTime;

      return insights;
      
    } catch (error) {
      console.error('Attachment processing error:', error);
      throw new Error(`Failed to process attachment: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Process document files (PDF, DOCX, XLSX, etc.)
   */
  private async processDocument(
    buffer: Buffer,
    metadata: AttachmentMetadata
  ): Promise<DocumentAnalysis> {
    const fileExtension = this.extractFileExtension(metadata.filename);
    let extractedText = '';
    let pageCount = 0;
    
    try {
      switch (fileExtension.toLowerCase()) {
        case 'pdf':
          const pdfData = await this.extractFromPDF(buffer);
          extractedText = pdfData.text;
          pageCount = pdfData.pageCount;
          break;
          
        case 'docx':
          extractedText = await this.extractFromDocx(buffer);
          break;
          
        case 'xlsx':
          extractedText = await this.extractFromXlsx(buffer);
          break;
          
        case 'txt':
          extractedText = buffer.toString('utf-8');
          break;
          
        case 'csv':
          extractedText = await this.processCSV(buffer);
          break;
          
        default:
          // Fallback to basic text extraction
          extractedText = buffer.toString('utf-8');
      }

      // Analyze extracted text
      const analysis = await this.analyzeDocumentText(extractedText, metadata);
      
      return {
        id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        attachmentId: metadata.id,
        documentType: this.classifyDocumentType(fileExtension),
        extractedText: extractedText,
        pageCount: pageCount,
        wordCount: extractedText.split(/\s+/).length,
        language: this.detectLanguage(extractedText),
        summary: analysis.summary,
        keyTopics: analysis.keyTopics,
        actionItems: analysis.actionItems,
        decisions: analysis.decisions,
        financialData: analysis.financialData,
        dates: analysis.dates,
        contacts: analysis.contacts,
        technicalSpecs: analysis.technicalSpecs,
        confidenceScore: analysis.confidenceScore,
        processingTime: Date.now() - Date.now()
      };
      
    } catch (error) {
      console.error('Document processing error:', error);
      throw new Error(`Failed to process document: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Process image files (JPG, PNG, etc.)
   */
  private async processImage(
    buffer: Buffer,
    metadata: AttachmentMetadata
  ): Promise<ImageAnalysis> {
    const startTime = Date.now();
    
    try {
      // Get image metadata
      const imageMetadata = await this.extractImageMetadata(buffer);
      
      // Classify image type
      const imageType = await this.classifyImageType(buffer, metadata);
      
      // Extract text via OCR if needed
      const ocrText = await this.performOCR(buffer, imageType);
      
      // Generate visual description
      const visualDescription = await this.generateVisualDescription(buffer, imageType);
      
      // Detect objects and elements
      const detectedObjects = await this.detectObjects(buffer);
      
      // Specialized analysis based on image type
      let chartData: ChartDataExtraction | undefined;
      let diagramAnalysis: DiagramAnalysis | undefined;
      
      if (imageType === 'chart') {
        chartData = await this.extractChartData(buffer, ocrText);
      } else if (imageType === 'diagram') {
        diagramAnalysis = await this.analyzeDiagram(buffer, ocrText);
      }
      
      // Extract branding elements
      const brandingElements = await this.extractBrandingElements(buffer);
      
      const processingTime = Date.now() - startTime;
      
      return {
        id: `img_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        attachmentId: metadata.id,
        imageType: imageType,
        dimensions: imageMetadata.dimensions,
        extractedText: ocrText,
        visualDescription: visualDescription,
        detectedObjects: detectedObjects,
        chartData: chartData,
        diagramAnalysis: diagramAnalysis,
        brandingElements: brandingElements,
        confidenceScore: 0.85, // Would be calculated based on analysis quality
        processingTime: processingTime
      };
      
    } catch (error) {
      console.error('Image processing error:', error);
      throw new Error(`Failed to process image: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Generate comprehensive insights from all analyses
   */
  private async generateInsights(
    documentAnalysis: DocumentAnalysis | null,
    imageAnalysis: ImageAnalysis | null,
    metadata: AttachmentMetadata
  ): Promise<AttachmentInsights> {
    const insights: string[] = [];
    const actionItems: ActionItemExtraction[] = [];
    const importantDates: DateExtraction[] = [];
    const financialData: FinancialDataExtraction[] = [];
    const stakeholders: ContactExtraction[] = [];
    const riskFactors: string[] = [];
    const opportunities: string[] = [];
    
    // Aggregate insights from document analysis
    if (documentAnalysis) {
      insights.push(`Document contains ${documentAnalysis.wordCount} words across ${documentAnalysis.pageCount || 1} page(s)`);
      insights.push(...documentAnalysis.keyTopics.map(topic => `Key topic identified: ${topic}`));
      
      actionItems.push(...documentAnalysis.actionItems);
      importantDates.push(...documentAnalysis.dates);
      financialData.push(...documentAnalysis.financialData);
      stakeholders.push(...documentAnalysis.contacts);
      
      // Identify risks and opportunities from document content
      riskFactors.push(...this.identifyRisks(documentAnalysis.extractedText));
      opportunities.push(...this.identifyOpportunities(documentAnalysis.extractedText));
    }
    
    // Aggregate insights from image analysis
    if (imageAnalysis) {
      insights.push(`Image analysis: ${imageAnalysis.imageType} with ${imageAnalysis.detectedObjects.length} detected elements`);
      
      if (imageAnalysis.chartData) {
        insights.push(`Chart data extracted: ${imageAnalysis.chartData.chartType} chart with ${imageAnalysis.chartData.dataPoints.length} data points`);
        insights.push(...imageAnalysis.chartData.insights);
      }
      
      if (imageAnalysis.diagramAnalysis) {
        insights.push(`Diagram analysis: ${imageAnalysis.diagramAnalysis.diagramType} with ${imageAnalysis.diagramAnalysis.elements.length} elements`);
        insights.push(...imageAnalysis.diagramAnalysis.insights);
      }
    }
    
    // Generate overall summary
    const overallSummary = this.generateOverallSummary(documentAnalysis, imageAnalysis, metadata);
    
    // Generate recommended actions
    const recommendedActions = this.generateRecommendedActions(actionItems, importantDates, financialData);
    
    // Find related documents (placeholder - would use vector similarity)
    const relatedDocuments = this.findRelatedDocuments(documentAnalysis, imageAnalysis);
    
    // Calculate overall confidence score
    const confidenceScore = this.calculateOverallConfidence(documentAnalysis, imageAnalysis);
    
    return {
      attachmentId: metadata.id,
      overallSummary: overallSummary,
      keyInsights: insights,
      actionRequiredItems: actionItems.filter(item => item.priority === 'high'),
      importantDates: importantDates.sort((a, b) => a.date.getTime() - b.date.getTime()),
      financialImplications: financialData,
      stakeholders: stakeholders,
      riskFactors: riskFactors,
      opportunities: opportunities,
      recommendedActions: recommendedActions,
      relatedDocuments: relatedDocuments,
      confidenceScore: confidenceScore,
      processingMetadata: {
        processingTime: 0, // Set by caller
        algorithmsUsed: this.getAlgorithmsUsed(documentAnalysis, imageAnalysis),
        dataQuality: this.assessDataQuality(documentAnalysis, imageAnalysis)
      }
    };
  }

  // Helper methods for document processing
  private async extractFromPDF(buffer: Buffer): Promise<{ text: string; pageCount: number }> {
    // Placeholder - would use pdf2pic, pdf-parse, or similar
    // For now, return simulated extraction
    const text = `Simulated PDF content extraction from ${buffer.length} bytes`;
    const pageCount = Math.ceil(buffer.length / 5000); // Rough estimate
    
    return { text, pageCount };
  }

  private async extractFromDocx(buffer: Buffer): Promise<string> {
    // Placeholder - would use mammoth.js or similar
    return `Simulated DOCX content extraction from ${buffer.length} bytes`;
  }

  private async extractFromXlsx(buffer: Buffer): Promise<string> {
    // Placeholder - would use xlsx or exceljs
    return `Simulated XLSX content extraction from ${buffer.length} bytes`;
  }

  private async processCSV(buffer: Buffer): Promise<string> {
    const csvContent = buffer.toString('utf-8');
    const lines = csvContent.split('\n');
    const header = lines[0];
    const rowCount = lines.length - 1;
    
    return `CSV file with header: ${header}\nContains ${rowCount} rows of data\n\n${csvContent}`;
  }

  // Helper methods for image processing
  private async extractImageMetadata(buffer: Buffer): Promise<{ dimensions: { width: number; height: number } }> {
    // Placeholder - would use sharp or similar
    return {
      dimensions: {
        width: 1920, // Simulated
        height: 1080
      }
    };
  }

  private async classifyImageType(buffer: Buffer, metadata: AttachmentMetadata): Promise<ImageAnalysis['imageType']> {
    const filename = metadata.filename.toLowerCase();
    
    if (filename.includes('chart') || filename.includes('graph')) return 'chart';
    if (filename.includes('diagram') || filename.includes('flow')) return 'diagram';
    if (filename.includes('screenshot') || filename.includes('screen')) return 'screenshot';
    if (filename.includes('scan') || filename.includes('document')) return 'document_scan';
    
    // Would use image classification AI here
    return 'other';
  }

  private async performOCR(buffer: Buffer, imageType: string): Promise<string> {
    // Placeholder - would use Tesseract.js, Google Vision API, or Azure Cognitive Services
    if (imageType === 'document_scan' || imageType === 'screenshot') {
      return `Simulated OCR text extraction from ${imageType}`;
    }
    return '';
  }

  private async generateVisualDescription(buffer: Buffer, imageType: string): Promise<string> {
    // Placeholder - would use GPT-4V, Google Vision API, or similar
    const descriptions = {
      chart: 'A business chart showing data trends and metrics',
      diagram: 'A technical diagram illustrating process flow or system architecture',
      screenshot: 'A screenshot of an application or website interface',
      photo: 'A photograph containing people, objects, or scenery',
      document_scan: 'A scanned document with text and possible graphics',
      other: 'An image file with various visual elements'
    };
    
    return descriptions[imageType as keyof typeof descriptions] || descriptions.other;
  }

  private async detectObjects(buffer: Buffer): Promise<DetectedObject[]> {
    // Placeholder - would use YOLO, TensorFlow, or similar
    return [
      {
        id: 'obj_1',
        type: 'text_block',
        label: 'Text Block',
        confidence: 0.95,
        boundingBox: { x: 100, y: 50, width: 300, height: 100 },
        description: 'Text content block'
      }
    ];
  }

  private async extractChartData(buffer: Buffer, ocrText: string): Promise<ChartDataExtraction> {
    // Placeholder - would analyze chart elements and extract data
    return {
      chartType: 'bar',
      title: 'Sample Chart Title',
      xAxisLabel: 'Categories',
      yAxisLabel: 'Values',
      dataPoints: [
        { label: 'Q1', value: 100, category: 'quarterly' },
        { label: 'Q2', value: 150, category: 'quarterly' },
        { label: 'Q3', value: 120, category: 'quarterly' }
      ],
      trends: ['Upward trend in Q2', 'Slight decline in Q3'],
      insights: ['Strong Q2 performance', 'Need to investigate Q3 decline'],
      confidence: 0.87
    };
  }

  private async analyzeDiagram(buffer: Buffer, ocrText: string): Promise<DiagramAnalysis> {
    // Placeholder - would analyze diagram structure
    return {
      diagramType: 'flowchart',
      elements: [
        {
          id: 'elem_1',
          type: 'node',
          text: 'Start Process',
          position: { x: 100, y: 50 },
          properties: { shape: 'rectangle', color: 'blue' }
        }
      ],
      relationships: [
        {
          from: 'elem_1',
          to: 'elem_2',
          type: 'arrow',
          label: 'leads to'
        }
      ],
      insights: ['Process flow shows clear progression', 'Decision points identified'],
      confidence: 0.82
    };
  }

  private async extractBrandingElements(buffer: Buffer): Promise<BrandingElement[]> {
    // Placeholder - would detect logos, colors, fonts, etc.
    return [
      {
        id: 'brand_1',
        type: 'color_scheme',
        description: 'Corporate blue and white color scheme',
        properties: { primaryColor: '#0066cc', secondaryColor: '#ffffff' },
        confidence: 0.78
      }
    ];
  }

  private async extractImagesFromDocument(buffer: Buffer, metadata: AttachmentMetadata): Promise<ImageAnalysis | null> {
    // Placeholder - would extract embedded images from documents
    // For now, return null indicating no images found
    return null;
  }

  // Analysis helper methods
  private async analyzeDocumentText(text: string, metadata: AttachmentMetadata) {
    const actionItems = this.extractActionItemsFromText(text);
    const decisions = this.extractDecisionsFromText(text);
    const financialData = this.extractFinancialDataFromText(text);
    const dates = this.extractDatesFromText(text);
    const contacts = this.extractContactsFromText(text);
    const technicalSpecs = this.extractTechnicalSpecsFromText(text);
    const keyTopics = this.extractKeyTopicsFromText(text);
    const summary = this.generateTextSummary(text, keyTopics);
    
    return {
      summary,
      keyTopics,
      actionItems,
      decisions,
      financialData,
      dates,
      contacts,
      technicalSpecs,
      confidenceScore: 0.85
    };
  }

  private extractActionItemsFromText(text: string): ActionItemExtraction[] {
    const actionPatterns = [
      /(?:action item|todo|task|follow up|must do|need to|should):\s*(.+?)(?:\.|$)/gi,
      /(?:assigned to|responsibility|owner):\s*(.+?)(?:\.|$)/gi,
      /(?:due by|deadline|by date):\s*(.+?)(?:\.|$)/gi
    ];
    
    const actionItems: ActionItemExtraction[] = [];
    let match;
    
    actionPatterns.forEach(pattern => {
      while ((match = pattern.exec(text)) !== null) {
        if (match[1] && match[1].length > 5) {
          actionItems.push({
            id: `action_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            description: match[1].trim(),
            priority: this.assessPriority(match[1]),
            status: 'pending',
            source: 'document_text',
            context: this.extractContext(text, match.index!),
            confidence: 0.8
          });
        }
      }
    });
    
    return actionItems;
  }

  private extractDecisionsFromText(text: string): DecisionExtraction[] {
    const decisionPatterns = [
      /(?:decided|decision|agreed|concluded|determined|approved|rejected)(?:\s+to|\s+that)?\s+(.+?)(?:\.|$)/gi,
      /(?:final decision|resolution|outcome):\s*(.+?)(?:\.|$)/gi
    ];
    
    const decisions: DecisionExtraction[] = [];
    let match;
    
    decisionPatterns.forEach(pattern => {
      while ((match = pattern.exec(text)) !== null) {
        if (match[1] && match[1].length > 5) {
          decisions.push({
            id: `decision_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            decision: match[1].trim(),
            impact: this.assessDecisionImpact(match[1]),
            category: this.classifyDecision(match[1]),
            relatedTo: [],
            confidence: 0.75
          });
        }
      }
    });
    
    return decisions;
  }

  private extractFinancialDataFromText(text: string): FinancialDataExtraction[] {
    const currencyPatterns = [
      /\$([0-9,]+\.?[0-9]*)/g,
      /([0-9,]+\.?[0-9]*)\s*(USD|EUR|GBP|CAD|AUD)/gi,
      /(?:budget|cost|price|revenue|expense|investment|funding):\s*\$?([0-9,]+\.?[0-9]*)/gi
    ];
    
    const financialData: FinancialDataExtraction[] = [];
    let match;
    
    currencyPatterns.forEach(pattern => {
      while ((match = pattern.exec(text)) !== null) {
        const amount = parseFloat(match[1].replace(/,/g, ''));
        if (!isNaN(amount) && amount > 0) {
          financialData.push({
            id: `financial_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            type: this.classifyFinancialType(text, match.index!),
            amount: amount,
            currency: match[2] || 'USD',
            context: this.extractContext(text, match.index!),
            confidence: 0.85
          });
        }
      }
    });
    
    return financialData;
  }

  private extractDatesFromText(text: string): DateExtraction[] {
    const datePatterns = [
      /(?:due|deadline|by|until|before)\s+(\d{1,2}\/\d{1,2}\/\d{4})/gi,
      /(?:meeting|call|event)\s+(?:on|at)?\s*(\d{1,2}\/\d{1,2}\/\d{4})/gi,
      /(\d{4}-\d{2}-\d{2})/g,
      /(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2},?\s+\d{4}/gi
    ];
    
    const dates: DateExtraction[] = [];
    let match;
    
    datePatterns.forEach(pattern => {
      while ((match = pattern.exec(text)) !== null) {
        const dateStr = match[1] || match[0];
        const parsedDate = new Date(dateStr);
        
        if (!isNaN(parsedDate.getTime())) {
          dates.push({
            id: `date_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            date: parsedDate,
            type: this.classifyDateType(text, match.index!),
            description: this.extractContext(text, match.index!, 50),
            importance: this.assessDateImportance(text, match.index!),
            context: this.extractContext(text, match.index!),
            confidence: 0.8
          });
        }
      }
    });
    
    return dates;
  }

  private extractContactsFromText(text: string): ContactExtraction[] {
    const emailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g;
    const phonePattern = /(\+?\d{1,4}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{0,9})/g;
    
    const contacts: ContactExtraction[] = [];
    const foundEmails = new Set<string>();
    const foundPhones = new Set<string>();
    
    let match;
    
    // Extract emails
    while ((match = emailPattern.exec(text)) !== null) {
      const email = match[1];
      if (!foundEmails.has(email)) {
        foundEmails.add(email);
        contacts.push({
          id: `contact_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: this.extractNameFromEmail(email),
          email: email,
          context: this.extractContext(text, match.index!),
          confidence: 0.9
        });
      }
    }
    
    // Extract phone numbers
    while ((match = phonePattern.exec(text)) !== null) {
      const phone = match[1];
      if (!foundPhones.has(phone) && this.isValidPhoneNumber(phone)) {
        foundPhones.add(phone);
        contacts.push({
          id: `contact_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: this.extractNameNearPhone(text, match.index!),
          phone: phone,
          context: this.extractContext(text, match.index!),
          confidence: 0.75
        });
      }
    }
    
    return contacts;
  }

  private extractTechnicalSpecsFromText(text: string): TechnicalSpecExtraction[] {
    const techPatterns = [
      /(?:requirement|specification|spec|api|config|configuration):\s*(.+?)(?:\.|$)/gi,
      /(?:version|build|release)\s+([0-9]+\.[0-9]+(?:\.[0-9]+)?)/gi,
      /(?:port|url|endpoint):\s*(.+?)(?:\s|$)/gi
    ];
    
    const technicalSpecs: TechnicalSpecExtraction[] = [];
    let match;
    
    techPatterns.forEach(pattern => {
      while ((match = pattern.exec(text)) !== null) {
        if (match[1] && match[1].length > 3) {
          technicalSpecs.push({
            id: `tech_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            category: this.classifyTechnicalCategory(match[0]),
            title: match[1].trim(),
            description: this.extractContext(text, match.index!),
            technicalDetails: this.extractTechnicalDetails(match[1]),
            priority: this.assessTechnicalPriority(match[1]),
            confidence: 0.8
          });
        }
      }
    });
    
    return technicalSpecs;
  }

  private extractKeyTopicsFromText(text: string): string[] {
    const words = text.toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 3);
    
    const stopWords = new Set([
      'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
      'by', 'from', 'up', 'about', 'into', 'through', 'during', 'before',
      'after', 'above', 'below', 'between', 'among', 'this', 'that', 'these',
      'those', 'they', 'them', 'their', 'there', 'then', 'than', 'would',
      'could', 'should', 'will', 'have', 'been', 'said', 'each', 'which'
    ]);
    
    const wordFreq = new Map<string, number>();
    words.forEach(word => {
      if (!stopWords.has(word)) {
        wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
      }
    });
    
    return Array.from(wordFreq.entries())
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .filter(([,freq]) => freq > 1)
      .map(([word]) => word);
  }

  private generateTextSummary(text: string, keyTopics: string[]): string {
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 20);
    const wordCount = text.split(/\s+/).length;
    
    let summary = `Document contains ${wordCount} words. `;
    
    if (keyTopics.length > 0) {
      summary += `Main topics include: ${keyTopics.slice(0, 3).join(', ')}. `;
    }
    
    // Simple extractive summarization - take first and last sentences
    if (sentences.length >= 2) {
      summary += `${sentences[0].trim()}. `;
      if (sentences.length > 2) {
        summary += `${sentences[sentences.length - 1].trim()}.`;
      }
    }
    
    return summary.trim();
  }

  // Utility methods
  private extractFileExtension(filename: string): string {
    const lastDot = filename.lastIndexOf('.');
    return lastDot !== -1 ? filename.substring(lastDot + 1) : '';
  }

  private determineProcessingStrategy(extension: string, mimeType: string): 'document' | 'image' | 'hybrid' {
    const ext = extension.toLowerCase();
    
    if (this.supportedTypes.documents.includes(ext)) {
      return ext === 'pdf' ? 'hybrid' : 'document';
    }
    
    if (this.supportedTypes.images.includes(ext)) {
      return 'image';
    }
    
    // Default to document for unknown types
    return 'document';
  }

  private classifyDocumentType(extension: string): DocumentAnalysis['documentType'] {
    const ext = extension.toLowerCase();
    const typeMap: Record<string, DocumentAnalysis['documentType']> = {
      'pdf': 'pdf',
      'docx': 'docx',
      'doc': 'docx',
      'xlsx': 'xlsx',
      'xls': 'xlsx',
      'pptx': 'pptx',
      'ppt': 'pptx',
      'txt': 'txt',
      'csv': 'csv'
    };
    
    return typeMap[ext] || 'other';
  }

  private detectLanguage(text: string): string {
    // Simple language detection - would use a proper library like franc
    const commonEnglishWords = ['the', 'and', 'is', 'in', 'to', 'of', 'a', 'that', 'it', 'with'];
    const words = text.toLowerCase().split(/\s+/);
    const englishWordCount = words.filter(word => commonEnglishWords.includes(word)).length;
    const englishRatio = englishWordCount / Math.min(words.length, 100);
    
    return englishRatio > 0.1 ? 'en' : 'unknown';
  }

  private extractContext(text: string, position: number, length: number = 100): string {
    const start = Math.max(0, position - length / 2);
    const end = Math.min(text.length, position + length / 2);
    return text.substring(start, end).trim();
  }

  private assessPriority(content: string): ActionItemExtraction['priority'] {
    const highPriorityWords = ['urgent', 'critical', 'asap', 'immediately', 'high priority'];
    const lowPriorityWords = ['when possible', 'eventually', 'low priority', 'nice to have'];
    
    const lowerContent = content.toLowerCase();
    
    if (highPriorityWords.some(word => lowerContent.includes(word))) return 'high';
    if (lowPriorityWords.some(word => lowerContent.includes(word))) return 'low';
    return 'medium';
  }

  private assessDecisionImpact(decision: string): DecisionExtraction['impact'] {
    const highImpactWords = ['budget', 'strategy', 'hire', 'fire', 'acquire', 'merge', 'partnership'];
    const lowImpactWords = ['meeting', 'schedule', 'minor', 'small'];
    
    const lowerDecision = decision.toLowerCase();
    
    if (highImpactWords.some(word => lowerDecision.includes(word))) return 'high';
    if (lowImpactWords.some(word => lowerDecision.includes(word))) return 'low';
    return 'medium';
  }

  private classifyDecision(decision: string): DecisionExtraction['category'] {
    const categories = {
      strategic: ['strategy', 'vision', 'mission', 'direction', 'goal', 'objective'],
      financial: ['budget', 'cost', 'investment', 'revenue', 'expense', 'funding'],
      technical: ['system', 'software', 'hardware', 'technology', 'development', 'architecture'],
      operational: ['process', 'procedure', 'workflow', 'operation', 'execution']
    };
    
    const lowerDecision = decision.toLowerCase();
    
    for (const [category, keywords] of Object.entries(categories)) {
      if (keywords.some(keyword => lowerDecision.includes(keyword))) {
        return category as DecisionExtraction['category'];
      }
    }
    
    return 'other';
  }

  private classifyFinancialType(text: string, position: number): FinancialDataExtraction['type'] {
    const context = this.extractContext(text, position, 50).toLowerCase();
    
    if (context.includes('budget')) return 'budget';
    if (context.includes('cost') || context.includes('expense')) return 'expense';
    if (context.includes('revenue') || context.includes('income')) return 'revenue';
    if (context.includes('investment') || context.includes('funding')) return 'investment';
    
    return 'other';
  }

  private classifyDateType(text: string, position: number): DateExtraction['type'] {
    const context = this.extractContext(text, position, 50).toLowerCase();
    
    if (context.includes('deadline') || context.includes('due')) return 'deadline';
    if (context.includes('meeting') || context.includes('call')) return 'meeting';
    if (context.includes('milestone')) return 'milestone';
    if (context.includes('launch') || context.includes('release')) return 'launch';
    if (context.includes('event')) return 'event';
    
    return 'other';
  }

  private assessDateImportance(text: string, position: number): DateExtraction['importance'] {
    const context = this.extractContext(text, position, 50).toLowerCase();
    
    if (context.includes('critical') || context.includes('urgent') || context.includes('important')) return 'high';
    if (context.includes('optional') || context.includes('nice to have')) return 'low';
    return 'medium';
  }

  private extractNameFromEmail(email: string): string {
    const localPart = email.split('@')[0];
    return localPart.replace(/[._-]/g, ' ').split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  private isValidPhoneNumber(phone: string): boolean {
    const cleanPhone = phone.replace(/[^\d]/g, '');
    return cleanPhone.length >= 10 && cleanPhone.length <= 15;
  }

  private extractNameNearPhone(text: string, position: number): string {
    const context = this.extractContext(text, position, 100);
    const words = context.split(/\s+/);
    
    // Simple name extraction - look for capitalized words
    const capitalizedWords = words.filter(word => /^[A-Z][a-z]+$/.test(word));
    return capitalizedWords.slice(0, 2).join(' ') || 'Unknown';
  }

  private classifyTechnicalCategory(match: string): TechnicalSpecExtraction['category'] {
    const lowerMatch = match.toLowerCase();
    
    if (lowerMatch.includes('requirement')) return 'requirements';
    if (lowerMatch.includes('spec')) return 'specifications';
    if (lowerMatch.includes('api')) return 'api';
    if (lowerMatch.includes('config')) return 'configuration';
    
    return 'other';
  }

  private extractTechnicalDetails(content: string): Record<string, any> {
    const details: Record<string, any> = {};
    
    // Extract version numbers
    const versionMatch = content.match(/([0-9]+\.[0-9]+(?:\.[0-9]+)?)/);
    if (versionMatch) {
      details.version = versionMatch[1];
    }
    
    // Extract URLs
    const urlMatch = content.match(/(https?:\/\/[^\s]+)/);
    if (urlMatch) {
      details.url = urlMatch[1];
    }
    
    // Extract port numbers
    const portMatch = content.match(/port\s*:?\s*([0-9]+)/i);
    if (portMatch) {
      details.port = parseInt(portMatch[1]);
    }
    
    return details;
  }

  private assessTechnicalPriority(content: string): TechnicalSpecExtraction['priority'] {
    const lowerContent = content.toLowerCase();
    
    if (lowerContent.includes('critical') || lowerContent.includes('required')) return 'critical';
    if (lowerContent.includes('optional') || lowerContent.includes('nice')) return 'nice_to_have';
    return 'important';
  }

  private identifyRisks(text: string): string[] {
    const riskKeywords = ['risk', 'threat', 'vulnerability', 'concern', 'issue', 'problem', 'challenge'];
    const risks: string[] = [];
    
    const sentences = text.split(/[.!?]+/);
    sentences.forEach(sentence => {
      const lowerSentence = sentence.toLowerCase();
      if (riskKeywords.some(keyword => lowerSentence.includes(keyword))) {
        risks.push(sentence.trim());
      }
    });
    
    return risks.slice(0, 5); // Limit to top 5 risks
  }

  private identifyOpportunities(text: string): string[] {
    const opportunityKeywords = ['opportunity', 'benefit', 'advantage', 'potential', 'growth', 'improvement'];
    const opportunities: string[] = [];
    
    const sentences = text.split(/[.!?]+/);
    sentences.forEach(sentence => {
      const lowerSentence = sentence.toLowerCase();
      if (opportunityKeywords.some(keyword => lowerSentence.includes(keyword))) {
        opportunities.push(sentence.trim());
      }
    });
    
    return opportunities.slice(0, 5); // Limit to top 5 opportunities
  }

  private generateOverallSummary(
    documentAnalysis: DocumentAnalysis | null,
    imageAnalysis: ImageAnalysis | null,
    metadata: AttachmentMetadata
  ): string {
    let summary = `Processed ${metadata.filename} (${(metadata.size / 1024).toFixed(1)} KB). `;
    
    if (documentAnalysis) {
      summary += `Document contains ${documentAnalysis.wordCount} words with ${documentAnalysis.keyTopics.length} key topics identified. `;
      if (documentAnalysis.actionItems.length > 0) {
        summary += `Found ${documentAnalysis.actionItems.length} action items. `;
      }
      if (documentAnalysis.decisions.length > 0) {
        summary += `Identified ${documentAnalysis.decisions.length} decisions. `;
      }
    }
    
    if (imageAnalysis) {
      summary += `Image analysis reveals ${imageAnalysis.imageType} with ${imageAnalysis.detectedObjects.length} elements detected. `;
    }
    
    return summary.trim();
  }

  private generateRecommendedActions(
    actionItems: ActionItemExtraction[],
    dates: DateExtraction[],
    financialData: FinancialDataExtraction[]
  ): string[] {
    const recommendations: string[] = [];
    
    // Action item recommendations
    const highPriorityActions = actionItems.filter(item => item.priority === 'high');
    if (highPriorityActions.length > 0) {
      recommendations.push(`Follow up on ${highPriorityActions.length} high-priority action items`);
    }
    
    // Date recommendations
    const upcomingDates = dates.filter(date => 
      date.date > new Date() && 
      date.date < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // Next 30 days
    );
    if (upcomingDates.length > 0) {
      recommendations.push(`Monitor ${upcomingDates.length} upcoming important dates`);
    }
    
    // Financial recommendations
    if (financialData.length > 0) {
      const totalAmount = financialData.reduce((sum, item) => sum + item.amount, 0);
      if (totalAmount > 10000) {
        recommendations.push('Review significant financial implications mentioned in document');
      }
    }
    
    return recommendations;
  }

  private findRelatedDocuments(
    documentAnalysis: DocumentAnalysis | null,
    imageAnalysis: ImageAnalysis | null
  ): string[] {
    // Placeholder - would use vector similarity search or keyword matching
    // Return simulated related documents
    return [
      'Previous contract v2.1.pdf',
      'Budget proposal Q4.xlsx',
      'Project timeline diagram.png'
    ];
  }

  private calculateOverallConfidence(
    documentAnalysis: DocumentAnalysis | null,
    imageAnalysis: ImageAnalysis | null
  ): number {
    let totalConfidence = 0;
    let count = 0;
    
    if (documentAnalysis) {
      totalConfidence += documentAnalysis.confidenceScore;
      count++;
    }
    
    if (imageAnalysis) {
      totalConfidence += imageAnalysis.confidenceScore;
      count++;
    }
    
    return count > 0 ? totalConfidence / count : 0.5;
  }

  private getAlgorithmsUsed(
    documentAnalysis: DocumentAnalysis | null,
    imageAnalysis: ImageAnalysis | null
  ): string[] {
    const algorithms: string[] = [];
    
    if (documentAnalysis) {
      algorithms.push('text_extraction', 'nlp_analysis', 'pattern_matching');
    }
    
    if (imageAnalysis) {
      algorithms.push('ocr', 'object_detection', 'visual_analysis');
    }
    
    return algorithms;
  }

  private assessDataQuality(
    documentAnalysis: DocumentAnalysis | null,
    imageAnalysis: ImageAnalysis | null
  ): AttachmentInsights['processingMetadata']['dataQuality'] {
    let qualityScore = 0;
    let factors = 0;
    
    if (documentAnalysis) {
      qualityScore += documentAnalysis.confidenceScore;
      factors++;
      
      // Adjust based on text length and structure
      if (documentAnalysis.wordCount > 1000) qualityScore += 0.1;
      if (documentAnalysis.keyTopics.length > 5) qualityScore += 0.05;
    }
    
    if (imageAnalysis) {
      qualityScore += imageAnalysis.confidenceScore;
      factors++;
      
      // Adjust based on detected elements
      if (imageAnalysis.detectedObjects.length > 3) qualityScore += 0.1;
    }
    
    const avgScore = factors > 0 ? qualityScore / factors : 0.5;
    
    if (avgScore >= 0.9) return 'excellent';
    if (avgScore >= 0.8) return 'good';
    if (avgScore >= 0.6) return 'fair';
    return 'poor';
  }

  /**
   * Get supported file types
   */
  getSupportedTypes() {
    return this.supportedTypes;
  }

  /**
   * Check if file type is supported
   */
  isSupported(filename: string, mimeType?: string): boolean {
    const extension = this.extractFileExtension(filename).toLowerCase();
    
    return Object.values(this.supportedTypes)
      .flat()
      .includes(extension);
  }

  /**
   * Get processing capabilities for file type
   */
  getProcessingCapabilities(filename: string): {
    textExtraction: boolean;
    imageAnalysis: boolean;
    structuredData: boolean;
    ocrCapable: boolean;
  } {
    const extension = this.extractFileExtension(filename).toLowerCase();
    
    return {
      textExtraction: this.supportedTypes.documents.includes(extension) || this.supportedTypes.images.includes(extension),
      imageAnalysis: this.supportedTypes.images.includes(extension) || extension === 'pdf',
      structuredData: ['xlsx', 'csv', 'pdf'].includes(extension),
      ocrCapable: this.supportedTypes.images.includes(extension) || extension === 'pdf'
    };
  }
}

export const jamesAttachmentProcessor = new JamesAttachmentProcessor();
