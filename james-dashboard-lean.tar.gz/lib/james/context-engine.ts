
/**
 * James Context Engine
 * Advanced thread analysis, conversation memory, and document surfacing
 */

export interface EmailThread {
  thread_id: string;
  participants: string[];
  subject_line: string;
  message_count: number;
  date_range: {
    first_message: Date;
    last_message: Date;
  };
  messages: ThreadMessage[];
  conversation_summary: string;
  key_topics: string[];
  action_items: ActionItem[];
  decisions_made: Decision[];
  attachments: ThreadAttachment[];
}

export interface ThreadMessage {
  message_id: string;
  sender: string;
  timestamp: Date;
  content: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  message_type: 'question' | 'answer' | 'update' | 'request' | 'decision' | 'other';
  references_previous: boolean;
  key_points: string[];
}

export interface ActionItem {
  id: string;
  description: string;
  assignee: string | null;
  due_date: Date | null;
  status: 'pending' | 'completed' | 'overdue';
  mentioned_in_message: string;
  context: string;
}

export interface Decision {
  id: string;
  decision: string;
  decision_maker: string;
  rationale: string;
  timestamp: Date;
  referenced_messages: string[];
  impact_level: 'high' | 'medium' | 'low';
}

export interface ThreadAttachment {
  id: string;
  filename: string;
  type: string;
  size: number;
  message_id: string;
  summary: string;
  key_insights: string[];
  action_items_extracted: ActionItem[];
}

export interface ContextualInsight {
  type: 'related_thread' | 'past_decision' | 'recurring_topic' | 'follow_up_needed';
  relevance_score: number;
  title: string;
  description: string;
  source_reference: string;
  suggested_action: string | null;
  confidence: number;
}

export interface ConversationContext {
  user_id: string;
  contact_email: string;
  relationship_history: {
    first_contact: Date;
    total_exchanges: number;
    avg_response_time: number;
    communication_frequency: 'daily' | 'weekly' | 'monthly' | 'occasional';
    tone_evolution: Array<{
      period: string;
      formality_trend: number;
      sentiment_trend: number;
    }>;
  };
  recurring_topics: Array<{
    topic: string;
    frequency: number;
    last_discussed: Date;
    typical_outcome: string;
  }>;
  pending_items: ActionItem[];
  shared_context: Array<{
    context_type: 'project' | 'meeting' | 'document' | 'deadline';
    name: string;
    status: string;
    last_mentioned: Date;
    importance: number;
  }>;
  conversation_patterns: {
    preferred_communication_style: string;
    typical_response_length: 'brief' | 'detailed' | 'varies';
    decision_making_style: 'quick' | 'deliberate' | 'collaborative';
    follow_up_expectations: string;
  };
}

export class JamesContextEngine {
  private conversationContexts: Map<string, ConversationContext> = new Map();
  private threadAnalyses: Map<string, EmailThread> = new Map();
  
  /**
   * Analyze email thread for context and insights
   */
  async analyzeEmailThread(messages: any[]): Promise<EmailThread> {
    if (!messages.length) {
      throw new Error('No messages provided for thread analysis');
    }

    const threadId = this.extractThreadId(messages);
    const participants = this.extractParticipants(messages);
    const subjectLine = messages[0]?.subject || 'No Subject';
    
    // Sort messages chronologically
    const sortedMessages = messages.sort((a, b) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    // Process each message for insights
    const processedMessages = await Promise.all(
      sortedMessages.map(msg => this.processThreadMessage(msg, sortedMessages))
    );

    // Extract conversation elements
    const actionItems = this.extractActionItems(processedMessages);
    const decisions = this.extractDecisions(processedMessages);
    const keyTopics = this.extractKeyTopics(processedMessages);
    const attachments = await this.processThreadAttachments(sortedMessages);
    
    // Generate conversation summary
    const conversationSummary = await this.generateThreadSummary(
      processedMessages, actionItems, decisions, keyTopics
    );

    const thread: EmailThread = {
      thread_id: threadId,
      participants,
      subject_line: subjectLine,
      message_count: messages.length,
      date_range: {
        first_message: new Date(sortedMessages[0].timestamp),
        last_message: new Date(sortedMessages[sortedMessages.length - 1].timestamp)
      },
      messages: processedMessages,
      conversation_summary: conversationSummary,
      key_topics: keyTopics,
      action_items: actionItems,
      decisions_made: decisions,
      attachments: attachments
    };

    // Cache the analysis
    this.threadAnalyses.set(threadId, thread);
    
    return thread;
  }

  /**
   * Process individual message within thread context
   */
  private async processThreadMessage(
    message: any, 
    fullThread: any[]
  ): Promise<ThreadMessage> {
    const content = message.content || message.body || '';
    
    // Analyze message sentiment
    const sentiment = this.analyzeSentiment(content);
    
    // Classify message type
    const messageType = this.classifyMessageType(content);
    
    // Check if references previous messages
    const referencesPrevious = this.checkForReferences(content, fullThread);
    
    // Extract key points
    const keyPoints = this.extractKeyPoints(content);

    return {
      message_id: message.id || message.message_id,
      sender: message.from || message.sender,
      timestamp: new Date(message.timestamp || message.date),
      content: content,
      sentiment: sentiment,
      message_type: messageType,
      references_previous: referencesPrevious,
      key_points: keyPoints
    };
  }

  /**
   * Extract action items from thread messages
   */
  private extractActionItems(messages: ThreadMessage[]): ActionItem[] {
    const actionItems: ActionItem[] = [];
    const actionPatterns = [
      /(?:please|could you|can you|need to|should|must|will)\s+(.+?)(?:\.|$)/gi,
      /(?:action item|todo|task|follow up):\s*(.+?)(?:\.|$)/gi,
      /(?:by|due|deadline)\s+(.+?)(?:\.|$)/gi,
      /(?:assigned to|responsibility|owner):\s*(.+?)(?:\.|$)/gi
    ];

    messages.forEach(message => {
      actionPatterns.forEach(pattern => {
        let match;
        while ((match = pattern.exec(message.content)) !== null) {
          if (match[1] && match[1].length > 5) {
            const actionItem: ActionItem = {
              id: `ai_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              description: match[1].trim(),
              assignee: this.extractAssignee(match[1], message.content),
              due_date: this.extractDueDate(match[1], message.content),
              status: 'pending',
              mentioned_in_message: message.message_id,
              context: this.extractActionContext(match[1], message.content)
            };
            
            actionItems.push(actionItem);
          }
        }
      });
    });

    return this.deduplicateActionItems(actionItems);
  }

  /**
   * Extract decisions made in thread
   */
  private extractDecisions(messages: ThreadMessage[]): Decision[] {
    const decisions: Decision[] = [];
    const decisionPatterns = [
      /(?:decided|decision|agreed|concluded|determined|resolved)(?:\s+to|\s+that)?\s+(.+?)(?:\.|$)/gi,
      /(?:we will|let's|going forward|final decision):\s*(.+?)(?:\.|$)/gi,
      /(?:approved|rejected|accepted|declined):\s*(.+?)(?:\.|$)/gi
    ];

    messages.forEach(message => {
      decisionPatterns.forEach(pattern => {
        let match;
        while ((match = pattern.exec(message.content)) !== null) {
          if (match[1] && match[1].length > 5) {
            const decision: Decision = {
              id: `dec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              decision: match[1].trim(),
              decision_maker: message.sender,
              rationale: this.extractDecisionRationale(match[1], message.content),
              timestamp: message.timestamp,
              referenced_messages: [message.message_id],
              impact_level: this.assessDecisionImpact(match[1])
            };
            
            decisions.push(decision);
          }
        }
      });
    });

    return decisions;
  }

  /**
   * Extract key topics from thread
   */
  private extractKeyTopics(messages: ThreadMessage[]): string[] {
    const allContent = messages.map(m => m.content).join(' ');
    const words = allContent.toLowerCase().split(/\s+/);
    
    // Filter out common words and short words
    const stopWords = new Set([
      'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
      'by', 'from', 'up', 'about', 'into', 'through', 'during', 'before', 
      'after', 'above', 'below', 'between', 'among', 'this', 'that', 'these',
      'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'a', 'an', 'is',
      'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do',
      'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can'
    ]);

    const wordFreq = new Map<string, number>();
    
    words.forEach(word => {
      const cleaned = word.replace(/[^\w]/g, '').toLowerCase();
      if (cleaned.length > 3 && !stopWords.has(cleaned)) {
        wordFreq.set(cleaned, (wordFreq.get(cleaned) || 0) + 1);
      }
    });

    // Get top topics by frequency
    const topTopics = Array.from(wordFreq.entries())
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .filter(([,freq]) => freq > 1)
      .map(([word]) => word);

    // Add phrase extraction for better context
    const phrases = this.extractKeyPhrases(allContent);
    
    return [...topTopics, ...phrases].slice(0, 15);
  }

  /**
   * Process attachments in thread for context
   */
  private async processThreadAttachments(messages: any[]): Promise<ThreadAttachment[]> {
    const attachments: ThreadAttachment[] = [];
    
    messages.forEach(message => {
      if (message.attachments && Array.isArray(message.attachments)) {
        message.attachments.forEach((att: any) => {
          const attachment: ThreadAttachment = {
            id: att.id || `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            filename: att.filename || att.name || 'Unknown',
            type: att.type || att.mimeType || 'unknown',
            size: att.size || 0,
            message_id: message.id,
            summary: this.generateAttachmentSummary(att),
            key_insights: this.extractAttachmentInsights(att),
            action_items_extracted: this.extractAttachmentActionItems(att)
          };
          
          attachments.push(attachment);
        });
      }
    });

    return attachments;
  }

  /**
   * Generate comprehensive thread summary
   */
  private async generateThreadSummary(
    messages: ThreadMessage[],
    actionItems: ActionItem[],
    decisions: Decision[],
    keyTopics: string[]
  ): Promise<string> {
    const participantCount = new Set(messages.map(m => m.sender)).size;
    const timeSpan = this.calculateTimeSpan(messages);
    const primarySentiment = this.calculateOverallSentiment(messages);
    
    let summary = `Thread involving ${participantCount} participant${participantCount > 1 ? 's' : ''} `;
    summary += `over ${timeSpan}. `;
    
    if (keyTopics.length > 0) {
      summary += `Main topics discussed: ${keyTopics.slice(0, 3).join(', ')}. `;
    }
    
    if (decisions.length > 0) {
      summary += `${decisions.length} decision${decisions.length > 1 ? 's' : ''} made. `;
    }
    
    if (actionItems.length > 0) {
      summary += `${actionItems.length} action item${actionItems.length > 1 ? 's' : ''} identified. `;
    }
    
    summary += `Overall tone: ${primarySentiment}.`;
    
    return summary;
  }

  /**
   * Build conversation context for contact
   */
  async buildConversationContext(
    userId: string, 
    contactEmail: string, 
    historicalThreads: EmailThread[]
  ): Promise<ConversationContext> {
    const existingContext = this.conversationContexts.get(`${userId}-${contactEmail}`);
    
    // Calculate relationship metrics
    const firstContact = historicalThreads.reduce((earliest, thread) => 
      thread.date_range.first_message < earliest ? thread.date_range.first_message : earliest,
      new Date()
    );
    
    const totalExchanges = historicalThreads.reduce((sum, thread) => sum + thread.message_count, 0);
    
    // Analyze communication patterns
    const recurringTopics = this.analyzeRecurringTopics(historicalThreads);
    const pendingItems = this.aggregatePendingItems(historicalThreads);
    const sharedContext = this.buildSharedContext(historicalThreads);
    
    const context: ConversationContext = {
      user_id: userId,
      contact_email: contactEmail,
      relationship_history: {
        first_contact: firstContact,
        total_exchanges: totalExchanges,
        avg_response_time: this.calculateAvgResponseTime(historicalThreads),
        communication_frequency: this.determineCommunicationFrequency(historicalThreads),
        tone_evolution: this.analyzeToneEvolution(historicalThreads)
      },
      recurring_topics: recurringTopics,
      pending_items: pendingItems,
      shared_context: sharedContext,
      conversation_patterns: {
        preferred_communication_style: this.determinePreferredStyle(historicalThreads),
        typical_response_length: this.analyzeResponseLength(historicalThreads),
        decision_making_style: this.analyzeDecisionStyle(historicalThreads),
        follow_up_expectations: this.analyzeFollowUpPatterns(historicalThreads)
      }
    };

    this.conversationContexts.set(`${userId}-${contactEmail}`, context);
    return context;
  }

  /**
   * Get contextual insights for new email composition
   */
  async getContextualInsights(
    userId: string,
    contactEmail: string,
    currentSubject: string,
    currentContent: string
  ): Promise<ContextualInsight[]> {
    const insights: ContextualInsight[] = [];
    const context = this.conversationContexts.get(`${userId}-${contactEmail}`);
    
    if (!context) {
      return insights;
    }

    // Check for related threads
    const relatedThreads = this.findRelatedThreads(currentSubject, currentContent);
    relatedThreads.forEach(thread => {
      insights.push({
        type: 'related_thread',
        relevance_score: thread.relevance,
        title: `Related: ${thread.subject_line}`,
        description: `Similar discussion from ${thread.date_range.last_message.toLocaleDateString()}`,
        source_reference: thread.thread_id,
        suggested_action: `Review previous thread for context`,
        confidence: 0.8
      });
    });

    // Check for pending action items
    context.pending_items.forEach(item => {
      if (item.status === 'pending' && this.isRelevantToCurrentEmail(item, currentContent)) {
        insights.push({
          type: 'follow_up_needed',
          relevance_score: 0.9,
          title: 'Pending Action Item',
          description: item.description,
          source_reference: item.mentioned_in_message,
          suggested_action: `Follow up on: ${item.description}`,
          confidence: 0.85
        });
      }
    });

    // Check for recurring topics
    context.recurring_topics.forEach(topic => {
      if (this.topicMatchesContent(topic.topic, currentContent)) {
        insights.push({
          type: 'recurring_topic',
          relevance_score: topic.frequency / 10,
          title: `Recurring Topic: ${topic.topic}`,
          description: `Last discussed ${topic.last_discussed.toLocaleDateString()}`,
          source_reference: '',
          suggested_action: `Consider ${topic.typical_outcome}`,
          confidence: 0.75
        });
      }
    });

    return insights.sort((a, b) => b.relevance_score - a.relevance_score).slice(0, 5);
  }

  // Helper methods
  private extractThreadId(messages: any[]): string {
    return messages[0]?.thread_id || messages[0]?.threadId || 
           `thread_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private extractParticipants(messages: any[]): string[] {
    const participants = new Set<string>();
    messages.forEach(msg => {
      if (msg.from) participants.add(msg.from);
      if (msg.to) {
        const recipients = Array.isArray(msg.to) ? msg.to : [msg.to];
        recipients.forEach((recipient: string) => participants.add(recipient));
      }
    });
    return Array.from(participants);
  }

  private analyzeSentiment(content: string): 'positive' | 'negative' | 'neutral' {
    const positiveWords = ['thank', 'great', 'excellent', 'good', 'appreciate', 'perfect'];
    const negativeWords = ['sorry', 'problem', 'issue', 'concern', 'disappointed', 'urgent'];
    
    const words = content.toLowerCase().split(/\s+/);
    let positiveCount = 0;
    let negativeCount = 0;
    
    words.forEach(word => {
      if (positiveWords.some(pw => word.includes(pw))) positiveCount++;
      if (negativeWords.some(nw => word.includes(nw))) negativeCount++;
    });
    
    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }

  private classifyMessageType(content: string): ThreadMessage['message_type'] {
    const questionMarkers = ['?', 'what', 'how', 'when', 'where', 'who', 'why', 'could you', 'can you'];
    const updateMarkers = ['update', 'status', 'progress', 'completed', 'finished'];
    const requestMarkers = ['please', 'need', 'require', 'request'];
    const decisionMarkers = ['decided', 'decision', 'approved', 'rejected'];
    
    const lowerContent = content.toLowerCase();
    
    if (questionMarkers.some(marker => lowerContent.includes(marker))) return 'question';
    if (decisionMarkers.some(marker => lowerContent.includes(marker))) return 'decision';
    if (updateMarkers.some(marker => lowerContent.includes(marker))) return 'update';
    if (requestMarkers.some(marker => lowerContent.includes(marker))) return 'request';
    
    return 'other';
  }

  private checkForReferences(content: string, fullThread: any[]): boolean {
    const referencePatterns = [
      /as mentioned/i, /previously/i, /earlier/i, /above/i, /below/i,
      /your email/i, /your message/i, /you said/i, /you mentioned/i
    ];
    
    return referencePatterns.some(pattern => pattern.test(content));
  }

  private extractKeyPoints(content: string): string[] {
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 10);
    return sentences.slice(0, 3).map(s => s.trim());
  }

  private extractAssignee(description: string, fullContent: string): string | null {
    const assigneePatterns = [
      /@(\w+)/,
      /assigned to (\w+)/i,
      /(\w+) will handle/i,
      /(\w+)'s responsibility/i
    ];
    
    for (const pattern of assigneePatterns) {
      const match = fullContent.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }
    
    return null;
  }

  private extractDueDate(description: string, fullContent: string): Date | null {
    const datePatterns = [
      /by (\w+ \d{1,2})/i,
      /due (\w+ \d{1,2})/i,
      /deadline (\w+ \d{1,2})/i,
      /(\d{1,2}\/\d{1,2}\/\d{4})/
    ];
    
    for (const pattern of datePatterns) {
      const match = fullContent.match(pattern);
      if (match && match[1]) {
        const parsed = new Date(match[1]);
        if (!isNaN(parsed.getTime())) {
          return parsed;
        }
      }
    }
    
    return null;
  }

  private extractActionContext(description: string, fullContent: string): string {
    const sentences = fullContent.split(/[.!?]+/);
    const contextSentence = sentences.find(s => s.includes(description.substring(0, 20)));
    return contextSentence ? contextSentence.trim() : description;
  }

  private deduplicateActionItems(items: ActionItem[]): ActionItem[] {
    const seen = new Set<string>();
    return items.filter(item => {
      const key = item.description.toLowerCase().substring(0, 50);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  private extractDecisionRationale(decision: string, fullContent: string): string {
    // Look for explanatory text near the decision
    const sentences = fullContent.split(/[.!?]+/);
    const decisionIndex = sentences.findIndex(s => s.toLowerCase().includes(decision.substring(0, 20).toLowerCase()));
    
    if (decisionIndex >= 0 && decisionIndex < sentences.length - 1) {
      return sentences[decisionIndex + 1]?.trim() || 'No rationale provided';
    }
    
    return 'No rationale provided';
  }

  private assessDecisionImpact(decision: string): Decision['impact_level'] {
    const highImpactWords = ['budget', 'strategy', 'hire', 'fire', 'contract', 'partnership'];
    const mediumImpactWords = ['process', 'timeline', 'meeting', 'deadline'];
    
    const lowerDecision = decision.toLowerCase();
    
    if (highImpactWords.some(word => lowerDecision.includes(word))) return 'high';
    if (mediumImpactWords.some(word => lowerDecision.includes(word))) return 'medium';
    return 'low';
  }

  private extractKeyPhrases(content: string): string[] {
    const phrases: string[] = [];
    // Simple noun phrase extraction
    const nounPhrases = content.match(/\b[A-Z][a-z]+ [a-z]+\b/g) || [];
    phrases.push(...nounPhrases.slice(0, 5));
    return phrases;
  }

  private generateAttachmentSummary(attachment: any): string {
    return `${attachment.filename || 'Unknown file'} (${attachment.type || 'unknown type'})`;
  }

  private extractAttachmentInsights(attachment: any): string[] {
    // Placeholder for attachment content analysis
    return [`File type: ${attachment.type}`, `Size: ${attachment.size} bytes`];
  }

  private extractAttachmentActionItems(attachment: any): ActionItem[] {
    // Placeholder for PDF/document action item extraction
    return [];
  }

  private calculateTimeSpan(messages: ThreadMessage[]): string {
    const first = messages[0]?.timestamp;
    const last = messages[messages.length - 1]?.timestamp;
    
    if (!first || !last) return 'unknown timespan';
    
    const diffMs = last.getTime() - first.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'same day';
    if (diffDays === 1) return '1 day';
    if (diffDays < 7) return `${diffDays} days`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks`;
    return `${Math.floor(diffDays / 30)} months`;
  }

  private calculateOverallSentiment(messages: ThreadMessage[]): string {
    const sentimentCounts = { positive: 0, negative: 0, neutral: 0 };
    messages.forEach(msg => sentimentCounts[msg.sentiment]++);
    
    const dominant = Object.entries(sentimentCounts)
      .sort(([,a], [,b]) => b - a)[0][0];
    
    return dominant;
  }

  // Placeholder methods for conversation context analysis
  private analyzeRecurringTopics(threads: EmailThread[]): ConversationContext['recurring_topics'] {
    return [];
  }

  private aggregatePendingItems(threads: EmailThread[]): ActionItem[] {
    return threads.flatMap(thread => thread.action_items.filter(item => item.status === 'pending'));
  }

  private buildSharedContext(threads: EmailThread[]): ConversationContext['shared_context'] {
    return [];
  }

  private calculateAvgResponseTime(threads: EmailThread[]): number {
    return 24; // hours - placeholder
  }

  private determineCommunicationFrequency(threads: EmailThread[]): ConversationContext['relationship_history']['communication_frequency'] {
    return 'weekly';
  }

  private analyzeToneEvolution(threads: EmailThread[]): ConversationContext['relationship_history']['tone_evolution'] {
    return [];
  }

  private determinePreferredStyle(threads: EmailThread[]): string {
    return 'professional';
  }

  private analyzeResponseLength(threads: EmailThread[]): ConversationContext['conversation_patterns']['typical_response_length'] {
    return 'detailed';
  }

  private analyzeDecisionStyle(threads: EmailThread[]): ConversationContext['conversation_patterns']['decision_making_style'] {
    return 'collaborative';
  }

  private analyzeFollowUpPatterns(threads: EmailThread[]): string {
    return 'Expects follow-up within 48 hours';
  }

  private findRelatedThreads(subject: string, content: string): Array<{ thread_id: string; subject_line: string; relevance: number; date_range: { last_message: Date } }> {
    return [];
  }

  private isRelevantToCurrentEmail(item: ActionItem, content: string): boolean {
    return content.toLowerCase().includes(item.description.toLowerCase().substring(0, 20));
  }

  private topicMatchesContent(topic: string, content: string): boolean {
    return content.toLowerCase().includes(topic.toLowerCase());
  }
}

export const jamesContextEngine = new JamesContextEngine();
