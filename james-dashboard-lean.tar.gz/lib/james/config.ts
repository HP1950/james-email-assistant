
/**
 * James Email Specialist Configuration
 * Based on the directive provided by user
 */

export const JAMES_CONFIG = {
  name: "James_Email_Specialist",
  version: "1.0",
  description: "Directive for James to evolve into the best-in-class email assistant. Scope is EMAIL ONLY (no calendar, SMS, or docs yet). Goal: Maximize UX, intelligence, and autonomy within the inbox.",
  
  objectives: [
    "Proactive Inbox Management",
    "Adaptive Tone Drafting", 
    "Contextual Intelligence",
    "Deep Attachments Handling",
    "Agent-to-Agent Email Protocols",
    "Offline + Privacy-First Edge Emailing"
  ],
  
  capabilities: {
    inbox_management: {
      learn_priority_patterns: true,
      daily_summary: ["urgent", "fyi", "spam", "archive"],
      detect_recurring_ignored_senders: true
    },
    adaptive_tone: {
      sentiment_analysis: true,
      role_based_drafting: ["friendly", "formal", "persuasive"],
      mirror_mode: "train_on_past_emails"
    },
    context_awareness: {
      thread_history_recall: true,
      summarize_past_exchanges: true,
      auto_surface_relevant_docs: true
    },
    attachments_handling: {
      summarize_docs: ["PDF", "Word", "Invoices"],
      extract_action_items: true,
      suggest_followups: true
    },
    agent_protocols: {
      detect_machine_messages: true,
      auto_handle_structured_requests: true,
      log_agent_transactions: true
    },
    edge_privacy: {
      local_first: true,
      no_external_sending_without_auth: true,
      dx_m1_ready: true
    }
  },
  
  future_extensions: [
    "Calendar and task manager integration",
    "Multimodal expansion (voice/SMS/docs)"
  ],
  
  priority_order: {
    quick_wins: [
      "Proactive Inbox Management",
      "Adaptive Tone Drafting"
    ],
    mid_term: [
      "Contextual Intelligence", 
      "Attachments Handling"
    ],
    long_term: [
      "Agent-to-Agent Protocols",
      "Edge Neuromorphic Deployment"
    ]
  },
  
  success_metrics: {
    categorization_accuracy: 0.90, // >90%
    draft_acceptance_rate: 0.15, // <15% user edits after Mirror Mode training
    context_recall_accuracy: 0.85, // >85% for threads older than 30 days
    attachment_task_extraction_accuracy: 0.95, // 95%
    agent_protocol_validation: "Passes vendor invoice & structured email tests"
  }
} as const;
