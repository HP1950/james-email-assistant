
/**
 * James Tone Engine
 * Advanced sentiment analysis and tone matching for email drafting
 */

export interface SentimentAnalysis {
  sentiment: 'positive' | 'negative' | 'neutral';
  intensity: number; // 0-1 scale
  emotions: string[];
  confidence: number;
  key_phrases: string[];
  context_markers: string[];
}

export interface ToneProfile {
  formality_level: number; // 0-1 (casual to formal)
  enthusiasm_level: number; // 0-1 (reserved to energetic)
  directness_level: number; // 0-1 (diplomatic to blunt)
  emoji_usage: number; // 0-1 (never to frequent)
  sentence_length: 'short' | 'medium' | 'long';
  greeting_style: 'formal' | 'casual' | 'friendly' | 'professional';
  closing_style: 'formal' | 'casual' | 'warm' | 'brief';
  vocabulary_complexity: 'simple' | 'moderate' | 'complex';
  punctuation_style: 'minimal' | 'standard' | 'expressive';
}

export interface UserWritingStyle {
  user_id: string;
  base_tone: ToneProfile;
  context_variations: {
    [context: string]: Partial<ToneProfile>; // e.g., 'work', 'family', 'vendor'
  };
  learned_phrases: string[];
  signature_patterns: string[];
  mirror_mode_confidence: number;
  sample_count: number;
  last_updated: Date;
}

export interface DraftRequest {
  recipient_email: string;
  recipient_context: 'work' | 'personal' | 'vendor' | 'family' | 'formal' | 'unknown';
  subject: string;
  original_email?: {
    content: string;
    sender: string;
    sentiment: SentimentAnalysis;
  };
  draft_intent: 'reply' | 'forward' | 'new' | 'follow_up';
  key_points: string[];
  desired_tone?: Partial<ToneProfile>;
  mirror_mode: boolean;
}

export interface GeneratedDraft {
  subject: string;
  body: string;
  tone_analysis: {
    predicted_tone: ToneProfile;
    confidence_score: number;
    mirror_accuracy: number;
  };
  alternatives: Array<{
    body: string;
    tone_variant: string;
    use_case: string;
  }>;
  explanation: string;
  estimated_edit_probability: number;
}

export class JamesToneEngine {
  private userStyles: Map<string, UserWritingStyle> = new Map();
  
  /**
   * Analyze sentiment and tone of email content
   */
  async analyzeSentiment(content: string, context?: string): Promise<SentimentAnalysis> {
    // Use LangChain for advanced sentiment analysis
    const cleanContent = content.replace(/[<>]/g, '').trim();
    
    // Extract emotional indicators
    const positiveWords = ['thank', 'great', 'excellent', 'appreciate', 'wonderful', 'amazing', 'love', 'fantastic', 'perfect'];
    const negativeWords = ['sorry', 'problem', 'issue', 'concern', 'disappointed', 'frustrated', 'urgent', 'difficult'];
    const emotionalWords = ['excited', 'worried', 'confused', 'confident', 'hopeful', 'anxious'];
    
    let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
    let intensity = 0.5;
    let confidence = 0.7;
    
    const words = cleanContent.toLowerCase().split(/\s+/);
    const totalWords = words.length;
    
    let positiveCount = 0;
    let negativeCount = 0;
    const foundEmotions: string[] = [];
    const keyPhrases: string[] = [];
    const contextMarkers: string[] = [];
    
    // Analyze word sentiment
    words.forEach(word => {
      if (positiveWords.some(pw => word.includes(pw))) {
        positiveCount++;
        keyPhrases.push(word);
      }
      if (negativeWords.some(nw => word.includes(nw))) {
        negativeCount++;
        keyPhrases.push(word);
      }
      if (emotionalWords.some(ew => word.includes(ew))) {
        foundEmotions.push(word);
      }
    });
    
    // Determine overall sentiment
    if (positiveCount > negativeCount) {
      sentiment = 'positive';
      intensity = Math.min(0.9, 0.5 + (positiveCount / totalWords) * 2);
    } else if (negativeCount > positiveCount) {
      sentiment = 'negative';
      intensity = Math.min(0.9, 0.5 + (negativeCount / totalWords) * 2);
    }
    
    // Context markers
    if (content.includes('urgent') || content.includes('asap')) {
      contextMarkers.push('urgent');
    }
    if (content.includes('meeting') || content.includes('call')) {
      contextMarkers.push('scheduling');
    }
    if (content.includes('?')) {
      contextMarkers.push('inquiry');
    }
    
    return {
      sentiment,
      intensity,
      emotions: foundEmotions,
      confidence,
      key_phrases: keyPhrases,
      context_markers: contextMarkers
    };
  }

  /**
   * Extract user's writing style from email samples
   */
  async analyzeUserWritingStyle(userId: string, emailSamples: Array<{
    content: string;
    context: string;
    recipient_type: string;
  }>): Promise<UserWritingStyle> {
    let existingStyle = this.userStyles.get(userId);
    
    if (!existingStyle) {
      existingStyle = {
        user_id: userId,
        base_tone: {
          formality_level: 0.6,
          enthusiasm_level: 0.5,
          directness_level: 0.5,
          emoji_usage: 0.1,
          sentence_length: 'medium',
          greeting_style: 'professional',
          closing_style: 'formal',
          vocabulary_complexity: 'moderate',
          punctuation_style: 'standard'
        },
        context_variations: {},
        learned_phrases: [],
        signature_patterns: [],
        mirror_mode_confidence: 0.3,
        sample_count: 0,
        last_updated: new Date()
      };
    }

    // Analyze each sample
    for (const sample of emailSamples) {
      const analysis = await this.extractStyleFromSample(sample.content);
      
      // Update base tone (weighted average)
      const weight = 0.1; // Learning rate
      existingStyle.base_tone.formality_level = 
        existingStyle.base_tone.formality_level * (1 - weight) + analysis.formality_level * weight;
      existingStyle.base_tone.enthusiasm_level = 
        existingStyle.base_tone.enthusiasm_level * (1 - weight) + analysis.enthusiasm_level * weight;
      existingStyle.base_tone.directness_level = 
        existingStyle.base_tone.directness_level * (1 - weight) + analysis.directness_level * weight;
      existingStyle.base_tone.emoji_usage = 
        existingStyle.base_tone.emoji_usage * (1 - weight) + analysis.emoji_usage * weight;
      
      // Update context variations
      if (sample.context && sample.context !== 'unknown') {
        existingStyle.context_variations[sample.context] = analysis;
      }
      
      // Extract signature phrases
      const phrases = this.extractSignaturePhrases(sample.content);
      existingStyle.learned_phrases.push(...phrases);
      
      existingStyle.sample_count++;
    }
    
    // Calculate mirror mode confidence
    existingStyle.mirror_mode_confidence = Math.min(0.95, 
      0.3 + (existingStyle.sample_count * 0.05)
    );
    
    existingStyle.last_updated = new Date();
    this.userStyles.set(userId, existingStyle);
    
    return existingStyle;
  }

  /**
   * Extract style characteristics from a single email sample
   */
  private async extractStyleFromSample(content: string): Promise<ToneProfile> {
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const words = content.split(/\s+/);
    const totalWords = words.length;
    
    // Analyze formality
    const formalWords = ['regarding', 'furthermore', 'therefore', 'consequently', 'sincerely'];
    const casualWords = ['hey', 'cool', 'awesome', 'yeah', 'ok', 'thanks!'];
    
    let formalityScore = 0.5;
    formalWords.forEach(word => {
      if (content.toLowerCase().includes(word)) formalityScore += 0.1;
    });
    casualWords.forEach(word => {
      if (content.toLowerCase().includes(word)) formalityScore -= 0.1;
    });
    formalityScore = Math.max(0, Math.min(1, formalityScore));
    
    // Analyze enthusiasm
    const enthusiasticWords = ['excited', 'amazing', 'fantastic', 'love', '!'];
    let enthusiasmScore = 0.3;
    const exclamationCount = (content.match(/!/g) || []).length;
    enthusiasmScore += Math.min(0.4, exclamationCount * 0.1);
    enthusiasticWords.forEach(word => {
      if (content.toLowerCase().includes(word)) enthusiasmScore += 0.05;
    });
    enthusiasmScore = Math.max(0, Math.min(1, enthusiasmScore));
    
    // Analyze directness
    const directWords = ['need', 'require', 'must', 'should', 'will'];
    const diplomaticWords = ['perhaps', 'maybe', 'could', 'might', 'possibly'];
    
    let directnessScore = 0.5;
    directWords.forEach(word => {
      if (content.toLowerCase().includes(word)) directnessScore += 0.08;
    });
    diplomaticWords.forEach(word => {
      if (content.toLowerCase().includes(word)) directnessScore -= 0.08;
    });
    directnessScore = Math.max(0, Math.min(1, directnessScore));
    
    // Analyze emoji usage
    const emojiCount = (content.match(/[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu) || []).length;
    const emojiUsage = Math.min(1, emojiCount / 50);
    
    // Determine sentence length preference
    const avgSentenceLength = sentences.reduce((sum, s) => sum + s.trim().split(' ').length, 0) / sentences.length;
    let sentenceLength: 'short' | 'medium' | 'long' = 'medium';
    if (avgSentenceLength < 10) sentenceLength = 'short';
    else if (avgSentenceLength > 20) sentenceLength = 'long';
    
    // Analyze greeting and closing styles
    const greetingStyle = this.detectGreetingStyle(content);
    const closingStyle = this.detectClosingStyle(content);
    
    // Vocabulary complexity
    const complexWords = words.filter(word => word.length > 7).length;
    const vocabularyComplexity = complexWords / totalWords > 0.15 ? 'complex' : 
                                complexWords / totalWords > 0.08 ? 'moderate' : 'simple';
    
    // Punctuation style
    const punctuationCount = (content.match(/[!?;:]/g) || []).length;
    const punctuationStyle = punctuationCount > totalWords * 0.05 ? 'expressive' :
                             punctuationCount < totalWords * 0.01 ? 'minimal' : 'standard';
    
    return {
      formality_level: formalityScore,
      enthusiasm_level: enthusiasmScore,
      directness_level: directnessScore,
      emoji_usage: emojiUsage,
      sentence_length: sentenceLength,
      greeting_style: greetingStyle,
      closing_style: closingStyle,
      vocabulary_complexity: vocabularyComplexity as 'simple' | 'moderate' | 'complex',
      punctuation_style: punctuationStyle as 'minimal' | 'standard' | 'expressive'
    };
  }

  /**
   * Detect greeting style from content
   */
  private detectGreetingStyle(content: string): 'formal' | 'casual' | 'friendly' | 'professional' {
    const lowerContent = content.toLowerCase();
    
    if (lowerContent.includes('dear sir') || lowerContent.includes('to whom')) return 'formal';
    if (lowerContent.includes('hey') || lowerContent.includes('hi there')) return 'casual';
    if (lowerContent.includes('hope you')) return 'friendly';
    return 'professional';
  }

  /**
   * Detect closing style from content
   */
  private detectClosingStyle(content: string): 'formal' | 'casual' | 'warm' | 'brief' {
    const lowerContent = content.toLowerCase();
    
    if (lowerContent.includes('sincerely') || lowerContent.includes('respectfully')) return 'formal';
    if (lowerContent.includes('cheers') || lowerContent.includes('talk soon')) return 'casual';
    if (lowerContent.includes('warm regards') || lowerContent.includes('with love')) return 'warm';
    return 'brief';
  }

  /**
   * Extract signature phrases that user commonly uses
   */
  private extractSignaturePhrases(content: string): string[] {
    const commonPhrases = [
      'thank you for your time',
      'looking forward to hearing',
      'please let me know',
      'hope this helps',
      'any questions',
      'best regards'
    ];
    
    const foundPhrases: string[] = [];
    const lowerContent = content.toLowerCase();
    
    commonPhrases.forEach(phrase => {
      if (lowerContent.includes(phrase)) {
        foundPhrases.push(phrase);
      }
    });
    
    return foundPhrases;
  }

  /**
   * Generate email draft with Mirror Mode
   */
  async generateDraft(request: DraftRequest): Promise<GeneratedDraft> {
    const userStyle = this.userStyles.get(request.recipient_email) || await this.getDefaultStyle();
    
    // Determine context-specific tone
    let contextTone = userStyle.base_tone;
    if (request.recipient_context && userStyle.context_variations[request.recipient_context]) {
      contextTone = { ...contextTone, ...userStyle.context_variations[request.recipient_context] };
    }
    
    // Apply desired tone overrides
    if (request.desired_tone) {
      contextTone = { ...contextTone, ...request.desired_tone };
    }

    // Generate draft components
    const greeting = this.generateGreeting(request.recipient_email, contextTone);
    const body = await this.generateBody(request.key_points, contextTone, request.original_email);
    const closing = this.generateClosing(contextTone, userStyle.learned_phrases);
    
    const fullBody = `${greeting}\n\n${body}\n\n${closing}`;
    
    // Generate alternatives
    const alternatives = await this.generateAlternatives(request, contextTone);
    
    // Calculate confidence metrics
    const mirrorAccuracy = request.mirror_mode ? userStyle.mirror_mode_confidence : 0.7;
    const confidenceScore = Math.min(0.95, mirrorAccuracy * 0.8 + 0.2);
    const editProbability = Math.max(0.05, 1 - confidenceScore);

    return {
      subject: this.enhanceSubject(request.subject, contextTone),
      body: fullBody,
      tone_analysis: {
        predicted_tone: contextTone,
        confidence_score: confidenceScore,
        mirror_accuracy: mirrorAccuracy
      },
      alternatives: alternatives,
      explanation: this.generateExplanation(contextTone, request),
      estimated_edit_probability: editProbability
    };
  }

  private async getDefaultStyle(): Promise<UserWritingStyle> {
    return {
      user_id: 'default',
      base_tone: {
        formality_level: 0.6,
        enthusiasm_level: 0.5,
        directness_level: 0.5,
        emoji_usage: 0.1,
        sentence_length: 'medium',
        greeting_style: 'professional',
        closing_style: 'formal',
        vocabulary_complexity: 'moderate',
        punctuation_style: 'standard'
      },
      context_variations: {},
      learned_phrases: ['thank you', 'please let me know', 'best regards'],
      signature_patterns: [],
      mirror_mode_confidence: 0.5,
      sample_count: 0,
      last_updated: new Date()
    };
  }

  private generateGreeting(recipientEmail: string, tone: ToneProfile): string {
    const name = recipientEmail.split('@')[0];
    const capitalizedName = name.charAt(0).toUpperCase() + name.slice(1);
    
    switch (tone.greeting_style) {
      case 'formal':
        return `Dear ${capitalizedName},`;
      case 'casual':
        return `Hey ${capitalizedName},`;
      case 'friendly':
        return `Hi ${capitalizedName}!\n\nHope you're doing well.`;
      default:
        return `Hi ${capitalizedName},`;
    }
  }

  private async generateBody(keyPoints: string[], tone: ToneProfile, originalEmail?: any): Promise<string> {
    let body = '';
    
    // Add context response if replying
    if (originalEmail) {
      body += 'Thank you for your email. ';
    }
    
    // Generate main content based on key points
    keyPoints.forEach((point, index) => {
      if (index > 0) body += '\n\n';
      
      // Adjust sentence structure based on tone
      if (tone.directness_level > 0.7) {
        body += point;
      } else if (tone.formality_level > 0.7) {
        body += `I would like to inform you that ${point.toLowerCase()}`;
      } else {
        body += `I wanted to let you know that ${point.toLowerCase()}`;
      }
      
      // Add enthusiasm if needed
      if (tone.enthusiasm_level > 0.6 && Math.random() > 0.5) {
        body += tone.emoji_usage > 0.3 ? ' 🙂' : '!';
      }
    });
    
    return body;
  }

  private generateClosing(tone: ToneProfile, learnedPhrases: string[]): string {
    // Use learned phrases if available
    if (learnedPhrases.length > 0 && Math.random() > 0.3) {
      return learnedPhrases[Math.floor(Math.random() * learnedPhrases.length)];
    }
    
    switch (tone.closing_style) {
      case 'formal':
        return 'Sincerely,';
      case 'casual':
        return 'Cheers,';
      case 'warm':
        return 'Warm regards,';
      default:
        return 'Best regards,';
    }
  }

  private async generateAlternatives(request: DraftRequest, baseTone: ToneProfile): Promise<Array<{
    body: string;
    tone_variant: string;
    use_case: string;
  }>> {
    const alternatives = [];
    
    // More formal variant
    const formalTone = { ...baseTone, formality_level: Math.min(1, baseTone.formality_level + 0.3) };
    const formalGreeting = this.generateGreeting(request.recipient_email, formalTone);
    const formalBody = await this.generateBody(request.key_points, formalTone, request.original_email);
    const formalClosing = this.generateClosing(formalTone, []);
    
    alternatives.push({
      body: `${formalGreeting}\n\n${formalBody}\n\n${formalClosing}`,
      tone_variant: 'More Formal',
      use_case: 'Use for important business communications'
    });
    
    // More casual variant
    const casualTone = { ...baseTone, formality_level: Math.max(0, baseTone.formality_level - 0.3) };
    const casualGreeting = this.generateGreeting(request.recipient_email, casualTone);
    const casualBody = await this.generateBody(request.key_points, casualTone, request.original_email);
    const casualClosing = this.generateClosing(casualTone, ['Thanks!', 'Talk soon']);
    
    alternatives.push({
      body: `${casualGreeting}\n\n${casualBody}\n\n${casualClosing}`,
      tone_variant: 'More Casual',
      use_case: 'Use for friendly or internal communications'
    });
    
    return alternatives;
  }

  private enhanceSubject(originalSubject: string, tone: ToneProfile): string {
    if (!originalSubject) return 'Follow-up';
    
    // Add formality markers if needed
    if (tone.formality_level > 0.8 && !originalSubject.toLowerCase().includes('re:')) {
      return `Re: ${originalSubject}`;
    }
    
    // Add enthusiasm if appropriate
    if (tone.enthusiasm_level > 0.7 && !originalSubject.includes('!')) {
      return `${originalSubject}!`;
    }
    
    return originalSubject;
  }

  private generateExplanation(tone: ToneProfile, request: DraftRequest): string {
    let explanation = `I've crafted this email with a ${tone.formality_level > 0.6 ? 'professional' : 'casual'} tone`;
    
    if (request.mirror_mode) {
      explanation += ', matching your typical writing style';
    }
    
    if (request.recipient_context !== 'unknown') {
      explanation += ` appropriate for ${request.recipient_context} context`;
    }
    
    return explanation + '.';
  }

  /**
   * Get user's writing style
   */
  getUserStyle(userId: string): UserWritingStyle | null {
    return this.userStyles.get(userId) || null;
  }

  /**
   * Update user's writing style with new sample
   */
  async updateUserStyle(userId: string, emailSample: string, context: string): Promise<void> {
    await this.analyzeUserWritingStyle(userId, [{
      content: emailSample,
      context,
      recipient_type: 'unknown'
    }]);
  }
}

export const jamesToneEngine = new JamesToneEngine();
