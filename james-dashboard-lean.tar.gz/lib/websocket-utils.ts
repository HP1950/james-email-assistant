
import { WebSocketEventMap, WebSocketConnection, WebSocketSubscription } from './websocket-types';

// Connection Management Utilities
export class ConnectionManager {
  private connections: Map<string, WebSocketConnection> = new Map();
  private userConnections: Map<string, Set<string>> = new Map();

  addConnection(connection: WebSocketConnection): void {
    this.connections.set(connection.id, connection);
    
    if (!this.userConnections.has(connection.userId)) {
      this.userConnections.set(connection.userId, new Set());
    }
    this.userConnections.get(connection.userId)!.add(connection.id);
  }

  removeConnection(connectionId: string): void {
    const connection = this.connections.get(connectionId);
    if (connection) {
      this.connections.delete(connectionId);
      
      const userConnections = this.userConnections.get(connection.userId);
      if (userConnections) {
        userConnections.delete(connectionId);
        if (userConnections.size === 0) {
          this.userConnections.delete(connection.userId);
        }
      }
    }
  }

  getConnection(connectionId: string): WebSocketConnection | undefined {
    return this.connections.get(connectionId);
  }

  getUserConnections(userId: string): WebSocketConnection[] {
    const connectionIds = this.userConnections.get(userId);
    if (!connectionIds) return [];
    
    return Array.from(connectionIds)
      .map(id => this.connections.get(id))
      .filter(Boolean) as WebSocketConnection[];
  }

  getAllConnections(): WebSocketConnection[] {
    return Array.from(this.connections.values());
  }

  updateLastHeartbeat(connectionId: string): void {
    const connection = this.connections.get(connectionId);
    if (connection) {
      connection.lastHeartbeat = new Date();
    }
  }

  getStaleConnections(timeoutMs: number = 60000): WebSocketConnection[] {
    const now = Date.now();
    return Array.from(this.connections.values()).filter(
      connection => now - connection.lastHeartbeat.getTime() > timeoutMs
    );
  }
}

// Event Broadcasting Utilities
export class EventBroadcaster {
  constructor(private connectionManager: ConnectionManager) {}

  broadcast<T extends keyof WebSocketEventMap>(
    event: T,
    data: WebSocketEventMap[T],
    options: {
      excludeUsers?: string[];
      includeUsers?: string[];
      excludeConnections?: string[];
      filter?: (connection: WebSocketConnection) => boolean;
    } = {}
  ): void {
    const connections = this.getTargetConnections(options);
    
    connections.forEach(connection => {
      this.sendToConnection(connection.id, event, data);
    });
  }

  broadcastToUser<T extends keyof WebSocketEventMap>(
    userId: string,
    event: T,
    data: WebSocketEventMap[T]
  ): void {
    const userConnections = this.connectionManager.getUserConnections(userId);
    userConnections.forEach(connection => {
      this.sendToConnection(connection.id, event, data);
    });
  }

  broadcastToRoom<T extends keyof WebSocketEventMap>(
    roomId: string,
    event: T,
    data: WebSocketEventMap[T]
  ): void {
    // Implementation would depend on room subscription system
    // For now, broadcast to all connections with room subscription
    const connections = this.connectionManager.getAllConnections().filter(
      connection => connection.subscriptions.includes(roomId)
    );
    
    connections.forEach(connection => {
      this.sendToConnection(connection.id, event, data);
    });
  }

  private getTargetConnections(options: {
    excludeUsers?: string[];
    includeUsers?: string[];
    excludeConnections?: string[];
    filter?: (connection: WebSocketConnection) => boolean;
  }): WebSocketConnection[] {
    let connections = this.connectionManager.getAllConnections();

    if (options.includeUsers) {
      connections = connections.filter(conn => options.includeUsers!.includes(conn.userId));
    }

    if (options.excludeUsers) {
      connections = connections.filter(conn => !options.excludeUsers!.includes(conn.userId));
    }

    if (options.excludeConnections) {
      connections = connections.filter(conn => !options.excludeConnections!.includes(conn.id));
    }

    if (options.filter) {
      connections = connections.filter(options.filter);
    }

    return connections;
  }

  private sendToConnection<T extends keyof WebSocketEventMap>(
    connectionId: string,
    event: T,
    data: WebSocketEventMap[T]
  ): void {
    // This would be implemented with the actual WebSocket sending mechanism
    // For now, it's a placeholder that would integrate with Socket.IO
    console.log(`Broadcasting ${event} to connection ${connectionId}:`, data);
  }
}

// Subscription Management
export class SubscriptionManager {
  private subscriptions: Map<string, WebSocketSubscription[]> = new Map();

  subscribe(connectionId: string, subscription: WebSocketSubscription): void {
    if (!this.subscriptions.has(connectionId)) {
      this.subscriptions.set(connectionId, []);
    }
    this.subscriptions.get(connectionId)!.push(subscription);
  }

  unsubscribe(connectionId: string, subscriptionId: string): void {
    const subscriptions = this.subscriptions.get(connectionId);
    if (subscriptions) {
      const index = subscriptions.findIndex(sub => sub.id === subscriptionId);
      if (index > -1) {
        subscriptions.splice(index, 1);
      }
    }
  }

  getSubscriptions(connectionId: string): WebSocketSubscription[] {
    return this.subscriptions.get(connectionId) || [];
  }

  removeAllSubscriptions(connectionId: string): void {
    this.subscriptions.delete(connectionId);
  }

  getSubscribersForPattern(pattern: string): string[] {
    const subscribers: string[] = [];
    
    for (const [connectionId, subscriptions] of this.subscriptions.entries()) {
      if (subscriptions.some(sub => this.matchesPattern(pattern, sub.pattern))) {
        subscribers.push(connectionId);
      }
    }
    
    return subscribers;
  }

  private matchesPattern(eventPattern: string, subscriptionPattern: string): boolean {
    // Simple pattern matching - could be enhanced with more complex rules
    if (subscriptionPattern === '*') return true;
    if (subscriptionPattern === eventPattern) return true;
    
    // Wildcard matching
    const regex = new RegExp(subscriptionPattern.replace(/\*/g, '.*'));
    return regex.test(eventPattern);
  }
}

// Rate Limiting Utilities
export class RateLimiter {
  private limits: Map<string, { count: number; resetTime: number }> = new Map();

  isAllowed(identifier: string, limit: number, windowMs: number): boolean {
    const now = Date.now();
    const current = this.limits.get(identifier);

    if (!current || now > current.resetTime) {
      this.limits.set(identifier, { count: 1, resetTime: now + windowMs });
      return true;
    }

    if (current.count >= limit) {
      return false;
    }

    current.count++;
    return true;
  }

  getRemainingLimit(identifier: string, limit: number): number {
    const current = this.limits.get(identifier);
    if (!current) return limit;
    return Math.max(0, limit - current.count);
  }

  getResetTime(identifier: string): number | null {
    const current = this.limits.get(identifier);
    return current ? current.resetTime : null;
  }

  cleanup(): void {
    const now = Date.now();
    for (const [identifier, data] of this.limits.entries()) {
      if (now > data.resetTime) {
        this.limits.delete(identifier);
      }
    }
  }
}

// Message Validation
export function validateWebSocketMessage(message: any): boolean {
  try {
    if (!message || typeof message !== 'object') return false;
    if (!message.type || typeof message.type !== 'string') return false;
    if (!message.timestamp) return false;
    
    return true;
  } catch {
    return false;
  }
}

// Error Handling
export function createWebSocketError(
  code: string, 
  message: string, 
  context?: any
): { error: { code: string; message: string; context?: any } } {
  return {
    error: {
      code,
      message,
      context
    }
  };
}

// Performance Monitoring
export class PerformanceMonitor {
  private metrics: Map<string, number[]> = new Map();
  private readonly maxSamples = 100;

  recordMetric(name: string, value: number): void {
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }
    
    const samples = this.metrics.get(name)!;
    samples.push(value);
    
    if (samples.length > this.maxSamples) {
      samples.shift();
    }
  }

  getAverageMetric(name: string): number {
    const samples = this.metrics.get(name);
    if (!samples || samples.length === 0) return 0;
    
    return samples.reduce((sum, value) => sum + value, 0) / samples.length;
  }

  getMetricSummary(name: string): { avg: number; min: number; max: number; count: number } {
    const samples = this.metrics.get(name) || [];
    if (samples.length === 0) {
      return { avg: 0, min: 0, max: 0, count: 0 };
    }
    
    const min = Math.min(...samples);
    const max = Math.max(...samples);
    const avg = samples.reduce((sum, value) => sum + value, 0) / samples.length;
    
    return { avg, min, max, count: samples.length };
  }

  getAllMetrics(): { [name: string]: { avg: number; min: number; max: number; count: number } } {
    const result: any = {};
    for (const name of this.metrics.keys()) {
      result[name] = this.getMetricSummary(name);
    }
    return result;
  }
}
