

export interface GmailAccount {
  id: string;
  email: string;
  displayName: string;
  smtp: {
    host: string;
    port: number;
    secure: boolean;
    auth: {
      user: string;
      pass: string; // App Password
    };
  };
  isActive: boolean;
}

export interface EmailConfig {
  mainReceivingEmail: string; // james@schulenberg.tech
  gmailAccounts: GmailAccount[];
  imapConfig: {
    host: string;
    port: number;
    secure: boolean;
    auth: {
      user: string;
      pass: string;
    };
  };
}

// Default configuration
export const defaultEmailConfig: EmailConfig = {
  mainReceivingEmail: 'james@schulenberg.tech',
  gmailAccounts: [
    // Add your Gmail accounts here
    {
      id: 'gmail1',
      email: 'your-email1@gmail.com',
      displayName: 'Main Account',
      smtp: {
        host: 'smtp.gmail.com',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
          user: 'your-email1@gmail.com',
          pass: 'your-app-password-1' // Gmail App Password
        }
      },
      isActive: true
    },
    {
      id: 'gmail2', 
      email: 'your-email2@gmail.com',
      displayName: 'Business Account',
      smtp: {
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
          user: 'your-email2@gmail.com',
          pass: 'your-app-password-2' // Gmail App Password
        }
      },
      isActive: true
    }
    // Add up to 10 Gmail accounts...
  ],
  imapConfig: {
    host: 'imap.hostinger.com', // For james@schulenberg.tech
    port: 993,
    secure: true,
    auth: {
      user: 'james@schulenberg.tech',
      pass: 'your-james-email-password'
    }
  }
};

// Utility functions
export function findGmailAccountByEmail(email: string, config: EmailConfig): GmailAccount | null {
  return config.gmailAccounts.find(account => account.email.toLowerCase() === email.toLowerCase()) || null;
}

export function getActiveGmailAccounts(config: EmailConfig): GmailAccount[] {
  return config.gmailAccounts.filter(account => account.isActive);
}
