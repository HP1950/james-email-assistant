
/**
 * Adaptive Tone Drafting Adapter
 * Quick Win #2: Sentiment analysis, role-based drafting, mirror mode training
 */

import { MCPAdapter, MCPRequest, MCPResponse } from '../mcp/core';
import { jamesOrchestrator } from '../langchain/orchestrator';
import { JAMES_CONFIG } from '../james/config';
import { jamesToneEngine } from '../james/tone-engine';
import { prisma } from '../prisma';

export interface ToneProfile {
  user_id: string;
  communication_style: 'friendly' | 'formal' | 'persuasive' | 'casual' | 'professional';
  writing_patterns: {
    avg_sentence_length: number;
    formality_score: number;
    emoji_usage: number;
    greeting_style: string;
    closing_style: string;
    technical_language_level: number;
  };
  relationship_contexts: Map<string, RelationshipContext>;
  training_data: UserEmailSample[];
}

export interface RelationshipContext {
  sender_email: string;
  relationship_type: 'colleague' | 'client' | 'vendor' | 'friend' | 'unknown';
  formality_preference: number; // 0-1 scale
  response_patterns: string[];
  communication_history: string[];
}

export interface UserEmailSample {
  to: string;
  subject: string;
  body: string;
  tone_markers: string[];
  relationship_context: string;
  timestamp: Date;
}

export interface DraftRequest {
  original_email: {
    from: string;
    subject: string;
    body: string;
    sentiment: string;
  };
  response_intent: 'acknowledge' | 'question' | 'decline' | 'accept' | 'request' | 'follow_up';
  desired_tone: 'match_sender' | 'friendly' | 'formal' | 'persuasive' | 'brief';
  context: {
    thread_history?: string;
    relationship_type?: string;
    urgency_level?: string;
  };
}

export class AdaptiveToneAdapter implements MCPAdapter {
  id = "adaptive-tone-adapter";
  name = "Adaptive Tone Drafting";
  version = "1.0.0";
  capabilities = ["sentiment_analysis", "tone_matching", "draft_generation", "style_learning"];
  
  private userProfiles: Map<string, ToneProfile> = new Map();
  private mirrorModeActive: boolean = false;
  
  async initialize(): Promise<void> {
    console.log(`Initializing ${this.name} adapter...`);
    
    // Initialize LangChain agents
    await jamesOrchestrator.createAdaptiveToneAgent();
    
    // Load user profiles and training data
    await this.loadUserProfiles();
    
    console.log(`${this.name} adapter initialized successfully`);
  }
  
  async execute(request: MCPRequest): Promise<MCPResponse> {
    try {
      switch (request.type) {
        case 'analyze_email_sentiment':
          return await this.analyzeEmailSentiment(request);
        
        case 'generate_adaptive_draft':
          return await this.generateAdaptiveDraft(request);
        
        case 'learn_from_user_email':
          return await this.learnFromUserEmail(request);
        
        case 'update_tone_profile':
          return await this.updateToneProfile(request);
        
        case 'enable_mirror_mode':
          return await this.enableMirrorMode(request);
        
        default:
          return {
            id: request.id,
            success: false,
            error: `Unknown request type: ${request.type}`
          };
      }
    } catch (error) {
      return {
        id: request.id,
        success: false,
        error: `Adaptive tone error: ${error}`
      };
    }
  }
  
  async healthCheck(): Promise<boolean> {
    try {
      const agent = await jamesOrchestrator.getAgent("adaptive-tone-agent");
      return !!agent;
    } catch (error) {
      console.error("Adaptive tone health check failed:", error);
      return false;
    }
  }
  
  private async analyzeEmailSentiment(request: MCPRequest): Promise<MCPResponse> {
    const { email } = request.payload;
    
    // Use LangChain for sentiment analysis
    const toneAgent = await jamesOrchestrator.getAgent("adaptive-tone-agent");
    
    if (!toneAgent) {
      throw new Error("Tone analysis agent not available");
    }
    
    const sentimentPrompt = `
      Analyze the sentiment and tone of this email:
      
      From: ${email.from}
      Subject: ${email.subject}
      Content: ${email.body}
      
      Provide analysis in this format:
      Sentiment: [positive/negative/neutral/mixed]
      Tone: [formal/casual/urgent/friendly/angry/excited]
      Confidence: [0-1]
      Key Indicators: [specific words/phrases that indicate the sentiment]
      Suggested Response Tone: [recommended tone for response]
    `;
    
    const analysis = await toneAgent.chain.call({
      user_style: "",
      relationship: "",
      thread_context: "",
      received_sentiment: "",
      original_sender: email.from,
      original_subject: email.subject,
      original_content: sentimentPrompt,
      response_intent: "analyze",
      desired_tone: "analytical",
      tone_history: "",
    });
    
    // Parse the analysis response
    const sentimentMatch = analysis.text.match(/Sentiment:\s*(\w+)/i);
    const toneMatch = analysis.text.match(/Tone:\s*(.+?)(?=\n|$)/i);
    const confidenceMatch = analysis.text.match(/Confidence:\s*([\d.]+)/i);
    const indicatorsMatch = analysis.text.match(/Key Indicators:\s*(.+?)(?=\n|$)/i);
    const suggestedToneMatch = analysis.text.match(/Suggested Response Tone:\s*(.+?)(?=\n|$)/i);
    
    const result = {
      sentiment: sentimentMatch?.[1]?.toLowerCase() || 'neutral',
      tone: toneMatch?.[1]?.trim() || 'neutral',
      confidence: parseFloat(confidenceMatch?.[1] || '0.5'),
      key_indicators: indicatorsMatch?.[1]?.trim().split(',').map((s: string) => s.trim()) || [],
      suggested_response_tone: suggestedToneMatch?.[1]?.trim() || 'professional',
      analysis_timestamp: new Date()
    };
    
    return {
      id: request.id,
      success: true,
      data: result
    };
  }
  
  private async generateAdaptiveDraft(request: MCPRequest): Promise<MCPResponse> {
    const draftRequest: DraftRequest = request.payload;
    const userId = request.context?.userId || 'default';
    
    // Get user's tone profile
    const userProfile = this.userProfiles.get(userId);
    
    // Analyze the original email sentiment first
    const sentimentAnalysis = await this.analyzeEmailSentiment({
      id: `sentiment-${request.id}`,
      type: 'analyze_email_sentiment',
      payload: { email: draftRequest.original_email }
    });
    
    // Get relationship context
    const relationshipContext = userProfile?.relationship_contexts.get(
      draftRequest.original_email.from
    );
    
    // Use LangChain agent for draft generation
    const toneAgent = await jamesOrchestrator.getAgent("adaptive-tone-agent");
    
    if (!toneAgent) {
      throw new Error("Tone drafting agent not available");
    }
    
    const userStyleDescription = this.generateUserStyleDescription(userProfile);
    const relationshipDescription = this.generateRelationshipDescription(relationshipContext);
    
    const draftResult = await toneAgent.chain.call({
      user_style: userStyleDescription,
      relationship: relationshipDescription,
      thread_context: draftRequest.context.thread_history || "",
      received_sentiment: sentimentAnalysis.data?.sentiment || 'neutral',
      original_sender: draftRequest.original_email.from,
      original_subject: draftRequest.original_email.subject,
      original_content: draftRequest.original_email.body,
      response_intent: draftRequest.response_intent,
      desired_tone: draftRequest.desired_tone,
      tone_history: "",
    });
    
    // Parse the draft response
    const subjectMatch = draftResult.text.match(/Subject:\s*(.+?)(?=\n|Body:|$)/i);
    const bodyMatch = draftResult.text.match(/Body:\s*(.*?)(?=\nTone Analysis:|$)/s);
    const toneAnalysisMatch = draftResult.text.match(/Tone Analysis:\s*(.*?)$/s);
    
    const draft = {
      subject: subjectMatch?.[1]?.trim() || `Re: ${draftRequest.original_email.subject}`,
      body: bodyMatch?.[1]?.trim() || "",
      tone_analysis: toneAnalysisMatch?.[1]?.trim() || "",
      confidence_score: this.calculateDraftConfidence(userProfile, relationshipContext),
      style_matches: this.identifyStyleMatches(draftResult.text, userProfile),
      suggestions: this.generateImprovementSuggestions(draftResult.text, draftRequest)
    };
    
    return {
      id: request.id,
      success: true,
      data: {
        draft,
        metadata: {
          user_style_applied: userStyleDescription,
          relationship_context: relationshipContext?.relationship_type || 'unknown',
          sentiment_considered: sentimentAnalysis.data?.sentiment,
          generation_strategy: draftRequest.desired_tone
        }
      }
    };
  }
  
  private async learnFromUserEmail(request: MCPRequest): Promise<MCPResponse> {
    const { sent_email, user_id } = request.payload;
    
    let userProfile = this.userProfiles.get(user_id);
    
    if (!userProfile) {
      userProfile = this.createDefaultUserProfile(user_id);
      this.userProfiles.set(user_id, userProfile);
    }
    
    // Extract patterns from the user's email
    const emailSample: UserEmailSample = {
      to: sent_email.to,
      subject: sent_email.subject,
      body: sent_email.body,
      tone_markers: this.extractToneMarkers(sent_email.body),
      relationship_context: sent_email.relationship_type || 'unknown',
      timestamp: new Date(sent_email.timestamp || Date.now())
    };
    
    userProfile.training_data.push(emailSample);
    
    // Update writing patterns
    this.updateWritingPatterns(userProfile, emailSample);
    
    // Update relationship context
    this.updateRelationshipContext(userProfile, sent_email.to, emailSample);
    
    // Keep training data limited to recent samples
    if (userProfile.training_data.length > 100) {
      userProfile.training_data = userProfile.training_data.slice(-100);
    }
    
    return {
      id: request.id,
      success: true,
      data: {
        message: "User email patterns learned successfully",
        profile_stats: {
          total_samples: userProfile.training_data.length,
          writing_patterns: userProfile.writing_patterns,
          known_relationships: userProfile.relationship_contexts.size
        }
      }
    };
  }
  
  private async updateToneProfile(request: MCPRequest): Promise<MCPResponse> {
    const { user_id, preferences } = request.payload;
    
    let userProfile = this.userProfiles.get(user_id);
    
    if (!userProfile) {
      userProfile = this.createDefaultUserProfile(user_id);
      this.userProfiles.set(user_id, userProfile);
    }
    
    // Update communication style
    if (preferences.communication_style) {
      userProfile.communication_style = preferences.communication_style;
    }
    
    // Update specific relationship contexts
    if (preferences.relationship_updates) {
      for (const update of preferences.relationship_updates) {
        const context = userProfile.relationship_contexts.get(update.email) || {
          sender_email: update.email,
          relationship_type: 'unknown',
          formality_preference: 0.5,
          response_patterns: [],
          communication_history: []
        };
        
        Object.assign(context, update.context);
        userProfile.relationship_contexts.set(update.email, context);
      }
    }
    
    return {
      id: request.id,
      success: true,
      data: {
        message: "Tone profile updated successfully",
        updated_profile: {
          communication_style: userProfile.communication_style,
          relationship_count: userProfile.relationship_contexts.size
        }
      }
    };
  }
  
  private async enableMirrorMode(request: MCPRequest): Promise<MCPResponse> {
    const { enabled, user_id } = request.payload;
    
    this.mirrorModeActive = enabled;
    
    if (enabled) {
      // Start learning from user's sent emails
      console.log(`Mirror mode enabled for user ${user_id}`);
      
      // In mirror mode, we'll analyze all sent emails to learn patterns
      // This would typically involve setting up email monitoring
    }
    
    return {
      id: request.id,
      success: true,
      data: {
        mirror_mode: this.mirrorModeActive,
        message: enabled ? "Mirror mode enabled - learning from your email style" : "Mirror mode disabled"
      }
    };
  }
  
  // Helper methods
  private async loadUserProfiles(): Promise<void> {
    // In a real implementation, this would load from database
    // For now, we'll start with empty profiles that learn over time
  }
  
  private createDefaultUserProfile(userId: string): ToneProfile {
    return {
      user_id: userId,
      communication_style: 'professional',
      writing_patterns: {
        avg_sentence_length: 15,
        formality_score: 0.7,
        emoji_usage: 0.1,
        greeting_style: "Hello",
        closing_style: "Best regards",
        technical_language_level: 0.5
      },
      relationship_contexts: new Map(),
      training_data: []
    };
  }
  
  private generateUserStyleDescription(profile?: ToneProfile): string {
    if (!profile) {
      return "Professional, moderate formality, clear and concise communication";
    }
    
    const patterns = profile.writing_patterns;
    let description = `Communication style: ${profile.communication_style}. `;
    description += `Average sentence length: ${patterns.avg_sentence_length} words. `;
    description += `Formality level: ${(patterns.formality_score * 100).toFixed(0)}%. `;
    description += `Greeting style: "${patterns.greeting_style}". `;
    description += `Closing style: "${patterns.closing_style}". `;
    
    if (patterns.emoji_usage > 0.3) {
      description += "Uses emojis occasionally. ";
    }
    
    if (patterns.technical_language_level > 0.7) {
      description += "Comfortable with technical language. ";
    }
    
    return description;
  }
  
  private generateRelationshipDescription(context?: RelationshipContext): string {
    if (!context) {
      return "Unknown relationship - use professional tone";
    }
    
    let description = `Relationship: ${context.relationship_type}. `;
    description += `Formality preference: ${(context.formality_preference * 100).toFixed(0)}%. `;
    
    if (context.response_patterns.length > 0) {
      description += `Typical response patterns: ${context.response_patterns.slice(0, 3).join(', ')}. `;
    }
    
    return description;
  }
  
  private extractToneMarkers(text: string): string[] {
    const markers: string[] = [];
    
    // Detect formality markers
    if (/Dear|Sincerely|Regards|Respectfully/.test(text)) {
      markers.push('formal');
    }
    
    if (/Hi|Hey|Thanks!|Cheers/.test(text)) {
      markers.push('casual');
    }
    
    // Detect urgency markers
    if (/urgent|asap|immediately|deadline/i.test(text)) {
      markers.push('urgent');
    }
    
    // Detect friendly markers
    if (/😊|👍|thanks|appreciate|great|awesome/i.test(text)) {
      markers.push('friendly');
    }
    
    return markers;
  }
  
  private updateWritingPatterns(profile: ToneProfile, sample: UserEmailSample): void {
    const sentences = sample.body.split(/[.!?]+/).filter((s: string) => s.trim().length > 0);
    const avgSentenceLength = sentences.reduce((sum, s) => sum + s.trim().split(' ').length, 0) / sentences.length;
    
    // Update patterns using exponential moving average
    const alpha = 0.1; // Learning rate
    profile.writing_patterns.avg_sentence_length = 
      profile.writing_patterns.avg_sentence_length * (1 - alpha) + avgSentenceLength * alpha;
    
    // Update formality score based on tone markers
    const formalMarkers = sample.tone_markers.filter(m => ['formal', 'professional'].includes(m)).length;
    const casualMarkers = sample.tone_markers.filter(m => ['casual', 'friendly'].includes(m)).length;
    const formalityScore = (formalMarkers - casualMarkers + 1) / 2; // Normalize to 0-1
    
    profile.writing_patterns.formality_score = 
      profile.writing_patterns.formality_score * (1 - alpha) + formalityScore * alpha;
    
    // Update emoji usage - fixed regex for proper Unicode emoji matching
    const emojiCount = (sample.body.match(/[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu) || []).length;
    const emojiUsage = Math.min(1, emojiCount / 100); // Normalize
    
    profile.writing_patterns.emoji_usage = 
      profile.writing_patterns.emoji_usage * (1 - alpha) + emojiUsage * alpha;
  }
  
  private updateRelationshipContext(profile: ToneProfile, recipient: string, sample: UserEmailSample): void {
    let context = profile.relationship_contexts.get(recipient);
    
    if (!context) {
      context = {
        sender_email: recipient,
        relationship_type: sample.relationship_context as any || 'unknown',
        formality_preference: 0.5,
        response_patterns: [],
        communication_history: []
      };
    }
    
    // Add to communication history
    context.communication_history.push(`${sample.timestamp.toISOString()}: ${sample.subject}`);
    
    // Keep history limited
    if (context.communication_history.length > 20) {
      context.communication_history = context.communication_history.slice(-20);
    }
    
    // Update response patterns based on tone markers
    sample.tone_markers.forEach(marker => {
      if (!context!.response_patterns.includes(marker)) {
        context!.response_patterns.push(marker);
      }
    });
    
    profile.relationship_contexts.set(recipient, context);
  }
  
  private calculateDraftConfidence(profile?: ToneProfile, context?: RelationshipContext): number {
    let confidence = 0.5; // Base confidence
    
    if (profile && profile.training_data.length > 10) {
      confidence += 0.2; // More training data increases confidence
    }
    
    if (context && context.communication_history.length > 3) {
      confidence += 0.2; // Relationship history increases confidence
    }
    
    if (profile && profile.training_data.length > 50) {
      confidence += 0.1; // Lots of training data
    }
    
    return Math.min(1.0, confidence);
  }
  
  private identifyStyleMatches(draftText: string, profile?: ToneProfile): string[] {
    const matches: string[] = [];
    
    if (!profile) return matches;
    
    // Check greeting style match
    if (draftText.includes(profile.writing_patterns.greeting_style)) {
      matches.push('greeting_style');
    }
    
    // Check closing style match
    if (draftText.includes(profile.writing_patterns.closing_style)) {
      matches.push('closing_style');
    }
    
    // Check formality level
    const formalWords = ['Dear', 'Sincerely', 'Respectfully', 'Please'].filter(word => 
      draftText.includes(word)
    ).length;
    
    if (formalWords > 0 && profile.writing_patterns.formality_score > 0.6) {
      matches.push('formality_match');
    }
    
    return matches;
  }
  
  private generateImprovementSuggestions(draftText: string, request: DraftRequest): string[] {
    const suggestions: string[] = [];
    
    // Check if draft addresses all points from original email
    if (request.original_email.body.includes('?') && !draftText.includes('?')) {
      suggestions.push('Consider addressing the questions asked in the original email');
    }
    
    // Check for appropriate tone matching
    if (request.desired_tone === 'match_sender' && request.original_email.body.includes('!')) {
      if (!draftText.includes('!')) {
        suggestions.push('Consider matching the sender\'s enthusiastic tone');
      }
    }
    
    // Check for call to action
    if (request.response_intent === 'request' && !draftText.includes('please')) {
      suggestions.push('Consider adding a clear call to action');
    }
    
    return suggestions;
  }
}
