
/**
 * Proactive Inbox Management Adapter
 * Quick Win #1: Learn priority patterns, daily summaries, detect ignored senders
 */

import { MCPAdapter, MCPRequest, MCPResponse } from '../mcp/core';
import { jamesOrchestrator } from '../langchain/orchestrator';
import { JAMES_CONFIG } from '../james/config';
import { prisma } from '../prisma';

export interface EmailPriorityData {
  email_id: string;
  sender: string;
  subject: string;
  content: string;
  received_at: Date;
  thread_id?: string;
  priority_score?: number;
  category?: 'urgent' | 'important' | 'fyi' | 'spam' | 'archive';
}

export interface PriorityPattern {
  sender_domain: string;
  sender_email: string;
  avg_response_time: number;
  interaction_frequency: number;
  importance_score: number;
  user_actions: string[];
}

export class InboxManagementAdapter implements MCPAdapter {
  id = "inbox-management-adapter";
  name = "Proactive Inbox Management";
  version = "1.0.0";
  capabilities = ["email_prioritization", "pattern_learning", "daily_summary", "sender_analysis"];
  
  private priorityPatterns: Map<string, PriorityPattern> = new Map();
  private ignoredSenders: Set<string> = new Set();
  
  async initialize(): Promise<void> {
    console.log(`Initializing ${this.name} adapter...`);
    
    // Initialize LangChain agents
    await jamesOrchestrator.createEmailPriorityAgent();
    
    // Load existing patterns from database
    await this.loadPriorityPatterns();
    
    console.log(`${this.name} adapter initialized successfully`);
  }
  
  async execute(request: MCPRequest): Promise<MCPResponse> {
    try {
      switch (request.type) {
        case 'analyze_email_priority':
          return await this.analyzeEmailPriority(request);
        
        case 'learn_priority_pattern':
          return await this.learnPriorityPattern(request);
        
        case 'generate_daily_summary':
          return await this.generateDailySummary(request);
        
        case 'detect_ignored_senders':
          return await this.detectIgnoredSenders(request);
        
        default:
          return {
            id: request.id,
            success: false,
            error: `Unknown request type: ${request.type}`
          };
      }
    } catch (error) {
      return {
        id: request.id,
        success: false,
        error: `Inbox management error: ${error}`
      };
    }
  }
  
  async healthCheck(): Promise<boolean> {
    try {
      // Check if LangChain agent is available
      const agent = await jamesOrchestrator.getAgent("email-priority-agent");
      return !!agent;
    } catch (error) {
      console.error("Inbox management health check failed:", error);
      return false;
    }
  }
  
  private async analyzeEmailPriority(request: MCPRequest): Promise<MCPResponse> {
    const { email, user_context } = request.payload;
    
    // Use LangChain agent for priority analysis
    const priorityAgent = await jamesOrchestrator.getAgent("email-priority-agent");
    
    if (!priorityAgent) {
      throw new Error("Priority analysis agent not available");
    }
    
    const analysis = await priorityAgent.chain.call({
      sender: email.from,
      subject: email.subject,
      content: email.body,
      thread_history: user_context?.thread_history || "",
      priority_history: this.getPriorityHistoryForSender(email.from),
    });
    
    // Extract priority level and reasoning
    const priorityMatch = analysis.text.match(/Priority Level:\s*(\w+)/i);
    const reasoningMatch = analysis.text.match(/Reasoning:\s*(.+?)(?=\n|$)/i);
    const actionMatch = analysis.text.match(/Suggested Action:\s*(.+?)(?=\n|$)/i);
    const timingMatch = analysis.text.match(/Time Sensitivity:\s*(.+?)(?=\n|$)/i);
    
    const result = {
      priority_level: priorityMatch?.[1]?.toLowerCase() || 'medium',
      reasoning: reasoningMatch?.[1]?.trim() || 'Analysis unavailable',
      suggested_action: actionMatch?.[1]?.trim() || 'review',
      time_sensitivity: timingMatch?.[1]?.trim() || 'no deadline',
      confidence_score: 0.85, // Could be calculated based on pattern matching
      category: this.mapPriorityToCategory(priorityMatch?.[1]?.toLowerCase() || 'medium')
    };
    
    // Learn from this interaction
    await this.updatePriorityPattern(email.from, result);
    
    return {
      id: request.id,
      success: true,
      data: result
    };
  }
  
  private async learnPriorityPattern(request: MCPRequest): Promise<MCPResponse> {
    const { sender, user_action, response_time, email_data } = request.payload;
    
    let pattern: PriorityPattern = this.priorityPatterns.get(sender) || {
      sender_domain: sender.split('@')[1] || '',
      sender_email: sender,
      avg_response_time: 0,
      interaction_frequency: 0,
      importance_score: 0.5,
      user_actions: [] as string[]
    };
    
    // Update pattern based on user behavior
    pattern.interaction_frequency += 1;
    if (typeof user_action === 'string') {
      pattern.user_actions.push(user_action);
    }
    
    if (response_time) {
      pattern.avg_response_time = 
        (pattern.avg_response_time + response_time) / pattern.interaction_frequency;
    }
    
    // Adjust importance score based on user actions
    if (['reply_immediately', 'flag', 'prioritize'].includes(user_action)) {
      pattern.importance_score = Math.min(1.0, pattern.importance_score + 0.1);
    } else if (['archive', 'delete', 'ignore'].includes(user_action)) {
      pattern.importance_score = Math.max(0.0, pattern.importance_score - 0.1);
    }
    
    this.priorityPatterns.set(sender, pattern);
    
    return {
      id: request.id,
      success: true,
      data: {
        message: "Priority pattern updated",
        pattern: pattern
      }
    };
  }
  
  private async generateDailySummary(request: MCPRequest): Promise<MCPResponse> {
    const { emails, date } = request.payload;
    
    const categorized = {
      urgent: [] as EmailPriorityData[],
      important: [] as EmailPriorityData[],
      fyi: [] as EmailPriorityData[],
      spam: [] as EmailPriorityData[],
      archive: [] as EmailPriorityData[]
    };
    
    // Categorize emails using our priority analysis
    for (const email of emails) {
      const priorityResult = await this.analyzeEmailPriority({
        id: `priority-${email.id}`,
        type: 'analyze_email_priority',
        payload: { email, user_context: {} }
      });
      
      if (priorityResult.success && priorityResult.data) {
        const category = priorityResult.data.category;
        categorized[category as keyof typeof categorized].push({
          email_id: email.id,
          sender: email.from,
          subject: email.subject,
          content: email.body.substring(0, 200) + '...',
          received_at: new Date(email.received_at),
          priority_score: this.getPriorityScore(priorityResult.data.priority_level)
        });
      }
    }
    
    // Generate summary statistics
    const summary = {
      date,
      total_emails: emails.length,
      categories: {
        urgent: {
          count: categorized.urgent.length,
          emails: categorized.urgent.slice(0, 5) // Top 5 most urgent
        },
        important: {
          count: categorized.important.length,
          emails: categorized.important.slice(0, 10)
        },
        fyi: {
          count: categorized.fyi.length,
          top_senders: this.getTopSenders(categorized.fyi)
        },
        spam: {
          count: categorized.spam.length,
          blocked_domains: this.getTopDomains(categorized.spam)
        },
        archive: {
          count: categorized.archive.length
        }
      },
      insights: {
        busiest_hour: this.getBusiestHour(emails),
        top_senders: this.getTopSenders(emails),
        response_needed: categorized.urgent.length + categorized.important.length,
        processing_accuracy: this.calculateAccuracy()
      }
    };
    
    return {
      id: request.id,
      success: true,
      data: summary
    };
  }
  
  private async detectIgnoredSenders(request: MCPRequest): Promise<MCPResponse> {
    const { timeframe_days = 30 } = request.payload;
    
    const ignoredThreshold = 5; // Emails ignored before flagging
    const responseTimeThreshold = 7 * 24 * 60 * 60 * 1000; // 7 days in ms
    
    const senderStats = new Map<string, {
      total_emails: number;
      ignored_emails: number;
      avg_response_time: number;
      last_response: Date | null;
    }>();
    
    // Analyze patterns to detect consistently ignored senders
    for (const [sender, pattern] of this.priorityPatterns) {
      const ignoreActions = pattern.user_actions.filter(action => 
        ['ignore', 'archive_without_reading', 'delete'].includes(action)
      ).length;
      
      const totalActions = pattern.user_actions.length;
      const ignoreRatio = ignoreActions / Math.max(totalActions, 1);
      
      if (ignoreRatio > 0.8 && ignoreActions >= ignoredThreshold) {
        this.ignoredSenders.add(sender);
        
        senderStats.set(sender, {
          total_emails: totalActions,
          ignored_emails: ignoreActions,
          avg_response_time: pattern.avg_response_time,
          last_response: null // Would need to track this from database
        });
      }
    }
    
    const recommendations = Array.from(this.ignoredSenders).map(sender => ({
      sender,
      stats: senderStats.get(sender),
      suggested_actions: [
        'create_filter_rule',
        'add_to_low_priority',
        'unsubscribe_if_newsletter',
        'block_if_spam'
      ]
    }));
    
    return {
      id: request.id,
      success: true,
      data: {
        ignored_senders: Array.from(this.ignoredSenders),
        recommendations,
        summary: {
          total_ignored_senders: this.ignoredSenders.size,
          potential_time_saved: recommendations.length * 30 // 30 seconds per ignored email
        }
      }
    };
  }
  
  // Helper methods
  private async loadPriorityPatterns(): Promise<void> {
    try {
      // Load existing patterns from database for all users
      // Note: In production, this might be user-specific
      const dbPatterns = await prisma.jamesPriorityPattern.findMany({
        take: 1000 // Limit to prevent memory issues
      });

      // Convert database patterns to our in-memory format
      for (const dbPattern of dbPatterns) {
        const pattern: PriorityPattern = {
          sender_domain: dbPattern.senderDomain,
          sender_email: dbPattern.senderEmail,
          avg_response_time: dbPattern.avgResponseTime,
          interaction_frequency: dbPattern.interactionCount,
          importance_score: dbPattern.importanceScore,
          user_actions: dbPattern.userActions
        };
        
        this.priorityPatterns.set(dbPattern.senderEmail, pattern);
      }

      console.log(`Loaded ${dbPatterns.length} priority patterns from database`);
    } catch (error) {
      console.error('Error loading priority patterns from database:', error);
      // Continue with empty patterns - they'll be learned over time
    }
  }
  
  private getPriorityHistoryForSender(sender: string): string {
    const pattern = this.priorityPatterns.get(sender);
    if (!pattern) return "";
    
    return `Previous interactions: ${pattern.interaction_frequency}, 
            Avg response time: ${Math.round(pattern.avg_response_time / 3600000)} hours,
            Importance score: ${pattern.importance_score.toFixed(2)}`;
  }
  
  private mapPriorityToCategory(priority: string): 'urgent' | 'important' | 'fyi' | 'spam' | 'archive' {
    switch (priority) {
      case 'critical':
      case 'high': return 'urgent';
      case 'medium': return 'important';
      case 'low': return 'fyi';
      default: return 'archive';
    }
  }
  
  private getPriorityScore(priority: string): number {
    switch (priority) {
      case 'critical': return 1.0;
      case 'high': return 0.8;
      case 'medium': return 0.6;
      case 'low': return 0.4;
      default: return 0.2;
    }
  }
  
  private async updatePriorityPattern(sender: string, result: any): Promise<void> {
    // Update our learning patterns based on AI analysis results
    let pattern = this.priorityPatterns.get(sender) || {
      sender_domain: sender.split('@')[1] || '',
      sender_email: sender,
      avg_response_time: 0,
      interaction_frequency: 0,
      importance_score: 0.5,
      user_actions: []
    };
    
    // Adjust importance score based on AI priority assessment
    const priorityScore = this.getPriorityScore(result.priority_level);
    pattern.importance_score = (pattern.importance_score + priorityScore) / 2;
    pattern.interaction_frequency += 1;
    
    this.priorityPatterns.set(sender, pattern);
  }
  
  private getTopSenders(emails: EmailPriorityData[]): string[] {
    const senderCounts = new Map<string, number>();
    
    emails.forEach(email => {
      senderCounts.set(email.sender, (senderCounts.get(email.sender) || 0) + 1);
    });
    
    return Array.from(senderCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(entry => entry[0]);
  }
  
  private getTopDomains(emails: EmailPriorityData[]): string[] {
    const domainCounts = new Map<string, number>();
    
    emails.forEach(email => {
      const domain = email.sender.split('@')[1];
      if (domain) {
        domainCounts.set(domain, (domainCounts.get(domain) || 0) + 1);
      }
    });
    
    return Array.from(domainCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(entry => entry[0]);
  }
  
  private getBusiestHour(emails: any[]): number {
    const hourCounts = new Array(24).fill(0);
    
    emails.forEach(email => {
      const hour = new Date(email.received_at).getHours();
      hourCounts[hour]++;
    });
    
    return hourCounts.indexOf(Math.max(...hourCounts));
  }
  
  private calculateAccuracy(): number {
    // Placeholder for accuracy calculation
    // Would compare AI predictions vs user actions
    return 0.87; // 87% accuracy target
  }
}
