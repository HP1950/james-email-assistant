
/**
 * James Email Assistant - API Client for FastAPI Backend
 * This file provides HTTP client functions to call the FastAPI backend
 */

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

class ApiClient {
  private baseUrl: string;
  private token: string | null = null;

  constructor() {
    // Use environment variable for API URL, fallback to localhost for development
    this.baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';
    
    // For browser requests, use different URL if specified
    if (typeof window !== 'undefined') {
      this.baseUrl = process.env.NEXT_PUBLIC_API_URL_BROWSER || this.baseUrl;
    }
  }

  setToken(token: string) {
    this.token = token;
  }

  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    return headers;
  }

  private async handleResponse<T>(response: Response): Promise<ApiResponse<T>> {
    try {
      const data = await response.json();
      
      if (!response.ok) {
        return {
          success: false,
          error: data.detail || data.error || 'Request failed',
          data: data
        };
      }

      return {
        success: true,
        data: data.data || data,
        message: data.message
      };
    } catch (error) {
      return {
        success: false,
        error: 'Failed to parse response',
      };
    }
  }

  // Authentication
  async login(email: string, password: string): Promise<ApiResponse<{ access_token: string }>> {
    const response = await fetch(`${this.baseUrl}/auth/login`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ email, password }),
    });

    return this.handleResponse(response);
  }

  async register(email: string, password: string, full_name: string): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/auth/register`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ email, password, full_name }),
    });

    return this.handleResponse(response);
  }

  // James Inbox Management
  async syncInbox(): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/james/inbox/sync`, {
      method: 'POST',
      headers: this.getHeaders(),
    });

    return this.handleResponse(response);
  }

  async getInboxSummary(): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/james/inbox/summary`, {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return this.handleResponse(response);
  }

  async analyzeEmails(emailIds: string[], analysisTypes: string[] = ['priority', 'sentiment', 'insights']): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/james/inbox-analysis`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        email_ids: emailIds,
        analysis_types: analysisTypes,
      }),
    });

    return this.handleResponse(response);
  }

  // James Tone Analysis
  async analyzeTone(content: string, context?: string): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/james/tone/analyze`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        content,
        context,
      }),
    });

    return this.handleResponse(response);
  }

  async generateDraft(context: string, tonePreference?: string, keyPoints: string[] = []): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/james/tone/draft`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        context,
        tone_preference: tonePreference,
        key_points: keyPoints,
      }),
    });

    return this.handleResponse(response);
  }

  // James Attachment Processing
  async processAttachment(
    file: File,
    threadId?: string,
    messageId?: string,
    processImmediately: boolean = true
  ): Promise<ApiResponse> {
    const formData = new FormData();
    formData.append('attachment', file);
    
    if (threadId) formData.append('thread_id', threadId);
    if (messageId) formData.append('message_id', messageId);
    formData.append('process_immediately', processImmediately.toString());

    const headers: HeadersInit = {};
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(`${this.baseUrl}/james/attachments/process`, {
      method: 'POST',
      headers: headers,
      body: formData,
    });

    return this.handleResponse(response);
  }

  async analyzeAttachment(attachmentId: string, forceReprocess: boolean = false): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/james/attachments/analyze`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        attachment_id: attachmentId,
        force_reprocess: forceReprocess,
      }),
    });

    return this.handleResponse(response);
  }

  async getAttachmentInsights(attachmentIds: string[] = [], timeRange: string = '30d'): Promise<ApiResponse> {
    const params = new URLSearchParams();
    if (attachmentIds.length > 0) {
      params.append('attachment_ids', attachmentIds.join(','));
    }
    params.append('time_range', timeRange);

    const response = await fetch(`${this.baseUrl}/james/attachments/insights?${params}`, {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return this.handleResponse(response);
  }

  // James Context Intelligence
  async analyzeThreadContext(threadId: string, includeAttachments: boolean = true): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/james/context/thread-analysis`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        thread_id: threadId,
        include_attachments: includeAttachments,
      }),
    });

    return this.handleResponse(response);
  }

  async getContextInsights(threadIds: string[] = [], timeframe: string = '7d'): Promise<ApiResponse> {
    const params = new URLSearchParams();
    if (threadIds.length > 0) {
      params.append('thread_ids', threadIds.join(','));
    }
    params.append('timeframe', timeframe);

    const response = await fetch(`${this.baseUrl}/james/context/insights?${params}`, {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return this.handleResponse(response);
  }

  // James Orchestrator
  async runJamesOrchestrator(operation: string, params: Record<string, any> = {}): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/james/orchestrator`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        operation,
        ...params,
      }),
    });

    return this.handleResponse(response);
  }

  // Health Check
  async healthCheck(): Promise<ApiResponse> {
    const response = await fetch(`${this.baseUrl}/health`, {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return this.handleResponse(response);
  }
}

// Create and export a singleton instance
export const apiClient = new ApiClient();

// Export the class for custom instances if needed
export { ApiClient };

// Utility function to get API client with token
export function getApiClient(token?: string): ApiClient {
  const client = new ApiClient();
  if (token) {
    client.setToken(token);
  }
  return client;
}

// Hook for React components
export function useApiClient(token?: string) {
  const client = getApiClient(token);
  return client;
}
