
// Daily Drop Scheduler for Advanced Batch Sending
import { PrismaClient } from '@prisma/client';
import { 
  DropScheduleType, 
  BatchPriority, 
  BatchStatus,
  DailyDropSchedulerData,
  DropBatchData 
} from './types';

const prisma = new PrismaClient();

export class DailyDropScheduler {
  // Create daily drop scheduler
  static async createScheduler(data: {
    userId: string;
    name: string;
    description?: string;
    scheduleType?: DropScheduleType;
    timeSlots: Array<{
      hour: number;
      minute: number;
      timezone: string;
      maxEmails: number;
    }>;
    maxDailyEmails?: number;
    maxHourlyEmails?: number;
    batchSize?: number;
    batchDelay?: number;
    ispLimits?: Record<string, { hourly: number; daily: number }>;
    optimizeForTimezone?: boolean;
    optimizeForEngagement?: boolean;
  }): Promise<DailyDropSchedulerData> {
    return await prisma.dailyDropScheduler.create({
      data: {
        userId: data.userId,
        name: data.name,
        description: data.description,
        scheduleType: data.scheduleType || DropScheduleType.DAILY,
        timeSlots: data.timeSlots,
        maxDailyEmails: data.maxDailyEmails || 10000,
        maxHourlyEmails: data.maxHourlyEmails || 1000,
        batchSize: data.batchSize || 100,
        batchDelay: data.batchDelay || 60,
        ispLimits: data.ispLimits,
        optimizeForTimezone: data.optimizeForTimezone || true,
        optimizeForEngagement: data.optimizeForEngagement || true,
        timeZoneDistribution: await this.calculateTimezoneDistribution(data.userId)
      }
    }) as DailyDropSchedulerData;
  }
  
  // Schedule campaign for delivery
  static async scheduleCampaign(data: {
    schedulerId: string;
    campaignId: string;
    recipients: Array<{
      email: string;
      timezone?: string;
      lastEngagement?: Date;
      preferredTime?: string;
    }>;
    priority?: BatchPriority;
    startDate?: Date;
  }): Promise<DropBatchData[]> {
    const scheduler = await prisma.dailyDropScheduler.findUnique({
      where: { id: data.schedulerId }
    });
    
    if (!scheduler) {
      throw new Error('Scheduler not found');
    }
    
    // Optimize send times if enabled
    const optimizedRecipients = scheduler.optimizeForEngagement
      ? await this.optimizeRecipientTiming(data.recipients)
      : data.recipients;
    
    // Group recipients by timezone if optimization is enabled
    const recipientGroups = scheduler.optimizeForTimezone
      ? this.groupRecipientsByTimezone(optimizedRecipients)
      : { 'UTC': optimizedRecipients };
    
    const batches: DropBatchData[] = [];
    let batchNumber = 1;
    
    for (const [timezone, recipients] of Object.entries(recipientGroups)) {
      // Split recipients into batches
      const recipientBatches = this.splitIntoBatches(recipients, scheduler.batchSize);
      
      for (const recipientBatch of recipientBatches) {
        // Calculate optimal send time for this timezone
        const scheduledAt = this.calculateOptimalSendTime(
          scheduler,
          timezone,
          data.startDate || new Date()
        );
        
        const batch = await prisma.dropBatch.create({
          data: {
            schedulerId: data.schedulerId,
            campaignId: data.campaignId,
            batchNumber: batchNumber++,
            recipientCount: recipientBatch.length,
            recipientData: recipientBatch,
            scheduledAt,
            timezone,
            priority: data.priority || BatchPriority.NORMAL,
            status: BatchStatus.PENDING
          }
        }) as DropBatchData;
        
        batches.push(batch);
      }
    }
    
    return batches;
  }
  
  // Process pending batches
  static async processPendingBatches(): Promise<void> {
    const pendingBatches = await prisma.dropBatch.findMany({
      where: {
        status: BatchStatus.PENDING,
        scheduledAt: { lte: new Date() }
      },
      include: {
        scheduler: true,
        campaign: true
      },
      orderBy: [
        { priority: 'desc' },
        { scheduledAt: 'asc' }
      ]
    });
    
    for (const batch of pendingBatches) {
      await this.processBatch(batch);
    }
  }
  
  // Process individual batch
  private static async processBatch(batch: any): Promise<void> {
    try {
      // Update batch status to processing
      await prisma.dropBatch.update({
        where: { id: batch.id },
        data: {
          status: BatchStatus.PROCESSING,
          startedAt: new Date()
        }
      });
      
      // Check daily/hourly limits
      const canSend = await this.checkSendingLimits(batch.scheduler, batch.recipientCount);
      
      if (!canSend.allowed) {
        // Reschedule batch
        await this.rescheduleBatch(batch.id, canSend.nextAvailableTime);
        return;
      }
      
      // Send emails in batch
      const result = await this.sendBatchEmails(batch);
      
      // Update batch with results
      await prisma.dropBatch.update({
        where: { id: batch.id },
        data: {
          status: BatchStatus.COMPLETED,
          completedAt: new Date(),
          sentCount: result.sent,
          deliveredCount: result.delivered,
          failedCount: result.failed,
          errors: result.errors
        }
      });
      
      // Update scheduler statistics
      await this.updateSchedulerStats(batch.schedulerId, result);
      
    } catch (error: any) {
      console.error(`Batch ${batch.id} processing failed:`, error);
      
      await prisma.dropBatch.update({
        where: { id: batch.id },
        data: {
          status: BatchStatus.FAILED,
          completedAt: new Date(),
          errors: [{ error: error.message, timestamp: new Date() }]
        }
      });
      
      // Schedule retry if under retry limit
      if (batch.retryAttempts < batch.maxRetries) {
        await this.scheduleRetry(batch.id);
      }
    }
  }
  
  // Send batch emails
  private static async sendBatchEmails(batch: any): Promise<{
    sent: number;
    delivered: number;
    failed: number;
    errors: any[];
  }> {
    const recipients = batch.recipientData;
    let sent = 0;
    let delivered = 0;
    let failed = 0;
    const errors: any[] = [];
    
    for (const recipient of recipients) {
      try {
        // Apply ISP-specific throttling
        await this.applyISPThrottling(recipient.email, batch.scheduler);
        
        // Send email (this would integrate with email service providers)
        const result = await this.sendSingleEmail(batch.campaign, recipient);
        
        if (result.success) {
          sent++;
          if (result.delivered) delivered++;
        } else {
          failed++;
          errors.push({
            email: recipient.email,
            error: result.error,
            timestamp: new Date()
          });
        }
        
        // Apply batch delay
        if (batch.scheduler.batchDelay > 0) {
          await this.delay(batch.scheduler.batchDelay * 1000);
        }
        
      } catch (error: any) {
        failed++;
        errors.push({
          email: recipient.email,
          error: error.message,
          timestamp: new Date()
        });
      }
    }
    
    return { sent, delivered, failed, errors };
  }
  
  // Check sending limits
  private static async checkSendingLimits(scheduler: any, emailCount: number): Promise<{
    allowed: boolean;
    dailyUsed: number;
    hourlyUsed: number;
    nextAvailableTime?: Date;
  }> {
    const now = new Date();
    const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const hourStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours());
    
    // Get current usage
    const dailyUsage = await prisma.dropBatch.aggregate({
      where: {
        schedulerId: scheduler.id,
        completedAt: { gte: dayStart },
        status: BatchStatus.COMPLETED
      },
      _sum: { sentCount: true }
    });
    
    const hourlyUsage = await prisma.dropBatch.aggregate({
      where: {
        schedulerId: scheduler.id,
        completedAt: { gte: hourStart },
        status: BatchStatus.COMPLETED
      },
      _sum: { sentCount: true }
    });
    
    const dailyUsed = dailyUsage._sum.sentCount || 0;
    const hourlyUsed = hourlyUsage._sum.sentCount || 0;
    
    // Check limits
    const dailyAllowed = dailyUsed + emailCount <= scheduler.maxDailyEmails;
    const hourlyAllowed = hourlyUsed + emailCount <= scheduler.maxHourlyEmails;
    
    if (!dailyAllowed) {
      return {
        allowed: false,
        dailyUsed,
        hourlyUsed,
        nextAvailableTime: new Date(dayStart.getTime() + 24 * 60 * 60 * 1000)
      };
    }
    
    if (!hourlyAllowed) {
      return {
        allowed: false,
        dailyUsed,
        hourlyUsed,
        nextAvailableTime: new Date(hourStart.getTime() + 60 * 60 * 1000)
      };
    }
    
    return { allowed: true, dailyUsed, hourlyUsed };
  }
  
  // Optimize recipient timing based on engagement history
  private static async optimizeRecipientTiming(recipients: any[]): Promise<any[]> {
    return await Promise.all(recipients.map(async (recipient) => {
      if (recipient.lastEngagement) {
        // Analyze historical engagement to determine optimal send time
        const optimalTime = await this.getOptimalSendTime(recipient.email);
        return { ...recipient, optimalTime };
      }
      return recipient;
    }));
  }
  
  // Get optimal send time for subscriber
  private static async getOptimalSendTime(email: string): Promise<string> {
    // Analyze campaign stats to find when this subscriber is most likely to engage
    const stats = await prisma.campaignSubscriberStat.findMany({
      where: { subscriber: { email } },
      orderBy: { openedAt: 'desc' },
      take: 10
    });
    
    if (stats.length === 0) return '09:00'; // Default
    
    // Calculate average engagement time
    const engagementHours = stats
      .filter(stat => stat.openedAt)
      .map(stat => stat.openedAt!.getHours());
    
    if (engagementHours.length === 0) return '09:00';
    
    const avgHour = Math.round(
      engagementHours.reduce((sum, hour) => sum + hour, 0) / engagementHours.length
    );
    
    return `${avgHour.toString().padStart(2, '0')}:00`;
  }
  
  // Group recipients by timezone
  private static groupRecipientsByTimezone(recipients: any[]): Record<string, any[]> {
    return recipients.reduce((groups, recipient) => {
      const timezone = recipient.timezone || 'UTC';
      if (!groups[timezone]) groups[timezone] = [];
      groups[timezone].push(recipient);
      return groups;
    }, {} as Record<string, any[]>);
  }
  
  // Split recipients into batches
  private static splitIntoBatches(recipients: any[], batchSize: number): any[][] {
    const batches: any[][] = [];
    for (let i = 0; i < recipients.length; i += batchSize) {
      batches.push(recipients.slice(i, i + batchSize));
    }
    return batches;
  }
  
  // Calculate optimal send time for timezone
  private static calculateOptimalSendTime(scheduler: any, timezone: string, baseDate: Date): Date {
    const timeSlots = scheduler.timeSlots as any[];
    
    // Find best time slot for this timezone
    const timezoneSlot = timeSlots.find(slot => slot.timezone === timezone) || timeSlots[0];
    
    const sendTime = new Date(baseDate);
    sendTime.setHours(timezoneSlot.hour, timezoneSlot.minute, 0, 0);
    
    // If time has passed today, schedule for tomorrow
    if (sendTime <= new Date()) {
      sendTime.setDate(sendTime.getDate() + 1);
    }
    
    return sendTime;
  }
  
  // Apply ISP-specific throttling
  private static async applyISPThrottling(email: string, scheduler: any): Promise<void> {
    if (!scheduler.ispLimits) return;
    
    const domain = email.split('@')[1];
    const ispConfig = scheduler.ispLimits[domain];
    
    if (ispConfig) {
      // Check ISP-specific limits and apply delays
      // This is a simplified implementation
      await this.delay(100); // 100ms delay for ISP throttling
    }
  }
  
  // Send single email
  private static async sendSingleEmail(campaign: any, recipient: any): Promise<{
    success: boolean;
    delivered?: boolean;
    error?: string;
  }> {
    try {
      // This would integrate with email service providers
      // For now, simulate sending
      await this.delay(50); // Simulate API call
      
      // Simulate 95% success rate
      if (Math.random() < 0.95) {
        return { success: true, delivered: true };
      } else {
        return { success: false, error: 'Simulated delivery failure' };
      }
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
  
  // Helper methods
  private static async calculateTimezoneDistribution(userId: string): Promise<any> {
    // Calculate timezone distribution for user's subscribers
    const distribution = await prisma.listSubscriber.groupBy({
      by: ['timezone'],
      where: { list: { userId } },
      _count: true
    });
    
    return distribution.reduce((acc, item) => {
      acc[item.timezone || 'UTC'] = item._count;
      return acc;
    }, {} as Record<string, number>);
  }
  
  private static async rescheduleBatch(batchId: string, rescheduleTime: Date): Promise<void> {
    await prisma.dropBatch.update({
      where: { id: batchId },
      data: {
        status: BatchStatus.PENDING,
        scheduledAt: rescheduleTime,
        startedAt: null
      }
    });
  }
  
  private static async scheduleRetry(batchId: string): Promise<void> {
    const batch = await prisma.dropBatch.findUnique({ where: { id: batchId } });
    if (!batch) return;
    
    const retryDelay = Math.pow(2, batch.retryAttempts) * 5; // Exponential backoff
    const retryTime = new Date(Date.now() + retryDelay * 60 * 1000);
    
    await prisma.dropBatch.update({
      where: { id: batchId },
      data: {
        status: BatchStatus.PENDING,
        scheduledAt: retryTime,
        retryAttempts: batch.retryAttempts + 1
      }
    });
  }
  
  private static async updateSchedulerStats(schedulerId: string, result: any): Promise<void> {
    await prisma.dailyDropScheduler.update({
      where: { id: schedulerId },
      data: {
        totalEmailsSent: { increment: result.sent },
        // Update other statistics as needed
      }
    });
  }
  
  private static delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // Public API methods
  static async pauseScheduler(schedulerId: string): Promise<void> {
    await prisma.dailyDropScheduler.update({
      where: { id: schedulerId },
      data: { isActive: false }
    });
  }
  
  static async resumeScheduler(schedulerId: string): Promise<void> {
    await prisma.dailyDropScheduler.update({
      where: { id: schedulerId },
      data: { isActive: true }
    });
  }
  
  static async getSchedulerStatus(schedulerId: string): Promise<{
    dailyEmailsSent: number;
    hourlyEmailsSent: number;
    pendingBatches: number;
    processingBatches: number;
    nextBatchTime?: Date;
  }> {
    const now = new Date();
    const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const hourStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours());
    
    const [dailyStats, hourlyStats, pendingCount, processingCount, nextBatch] = await Promise.all([
      prisma.dropBatch.aggregate({
        where: {
          schedulerId,
          completedAt: { gte: dayStart },
          status: BatchStatus.COMPLETED
        },
        _sum: { sentCount: true }
      }),
      prisma.dropBatch.aggregate({
        where: {
          schedulerId,
          completedAt: { gte: hourStart },
          status: BatchStatus.COMPLETED
        },
        _sum: { sentCount: true }
      }),
      prisma.dropBatch.count({
        where: { schedulerId, status: BatchStatus.PENDING }
      }),
      prisma.dropBatch.count({
        where: { schedulerId, status: BatchStatus.PROCESSING }
      }),
      prisma.dropBatch.findFirst({
        where: { schedulerId, status: BatchStatus.PENDING },
        orderBy: { scheduledAt: 'asc' }
      })
    ]);
    
    return {
      dailyEmailsSent: dailyStats._sum.sentCount || 0,
      hourlyEmailsSent: hourlyStats._sum.sentCount || 0,
      pendingBatches: pendingCount,
      processingBatches: processingCount,
      nextBatchTime: nextBatch?.scheduledAt
    };
  }
}
