
import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  metadataBase: new URL('https://schulenberg.tech'),
  title: 'James - Your Email Assistant | Emotionally Intelligent AI',
  description: 'Meet James, your emotionally intelligent email assistant. They write, he answers with perfect tone, cultural sensitivity, and complete privacy.',
  keywords: ['email', 'assistant', 'AI', 'emotional intelligence', 'james', 'voice command', 'privacy', 'smtp'],
  authors: [{ name: 'Schulenberg.tech' }],
  creator: 'James Email Assistant',
  publisher: 'Schulenberg.tech',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'James Assistant',
    startupImage: [
      '/icons/icon-192x192.png',
    ],
  },
  openGraph: {
    type: 'website',
    siteName: 'James - Your Email Assistant',
    title: 'James - Your Email Assistant | Emotionally Intelligent AI',
    description: 'Meet James, your emotionally intelligent email assistant. They write, he answers with perfect tone and cultural sensitivity.',
    images: ['/james-branding.jpg'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'James - Your Email Assistant | Emotionally Intelligent AI', 
    description: 'Meet James, your emotionally intelligent email assistant. They write, he answers with perfect tone and cultural sensitivity.',
    images: ['/james-branding.jpg'],
  },
  other: {
    'mobile-web-app-capable': 'yes',
    'apple-mobile-web-app-capable': 'yes',
    'apple-mobile-web-app-status-bar-style': 'default',
    'apple-mobile-web-app-title': 'James Assistant',
    'application-name': 'James Email Assistant',
    'msapplication-TileColor': '#2563eb',
    'msapplication-config': '/browserconfig.xml',
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#0f172a' },
  ],
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  viewportFit: 'cover',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/icons/icon-192x192.png" type="image/png" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
        <meta name="theme-color" content="#2563eb" />
      </head>
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}
