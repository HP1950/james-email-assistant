
import { Suspense } from 'react';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { redirect } from 'next/navigation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import JobSchedulerDashboard from '@/components/advanced/job-scheduler-dashboard';
import SpinTextEditor from '@/components/advanced/spin-text-editor';
import SuppressionManager from '@/components/advanced/suppression-manager';
import DailyDropScheduler from '@/components/advanced/daily-drop-scheduler';
import AdvancedAutomationBuilder from '@/components/advanced/advanced-automation-builder';
import { 
  Clock, 
  Zap, 
  Shield, 
  Send, 
  GitBranch,
  BarChart3,
  Settings,
  Rocket,
  TrendingUp,
  Users
} from 'lucide-react';

export const dynamic = "force-dynamic";

export default async function AdvancedPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.id) {
    redirect('/auth/signin');
  }

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <div className="p-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl">
            <Rocket className="w-12 h-12 text-white" />
          </div>
        </div>
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Advanced Email Marketing Platform
          </h1>
          <p className="text-xl text-muted-foreground mt-2">
            Professional-grade automation, scheduling, and optimization tools
          </p>
        </div>
      </div>

      {/* Quick Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="flex justify-center mb-3">
              <div className="p-3 bg-blue-100 rounded-full">
                <Clock className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <div className="text-2xl font-bold">12</div>
            <div className="text-sm text-muted-foreground">Active Jobs</div>
          </CardContent>
        </Card>
        
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="flex justify-center mb-3">
              <div className="p-3 bg-green-100 rounded-full">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <div className="text-2xl font-bold">98.5%</div>
            <div className="text-sm text-muted-foreground">Delivery Rate</div>
          </CardContent>
        </Card>
        
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="flex justify-center mb-3">
              <div className="p-3 bg-purple-100 rounded-full">
                <GitBranch className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <div className="text-2xl font-bold">24</div>
            <div className="text-sm text-muted-foreground">Active Automations</div>
          </CardContent>
        </Card>
        
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="flex justify-center mb-3">
              <div className="p-3 bg-orange-100 rounded-full">
                <Users className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <div className="text-2xl font-bold">1.2M</div>
            <div className="text-sm text-muted-foreground">Emails Sent Today</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Tabs */}
      <Tabs defaultValue="scheduler" className="w-full">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5">
          <TabsTrigger value="scheduler" className="flex items-center space-x-2">
            <Clock className="w-4 h-4" />
            <span className="hidden sm:inline">Job Scheduler</span>
          </TabsTrigger>
          <TabsTrigger value="automation" className="flex items-center space-x-2">
            <GitBranch className="w-4 h-4" />
            <span className="hidden sm:inline">Automation</span>
          </TabsTrigger>
          <TabsTrigger value="daily-drop" className="flex items-center space-x-2">
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Daily Drop</span>
          </TabsTrigger>
          <TabsTrigger value="spin-text" className="flex items-center space-x-2">
            <Zap className="w-4 h-4" />
            <span className="hidden sm:inline">Spin Text</span>
          </TabsTrigger>
          <TabsTrigger value="suppression" className="flex items-center space-x-2">
            <Shield className="w-4 h-4" />
            <span className="hidden sm:inline">Suppression</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="scheduler" className="mt-6">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Clock className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle>Job Scheduler Dashboard</CardTitle>
                    <CardDescription>
                      Manage automated tasks and job execution with cron-like functionality
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
            <Suspense fallback={<div className="flex justify-center p-8">Loading job scheduler...</div>}>
              <JobSchedulerDashboard userId={session.user.id} />
            </Suspense>
          </div>
        </TabsContent>

        <TabsContent value="automation" className="mt-6">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <GitBranch className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <CardTitle>Advanced Automation Builder</CardTitle>
                    <CardDescription>
                      Create sophisticated email workflows with conditional logic and triggers
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
            <Suspense fallback={<div className="flex justify-center p-8">Loading automation builder...</div>}>
              <AdvancedAutomationBuilder userId={session.user.id} />
            </Suspense>
          </div>
        </TabsContent>

        <TabsContent value="daily-drop" className="mt-6">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Send className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <CardTitle>Daily Drop Scheduler</CardTitle>
                    <CardDescription>
                      Advanced batch email delivery with time optimization and ISP throttling
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
            <Suspense fallback={<div className="flex justify-center p-8">Loading daily drop scheduler...</div>}>
              <DailyDropScheduler userId={session.user.id} />
            </Suspense>
          </div>
        </TabsContent>

        <TabsContent value="spin-text" className="mt-6">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <Zap className="w-5 h-5 text-yellow-600" />
                  </div>
                  <div>
                    <CardTitle>Spin-Text Engine</CardTitle>
                    <CardDescription>
                      Create dynamic content variations to improve deliverability and avoid spam filters
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
            <Suspense fallback={<div className="flex justify-center p-8">Loading spin-text editor...</div>}>
              <SpinTextEditor userId={session.user.id} />
            </Suspense>
          </div>
        </TabsContent>

        <TabsContent value="suppression" className="mt-6">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-red-100 rounded-lg">
                    <Shield className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <CardTitle>Global Suppression Manager</CardTitle>
                    <CardDescription>
                      Manage email suppressions and maintain list hygiene across all campaigns
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
            <Suspense fallback={<div className="flex justify-center p-8">Loading suppression manager...</div>}>
              <SuppressionManager userId={session.user.id} />
            </Suspense>
          </div>
        </TabsContent>
      </Tabs>

      {/* Feature Highlights */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-center mb-8">Enterprise-Grade Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-blue-100 rounded-full">
                  <Clock className="w-8 h-8 text-blue-600" />
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Intelligent Scheduling</h3>
              <p className="text-sm text-muted-foreground">
                Advanced cron-based job scheduling with automatic retries, priority handling, and real-time monitoring
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-purple-100 rounded-full">
                  <Zap className="w-8 h-8 text-purple-600" />
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Dynamic Content</h3>
              <p className="text-sm text-muted-foreground">
                Spin-text engine generates unlimited content variations to improve deliverability and engagement
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-green-100 rounded-full">
                  <TrendingUp className="w-8 h-8 text-green-600" />
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Send Optimization</h3>
              <p className="text-sm text-muted-foreground">
                Time-zone aware delivery optimization with ISP throttling and engagement-based timing
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-red-100 rounded-full">
                  <Shield className="w-8 h-8 text-red-600" />
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Global Suppression</h3>
              <p className="text-sm text-muted-foreground">
                Cross-list suppression management with automatic bounce and complaint handling for list hygiene
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-orange-100 rounded-full">
                  <GitBranch className="w-8 h-8 text-orange-600" />
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Visual Workflows</h3>
              <p className="text-sm text-muted-foreground">
                Drag-and-drop automation builder with conditional logic, A/B testing, and goal tracking
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-yellow-100 rounded-full">
                  <BarChart3 className="w-8 h-8 text-yellow-600" />
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Advanced Analytics</h3>
              <p className="text-sm text-muted-foreground">
                Comprehensive reporting with custom dashboards, real-time metrics, and performance insights
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
