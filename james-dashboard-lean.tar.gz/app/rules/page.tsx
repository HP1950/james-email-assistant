
import { Suspense } from 'react';
import { RulesManager } from '@/components/rules/rules-manager';

export default function RulesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">Custom Rules</h1>
          <p className="text-muted-foreground">
            Create and manage custom rules for email categorization and filtering
          </p>
        </div>
      </div>

      <Suspense fallback={<div>Loading rules...</div>}>
        <RulesManager />
      </Suspense>
    </div>
  );
}
