
import { Suspense } from 'react';
import { DraftsList } from '@/components/drafts/drafts-list';

export default function DraftsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">Draft Approvals</h1>
          <p className="text-muted-foreground">
            Review and approve AI-composed email responses before sending
          </p>
        </div>
      </div>

      <Suspense fallback={<div>Loading drafts...</div>}>
        <DraftsList />
      </Suspense>
    </div>
  );
}
