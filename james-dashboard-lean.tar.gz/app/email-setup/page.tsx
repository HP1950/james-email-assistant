

import { Suspense } from 'react';
import { MultiAccountSetup } from '@/components/email/multi-account-setup';

export default function EmailSetupPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">Email Account Setup</h1>
          <p className="text-muted-foreground">
            Configure your Gmail accounts for forwarding and reply routing
          </p>
        </div>
      </div>

      <Suspense fallback={<div>Loading email setup...</div>}>
        <MultiAccountSetup />
      </Suspense>
    </div>
  );
}
