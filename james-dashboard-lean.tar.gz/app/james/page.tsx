
/**
 * James Email Specialist Page
 * Main entry point for the James AI email assistant
 */

import { JamesDashboard } from "@/components/james/james-dashboard";

export default function JamesPage() {
  return (
    <div className="container mx-auto py-6">
      <JamesDashboard />
    </div>
  );
}
