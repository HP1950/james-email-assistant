

import { LandingPage } from '@/components/landing/landing-page';

// 🎨 Beautiful Marketing Landing Page - Saved for Future Use
// This is the full marketing page that can be activated later
// Simply change the main page.tsx to use this component when needed

export default function MarketingLandingPage() {
  return <LandingPage />;
}
