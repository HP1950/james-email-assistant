
import { Suspense } from 'react';
import { AutomationSettings } from '@/components/automation/automation-settings';
import { VoiceCommandInterface } from '@/components/voice/voice-command-interface';
import { appConfig } from '@/lib/config';

export default function AutomationPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">Automation & Voice Commands</h1>
          <p className="text-muted-foreground">
            Configure email automation rules and try voice commands with James
          </p>
        </div>
      </div>

      {/* Voice Commands Section */}
      {appConfig.features.voiceCommands && (
        <VoiceCommandInterface />
      )}

      {/* Automation Settings */}
      <Suspense fallback={<div>Loading settings...</div>}>
        <AutomationSettings />
      </Suspense>
    </div>
  );
}
