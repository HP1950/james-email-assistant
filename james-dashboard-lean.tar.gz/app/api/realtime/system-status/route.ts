
import { NextRequest } from 'next/server';
import { getSession } from '@/lib/auth';
import { broadcastToUsers } from '@/app/api/websocket/route';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    const body = await request.json();
    const { status, services, message } = body;

    await broadcastToUsers('system:status', {
      status: status || 'operational',
      services: services || {
        email: 'online',
        ai: 'online',
        database: 'online',
        websocket: 'online',
      },
      message: message || undefined,
    }, [session.user.id]);

    return Response.json({ success: true });
  } catch (error) {
    console.error('System status API error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    // Simulate system performance metrics
    const performanceMetrics = {
      responseTime: Math.floor(Math.random() * 100) + 20, // 20-120ms
      throughput: Math.floor(Math.random() * 500) + 1000, // 1000-1500/min
      errorRate: Math.random() * 0.5, // 0-0.5%
      activeConnections: Math.floor(Math.random() * 50) + 10, // 10-60
      memoryUsage: Math.floor(Math.random() * 30) + 50, // 50-80%
      cpuUsage: Math.floor(Math.random() * 40) + 20, // 20-60%
    };

    await broadcastToUsers('system:performance', {
      metrics: performanceMetrics,
    }, [session.user.id]);

    return Response.json({
      success: true,
      message: 'Performance metrics updated',
      data: performanceMetrics,
    });
  } catch (error) {
    console.error('System performance API error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}
