
import { NextRequest } from 'next/server';
import { getSession } from '@/lib/auth';
import { broadcastToUsers } from '@/app/api/websocket/route';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    const body = await request.json();
    const { type, emailData } = body;

    switch (type) {
      case 'new_email':
        await broadcastToUsers('email:new', {
          email: {
            id: emailData.id || `email_${Date.now()}`,
            gmailId: emailData.gmailId || `gmail_${Date.now()}`,
            subject: emailData.subject || 'New Email Received',
            fromAddress: emailData.fromAddress || 'example@company.com',
            fromName: emailData.fromName || 'John Doe',
            isRead: false,
            isStarred: false,
            priority: emailData.priority || 'MEDIUM',
            sentiment: emailData.sentiment || 'NEUTRAL',
            category: emailData.category || 'Work',
            aiSummary: emailData.aiSummary || 'AI analysis in progress...',
            receivedAt: new Date(),
          },
          action: 'created',
        }, [session.user.id]);

        // Trigger processing simulation
        await simulateEmailProcessing(emailData.id || `email_${Date.now()}`, session.user.id);
        break;

      case 'email_read':
        await broadcastToUsers('email:status', {
          emailId: emailData.id,
          status: {
            isRead: true,
            isStarred: emailData.isStarred || false,
            isArchived: false,
            priority: emailData.priority,
            category: emailData.category,
          },
        }, [session.user.id]);
        break;

      case 'email_starred':
        await broadcastToUsers('email:status', {
          emailId: emailData.id,
          status: {
            isRead: emailData.isRead || true,
            isStarred: true,
            isArchived: false,
            priority: emailData.priority,
            category: emailData.category,
          },
        }, [session.user.id]);
        break;

      default:
        return Response.json({
          success: false,
          error: 'Unknown event type',
        }, { status: 400 });
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Email events API error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}

async function simulateEmailProcessing(emailId: string, userId: string) {
  const stages = [
    { stage: 'parsing', progress: 20, message: 'Parsing email content...', estimatedTimeRemaining: 8 },
    { stage: 'ai_analysis', progress: 50, message: 'Running AI analysis...', estimatedTimeRemaining: 6 },
    { stage: 'categorization', progress: 75, message: 'Categorizing email...', estimatedTimeRemaining: 3 },
    { stage: 'task_extraction', progress: 90, message: 'Extracting tasks...', estimatedTimeRemaining: 1 },
    { stage: 'completed', progress: 100, message: 'Processing completed successfully', estimatedTimeRemaining: 0 },
  ];

  for (let i = 0; i < stages.length; i++) {
    setTimeout(async () => {
      await broadcastToUsers('email:processed', {
        emailId,
        ...stages[i],
      }, [userId]);
    }, i * 2000); // 2 second intervals
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    // Simulate some email events for demo purposes
    const demoEmails = [
      {
        id: 'demo_1',
        subject: 'Project Update Required',
        fromAddress: 'sarah@company.com',
        fromName: 'Sarah Johnson',
        priority: 'HIGH',
        sentiment: 'NEUTRAL',
        category: 'Work',
      },
      {
        id: 'demo_2',
        subject: 'Meeting Reminder',
        fromAddress: 'calendar@company.com',
        fromName: 'Calendar System',
        priority: 'MEDIUM',
        sentiment: 'POSITIVE',
        category: 'Meeting',
      },
    ];

    // Broadcast a random demo email
    const randomEmail = demoEmails[Math.floor(Math.random() * demoEmails.length)];
    
    await broadcastToUsers('email:new', {
      email: {
        ...randomEmail,
        gmailId: `gmail_${Date.now()}`,
        isRead: false,
        isStarred: false,
        aiSummary: 'AI analysis in progress...',
        receivedAt: new Date(),
      },
      action: 'created',
    }, [session.user.id]);

    return Response.json({
      success: true,
      message: 'Demo email event broadcasted',
    });
  } catch (error) {
    console.error('Demo email events error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}
