
import { NextRequest } from 'next/server';
import { getSession } from '@/lib/auth';
import { broadcastToUsers } from '@/app/api/websocket/route';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    const body = await request.json();
    const { title, message, type, priority, actionUrl } = body;

    await broadcastToUsers('notification:new', {
      notification: {
        id: `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        title: title || 'New Notification',
        message: message || 'You have a new notification',
        type: type || 'system',
        priority: priority || 'medium',
        actionUrl: actionUrl || undefined,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
      },
    }, [session.user.id]);

    return Response.json({ success: true });
  } catch (error) {
    console.error('Notifications API error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    // Generate demo notifications
    const demoNotifications = [
      {
        title: 'High Priority Email',
        message: 'You have received an urgent email from your manager',
        type: 'email',
        priority: 'urgent',
      },
      {
        title: 'Task Due Soon',
        message: 'Your task "Review contract" is due in 2 hours',
        type: 'task',
        priority: 'high',
      },
      {
        title: 'AI Analysis Complete',
        message: 'Sentiment analysis completed for 5 emails',
        type: 'system',
        priority: 'medium',
      },
      {
        title: 'Team Collaboration',
        message: 'John Doe shared an email with you',
        type: 'collaboration',
        priority: 'medium',
      },
    ];

    // Send a random demo notification
    const randomNotification = demoNotifications[Math.floor(Math.random() * demoNotifications.length)];
    
    await broadcastToUsers('notification:new', {
      notification: {
        id: `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        ...randomNotification,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
      },
    }, [session.user.id]);

    return Response.json({
      success: true,
      message: 'Demo notification sent',
    });
  } catch (error) {
    console.error('Demo notifications error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}
