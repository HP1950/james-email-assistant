
import { NextRequest } from 'next/server';
import { getSession } from '@/lib/auth';
import { broadcastToUsers } from '@/app/api/websocket/route';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    const body = await request.json();
    const { type, description, metadata } = body;

    await broadcastToUsers('activity:new', {
      activity: {
        id: `activity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type: type || 'email_received',
        description: description || 'New activity recorded',
        metadata: metadata || {},
        createdAt: new Date(),
      },
    }, [session.user.id]);

    return Response.json({ success: true });
  } catch (error) {
    console.error('Activity events API error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    // Generate demo activities
    const demoActivities = [
      {
        type: 'email_received',
        description: 'New email from client about project update',
        metadata: { emailId: 'email_1', subject: 'Project Update Required', priority: 'HIGH' },
      },
      {
        type: 'ai_analysis',
        description: 'AI analysis completed for urgent email',
        metadata: { confidence: 0.95, priority: 'HIGH', processingTime: 1.2 },
      },
      {
        type: 'task_created',
        description: 'Task extracted from email: "Review contract by Friday"',
        metadata: { taskId: 'task_1', dueDate: '2025-07-10', priority: 'MEDIUM' },
      },
      {
        type: 'workflow_run',
        description: 'Auto-reply workflow executed successfully',
        metadata: { workflowId: 'workflow_1', success: true, duration: 0.5 },
      },
      {
        type: 'email_sent',
        description: 'Response sent to client inquiry',
        metadata: { emailId: 'email_2', recipient: 'client@company.com' },
      },
    ];

    // Send a batch of demo activities
    const selectedActivities = demoActivities
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)
      .map(activity => ({
        activity: {
          id: `activity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          ...activity,
          createdAt: new Date(Date.now() - Math.random() * 300000), // Random time in last 5 minutes
        },
      }));

    await broadcastToUsers('activity:bulk', selectedActivities, [session.user.id]);

    return Response.json({
      success: true,
      message: `${selectedActivities.length} demo activities broadcasted`,
    });
  } catch (error) {
    console.error('Demo activity events error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}
