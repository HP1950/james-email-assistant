
// Daily Drop Scheduler API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { DailyDropScheduler } from '@/lib/daily-drop-scheduler';
import { DropScheduleType } from '@/lib/types';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    
    const [schedulers, total] = await Promise.all([
      prisma.dailyDropScheduler.findMany({
        where: { userId: session.user.id },
        include: {
          batches: {
            orderBy: { scheduledAt: 'desc' },
            take: 5
          },
          _count: {
            select: { batches: true }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.dailyDropScheduler.count({
        where: { userId: session.user.id }
      })
    ]);

    return NextResponse.json({
      success: true,
      data: schedulers,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('Daily drop schedulers fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      scheduleType = DropScheduleType.DAILY,
      timeSlots,
      maxDailyEmails = 10000,
      maxHourlyEmails = 1000,
      batchSize = 100,
      batchDelay = 60,
      ispLimits,
      optimizeForTimezone = true,
      optimizeForEngagement = true
    } = body;

    // Validate required fields
    if (!name || !timeSlots || !Array.isArray(timeSlots)) {
      return NextResponse.json(
        { error: 'Name and timeSlots are required' },
        { status: 400 }
      );
    }

    const scheduler = await DailyDropScheduler.createScheduler({
      userId: session.user.id,
      name,
      description,
      scheduleType,
      timeSlots,
      maxDailyEmails,
      maxHourlyEmails,
      batchSize,
      batchDelay,
      ispLimits,
      optimizeForTimezone,
      optimizeForEngagement
    });

    return NextResponse.json({ success: true, data: scheduler });
  } catch (error: any) {
    console.error('Daily drop scheduler creation error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
