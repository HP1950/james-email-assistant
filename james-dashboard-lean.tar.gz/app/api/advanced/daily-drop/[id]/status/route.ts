
// Daily Drop Scheduler Status API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { DailyDropScheduler } from '@/lib/daily-drop-scheduler';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if scheduler exists and user owns it
    const scheduler = await prisma.dailyDropScheduler.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!scheduler) {
      return NextResponse.json({ error: 'Scheduler not found' }, { status: 404 });
    }

    // Get scheduler status
    const status = await DailyDropScheduler.getSchedulerStatus(params.id);

    return NextResponse.json({ success: true, data: status });
  } catch (error: any) {
    console.error('Scheduler status fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
