
// Schedule Campaign for Daily Drop
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { DailyDropScheduler } from '@/lib/daily-drop-scheduler';
import { BatchPriority } from '@/lib/types';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      campaignId,
      recipients,
      priority = BatchPriority.NORMAL,
      startDate
    } = body;

    // Validate required fields
    if (!campaignId || !recipients || !Array.isArray(recipients)) {
      return NextResponse.json(
        { error: 'CampaignId and recipients are required' },
        { status: 400 }
      );
    }

    // Check if scheduler exists and user owns it
    const scheduler = await prisma.dailyDropScheduler.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!scheduler) {
      return NextResponse.json({ error: 'Scheduler not found' }, { status: 404 });
    }

    // Check if campaign exists and user owns it
    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        userId: session.user.id
      }
    });

    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }

    // Schedule campaign
    const batches = await DailyDropScheduler.scheduleCampaign({
      schedulerId: params.id,
      campaignId,
      recipients,
      priority,
      startDate: startDate ? new Date(startDate) : undefined
    });

    return NextResponse.json({ 
      success: true, 
      data: { 
        batchCount: batches.length,
        totalRecipients: recipients.length,
        batches: batches.slice(0, 5) // Return first 5 batches for preview
      }
    });
  } catch (error: any) {
    console.error('Campaign scheduling error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
