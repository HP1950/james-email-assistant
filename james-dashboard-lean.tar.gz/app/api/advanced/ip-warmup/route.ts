
// IP Warmup Plans API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { WarmupStatus } from '@/lib/types';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status');
    const providerId = searchParams.get('providerId');
    
    const where: any = { userId: session.user.id };
    if (status) where.status = status;
    if (providerId) where.providerId = providerId;
    
    const [plans, total] = await Promise.all([
      prisma.iPWarmupPlan.findMany({
        where,
        include: {
          provider: {
            select: {
              id: true,
              name: true,
              provider: true
            }
          },
          dailyLogs: {
            orderBy: { date: 'desc' },
            take: 7
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.iPWarmupPlan.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      data: plans,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('IP warmup plans fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      providerId,
      ipAddress,
      domain,
      startDate,
      duration = 30,
      dailyVolumeIncrease = 1.5,
      maxDailyVolume,
      startingVolume = 50
    } = body;

    // Validate required fields
    if (!name || !providerId || !ipAddress || !domain || !maxDailyVolume) {
      return NextResponse.json(
        { error: 'Name, providerId, ipAddress, domain, and maxDailyVolume are required' },
        { status: 400 }
      );
    }

    // Check if provider exists and user owns it
    const provider = await prisma.emailServiceProvider.findFirst({
      where: {
        id: providerId,
        userId: session.user.id
      }
    });

    if (!provider) {
      return NextResponse.json({ error: 'Provider not found' }, { status: 404 });
    }

    const plan = await prisma.iPWarmupPlan.create({
      data: {
        userId: session.user.id,
        providerId,
        name,
        description,
        ipAddress,
        domain,
        startDate: startDate ? new Date(startDate) : new Date(),
        duration,
        dailyVolumeIncrease,
        maxDailyVolume,
        startingVolume,
        status: WarmupStatus.PLANNED
      }
    });

    return NextResponse.json({ success: true, data: plan });
  } catch (error: any) {
    console.error('IP warmup plan creation error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
