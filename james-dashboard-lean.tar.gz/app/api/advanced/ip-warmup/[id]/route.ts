
// Individual IP Warmup Plan API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { WarmupStatus } from '@/lib/types';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const plan = await prisma.iPWarmupPlan.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      },
      include: {
        provider: true,
        dailyLogs: {
          orderBy: { date: 'asc' }
        }
      }
    });

    if (!plan) {
      return NextResponse.json({ error: 'Warmup plan not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: plan });
  } catch (error: any) {
    console.error('IP warmup plan fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      startDate,
      duration,
      dailyVolumeIncrease,
      maxDailyVolume,
      startingVolume,
      isActive
    } = body;

    // Check if plan exists and user owns it
    const existingPlan = await prisma.iPWarmupPlan.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!existingPlan) {
      return NextResponse.json({ error: 'Warmup plan not found' }, { status: 404 });
    }

    const plan = await prisma.iPWarmupPlan.update({
      where: { id: params.id },
      data: {
        name,
        description,
        startDate: startDate ? new Date(startDate) : undefined,
        duration,
        dailyVolumeIncrease,
        maxDailyVolume,
        startingVolume,
        isActive
      }
    });

    return NextResponse.json({ success: true, data: plan });
  } catch (error: any) {
    console.error('IP warmup plan update error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if plan exists and user owns it
    const plan = await prisma.iPWarmupPlan.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!plan) {
      return NextResponse.json({ error: 'Warmup plan not found' }, { status: 404 });
    }

    // Don't allow deletion of active plans
    if (plan.status === WarmupStatus.ACTIVE) {
      return NextResponse.json(
        { error: 'Cannot delete active warmup plan' },
        { status: 400 }
      );
    }

    // Delete plan
    await prisma.iPWarmupPlan.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('IP warmup plan deletion error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
