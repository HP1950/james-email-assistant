
// Email Service Providers API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { EmailProvider, ProviderHealthStatus } from '@/lib/types';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const provider = searchParams.get('provider');
    const isActive = searchParams.get('isActive');
    
    const where: any = { userId: session.user.id };
    if (provider) where.provider = provider;
    if (isActive !== null) where.isActive = isActive === 'true';
    
    const [providers, total] = await Promise.all([
      prisma.emailServiceProvider.findMany({
        where,
        include: {
          healthLogs: {
            orderBy: { checkedAt: 'desc' },
            take: 5
          },
          _count: {
            select: {
              deliveryLogs: true,
              warmupPlans: true
            }
          }
        },
        orderBy: [
          { isPrimary: 'desc' },
          { priority: 'asc' },
          { createdAt: 'desc' }
        ],
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.emailServiceProvider.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      data: providers,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('Email providers fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      provider,
      apiKey,
      apiSecret,
      region,
      endpoint,
      isPrimary = false,
      priority = 1,
      dailyLimit,
      hourlyLimit,
      perMinuteLimit,
      sendingDomains = [],
      trackingDomain,
      dedicatedIPs = [],
      ipWarmupEnabled = false,
      enableTracking = true,
      enableBounceHandling = true,
      enableComplaintHandling = true
    } = body;

    // Validate required fields
    if (!name || !provider || !apiKey) {
      return NextResponse.json(
        { error: 'Name, provider, and apiKey are required' },
        { status: 400 }
      );
    }

    // If setting as primary, unset other primary providers
    if (isPrimary) {
      await prisma.emailServiceProvider.updateMany({
        where: { 
          userId: session.user.id,
          isPrimary: true 
        },
        data: { isPrimary: false }
      });
    }

    const emailProvider = await prisma.emailServiceProvider.create({
      data: {
        userId: session.user.id,
        name,
        provider,
        apiKey,
        apiSecret,
        region,
        endpoint,
        isPrimary,
        priority,
        dailyLimit,
        hourlyLimit,
        perMinuteLimit,
        sendingDomains,
        trackingDomain,
        dedicatedIPs,
        ipWarmupEnabled,
        enableTracking,
        enableBounceHandling,
        enableComplaintHandling,
        healthStatus: ProviderHealthStatus.HEALTHY
      }
    });

    return NextResponse.json({ success: true, data: emailProvider });
  } catch (error: any) {
    console.error('Email provider creation error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
