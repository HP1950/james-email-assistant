
// Individual Email Service Provider API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const provider = await prisma.emailServiceProvider.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      },
      include: {
        deliveryLogs: {
          orderBy: { sentAt: 'desc' },
          take: 20
        },
        healthLogs: {
          orderBy: { checkedAt: 'desc' },
          take: 10
        },
        warmupPlans: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!provider) {
      return NextResponse.json({ error: 'Provider not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: provider });
  } catch (error: any) {
    console.error('Email provider fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      apiKey,
      apiSecret,
      region,
      endpoint,
      isActive,
      isPrimary,
      priority,
      dailyLimit,
      hourlyLimit,
      perMinuteLimit,
      sendingDomains,
      trackingDomain,
      dedicatedIPs,
      ipWarmupEnabled,
      enableTracking,
      enableBounceHandling,
      enableComplaintHandling
    } = body;

    // Check if provider exists and user owns it
    const existingProvider = await prisma.emailServiceProvider.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!existingProvider) {
      return NextResponse.json({ error: 'Provider not found' }, { status: 404 });
    }

    // If setting as primary, unset other primary providers
    if (isPrimary && !existingProvider.isPrimary) {
      await prisma.emailServiceProvider.updateMany({
        where: { 
          userId: session.user.id,
          isPrimary: true 
        },
        data: { isPrimary: false }
      });
    }

    const provider = await prisma.emailServiceProvider.update({
      where: { id: params.id },
      data: {
        name,
        apiKey,
        apiSecret,
        region,
        endpoint,
        isActive,
        isPrimary,
        priority,
        dailyLimit,
        hourlyLimit,
        perMinuteLimit,
        sendingDomains,
        trackingDomain,
        dedicatedIPs,
        ipWarmupEnabled,
        enableTracking,
        enableBounceHandling,
        enableComplaintHandling
      }
    });

    return NextResponse.json({ success: true, data: provider });
  } catch (error: any) {
    console.error('Email provider update error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if provider exists and user owns it
    const provider = await prisma.emailServiceProvider.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!provider) {
      return NextResponse.json({ error: 'Provider not found' }, { status: 404 });
    }

    // Don't allow deletion of primary provider if it's the only one
    if (provider.isPrimary) {
      const otherProviders = await prisma.emailServiceProvider.count({
        where: {
          userId: session.user.id,
          id: { not: params.id },
          isActive: true
        }
      });

      if (otherProviders === 0) {
        return NextResponse.json(
          { error: 'Cannot delete the only active provider' },
          { status: 400 }
        );
      }
    }

    // Delete provider
    await prisma.emailServiceProvider.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Email provider deletion error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
