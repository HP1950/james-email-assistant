
// Custom Reports API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { ReportType } from '@/lib/types';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const type = searchParams.get('type');
    const isScheduled = searchParams.get('isScheduled');
    
    const where: any = { userId: session.user.id };
    if (type) where.type = type;
    if (isScheduled !== null) where.isScheduled = isScheduled === 'true';
    
    const [reports, total] = await Promise.all([
      prisma.customReport.findMany({
        where,
        include: {
          executions: {
            orderBy: { startedAt: 'desc' },
            take: 5
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.customReport.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      data: reports,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('Custom reports fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      type,
      dataSource,
      metrics,
      dimensions,
      filters,
      charts,
      layout,
      isScheduled = false,
      scheduleConfig,
      recipients = [],
      emailOnCompletion = false,
      isPublic = false,
      sharedWith = []
    } = body;

    // Validate required fields
    if (!name || !type || !dataSource || !metrics) {
      return NextResponse.json(
        { error: 'Name, type, dataSource, and metrics are required' },
        { status: 400 }
      );
    }

    const report = await prisma.customReport.create({
      data: {
        userId: session.user.id,
        name,
        description,
        type,
        dataSource,
        metrics,
        dimensions,
        filters,
        charts,
        layout,
        isScheduled,
        scheduleConfig,
        recipients,
        emailOnCompletion,
        isPublic,
        sharedWith
      }
    });

    return NextResponse.json({ success: true, data: report });
  } catch (error: any) {
    console.error('Custom report creation error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
