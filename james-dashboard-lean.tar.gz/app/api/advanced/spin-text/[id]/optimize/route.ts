
// AI Optimization API for Spin-Text
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { SpinTextEngine } from '@/lib/spin-text-engine';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if template exists and user owns it
    const template = await prisma.spinTextTemplate.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!template) {
      return NextResponse.json({ error: 'Template not found' }, { status: 404 });
    }

    // Optimize with AI
    await SpinTextEngine.optimizeWithAI(params.id);

    // Get updated template with AI suggestions
    const updatedTemplate = await prisma.spinTextTemplate.findUnique({
      where: { id: params.id }
    });

    return NextResponse.json({ 
      success: true, 
      data: updatedTemplate,
      message: 'AI optimization completed'
    });
  } catch (error: any) {
    console.error('AI optimization error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
