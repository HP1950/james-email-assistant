
// Spin-Text Engine API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { SpinTextEngine } from '@/lib/spin-text-engine';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category');
    
    const where: any = { userId: session.user.id };
    if (category) where.category = category;
    
    const [templates, total] = await Promise.all([
      prisma.spinTextTemplate.findMany({
        where,
        include: {
          variations: true,
          _count: {
            select: {
              campaigns: true,
              automationEmails: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.spinTextTemplate.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      data: templates,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('Spin-text templates fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      category,
      originalText,
      spinTextContent,
      maxVariations = 50
    } = body;

    // Validate required fields
    if (!name || !originalText || !spinTextContent) {
      return NextResponse.json(
        { error: 'Name, originalText, and spinTextContent are required' },
        { status: 400 }
      );
    }

    const template = await SpinTextEngine.createTemplate({
      userId: session.user.id,
      name,
      description,
      category,
      originalText,
      spinTextContent,
      maxVariations
    });

    return NextResponse.json({ success: true, data: template });
  } catch (error: any) {
    console.error('Spin-text template creation error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
