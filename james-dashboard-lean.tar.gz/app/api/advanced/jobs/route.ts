
// Job Scheduler API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { jobRunner } from '@/lib/job-runner';
import { JobType, JobPriority } from '@/lib/types';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const jobType = searchParams.get('jobType');
    const isActive = searchParams.get('isActive');
    
    const where: any = {
      OR: [
        { userId: session.user.id },
        { userId: null } // System jobs
      ]
    };
    
    if (jobType) where.jobType = jobType;
    if (isActive !== null) where.isActive = isActive === 'true';
    
    const [jobs, total] = await Promise.all([
      prisma.jobScheduler.findMany({
        where,
        include: {
          executions: {
            orderBy: { startedAt: 'desc' },
            take: 5
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.jobScheduler.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      data: jobs,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('Jobs fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      jobType,
      cronExpression,
      timezone = 'UTC',
      config,
      priority = JobPriority.NORMAL,
      maxRetries = 3,
      retryDelay = 5,
      timeout = 300,
      concurrency = 1
    } = body;

    // Validate required fields
    if (!name || !jobType || !cronExpression) {
      return NextResponse.json(
        { error: 'Name, jobType, and cronExpression are required' },
        { status: 400 }
      );
    }

    // Validate cron expression
    if (!this.isValidCronExpression(cronExpression)) {
      return NextResponse.json(
        { error: 'Invalid cron expression' },
        { status: 400 }
      );
    }

    const job = await jobRunner.addJob({
      name,
      jobType,
      cronExpression,
      config,
      priority,
      userId: session.user.id
    });

    return NextResponse.json({ success: true, data: job });
  } catch (error: any) {
    console.error('Job creation error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

function isValidCronExpression(expression: string): boolean {
  // Basic cron expression validation
  const parts = expression.trim().split(/\s+/);
  return parts.length === 5 || parts.length === 6;
}
