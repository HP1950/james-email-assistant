
// Individual Job Management API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { jobRunner } from '@/lib/job-runner';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const job = await prisma.jobScheduler.findFirst({
      where: {
        id: params.id,
        OR: [
          { userId: session.user.id },
          { userId: null }
        ]
      },
      include: {
        executions: {
          orderBy: { startedAt: 'desc' },
          take: 20
        }
      }
    });

    if (!job) {
      return NextResponse.json({ error: 'Job not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: job });
  } catch (error: any) {
    console.error('Job fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { name, description, cronExpression, timezone, config, isActive } = body;

    // Check if job exists and user has permission
    const existingJob = await prisma.jobScheduler.findFirst({
      where: {
        id: params.id,
        OR: [
          { userId: session.user.id },
          { userId: null }
        ]
      }
    });

    if (!existingJob) {
      return NextResponse.json({ error: 'Job not found' }, { status: 404 });
    }

    const job = await prisma.jobScheduler.update({
      where: { id: params.id },
      data: {
        name,
        description,
        cronExpression,
        timezone,
        config,
        isActive
      }
    });

    // Reschedule if active
    if (isActive) {
      await jobRunner.resumeJob(params.id);
    } else {
      await jobRunner.pauseJob(params.id);
    }

    return NextResponse.json({ success: true, data: job });
  } catch (error: any) {
    console.error('Job update error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if job exists and user has permission
    const existingJob = await prisma.jobScheduler.findFirst({
      where: {
        id: params.id,
        userId: session.user.id // Only allow deleting own jobs
      }
    });

    if (!existingJob) {
      return NextResponse.json({ error: 'Job not found' }, { status: 404 });
    }

    // Pause job first
    await jobRunner.pauseJob(params.id);

    // Delete job
    await prisma.jobScheduler.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Job deletion error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
