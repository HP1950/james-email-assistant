
// Manual Job Execution API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { jobRunner } from '@/lib/job-runner';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if job exists and user has permission
    const job = await prisma.jobScheduler.findFirst({
      where: {
        id: params.id,
        OR: [
          { userId: session.user.id },
          { userId: null }
        ]
      }
    });

    if (!job) {
      return NextResponse.json({ error: 'Job not found' }, { status: 404 });
    }

    // Execute job manually
    await jobRunner.executeJob(params.id, 'manual');

    return NextResponse.json({ 
      success: true, 
      message: 'Job execution started' 
    });
  } catch (error: any) {
    console.error('Job execution error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
