
// Individual Suppression List API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { SuppressionManager } from '@/lib/suppression-manager';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const list = await prisma.globalSuppressionList.findFirst({
      where: {
        id: params.id,
        OR: [
          { userId: session.user.id },
          { isGlobal: true }
        ]
      }
    });

    if (!list) {
      return NextResponse.json({ error: 'Suppression list not found' }, { status: 404 });
    }

    const [suppressions, total] = await Promise.all([
      prisma.suppressionEntry.findMany({
        where: { suppressionListId: params.id },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.suppressionEntry.count({
        where: { suppressionListId: params.id }
      })
    ]);

    return NextResponse.json({
      success: true,
      data: {
        list,
        suppressions,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit)
        }
      }
    });
  } catch (error: any) {
    console.error('Suppression list fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      autoAddBounces,
      autoAddComplaints,
      autoAddUnsubscribes,
      appliedToAllLists,
      specificLists
    } = body;

    // Check if list exists and user owns it
    const existingList = await prisma.globalSuppressionList.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!existingList) {
      return NextResponse.json({ error: 'Suppression list not found' }, { status: 404 });
    }

    const list = await prisma.globalSuppressionList.update({
      where: { id: params.id },
      data: {
        name,
        description,
        autoAddBounces,
        autoAddComplaints,
        autoAddUnsubscribes,
        appliedToAllLists,
        specificLists
      }
    });

    return NextResponse.json({ success: true, data: list });
  } catch (error: any) {
    console.error('Suppression list update error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if list exists and user owns it
    const list = await prisma.globalSuppressionList.findFirst({
      where: {
        id: params.id,
        userId: session.user.id
      }
    });

    if (!list) {
      return NextResponse.json({ error: 'Suppression list not found' }, { status: 404 });
    }

    // Delete list (suppressions will be deleted via cascade)
    await prisma.globalSuppressionList.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Suppression list deletion error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
