
// Suppression Check API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { SuppressionManager } from '@/lib/suppression-manager';

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { emails } = body;

    if (!emails || !Array.isArray(emails)) {
      return NextResponse.json(
        { error: 'Emails array is required' },
        { status: 400 }
      );
    }

    // Filter emails against suppressions
    const result = await SuppressionManager.filterEmailList(emails, session.user.id);

    return NextResponse.json({ success: true, data: result });
  } catch (error: any) {
    console.error('Suppression check error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
