
// Global Suppression System API
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { PrismaClient } from '@prisma/client';
import { SuppressionManager } from '@/lib/suppression-manager';
import { SuppressionScope } from '@/lib/types';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const scope = searchParams.get('scope');
    
    const where: any = {
      OR: [
        { userId: session.user.id },
        { isGlobal: true }
      ]
    };
    
    if (scope) where.scope = scope;
    
    const [lists, total] = await Promise.all([
      prisma.globalSuppressionList.findMany({
        where,
        include: {
          suppressions: {
            take: 5,
            orderBy: { createdAt: 'desc' }
          },
          _count: {
            select: { suppressions: true }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.globalSuppressionList.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      data: lists,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('Suppression lists fetch error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      scope = SuppressionScope.USER,
      autoAddBounces = true,
      autoAddComplaints = true,
      autoAddUnsubscribes = true,
      appliedToAllLists = false,
      specificLists = []
    } = body;

    // Validate required fields
    if (!name) {
      return NextResponse.json(
        { error: 'Name is required' },
        { status: 400 }
      );
    }

    const list = await SuppressionManager.createSuppressionList({
      userId: session.user.id,
      name,
      description,
      scope,
      autoAddBounces,
      autoAddComplaints,
      autoAddUnsubscribes,
      appliedToAllLists,
      specificLists
    });

    return NextResponse.json({ success: true, data: list });
  } catch (error: any) {
    console.error('Suppression list creation error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
