
import { NextRequest } from 'next/server';
import { Server as SocketIOServer } from 'socket.io';
import { Server as HTTPServer } from 'http';
import { 
  verifyWebSocketToken, 
  extractTokenFromQuery, 
  extractTokenFromHeaders,
  generateSessionId 
} from '@/lib/websocket-auth';
import { 
  ConnectionManager, 
  EventBroadcaster, 
  SubscriptionManager, 
  RateLimiter,
  PerformanceMonitor,
  validateWebSocketMessage 
} from '@/lib/websocket-utils';
import { 
  WebSocketConnection, 
  WebSocketEventMap, 
  WebSocketAuthToken 
} from '@/lib/websocket-types';

export const dynamic = 'force-dynamic';

// Global instances for connection management
const connectionManager = new ConnectionManager();
const subscriptionManager = new SubscriptionManager();
const rateLimiter = new RateLimiter();
const performanceMonitor = new PerformanceMonitor();

let io: SocketIOServer | null = null;

// Initialize Socket.IO server
function initializeSocketIO(server: HTTPServer): SocketIOServer {
  if (io) return io;
  
  io = new SocketIOServer(server, {
    path: '/api/websocket',
    cors: {
      origin: process.env.NEXTAUTH_URL || 'http://localhost:3000',
      methods: ['GET', 'POST'],
      credentials: true,
    },
    pingTimeout: 60000,
    pingInterval: 25000,
    maxHttpBufferSize: 1e6, // 1MB
    allowEIO3: true,
  });

  // Authentication middleware
  io.use(async (socket, next) => {
    try {
      const startTime = Date.now();
      
      // Extract token from query or headers
      const token = extractTokenFromQuery(socket.handshake.query.token as string) ||
                   extractTokenFromHeaders(socket.handshake.headers);
      
      if (!token) {
        return next(new Error('Authentication token required'));
      }

      // Verify token
      const authData = await verifyWebSocketToken(token);
      if (!authData) {
        return next(new Error('Invalid authentication token'));
      }

      // Rate limiting
      const clientId = socket.handshake.address;
      if (!rateLimiter.isAllowed(clientId, 10, 60000)) { // 10 connections per minute
        return next(new Error('Rate limit exceeded'));
      }

      // Attach auth data to socket
      socket.data.auth = authData;
      socket.data.sessionId = generateSessionId();
      
      performanceMonitor.recordMetric('auth_time', Date.now() - startTime);
      next();
    } catch (error) {
      console.error('WebSocket authentication error:', error);
      next(new Error('Authentication failed'));
    }
  });

  // Connection event handlers
  io.on('connection', (socket) => {
    const authData: WebSocketAuthToken = socket.data.auth;
    const sessionId: string = socket.data.sessionId;
    
    console.log(`WebSocket connected: ${authData.userId} (${socket.id})`);

    // Create connection record
    const connection: WebSocketConnection = {
      id: socket.id,
      userId: authData.userId,
      sessionId,
      connectedAt: new Date(),
      lastHeartbeat: new Date(),
      subscriptions: [],
      metadata: {
        userAgent: socket.handshake.headers['user-agent'] || 'Unknown',
        ipAddress: socket.handshake.address,
        page: socket.handshake.query.page as string || '/',
      },
    };

    connectionManager.addConnection(connection);

    // Broadcast user connection
    const eventBroadcaster = new EventBroadcaster(connectionManager);
    eventBroadcaster.broadcast('collaboration:user:join', {
      id: `user_join_${Date.now()}`,
      userId: authData.userId,
      timestamp: new Date(),
      type: 'collaboration:user:join',
      user: {
        id: authData.userId,
        name: authData.name || '',
        email: authData.email,
        avatar: undefined,
      },
      status: 'online',
      lastSeen: new Date(),
      currentPage: connection.metadata.page,
    }, { excludeUsers: [authData.userId] });

    // Send initial data
    socket.emit('auth:success', { 
      userId: authData.userId, 
      user: authData 
    });

    // Subscribe to user-specific events
    socket.join(`user:${authData.userId}`);

    // Handle heartbeat
    socket.on('heartbeat', () => {
      connectionManager.updateLastHeartbeat(socket.id);
      socket.emit('heartbeat', { 
        userId: authData.userId, 
        timestamp: new Date() 
      });
    });

    // Handle subscriptions
    socket.on('subscribe', (data: { pattern: string; filters?: any }) => {
      const subscription = {
        id: `sub_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        pattern: data.pattern,
        filters: data.filters,
        createdAt: new Date(),
      };
      
      subscriptionManager.subscribe(socket.id, subscription);
      connection.subscriptions.push(subscription.pattern);
      
      socket.emit('subscribed', { subscriptionId: subscription.id });
    });

    socket.on('unsubscribe', (data: { subscriptionId: string }) => {
      subscriptionManager.unsubscribe(socket.id, data.subscriptionId);
      socket.emit('unsubscribed', { subscriptionId: data.subscriptionId });
    });

    // Handle custom events
    socket.on('email:status:update', (data: any) => {
      if (!rateLimiter.isAllowed(`${authData.userId}:email_update`, 50, 60000)) {
        socket.emit('rate_limit', { 
          limit: 50, 
          remaining: 0, 
          resetTime: new Date(Date.now() + 60000),
          retryAfter: 60 
        });
        return;
      }

      eventBroadcaster.broadcastToUser(authData.userId, 'email:status', {
        id: `email_status_${Date.now()}`,
        userId: authData.userId,
        timestamp: new Date(),
        type: 'email:status',
        emailId: data.emailId,
        status: data.status,
      });
    });

    socket.on('collaboration:typing', (data: any) => {
      eventBroadcaster.broadcast('collaboration:typing', {
        id: `typing_${Date.now()}`,
        userId: authData.userId,
        timestamp: new Date(),
        type: 'collaboration:typing',
        emailId: data.emailId,
        isTyping: data.isTyping,
        location: data.location,
      }, { excludeUsers: [authData.userId] });
    });

    // Handle page change
    socket.on('page:change', (data: { page: string }) => {
      connection.metadata.page = data.page;
    });

    // Handle disconnect
    socket.on('disconnect', (reason) => {
      console.log(`WebSocket disconnected: ${authData.userId} (${socket.id}) - ${reason}`);
      
      connectionManager.removeConnection(socket.id);
      subscriptionManager.removeAllSubscriptions(socket.id);

      // Check if user has any other connections
      const userConnections = connectionManager.getUserConnections(authData.userId);
      if (userConnections.length === 0) {
        eventBroadcaster.broadcast('collaboration:user:leave', {
          id: `user_leave_${Date.now()}`,
          userId: authData.userId,
          timestamp: new Date(),
          type: 'collaboration:user:leave',
          user: {
            id: authData.userId,
            name: authData.name || '',
            email: authData.email,
            avatar: undefined,
          },
          status: 'offline',
          lastSeen: new Date(),
        }, { excludeUsers: [authData.userId] });
      }
    });

    // Error handling
    socket.on('error', (error) => {
      console.error(`WebSocket error for user ${authData.userId}:`, error);
      socket.emit('error', {
        id: `error_${Date.now()}`,
        userId: authData.userId,
        timestamp: new Date(),
        type: 'error',
        error: {
          code: 'SOCKET_ERROR',
          message: error.message || 'Unknown socket error',
        },
        severity: 'medium',
      });
    });
  });

  // Cleanup stale connections every 30 seconds
  setInterval(() => {
    const staleConnections = connectionManager.getStaleConnections(90000); // 90 seconds
    staleConnections.forEach(connection => {
      const socket = io?.sockets.sockets.get(connection.id);
      if (socket) {
        socket.disconnect(true);
      }
      connectionManager.removeConnection(connection.id);
    });
    
    rateLimiter.cleanup();
  }, 30000);

  return io;
}

// API Routes for WebSocket management
export async function GET(request: NextRequest) {
  try {
    const connections = connectionManager.getAllConnections();
    const metrics = performanceMonitor.getAllMetrics();
    
    return Response.json({
      success: true,
      data: {
        activeConnections: connections.length,
        uniqueUsers: new Set(connections.map(c => c.userId)).size,
        metrics,
        status: 'operational',
      },
    });
  } catch (error) {
    console.error('WebSocket status error:', error);
    return Response.json({
      success: false,
      error: 'Failed to get WebSocket status',
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, data } = body;

    if (!action) {
      return Response.json({
        success: false,
        error: 'Action is required',
      }, { status: 400 });
    }

    const eventBroadcaster = new EventBroadcaster(connectionManager);

    switch (action) {
      case 'broadcast':
        if (!data.event || !data.payload) {
          return Response.json({
            success: false,
            error: 'Event and payload are required for broadcast',
          }, { status: 400 });
        }
        
        eventBroadcaster.broadcast(data.event, {
          id: `api_broadcast_${Date.now()}`,
          userId: 'system',
          timestamp: new Date(),
          type: data.event,
          ...data.payload,
        });
        break;

      case 'broadcast_to_user':
        if (!data.userId || !data.event || !data.payload) {
          return Response.json({
            success: false,
            error: 'UserId, event, and payload are required',
          }, { status: 400 });
        }
        
        eventBroadcaster.broadcastToUser(data.userId, data.event, {
          id: `api_user_broadcast_${Date.now()}`,
          userId: data.userId,
          timestamp: new Date(),
          type: data.event,
          ...data.payload,
        });
        break;

      case 'system_status':
        eventBroadcaster.broadcast('system:status', {
          id: `system_status_${Date.now()}`,
          userId: 'system',
          timestamp: new Date(),
          type: 'system:status',
          status: data.status || 'operational',
          services: data.services || {
            email: 'online',
            ai: 'online',
            database: 'online',
            websocket: 'online',
          },
          message: data.message,
        });
        break;

      default:
        return Response.json({
          success: false,
          error: 'Unknown action',
        }, { status: 400 });
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('WebSocket API error:', error);
    return Response.json({
      success: false,
      error: 'Internal server error',
    }, { status: 500 });
  }
}

// Export the Socket.IO instance for use in other parts of the application
export function getSocketIOInstance(): SocketIOServer | null {
  return io;
}

// Utility function to broadcast events from other API routes
export async function broadcastToUsers(event: keyof WebSocketEventMap, data: any, userIds?: string[]) {
  if (!io) return;
  
  const eventBroadcaster = new EventBroadcaster(connectionManager);
  
  if (userIds) {
    userIds.forEach(userId => {
      eventBroadcaster.broadcastToUser(userId, event, {
        id: `api_${event}_${Date.now()}`,
        userId,
        timestamp: new Date(),
        type: event,
        ...data,
      });
    });
  } else {
    eventBroadcaster.broadcast(event, {
      id: `api_${event}_${Date.now()}`,
      userId: 'system',
      timestamp: new Date(),
      type: event,
      ...data,
    });
  }
}
