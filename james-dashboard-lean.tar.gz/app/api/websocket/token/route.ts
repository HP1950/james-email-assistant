
import { NextRequest } from 'next/server';
import { getSession } from '@/lib/auth';
import { generateWebSocketToken, generateSessionId } from '@/lib/websocket-auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    const sessionId = generateSessionId();
    const token = await generateWebSocketToken(
      session.user.id,
      sessionId,
      session.user
    );

    return Response.json({
      success: true,
      data: {
        token,
        sessionId,
        expiresIn: 24 * 60 * 60, // 24 hours in seconds
      },
    });
  } catch (error) {
    console.error('WebSocket token generation error:', error);
    return Response.json({
      success: false,
      error: 'Failed to generate WebSocket token',
    }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session?.user?.id) {
      return Response.json({
        success: false,
        error: 'Authentication required',
      }, { status: 401 });
    }

    // Return WebSocket connection info
    return Response.json({
      success: true,
      data: {
        url: process.env.NEXTAUTH_URL || 'http://localhost:3000',
        path: '/api/websocket',
        userId: session.user.id,
        authenticated: true,
      },
    });
  } catch (error) {
    console.error('WebSocket info error:', error);
    return Response.json({
      success: false,
      error: 'Failed to get WebSocket info',
    }, { status: 500 });
  }
}
