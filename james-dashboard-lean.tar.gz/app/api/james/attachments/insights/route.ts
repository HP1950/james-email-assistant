
/**
 * James Attachment Insights API
 * Advanced insights and recommendations based on attachment analysis
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { 
      attachment_ids = [], 
      insight_types = ['all'],
      time_range = '30d',
      include_recommendations = true 
    } = await request.json();

    if (!Array.isArray(attachment_ids) || attachment_ids.length === 0) {
      return NextResponse.json({ 
        error: "At least one attachment ID is required" 
      }, { status: 400 });
    }

    // Get attachment analyses
    const attachmentAnalyses = await prisma.jamesAttachmentAnalysis.findMany({
      where: {
        attachmentId: { in: attachment_ids },
        userId: session.user.id!
      },
      include: {
        attachment: {
          select: {
            originalName: true,
            mimeType: true,
            size: true,
            createdAt: true,
            threadId: true,
            messageId: true
          }
        }
      }
    });

    if (attachmentAnalyses.length === 0) {
      return NextResponse.json({ 
        error: 'No analyzed attachments found for provided IDs' 
      }, { status: 404 });
    }

    // Generate cross-document insights
    const insights = await generateCrossDocumentInsights(attachmentAnalyses);
    
    // Generate patterns and trends
    const patterns = await identifyPatterns(attachmentAnalyses);
    
    // Generate recommendations if requested
    let recommendations: any[] = [];
    if (include_recommendations) {
      recommendations = await generateRecommendations(attachmentAnalyses, insights, patterns);
    }

    return NextResponse.json({
      success: true,
      data: {
        analyzed_attachments: attachmentAnalyses.length,
        insight_summary: {
          total_action_items: insights.totalActionItems,
          high_priority_actions: insights.highPriorityActions,
          upcoming_deadlines: insights.upcomingDeadlines,
          financial_impact: insights.financialImpact,
          unique_stakeholders: insights.uniqueStakeholders,
          risk_indicators: insights.riskIndicators.length,
          opportunity_indicators: insights.opportunityIndicators.length
        },
        
        detailed_insights: {
          cross_document_themes: insights.crossDocumentThemes,
          action_item_analysis: {
            by_priority: insights.actionItemsByPriority,
            by_assignee: {},
            by_status: insights.actionItemsByPriority,
            overdue_items: []
          },
          
          financial_analysis: {
            total_amounts_by_currency: insights.financialByCurrency,
            by_type: insights.financialByType,
            trend_indicators: ['stable'],
            budget_implications: []
          },
          
          timeline_analysis: {
            upcoming_milestones: insights.upcomingDeadlines,
            deadline_distribution: {},
            critical_path_items: []
          },
          
          stakeholder_network: {
            key_contacts: insights.keyContacts,
            communication_patterns: {},
            influence_mapping: {}
          },
          
          risk_opportunity_matrix: {
            high_risk_items: insights.riskIndicators.filter(r => r.severity === 'high'),
            medium_risk_items: insights.riskIndicators.filter(r => r.severity === 'medium'),
            high_opportunity_items: insights.opportunityIndicators.filter(o => o.potential === 'high'),
            medium_opportunity_items: insights.opportunityIndicators.filter(o => o.potential === 'medium')
          }
        },
        
        identified_patterns: {
          document_patterns: patterns.documentPatterns,
          temporal_patterns: patterns.temporalPatterns,
          stakeholder_patterns: patterns.stakeholderPatterns,
          content_patterns: patterns.contentPatterns
        },
        
        ...(include_recommendations && {
          ai_recommendations: {
            immediate_actions: recommendations.filter(r => r.urgency === 'immediate'),
            short_term_actions: recommendations.filter(r => r.urgency === 'short_term'),
            strategic_actions: recommendations.filter(r => r.urgency === 'strategic'),
            process_improvements: recommendations.filter(r => r.category === 'process'),
            risk_mitigations: recommendations.filter(r => r.category === 'risk'),
            opportunity_captures: recommendations.filter(r => r.category === 'opportunity')
          }
        }),
        
        processing_metadata: {
          analysis_timestamp: new Date().toISOString(),
          documents_analyzed: attachmentAnalyses.length,
          average_confidence: attachmentAnalyses.reduce((sum, a) => sum + a.confidenceScore, 0) / attachmentAnalyses.length,
          data_quality_distribution: attachmentAnalyses.reduce((acc: any, a) => {
            acc[a.dataQuality] = (acc[a.dataQuality] || 0) + 1;
            return acc;
          }, {})
        }
      }
    });

  } catch (error) {
    console.error('Attachment insights generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate attachment insights' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const timeRange = searchParams.get('time_range') || '30d';
    const insightType = searchParams.get('type') || 'summary';

    // Calculate date range
    const daysBack = timeRange === '7d' ? 7 : timeRange === '90d' ? 90 : 30;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysBack);

    // Get user's attachment analyses within time range
    const attachmentAnalyses = await prisma.jamesAttachmentAnalysis.findMany({
      where: {
        userId: session.user.id!,
        createdAt: { gte: startDate }
      },
      include: {
        attachment: {
          select: {
            originalName: true,
            mimeType: true,
            size: true,
            createdAt: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    if (insightType === 'summary') {
      // Return high-level summary
      const totalActionItems = attachmentAnalyses.reduce((sum, a) => 
        sum + (a.actionItems as any[]).length, 0);
      const totalFinancialEntries = attachmentAnalyses.reduce((sum, a) => 
        sum + (a.financialData as any[]).length, 0);
      const totalStakeholders = new Set(
        attachmentAnalyses.flatMap(a => 
          (a.contacts as any[]).map(c => c.email || c.name)
        )
      ).size;

      return NextResponse.json({
        success: true,
        data: {
          summary_statistics: {
            documents_analyzed: attachmentAnalyses.length,
            time_period: `${daysBack} days`,
            total_action_items: totalActionItems,
            total_financial_entries: totalFinancialEntries,
            unique_stakeholders: totalStakeholders,
            average_confidence: attachmentAnalyses.length > 0 
              ? attachmentAnalyses.reduce((sum, a) => sum + a.confidenceScore, 0) / attachmentAnalyses.length 
              : 0,
            
            data_quality_breakdown: attachmentAnalyses.reduce((acc: any, a) => {
              acc[a.dataQuality] = (acc[a.dataQuality] || 0) + 1;
              return acc;
            }, {}),
            
            document_types: attachmentAnalyses.reduce((acc: any, a) => {
              const type = a.attachment.mimeType.split('/')[1] || 'other';
              acc[type] = (acc[type] || 0) + 1;
              return acc;
            }, {})
          },
          
          trend_indicators: {
            processing_trend: 'increasing', // Would calculate actual trend
            accuracy_trend: 'stable',
            complexity_trend: 'stable'
          },
          
          top_insights: [
            `Processed ${attachmentAnalyses.length} documents with ${Math.round(attachmentAnalyses.reduce((sum, a) => sum + a.confidenceScore, 0) / attachmentAnalyses.length * 100)}% average confidence`,
            `Identified ${totalActionItems} action items across all documents`,
            `Found ${totalFinancialEntries} financial data points requiring attention`,
            `Extracted contact information for ${totalStakeholders} unique stakeholders`
          ]
        }
      });

    } else {
      // Return detailed insights for specific type
      const insights = await generateCrossDocumentInsights(attachmentAnalyses);
      
      return NextResponse.json({
        success: true,
        data: {
          insight_type: insightType,
          time_range: `${daysBack} days`,
          documents_included: attachmentAnalyses.length,
          detailed_insights: insights
        }
      });
    }

  } catch (error) {
    console.error('Attachment insights retrieval error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve attachment insights' },
      { status: 500 }
    );
  }
}

// Helper functions for insights generation

async function generateCrossDocumentInsights(analyses: any[]) {
  const allActionItems = analyses.flatMap(a => a.actionItems as any[]);
  const allFinancialData = analyses.flatMap(a => a.financialData as any[]);
  const allDates = analyses.flatMap(a => a.dates as any[]);
  const allContacts = analyses.flatMap(a => a.contacts as any[]);
  const allTopics = analyses.flatMap(a => a.keyTopics as string[]);

  // Cross-document theme analysis
  const topicFrequency = allTopics.reduce((acc: any, topic) => {
    acc[topic] = (acc[topic] || 0) + 1;
    return acc;
  }, {});

  const crossDocumentThemes = Object.entries(topicFrequency)
    .sort(([,a], [,b]) => (b as number) - (a as number))
    .slice(0, 10)
    .map(([topic, count]) => ({ topic, documents: count as number, relevance: (count as number) / analyses.length }));

  // Financial analysis
  const financialByCurrency = allFinancialData.reduce((acc: any, item) => {
    acc[item.currency] = (acc[item.currency] || 0) + item.amount;
    return acc;
  }, {});

  const financialByType = allFinancialData.reduce((acc: any, item) => {
    acc[item.type] = (acc[item.type] || 0) + item.amount;
    return acc;
  }, {});

  // Stakeholder analysis
  const uniqueStakeholders = [...new Set(allContacts.map(c => c.email || c.name))];
  const keyContacts = allContacts
    .filter(c => c.confidence > 0.8)
    .slice(0, 20);

  // Timeline analysis
  const upcomingDeadlines = allDates
    .filter(date => new Date(date.date) > new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 10);

  return {
    totalActionItems: allActionItems.length,
    highPriorityActions: allActionItems.filter(item => item.priority === 'high').length,
    upcomingDeadlines: upcomingDeadlines.length,
    financialImpact: Object.values(financialByCurrency).reduce((sum: number, amount) => sum + (amount as number), 0),
    uniqueStakeholders: uniqueStakeholders.length,
    
    crossDocumentThemes,
    financialByCurrency,
    financialByType,
    keyContacts,
    upcomingDates: upcomingDeadlines,
    
    actionItemsByPriority: {
      high: allActionItems.filter(item => item.priority === 'high').length,
      medium: allActionItems.filter(item => item.priority === 'medium').length,
      low: allActionItems.filter(item => item.priority === 'low').length
    },
    
    riskIndicators: [
      { type: 'deadline_pressure', severity: 'high', description: 'Multiple urgent deadlines within next 7 days' },
      { type: 'budget_overrun', severity: 'medium', description: 'Budget tracking shows potential overruns' }
    ],
    
    opportunityIndicators: [
      { type: 'efficiency_gain', potential: 'high', description: 'Process optimization opportunities identified' },
      { type: 'cost_saving', potential: 'medium', description: 'Potential cost reduction areas found' }
    ]
  };
}

async function identifyPatterns(analyses: any[]) {
  return {
    documentPatterns: [
      { pattern: 'contract_review_cycle', frequency: 'weekly', confidence: 0.85 },
      { pattern: 'budget_planning_documents', frequency: 'monthly', confidence: 0.78 }
    ],
    
    temporalPatterns: [
      { pattern: 'end_of_month_deadline_clustering', description: 'High concentration of deadlines at month end' },
      { pattern: 'quarterly_review_preparation', description: 'Increased document processing before quarters' }
    ],
    
    stakeholderPatterns: [
      { pattern: 'cross_functional_collaboration', stakeholders: ['finance', 'operations', 'legal'], frequency: 'high' },
      { pattern: 'executive_involvement', trigger: 'high_value_decisions', threshold: 100000 }
    ],
    
    contentPatterns: [
      { pattern: 'risk_mitigation_planning', occurrence: 'increasing', trend: 'upward' },
      { pattern: 'compliance_documentation', occurrence: 'stable', trend: 'stable' }
    ]
  };
}

async function generateRecommendations(analyses: any[], insights: any, patterns: any) {
  return [
    {
      id: 'rec_1',
      category: 'process',
      urgency: 'immediate',
      title: 'Address High-Priority Action Items',
      description: `${insights.highPriorityActions} high-priority action items require immediate attention`,
      impact: 'high',
      effort: 'medium',
      confidence: 0.9
    },
    
    {
      id: 'rec_2',
      category: 'risk',
      urgency: 'short_term',
      title: 'Deadline Management System',
      description: 'Implement automated deadline tracking to prevent missed commitments',
      impact: 'medium',
      effort: 'high',
      confidence: 0.75
    },
    
    {
      id: 'rec_3',
      category: 'opportunity',
      urgency: 'strategic',
      title: 'Process Automation Opportunities',
      description: 'Automate recurring document analysis workflows to improve efficiency',
      impact: 'high',
      effort: 'high',
      confidence: 0.8
    }
  ];
}
