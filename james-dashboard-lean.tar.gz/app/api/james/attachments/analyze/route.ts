
/**
 * James Attachment Analysis API
 * Re-analyze or get detailed analysis of specific attachments
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { jamesAttachmentProcessor } from "@/lib/james/attachment-processor";
import { prisma } from '@/lib/prisma';
import { readFile } from 'fs/promises';
import { existsSync } from 'fs';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { attachment_id, force_reprocess = false } = await request.json();

    if (!attachment_id) {
      return NextResponse.json({ 
        error: "Attachment ID is required" 
      }, { status: 400 });
    }

    // Get attachment metadata
    const attachment = await prisma.jamesAttachmentMetadata.findFirst({
      where: {
        id: attachment_id,
        userId: session.user.id!
      },
      include: {
        analysis: true
      }
    });

    if (!attachment) {
      return NextResponse.json({ 
        error: 'Attachment not found' 
      }, { status: 404 });
    }

    // Check if already processed and not forcing reprocess
    if (attachment.analysis && !force_reprocess) {
      return NextResponse.json({
        success: true,
        data: {
          attachment_id: attachment_id,
          already_processed: true,
          analysis_results: {
            summary: attachment.analysis.summary,
            key_insights: attachment.analysis.keyTopics,
            action_items: attachment.analysis.actionItems,
            decisions: attachment.analysis.decisions || [],
            financial_data: attachment.analysis.financialData,
            important_dates: attachment.analysis.dates,
            stakeholders: attachment.analysis.contacts,
            confidence_score: attachment.analysis.confidenceScore,
            processing_time: attachment.analysis.processingTime,
            data_quality: attachment.analysis.dataQuality,
            algorithms_used: attachment.analysis.algorithmsUsed,
            processed_at: attachment.analysis.createdAt
          }
        }
      });
    }

    // Check if file exists
    if (!existsSync(attachment.filePath)) {
      return NextResponse.json({ 
        error: 'Attachment file not found on disk' 
      }, { status: 404 });
    }

    // Read and process file
    const fileBuffer = await readFile(attachment.filePath);
    
    const attachmentMetadata = {
      id: attachment.id,
      filename: attachment.filename,
      originalName: attachment.originalName,
      mimeType: attachment.mimeType,
      size: attachment.size,
      uploadedAt: attachment.createdAt,
      userId: attachment.userId,
      threadId: attachment.threadId || undefined,
      messageId: attachment.messageId || undefined
    };

    // Process with James Attachment Processor
    const insights = await jamesAttachmentProcessor.processAttachment(fileBuffer, attachmentMetadata);

    // Store or update analysis results
    const analysisData = {
      userId: session.user.id!,
      
      // Document analysis
      documentType: insights.processingMetadata.algorithmsUsed.includes('text_extraction') ? 'document' as const : null,
      extractedText: '', // Would be populated from document analysis
      summary: insights.overallSummary,
      keyTopics: insights.keyInsights.slice(0, 10),
      
      // Structured extractions
      actionItems: insights.actionRequiredItems as any,
      decisions: [], // Would be populated from decision extractions
      financialData: insights.financialImplications as any,
      dates: insights.importantDates as any,
      contacts: insights.stakeholders as any,
      
      // Analysis metadata
      confidenceScore: insights.confidenceScore,
      processingTime: insights.processingMetadata.processingTime,
      dataQuality: insights.processingMetadata.dataQuality,
      algorithmsUsed: insights.processingMetadata.algorithmsUsed
    };

    let analysisResult;

    if (attachment.analysis) {
      // Update existing analysis
      analysisResult = await prisma.jamesAttachmentAnalysis.update({
        where: { id: attachment.analysis.id },
        data: analysisData
      });
    } else {
      // Create new analysis
      analysisResult = await prisma.jamesAttachmentAnalysis.create({
        data: {
          id: `analysis_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          attachmentId: attachment_id,
          ...analysisData
        }
      });
    }

    // Update attachment processing status
    await prisma.jamesAttachmentMetadata.update({
      where: { id: attachment_id },
      data: { 
        processingStatus: 'completed',
        processedAt: new Date()
      }
    });

    return NextResponse.json({
      success: true,
      data: {
        attachment_id: attachment_id,
        reprocessed: force_reprocess,
        processing_results: {
          overall_summary: insights.overallSummary,
          key_insights: insights.keyInsights,
          
          action_items: {
            total: insights.actionRequiredItems.length,
            high_priority: insights.actionRequiredItems.filter(item => item.priority === 'high').length,
            items: insights.actionRequiredItems.slice(0, 5) // Show first 5
          },
          
          important_dates: {
            total: insights.importantDates.length,
            upcoming: insights.importantDates.filter(date => date.date > new Date()).length,
            dates: insights.importantDates.slice(0, 5) // Show first 5
          },
          
          financial_implications: {
            total_entries: insights.financialImplications.length,
            total_amount: insights.financialImplications.reduce((sum, item) => sum + item.amount, 0),
            currencies: [...new Set(insights.financialImplications.map(item => item.currency))],
            breakdown: insights.financialImplications.slice(0, 5) // Show first 5
          },
          
          stakeholders: {
            total: insights.stakeholders.length,
            with_email: insights.stakeholders.filter(contact => contact.email).length,
            with_phone: insights.stakeholders.filter(contact => contact.phone).length,
            contacts: insights.stakeholders.slice(0, 5) // Show first 5
          },
          
          risk_factors: insights.riskFactors,
          opportunities: insights.opportunities,
          recommended_actions: insights.recommendedActions,
          related_documents: insights.relatedDocuments,
          
          processing_metadata: {
            confidence_score: insights.confidenceScore,
            processing_time: insights.processingMetadata.processingTime,
            data_quality: insights.processingMetadata.dataQuality,
            algorithms_used: insights.processingMetadata.algorithmsUsed
          }
        }
      }
    });

  } catch (error) {
    console.error('Attachment analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze attachment' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const attachmentId = searchParams.get('attachment_id');
    const includeFullText = searchParams.get('include_text') === 'true';

    if (!attachmentId) {
      return NextResponse.json({ 
        error: "Attachment ID is required" 
      }, { status: 400 });
    }

    // Get attachment with full analysis
    const attachment = await prisma.jamesAttachmentMetadata.findFirst({
      where: {
        id: attachmentId,
        userId: session.user.id!
      },
      include: {
        analysis: true
      }
    });

    if (!attachment) {
      return NextResponse.json({ 
        error: 'Attachment not found' 
      }, { status: 404 });
    }

    if (!attachment.analysis) {
      return NextResponse.json({ 
        error: 'Attachment has not been analyzed yet. Process it first.' 
      }, { status: 404 });
    }

    const response = {
      success: true,
      data: {
        attachment_metadata: {
          id: attachment.id,
          filename: attachment.originalName,
          size: attachment.size,
          mime_type: attachment.mimeType,
          processing_status: attachment.processingStatus,
          uploaded_at: attachment.createdAt,
          processed_at: attachment.processedAt
        },
        
        analysis_results: {
          summary: attachment.analysis.summary,
          key_topics: attachment.analysis.keyTopics,
          
          // Detailed breakdowns
          action_items: {
            total: (attachment.analysis.actionItems as any[]).length,
            by_priority: {
              high: (attachment.analysis.actionItems as any[]).filter(item => item.priority === 'high').length,
              medium: (attachment.analysis.actionItems as any[]).filter(item => item.priority === 'medium').length,
              low: (attachment.analysis.actionItems as any[]).filter(item => item.priority === 'low').length
            },
            items: attachment.analysis.actionItems
          },
          
          decisions: attachment.analysis.decisions || [],
          
          financial_data: {
            total_entries: (attachment.analysis.financialData as any[]).length,
            by_type: (attachment.analysis.financialData as any[]).reduce((acc: any, item: any) => {
              acc[item.type] = (acc[item.type] || 0) + 1;
              return acc;
            }, {}),
            total_amount_usd: (attachment.analysis.financialData as any[])
              .filter(item => item.currency === 'USD')
              .reduce((sum, item) => sum + item.amount, 0),
            entries: attachment.analysis.financialData
          },
          
          important_dates: {
            total: (attachment.analysis.dates as any[]).length,
            upcoming: (attachment.analysis.dates as any[]).filter(date => new Date(date.date) > new Date()).length,
            by_type: (attachment.analysis.dates as any[]).reduce((acc: any, date: any) => {
              acc[date.type] = (acc[date.type] || 0) + 1;
              return acc;
            }, {}),
            dates: attachment.analysis.dates
          },
          
          stakeholders: {
            total: (attachment.analysis.contacts as any[]).length,
            with_email: (attachment.analysis.contacts as any[]).filter(contact => contact.email).length,
            with_phone: (attachment.analysis.contacts as any[]).filter(contact => contact.phone).length,
            contacts: attachment.analysis.contacts
          },
          
          // Processing metadata
          confidence_score: attachment.analysis.confidenceScore,
          processing_time: attachment.analysis.processingTime,
          data_quality: attachment.analysis.dataQuality,
          algorithms_used: attachment.analysis.algorithmsUsed,
          
          // Optional full text
          ...(includeFullText && attachment.analysis.extractedText && {
            extracted_text: attachment.analysis.extractedText
          })
        }
      }
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('Attachment analysis retrieval error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve attachment analysis' },
      { status: 500 }
    );
  }
}
