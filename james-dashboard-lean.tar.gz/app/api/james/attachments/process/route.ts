
/**
 * James Attachment Processing API
 * Handles upload and intelligent processing of email attachments
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { jamesAttachmentProcessor } from "@/lib/james/attachment-processor";
import { prisma } from '@/lib/prisma';
import { writeFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';
import { nanoid } from 'nanoid';

const UPLOAD_DIR = path.join(process.cwd(), 'uploads', 'attachments');

// Ensure upload directory exists
async function ensureUploadDir() {
  if (!existsSync(UPLOAD_DIR)) {
    await mkdir(UPLOAD_DIR, { recursive: true });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    await ensureUploadDir();

    const formData = await request.formData();
    const file = formData.get('attachment') as File;
    const threadId = formData.get('thread_id') as string;
    const messageId = formData.get('message_id') as string;
    const processImmediately = formData.get('process_immediately') === 'true';

    if (!file) {
      return NextResponse.json({ 
        error: "No attachment file provided" 
      }, { status: 400 });
    }

    // Validate file
    const maxSize = 50 * 1024 * 1024; // 50MB limit
    if (file.size > maxSize) {
      return NextResponse.json({ 
        error: "File too large. Maximum size is 50MB" 
      }, { status: 413 });
    }

    // Check if file type is supported
    if (!jamesAttachmentProcessor.isSupported(file.name, file.type)) {
      return NextResponse.json({ 
        error: "Unsupported file type",
        supportedTypes: jamesAttachmentProcessor.getSupportedTypes()
      }, { status: 400 });
    }

    // Generate unique filename and save file
    const fileId = nanoid();
    const extension = file.name.split('.').pop()?.toLowerCase() || '';
    const filename = `${fileId}.${extension}`;
    const filepath = path.join(UPLOAD_DIR, filename);
    
    const fileBuffer = Buffer.from(await file.arrayBuffer());
    await writeFile(filepath, fileBuffer);

    // Create attachment metadata record
    const attachmentMetadata = {
      id: fileId,
      filename: filename,
      originalName: file.name,
      mimeType: file.type,
      size: file.size,
      uploadedAt: new Date(),
      userId: session.user.id!,
      threadId: threadId || undefined,
      messageId: messageId || undefined
    };

    // Store metadata in database
    const dbAttachment = await prisma.jamesAttachmentMetadata.create({
      data: {
        id: attachmentMetadata.id,
        userId: attachmentMetadata.userId,
        filename: attachmentMetadata.filename,
        originalName: attachmentMetadata.originalName,
        mimeType: attachmentMetadata.mimeType,
        size: attachmentMetadata.size,
        filePath: filepath,
        threadId: attachmentMetadata.threadId,
        messageId: attachmentMetadata.messageId,
        processingStatus: processImmediately ? 'processing' : 'pending'
      }
    });

    let processingResult = null;

    // Process attachment immediately if requested
    if (processImmediately) {
      try {
        const insights = await jamesAttachmentProcessor.processAttachment(fileBuffer, attachmentMetadata);
        
        // Store processing results
        processingResult = await prisma.jamesAttachmentAnalysis.create({
          data: {
            id: nanoid(),
            attachmentId: fileId,
            userId: session.user.id!,
            
            // Document analysis
            documentType: insights.processingMetadata.algorithmsUsed.includes('text_extraction') ? 'document' : null,
            extractedText: '', // Would be populated from document analysis
            summary: insights.overallSummary,
            keyTopics: insights.keyInsights.slice(0, 10),
            
            // Structured extractions
            actionItems: insights.actionRequiredItems as any,
            decisions: [], // Would be populated from decision extractions
            financialData: insights.financialImplications as any,
            dates: insights.importantDates as any,
            contacts: insights.stakeholders as any,
            
            // Analysis metadata
            confidenceScore: insights.confidenceScore,
            processingTime: insights.processingMetadata.processingTime,
            dataQuality: insights.processingMetadata.dataQuality,
            algorithmsUsed: insights.processingMetadata.algorithmsUsed
          }
        });

        // Update processing status
        await prisma.jamesAttachmentMetadata.update({
          where: { id: fileId },
          data: { 
            processingStatus: 'completed',
            processedAt: new Date()
          }
        });

        // Update system metrics
        await prisma.jamesSystemMetrics.upsert({
          where: {
            userId_metricDate: {
              userId: session.user.id!,
              metricDate: new Date(new Date().setHours(0, 0, 0, 0))
            }
          },
          update: {
            attachmentsProcessed: { increment: 1 }
          },
          create: {
            userId: session.user.id!,
            metricDate: new Date(new Date().setHours(0, 0, 0, 0)),
            metricType: 'daily',
            emailsAnalyzed: 0,
            categorizationAccuracy: 0.8,
            draftsGenerated: 0,
            patternsLearned: 0,
            contextRecallAccuracy: 0.85,
            attachmentsProcessed: 1
          }
        });

      } catch (processingError) {
        console.error('Attachment processing error:', processingError);
        
        // Update status to failed
        await prisma.jamesAttachmentMetadata.update({
          where: { id: fileId },
          data: { processingStatus: 'failed' }
        });

        return NextResponse.json({
          success: true,
          data: {
            attachment_id: fileId,
            filename: file.name,
            size: file.size,
            processing_status: 'failed',
            processing_error: 'Failed to process attachment content',
            capabilities: jamesAttachmentProcessor.getProcessingCapabilities(file.name)
          }
        });
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        attachment_id: fileId,
        filename: file.name,
        original_name: file.name,
        size: file.size,
        mime_type: file.type,
        processing_status: processImmediately ? 'completed' : 'pending',
        capabilities: jamesAttachmentProcessor.getProcessingCapabilities(file.name),
        
        // Include processing results if available
        ...(processingResult && {
          analysis_results: {
            summary: processingResult.summary,
            key_topics: processingResult.keyTopics,
            action_items: (processingResult.actionItems as any[]).length,
            important_dates: (processingResult.dates as any[]).length,
            financial_data: (processingResult.financialData as any[]).length,
            stakeholders: (processingResult.contacts as any[]).length,
            confidence_score: processingResult.confidenceScore,
            processing_time: processingResult.processingTime,
            data_quality: processingResult.dataQuality
          }
        }),
        
        uploaded_at: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('Attachment upload error:', error);
    return NextResponse.json(
      { error: 'Failed to process attachment upload' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const attachmentId = searchParams.get('attachment_id');
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '20');

    if (attachmentId) {
      // Get specific attachment analysis
      const attachment = await prisma.jamesAttachmentMetadata.findFirst({
        where: {
          id: attachmentId,
          userId: session.user.id!
        },
        include: {
          analysis: true
        }
      });

      if (!attachment) {
        return NextResponse.json({ 
          error: 'Attachment not found' 
        }, { status: 404 });
      }

      return NextResponse.json({
        success: true,
        data: {
          attachment_metadata: {
            id: attachment.id,
            filename: attachment.originalName,
            size: attachment.size,
            mime_type: attachment.mimeType,
            processing_status: attachment.processingStatus,
            uploaded_at: attachment.createdAt,
            processed_at: attachment.processedAt
          },
          analysis_results: attachment.analysis ? {
            summary: attachment.analysis.summary,
            key_topics: attachment.analysis.keyTopics,
            action_items: attachment.analysis.actionItems,
            decisions: attachment.analysis.decisions || [],
            financial_data: attachment.analysis.financialData,
            important_dates: attachment.analysis.dates,
            stakeholders: attachment.analysis.contacts,
            confidence_score: attachment.analysis.confidenceScore,
            processing_time: attachment.analysis.processingTime,
            data_quality: attachment.analysis.dataQuality,
            algorithms_used: attachment.analysis.algorithmsUsed
          } : null
        }
      });

    } else {
      // Get user's attachments with optional status filter
      const whereClause: any = { userId: session.user.id! };
      if (status) {
        whereClause.processingStatus = status;
      }

      const attachments = await prisma.jamesAttachmentMetadata.findMany({
        where: whereClause,
        include: {
          analysis: {
            select: {
              summary: true,
              confidenceScore: true,
              dataQuality: true,
              processingTime: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: limit
      });

      const attachmentSummaries = attachments.map(attachment => ({
        id: attachment.id,
        filename: attachment.originalName,
        size: attachment.size,
        mime_type: attachment.mimeType,
        processing_status: attachment.processingStatus,
        uploaded_at: attachment.createdAt,
        processed_at: attachment.processedAt,
        capabilities: jamesAttachmentProcessor.getProcessingCapabilities(attachment.originalName),
        
        // Include analysis summary if available
        ...(attachment.analysis && {
          analysis_summary: {
            summary: attachment.analysis.summary,
            confidence_score: attachment.analysis.confidenceScore,
            data_quality: attachment.analysis.dataQuality,
            processing_time: attachment.analysis.processingTime
          }
        })
      }));

      // Get processing statistics
      const totalAttachments = await prisma.jamesAttachmentMetadata.count({
        where: { userId: session.user.id! }
      });

      const completedAttachments = await prisma.jamesAttachmentMetadata.count({
        where: { 
          userId: session.user.id!,
          processingStatus: 'completed'
        }
      });

      const avgConfidenceScore = await prisma.jamesAttachmentAnalysis.aggregate({
        where: { userId: session.user.id! },
        _avg: { confidenceScore: true }
      });

      return NextResponse.json({
        success: true,
        data: {
          attachments: attachmentSummaries,
          statistics: {
            total_attachments: totalAttachments,
            completed_processing: completedAttachments,
            success_rate: totalAttachments > 0 ? (completedAttachments / totalAttachments) * 100 : 0,
            avg_confidence_score: avgConfidenceScore._avg.confidenceScore || 0,
            processing_capabilities: jamesAttachmentProcessor.getSupportedTypes()
          }
        }
      });
    }

  } catch (error) {
    console.error('Attachment retrieval error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve attachment data' },
      { status: 500 }
    );
  }
}
