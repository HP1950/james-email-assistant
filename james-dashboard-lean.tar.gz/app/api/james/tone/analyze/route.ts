
/**
 * James Tone Analysis API
 * Analyzes email content for sentiment and tone characteristics
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { jamesToneEngine } from "@/lib/james/tone-engine";
import { prisma } from '@/lib/prisma';
import { nanoid } from 'nanoid';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { 
      content, 
      context = 'unknown',
      learn_from_sample = false 
    } = await request.json();

    if (!content || typeof content !== 'string') {
      return NextResponse.json({ 
        error: "Email content is required" 
      }, { status: 400 });
    }

    // Analyze sentiment and tone
    const sentimentAnalysis = await jamesToneEngine.analyzeSentiment(content, context);

    // If this is a learning sample, update user's writing style
    if (learn_from_sample) {
      await jamesToneEngine.updateUserStyle(session.user.id!, content, context);
      
      // Store the sample for future training
      await prisma.jamesToneProfile.upsert({
        where: {
          userId: session.user.id!
        },
        update: {
          learnedSamples: {
            increment: 1
          },
          lastUpdated: new Date()
        },
        create: {
          userId: session.user.id!,
          formalityLevel: 0.6,
          enthusiasmLevel: 0.5,
          directnessLevel: 0.5,
          emojiUsage: 0.1,
          learnedSamples: 1,
          mirrorModeAccuracy: 0.3
        }
      });
    }

    // Get current user style
    const userStyle = jamesToneEngine.getUserStyle(session.user.id!) || null;

    return NextResponse.json({
      success: true,
      data: {
        sentiment_analysis: sentimentAnalysis,
        user_style: userStyle ? {
          mirror_mode_confidence: userStyle.mirror_mode_confidence,
          samples_analyzed: userStyle.sample_count,
          base_tone: userStyle.base_tone,
          learned_phrases: userStyle.learned_phrases.slice(0, 10) // Limit for response size
        } : null,
        analysis_timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('James tone analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze tone' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user's current tone profile from database
    const toneProfile = await prisma.jamesToneProfile.findUnique({
      where: {
        userId: session.user.id!
      }
    });

    // Get style from tone engine
    const userStyle = jamesToneEngine.getUserStyle(session.user.id!);

    return NextResponse.json({
      success: true,
      data: {
        profile: toneProfile ? {
          formality_level: toneProfile.formalityLevel,
          enthusiasm_level: toneProfile.enthusiasmLevel,
          directness_level: toneProfile.directnessLevel,
          emoji_usage: toneProfile.emojiUsage,
          learned_samples: toneProfile.learnedSamples,
          mirror_mode_accuracy: toneProfile.mirrorModeAccuracy,
          last_updated: toneProfile.lastUpdated
        } : null,
        style: userStyle ? {
          base_tone: userStyle.base_tone,
          context_variations: userStyle.context_variations,
          learned_phrases: userStyle.learned_phrases,
          mirror_mode_confidence: userStyle.mirror_mode_confidence,
          sample_count: userStyle.sample_count
        } : null,
        ready_for_mirror_mode: (toneProfile?.learnedSamples || 0) >= 5
      }
    });

  } catch (error) {
    console.error('James tone profile retrieval error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve tone profile' },
      { status: 500 }
    );
  }
}
