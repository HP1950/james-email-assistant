
/**
 * James Draft Generation API
 * Generates email drafts with adaptive tone matching
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { jamesToneEngine } from "@/lib/james/tone-engine";
import { prisma } from '@/lib/prisma';
import { nanoid } from 'nanoid';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const {
      recipient_email,
      recipient_context = 'unknown',
      subject,
      key_points = [],
      draft_intent = 'new',
      original_email,
      mirror_mode = false,
      desired_tone
    } = await request.json();

    if (!recipient_email || !subject || !key_points.length) {
      return NextResponse.json({ 
        error: "Recipient email, subject, and key points are required" 
      }, { status: 400 });
    }

    // Analyze original email sentiment if provided
    let originalSentiment = null;
    if (original_email?.content) {
      originalSentiment = await jamesToneEngine.analyzeSentiment(original_email.content);
    }

    // Generate draft using James tone engine
    const draft = await jamesToneEngine.generateDraft({
      recipient_email,
      recipient_context,
      subject,
      key_points,
      draft_intent,
      original_email: originalSentiment ? {
        content: original_email.content,
        sender: original_email.sender,
        sentiment: originalSentiment
      } : undefined,
      desired_tone,
      mirror_mode
    });

    // Store draft generation activity
    await prisma.jamesAnalysis.create({
      data: {
        userId: session.user.id!,
        emailId: nanoid(),
        analysisType: 'draft_generation',
        priorityLevel: 'medium',
        confidence: draft.tone_analysis.confidence_score,
        reasoning: draft.explanation,
        suggestions: {
          recipient: recipient_email,
          context: recipient_context,
          mirror_mode: mirror_mode,
          estimated_edit_probability: draft.estimated_edit_probability,
          alternatives_count: draft.alternatives.length
        },
        processingTime: 250 // Approximate processing time
      }
    });

    // Update user metrics
    await prisma.jamesSystemMetrics.upsert({
      where: {
        userId_metricDate: {
          userId: session.user.id!,
          metricDate: new Date(new Date().setHours(0, 0, 0, 0))
        }
      },
      update: {
        draftsGenerated: {
          increment: 1
        }
      },
      create: {
        userId: session.user.id!,
        metricDate: new Date(new Date().setHours(0, 0, 0, 0)),
        metricType: 'daily',
        emailsAnalyzed: 0,
        categorizationAccuracy: 0.8,
        draftsGenerated: 1,
        patternsLearned: 0
      }
    });

    return NextResponse.json({
      success: true,
      data: {
        draft: draft,
        generation_id: nanoid(),
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('James draft generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate draft' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const limit = parseInt(searchParams.get('limit') || '10');

    // Get recent draft generations
    const recentDrafts = await prisma.jamesAnalysis.findMany({
      where: {
        userId: session.user.id!,
        analysisType: 'draft_generation'
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      select: {
        id: true,
        emailId: true,
        confidence: true,
        reasoning: true,
        suggestions: true,
        createdAt: true
      }
    });

    // Get draft generation metrics
    const today = new Date(new Date().setHours(0, 0, 0, 0));
    const metrics = await prisma.jamesSystemMetrics.findUnique({
      where: {
        userId_metricDate: {
          userId: session.user.id!,
          metricDate: today
        }
      }
    });

    // Calculate average edit probability from recent drafts
    const avgEditProbability = recentDrafts.length > 0 
      ? recentDrafts.reduce((sum, draft) => {
          const suggestions = draft.suggestions as any;
          return sum + (suggestions?.estimated_edit_probability || 0.3);
        }, 0) / recentDrafts.length
      : 0.3;

    return NextResponse.json({
      success: true,
      data: {
        recent_drafts: recentDrafts.map(draft => ({
          id: draft.id,
          confidence: draft.confidence,
          explanation: draft.reasoning,
          recipient: (draft.suggestions as any)?.recipient,
          context: (draft.suggestions as any)?.context,
          mirror_mode: (draft.suggestions as any)?.mirror_mode,
          edit_probability: (draft.suggestions as any)?.estimated_edit_probability,
          created_at: draft.createdAt
        })),
        metrics: {
          drafts_generated_today: metrics?.draftsGenerated || 0,
          average_edit_probability: avgEditProbability,
          mirror_mode_ready: avgEditProbability < 0.15 // Success target
        },
        tone_engine_status: {
          initialized: true,
          models_loaded: true,
          ready: true
        }
      }
    });

  } catch (error) {
    console.error('James draft history retrieval error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve draft history' },
      { status: 500 }
    );
  }
}
