
/**
 * James Inbox Sync API
 * Fetches emails from Gmail and processes them through James intelligence
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { getGmailClientForUser } from "@/lib/gmail/client";
import { mcpOrchestrator } from "@/lib/mcp/core";
import { prisma } from '@/lib/prisma';
import { nanoid } from 'nanoid';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { maxEmails = 20 } = await request.json();

    // Get Gmail client for user
    const gmailClient = await getGmailClientForUser(session.user.id!);
    if (!gmailClient) {
      return NextResponse.json({ 
        error: "Gmail not connected. Please connect your Gmail account first." 
      }, { status: 400 });
    }

    // Fetch recent emails from Gmail
    console.log(`Fetching ${maxEmails} emails for user ${session.user.id}`);
    const emails = await gmailClient.fetchRecentEmails(maxEmails);

    // Process each email through James intelligence
    const processedEmails = [];
    const inboxAdapter = mcpOrchestrator.getRegistry().getAdapter("inbox-management-adapter");

    for (const email of emails) {
      try {
        // Analyze email priority using James
        if (inboxAdapter) {
          const analysisResult = await mcpOrchestrator.execute({
            id: nanoid(),
            type: 'analyze_email_priority',
            payload: {
              email: {
                id: email.id,
                from: email.from,
                subject: email.subject,
                body: email.body,
                received_at: email.receivedAt.toISOString()
              },
              user_context: {
                user_id: session.user.id,
                thread_history: '' // Could fetch thread history here
              }
            },
            context: {
              userId: session.user.id!,
              sessionId: nanoid(),
              timestamp: new Date()
            }
          });

          // Store analysis in database
          if (analysisResult.success) {
            await prisma.jamesAnalysis.create({
              data: {
                userId: session.user.id!,
                emailId: email.id,
                analysisType: 'priority',
                priorityLevel: analysisResult.data?.priority_level,
                confidence: analysisResult.data?.confidence_score || 0.5,
                reasoning: analysisResult.data?.reasoning,
                suggestions: analysisResult.data,
                processingTime: Date.now() - new Date().getTime()
              }
            });

            processedEmails.push({
              ...email,
              james_analysis: analysisResult.data
            });
          } else {
            console.error(`Failed to analyze email ${email.id}:`, analysisResult.error);
            processedEmails.push({
              ...email,
              james_analysis: { error: analysisResult.error }
            });
          }
        } else {
          processedEmails.push({
            ...email,
            james_analysis: { error: 'Inbox adapter not available' }
          });
        }
      } catch (error) {
        console.error(`Error processing email ${email.id}:`, error);
        processedEmails.push({
          ...email,
          james_analysis: { error: 'Processing failed' }
        });
      }
    }

    // Update user's email sync timestamp
    await prisma.user.update({
      where: { id: session.user.id! },
      data: { 
        lastEmailSync: new Date(),
        totalEmailsProcessed: {
          increment: processedEmails.length
        }
      }
    });

    return NextResponse.json({
      success: true,
      data: {
        emails_fetched: emails.length,
        emails_processed: processedEmails.length,
        emails: processedEmails,
        sync_timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('James inbox sync error:', error);
    return NextResponse.json(
      { error: 'Failed to sync inbox' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get sync status and recent analyses
    const user = await prisma.user.findUnique({
      where: { id: session.user.id! },
      select: {
        lastEmailSync: true,
        totalEmailsProcessed: true,
        gmailConnected: true
      }
    });

    const recentAnalyses = await prisma.jamesAnalysis.findMany({
      where: {
        userId: session.user.id!,
        analysisType: 'priority'
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
      select: {
        emailId: true,
        priorityLevel: true,
        confidence: true,
        createdAt: true,
        reasoning: true
      }
    });

    return NextResponse.json({
      success: true,
      data: {
        sync_status: {
          last_sync: user?.lastEmailSync,
          total_processed: user?.totalEmailsProcessed || 0,
          gmail_connected: user?.gmailConnected || false
        },
        recent_analyses: recentAnalyses
      }
    });

  } catch (error) {
    console.error('James inbox sync status error:', error);
    return NextResponse.json(
      { error: 'Failed to get sync status' },
      { status: 500 }
    );
  }
}
