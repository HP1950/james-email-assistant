
/**
 * James Daily Summary API
 * Generates intelligent daily email summaries
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { mcpOrchestrator } from "@/lib/mcp/core";
import { prisma } from '@/lib/prisma';
import { nanoid } from 'nanoid';
import { startOfDay, endOfDay, subDays } from 'date-fns';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { date, includeMetrics = true } = await request.json();
    const targetDate = date ? new Date(date) : new Date();
    const dayStart = startOfDay(targetDate);
    const dayEnd = endOfDay(targetDate);

    // Get email analyses for the specified day
    const dayAnalyses = await prisma.jamesAnalysis.findMany({
      where: {
        userId: session.user.id!,
        analysisType: 'priority',
        createdAt: {
          gte: dayStart,
          lte: dayEnd
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    // Mock email data structure for summary generation
    // In a real implementation, this would fetch actual email data
    const mockEmails = dayAnalyses.map(analysis => ({
      id: analysis.emailId,
      from: 'sender@example.com', // Would be retrieved from actual email
      subject: 'Email Subject', // Would be retrieved from actual email  
      body: 'Email content...', // Would be retrieved from actual email
      received_at: analysis.createdAt.toISOString(),
      priority_level: analysis.priorityLevel,
      confidence: analysis.confidence
    }));

    // Generate summary using James inbox adapter
    const inboxAdapter = mcpOrchestrator.getRegistry().getAdapter("inbox-management-adapter");
    
    if (!inboxAdapter) {
      return NextResponse.json({ 
        error: "James inbox adapter not available" 
      }, { status: 500 });
    }

    const summaryResult = await mcpOrchestrator.execute({
      id: nanoid(),
      type: 'generate_daily_summary',
      payload: {
        emails: mockEmails,
        date: targetDate.toISOString().split('T')[0]
      },
      context: {
        userId: session.user.id!,
        sessionId: nanoid(),
        timestamp: new Date()
      }
    });

    if (!summaryResult.success) {
      return NextResponse.json({ 
        error: summaryResult.error 
      }, { status: 500 });
    }

    // Store metrics if requested
    if (includeMetrics) {
      const metrics = summaryResult.data;
      
      await prisma.jamesSystemMetrics.upsert({
        where: {
          userId_metricDate: {
            userId: session.user.id!,
            metricDate: dayStart
          }
        },
        update: {
          emailsAnalyzed: metrics.total_emails,
          categorizationAccuracy: 0.87, // Would be calculated from actual data
          updatedAt: new Date()
        },
        create: {
          userId: session.user.id!,
          metricDate: dayStart,
          metricType: 'daily',
          emailsAnalyzed: metrics.total_emails,
          categorizationAccuracy: 0.87
        }
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        summary: summaryResult.data,
        date: targetDate.toISOString().split('T')[0],
        total_analyses: dayAnalyses.length,
        generated_at: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('James daily summary error:', error);
    return NextResponse.json(
      { error: 'Failed to generate daily summary' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const days = parseInt(searchParams.get('days') || '7');

    // Get summaries for the last N days
    const endDate = new Date();
    const startDate = subDays(endDate, days);

    const metrics = await prisma.jamesSystemMetrics.findMany({
      where: {
        userId: session.user.id!,
        metricType: 'daily',
        metricDate: {
          gte: startOfDay(startDate),
          lte: endOfDay(endDate)
        }
      },
      orderBy: { metricDate: 'desc' }
    });

    // Calculate trend data
    const totalEmails = metrics.reduce((sum, m) => sum + m.emailsAnalyzed, 0);
    const avgAccuracy = metrics.length > 0 
      ? metrics.reduce((sum, m) => sum + m.categorizationAccuracy, 0) / metrics.length 
      : 0;

    return NextResponse.json({
      success: true,
      data: {
        daily_metrics: metrics.map(m => ({
          date: m.metricDate.toISOString().split('T')[0],
          emails_analyzed: m.emailsAnalyzed,
          categorization_accuracy: m.categorizationAccuracy,
          drafts_generated: m.draftsGenerated,
          patterns_learned: m.patternsLearned
        })),
        summary_stats: {
          total_emails_analyzed: totalEmails,
          average_accuracy: avgAccuracy,
          trend_period_days: days
        }
      }
    });

  } catch (error) {
    console.error('James summary history error:', error);
    return NextResponse.json(
      { error: 'Failed to get summary history' },
      { status: 500 }
    );
  }
}
