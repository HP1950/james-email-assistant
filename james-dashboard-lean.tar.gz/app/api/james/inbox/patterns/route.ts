
/**
 * James Priority Patterns API
 * Manages learning patterns for inbox prioritization
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { mcpOrchestrator } from "@/lib/mcp/core";
import { prisma } from '@/lib/prisma';
import { nanoid } from 'nanoid';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { sender, user_action, response_time, email_data } = await request.json();

    // Use James inbox adapter to learn pattern
    const inboxAdapter = mcpOrchestrator.getRegistry().getAdapter("inbox-management-adapter");
    
    if (!inboxAdapter) {
      return NextResponse.json({ 
        error: "James inbox adapter not available" 
      }, { status: 500 });
    }

    const learnResult = await mcpOrchestrator.execute({
      id: nanoid(),
      type: 'learn_priority_pattern',
      payload: {
        sender,
        user_action,
        response_time,
        email_data
      },
      context: {
        userId: session.user.id!,
        sessionId: nanoid(),
        timestamp: new Date()
      }
    });

    if (!learnResult.success) {
      return NextResponse.json({ 
        error: learnResult.error 
      }, { status: 500 });
    }

    // Store pattern in database
    const pattern = learnResult.data.pattern;
    
    await prisma.jamesPriorityPattern.upsert({
      where: {
        userId_senderEmail: {
          userId: session.user.id!,
          senderEmail: sender
        }
      },
      update: {
        interactionCount: pattern.interaction_frequency,
        avgResponseTime: pattern.avg_response_time,
        importanceScore: pattern.importance_score,
        userActions: pattern.user_actions,
        lastInteraction: new Date(),
        confidenceLevel: pattern.importance_score // Use importance as confidence proxy
      },
      create: {
        userId: session.user.id!,
        senderEmail: sender,
        senderDomain: pattern.sender_domain,
        interactionCount: pattern.interaction_frequency,
        avgResponseTime: pattern.avg_response_time,
        importanceScore: pattern.importance_score,
        userActions: pattern.user_actions,
        lastInteraction: new Date(),
        confidenceLevel: pattern.importance_score
      }
    });

    return NextResponse.json({
      success: true,
      data: {
        message: 'Priority pattern learned successfully',
        pattern: learnResult.data.pattern
      }
    });

  } catch (error) {
    console.error('James pattern learning error:', error);
    return NextResponse.json(
      { error: 'Failed to learn priority pattern' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const limit = parseInt(searchParams.get('limit') || '20');

    // Get learned patterns for user
    const patterns = await prisma.jamesPriorityPattern.findMany({
      where: {
        userId: session.user.id!
      },
      orderBy: [
        { importanceScore: 'desc' },
        { interactionCount: 'desc' }
      ],
      take: limit
    });

    // Calculate insights
    const totalPatterns = patterns.length;
    const highImportancePatterns = patterns.filter(p => p.importanceScore > 0.7).length;
    const avgResponseTime = patterns.length > 0 
      ? patterns.reduce((sum, p) => sum + p.avgResponseTime, 0) / patterns.length 
      : 0;

    // Use James adapter to detect ignored senders
    const inboxAdapter = mcpOrchestrator.getRegistry().getAdapter("inbox-management-adapter");
    let ignoredSenders = [];

    if (inboxAdapter) {
      const ignoredResult = await mcpOrchestrator.execute({
        id: nanoid(),
        type: 'detect_ignored_senders',
        payload: { timeframe_days: 30 },
        context: {
          userId: session.user.id!,
          sessionId: nanoid(),
          timestamp: new Date()
        }
      });

      if (ignoredResult.success) {
        ignoredSenders = ignoredResult.data.ignored_senders;
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        patterns: patterns.map(p => ({
          sender_email: p.senderEmail,
          sender_domain: p.senderDomain,
          interaction_count: p.interactionCount,
          avg_response_time: p.avgResponseTime,
          importance_score: p.importanceScore,
          confidence_level: p.confidenceLevel,
          last_interaction: p.lastInteraction,
          user_actions: p.userActions
        })),
        insights: {
          total_patterns: totalPatterns,
          high_importance_senders: highImportancePatterns,
          avg_response_time_hours: Math.round(avgResponseTime),
          ignored_senders: ignoredSenders,
          learning_accuracy: totalPatterns > 10 ? 0.87 : 0.5 // Placeholder calculation
        }
      }
    });

  } catch (error) {
    console.error('James patterns retrieval error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve patterns' },
      { status: 500 }
    );
  }
}
