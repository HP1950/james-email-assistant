
import { NextRequest, NextResponse } from 'next/server';
import { EmailProcessor } from '@/lib/email-processor';

const emailProcessor = new EmailProcessor();

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userEmail, userName } = body;

    if (!userEmail) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    // Generate user ID (you might want to use a proper UUID library)
    const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Register user and assign to optimal domain
    const assignment = await emailProcessor.registerUser(userId, userEmail);

    if (!assignment) {
      return NextResponse.json(
        { error: 'Failed to assign user to domain. System may be at capacity.' },
        { status: 503 }
      );
    }

    // Send welcome email
    const welcomeEmailSent = await emailProcessor.sendWelcomeEmail(userId, userEmail);

    return NextResponse.json({
      success: true,
      userId,
      userEmail,
      jamesEmail: assignment.assignedJamesEmail,
      assignedDomain: assignment.assignedDomain,
      welcomeEmailSent,
      message: `Welcome to James! You've been assigned ${assignment.assignedJamesEmail}`
    });

  } catch (error) {
    console.error('Trial signup error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Get system status for monitoring
    const systemStatus = await emailProcessor.getSystemStatus();
    
    return NextResponse.json({
      status: 'operational',
      ...systemStatus
    });
  } catch (error) {
    console.error('System status error:', error);
    return NextResponse.json(
      { error: 'Failed to get system status' },
      { status: 500 }
    );
  }
}
