
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { emailContent, analysisType } = await request.json();

    if (!emailContent || !analysisType) {
      return NextResponse.json(
        { error: 'Email content and analysis type are required' },
        { status: 400 }
      );
    }

    const apiKey = process.env.ABACUSAI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'AI API key not configured' },
        { status: 500 }
      );
    }

    const analysisPrompts = {
      sentiment: `Analyze the sentiment of this email and respond with JSON only:
        {"sentiment": "VERY_POSITIVE|POSITIVE|NEUTRAL|NEGATIVE|VERY_NEGATIVE", "confidence": 0.95, "reasoning": "brief explanation"}
        
        Email: ${emailContent}`,
      
      priority: `Analyze the priority of this email and respond with JSON only:
        {"priority": "VERY_LOW|LOW|MEDIUM|HIGH|VERY_HIGH|URGENT", "confidence": 0.95, "reasoning": "brief explanation"}
        
        Email: ${emailContent}`,
      
      summary: `Provide a concise summary of this email in 2-3 sentences:
        
        Email: ${emailContent}`,
      
      tasks: `Extract actionable tasks from this email. Respond with JSON only:
        {"tasks": ["task 1", "task 2"], "confidence": 0.95}
        
        Email: ${emailContent}`,
      
      category: `Categorize this email. Respond with JSON only:
        {"category": "Work|Personal|Finance|Travel|Shopping|Social|Newsletter|Spam", "confidence": 0.95, "tags": ["tag1", "tag2"]}
        
        Email: ${emailContent}`,
    };

    const prompt = analysisPrompts[analysisType as keyof typeof analysisPrompts];
    if (!prompt) {
      return NextResponse.json(
        { error: 'Invalid analysis type' },
        { status: 400 }
      );
    }

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
        response_format: analysisType !== 'summary' ? { type: 'json_object' } : undefined,
        temperature: 0.3,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      throw new Error(`AI API error: ${response.statusText}`);
    }

    const aiResponse = await response.json();
    const content = aiResponse.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('No response from AI service');
    }

    let result;
    if (analysisType === 'summary') {
      result = { summary: content.trim() };
    } else {
      try {
        // Clean the response to ensure valid JSON
        const cleanedContent = content.replace(/```json\n?|\n?```/g, '').trim();
        result = JSON.parse(cleanedContent);
      } catch (parseError) {
        console.error('JSON parse error:', parseError, 'Content:', content);
        return NextResponse.json(
          { error: 'Invalid AI response format' },
          { status: 500 }
        );
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        analysisType,
        result,
        processingTime: Date.now() - Date.now(), // Placeholder
      },
    });
  } catch (error) {
    console.error('AI analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze email' },
      { status: 500 }
    );
  }
}
