
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { emailContent, suggestionType, context } = await request.json();

    if (!emailContent || !suggestionType) {
      return NextResponse.json(
        { error: 'Email content and suggestion type are required' },
        { status: 400 }
      );
    }

    const apiKey = process.env.ABACUSAI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'AI API key not configured' },
        { status: 500 }
      );
    }

    const suggestionPrompts = {
      reply: `Generate a professional reply to this email. Consider the tone and context. Respond with JSON only:
        {"reply": "email reply content", "tone": "professional|casual|formal", "confidence": 0.95}
        
        Original Email: ${emailContent}
        ${context ? `Additional Context: ${context}` : ''}`,
      
      followUp: `Generate a follow-up email template for this conversation. Respond with JSON only:
        {"followUp": "follow-up email content", "timing": "suggested timing", "confidence": 0.95}
        
        Original Email: ${emailContent}`,
      
      smartActions: `Suggest smart actions for this email. Respond with JSON only:
        {"actions": [{"type": "reply|forward|schedule|task|archive", "label": "action description", "priority": "high|medium|low"}], "confidence": 0.95}
        
        Email: ${emailContent}`,
      
      insights: `Provide insights about this email and sender. Respond with JSON only:
        {"insights": ["insight 1", "insight 2"], "senderAnalysis": "analysis of sender", "recommendations": ["rec 1", "rec 2"], "confidence": 0.95}
        
        Email: ${emailContent}`,
    };

    const prompt = suggestionPrompts[suggestionType as keyof typeof suggestionPrompts];
    if (!prompt) {
      return NextResponse.json(
        { error: 'Invalid suggestion type' },
        { status: 400 }
      );
    }

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
        response_format: { type: 'json_object' },
        temperature: 0.7,
        max_tokens: 800,
      }),
    });

    if (!response.ok) {
      throw new Error(`AI API error: ${response.statusText}`);
    }

    const aiResponse = await response.json();
    const content = aiResponse.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('No response from AI service');
    }

    let result;
    try {
      // Clean the response to ensure valid JSON
      const cleanedContent = content.replace(/```json\n?|\n?```/g, '').trim();
      result = JSON.parse(cleanedContent);
    } catch (parseError) {
      console.error('JSON parse error:', parseError, 'Content:', content);
      return NextResponse.json(
        { error: 'Invalid AI response format' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        suggestionType,
        result,
        processingTime: Date.now() - Date.now(), // Placeholder
      },
    });
  } catch (error) {
    console.error('AI suggestions error:', error);
    return NextResponse.json(
      { error: 'Failed to generate suggestions' },
      { status: 500 }
    );
  }
}
