
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const createSegmentSchema = z.object({
  listId: z.string().min(1, 'List ID is required'),
  name: z.string().min(1, 'Segment name is required'),
  description: z.string().optional(),
  criteria: z.object({
    conditions: z.array(z.object({
      field: z.string(),
      operator: z.enum(['equals', 'not_equals', 'contains', 'not_contains', 'greater_than', 'less_than', 'between']),
      value: z.any(),
      condition: z.enum(['and', 'or']).optional(),
    })),
  }),
  isStatic: z.boolean().default(false),
});

// GET /api/marketing/segments - Get segments for user's lists
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(request.url);
    const listId = url.searchParams.get('listId');
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '10');

    const skip = (page - 1) * limit;

    const where = {
      list: {
        userId: session.user.id,
      },
      ...(listId && { listId }),
    };

    const [segments, total] = await Promise.all([
      prisma.listSegment.findMany({
        where,
        skip,
        take: limit,
        include: {
          list: {
            select: {
              id: true,
              name: true,
            },
          },
          _count: {
            select: {
              campaigns: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.listSegment.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        segments,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Error fetching segments:', error);
    return NextResponse.json(
      { error: 'Failed to fetch segments' },
      { status: 500 }
    );
  }
}

// POST /api/marketing/segments - Create new segment
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = createSegmentSchema.parse(body);

    // Verify list ownership
    const list = await prisma.emailList.findFirst({
      where: {
        id: validatedData.listId,
        userId: session.user.id,
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    // Calculate subscriber count based on criteria
    const subscriberCount = await calculateSegmentCount(validatedData.listId, validatedData.criteria);

    const segment = await prisma.listSegment.create({
      data: {
        ...validatedData,
        subscriberCount,
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: segment,
    });
  } catch (error) {
    console.error('Error creating segment:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to create segment' },
      { status: 500 }
    );
  }
}

async function calculateSegmentCount(listId: string, criteria: any): Promise<number> {
  try {
    // This is a simplified implementation
    // In a real app, you'd need to build dynamic queries based on the criteria
    
    const baseWhere = {
      listId,
      status: { in: ['CONFIRMED', 'ACTIVE'] as any[] },
    };

    // For now, return the total subscriber count
    // In a real implementation, you'd parse the criteria and build the where clause
    const count = await prisma.listSubscriber.count({
      where: baseWhere,
    });

    return count;
  } catch (error) {
    console.error('Error calculating segment count:', error);
    return 0;
  }
}
