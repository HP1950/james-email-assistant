
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import jwt from 'jsonwebtoken';

export const dynamic = 'force-dynamic';

// GET /api/marketing/unsubscribe/[token] - Unsubscribe page
export async function GET(
  request: NextRequest,
  { params }: { params: { token: string } }
) {
  try {
    // Verify and decode the unsubscribe token
    const decoded = jwt.verify(params.token, process.env.NEXTAUTH_SECRET || 'secret') as any;
    
    const { subscriberId, campaignId } = decoded;

    const subscriber = await prisma.listSubscriber.findUnique({
      where: { id: subscriberId },
      include: {
        list: {
          select: {
            name: true,
            user: {
              select: {
                name: true,
                email: true,
              },
            },
          },
        },
      },
    });

    if (!subscriber) {
      return NextResponse.json({ error: 'Subscriber not found' }, { status: 404 });
    }

    // Return unsubscribe page HTML
    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Unsubscribe</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .container { text-align: center; }
            .btn { background: #dc3545; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
            .btn:hover { background: #c82333; }
            .success { color: #28a745; }
            .error { color: #dc3545; }
          </style>
        </head>
        <body>
          <div class="container">
            <h2>Unsubscribe from ${subscriber.list.name}</h2>
            <p>Email: ${subscriber.email}</p>
            ${subscriber.status === 'UNSUBSCRIBED' 
              ? '<p class="success">You are already unsubscribed from this list.</p>'
              : `
                <p>Are you sure you want to unsubscribe from this mailing list?</p>
                <form method="POST">
                  <button type="submit" class="btn">Unsubscribe</button>
                </form>
              `
            }
            <p><small>This request is from ${subscriber.list.user.name || subscriber.list.user.email}</small></p>
          </div>
        </body>
      </html>
    `;

    return new NextResponse(html, {
      headers: { 'Content-Type': 'text/html' },
    });
  } catch (error) {
    console.error('Error in unsubscribe page:', error);
    return NextResponse.json({ error: 'Invalid unsubscribe link' }, { status: 400 });
  }
}

// POST /api/marketing/unsubscribe/[token] - Process unsubscribe
export async function POST(
  request: NextRequest,
  { params }: { params: { token: string } }
) {
  try {
    // Verify and decode the unsubscribe token
    const decoded = jwt.verify(params.token, process.env.NEXTAUTH_SECRET || 'secret') as any;
    
    const { subscriberId, campaignId } = decoded;

    const subscriber = await prisma.listSubscriber.findUnique({
      where: { id: subscriberId },
      include: {
        list: {
          select: {
            name: true,
            userId: true,
          },
        },
      },
    });

    if (!subscriber) {
      return NextResponse.json({ error: 'Subscriber not found' }, { status: 404 });
    }

    if (subscriber.status !== 'UNSUBSCRIBED') {
      // Update subscriber status
      await prisma.listSubscriber.update({
        where: { id: subscriberId },
        data: {
          status: 'UNSUBSCRIBED',
          unsubscribedAt: new Date(),
        },
      });

      // Update list active count
      await prisma.emailList.update({
        where: { id: subscriber.listId },
        data: {
          activeCount: { decrement: 1 },
        },
      });

      // Record compliance event
      await prisma.complianceRecord.create({
        data: {
          userId: subscriber.list.userId,
          type: 'OPT_OUT',
          email: subscriber.email,
          listId: subscriber.listId,
          campaignId,
          action: 'unsubscribe',
          method: 'email_link',
        },
      });
    }

    // Return success page
    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Unsubscribed Successfully</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .container { text-align: center; }
            .success { color: #28a745; }
          </style>
        </head>
        <body>
          <div class="container">
            <h2 class="success">Successfully Unsubscribed</h2>
            <p>You have been unsubscribed from ${subscriber.list.name}.</p>
            <p>Email: ${subscriber.email}</p>
            <p><small>You will no longer receive emails from this list.</small></p>
          </div>
        </body>
      </html>
    `;

    return new NextResponse(html, {
      headers: { 'Content-Type': 'text/html' },
    });
  } catch (error) {
    console.error('Error processing unsubscribe:', error);
    return NextResponse.json({ error: 'Failed to unsubscribe' }, { status: 500 });
  }
}
