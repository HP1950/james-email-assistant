
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const createListSchema = z.object({
  name: z.string().min(1, 'List name is required'),
  description: z.string().optional(),
  type: z.enum(['STANDARD', 'IMPORTED', 'DYNAMIC', 'SUPPRESSION']).default('STANDARD'),
  doubleOptIn: z.boolean().default(true),
  welcomeEmail: z.boolean().default(false),
  tags: z.array(z.string()).default([]),
});

const updateListSchema = createListSchema.partial();

// GET /api/marketing/lists - Get all lists for user
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '10');
    const search = url.searchParams.get('search') || '';
    const type = url.searchParams.get('type');

    const skip = (page - 1) * limit;

    const where = {
      userId: session.user.id,
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' as const } },
          { description: { contains: search, mode: 'insensitive' as const } },
        ],
      }),
      ...(type && type !== 'all' && { type: type as any }),
    };

    const [lists, total] = await Promise.all([
      prisma.emailList.findMany({
        where,
        skip,
        take: limit,
        include: {
          _count: {
            select: {
              subscribers: true,
              campaigns: true,
              segments: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.emailList.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        lists,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Error fetching lists:', error);
    return NextResponse.json(
      { error: 'Failed to fetch lists' },
      { status: 500 }
    );
  }
}

// POST /api/marketing/lists - Create new list
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = createListSchema.parse(body);

    const list = await prisma.emailList.create({
      data: {
        ...validatedData,
        userId: session.user.id,
      },
      include: {
        _count: {
          select: {
            subscribers: true,
            campaigns: true,
            segments: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: list,
    });
  } catch (error) {
    console.error('Error creating list:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to create list' },
      { status: 500 }
    );
  }
}
