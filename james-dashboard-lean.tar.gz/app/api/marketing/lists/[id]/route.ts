
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const updateListSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  type: z.enum(['STANDARD', 'IMPORTED', 'DYNAMIC', 'SUPPRESSION']).optional(),
  doubleOptIn: z.boolean().optional(),
  welcomeEmail: z.boolean().optional(),
  tags: z.array(z.string()).optional(),
  isPublic: z.boolean().optional(),
});

// GET /api/marketing/lists/[id] - Get list by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const list = await prisma.emailList.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
      include: {
        subscribers: {
          take: 10,
          orderBy: { createdAt: 'desc' },
        },
        segments: true,
        campaigns: {
          take: 5,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            name: true,
            status: true,
            sentAt: true,
            recipientCount: true,
            openRate: true,
            clickRate: true,
          },
        },
        _count: {
          select: {
            subscribers: true,
            campaigns: true,
            segments: true,
          },
        },
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: list,
    });
  } catch (error) {
    console.error('Error fetching list:', error);
    return NextResponse.json(
      { error: 'Failed to fetch list' },
      { status: 500 }
    );
  }
}

// PATCH /api/marketing/lists/[id] - Update list
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = updateListSchema.parse(body);

    const list = await prisma.emailList.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    const updatedList = await prisma.emailList.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        _count: {
          select: {
            subscribers: true,
            campaigns: true,
            segments: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: updatedList,
    });
  } catch (error) {
    console.error('Error updating list:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to update list' },
      { status: 500 }
    );
  }
}

// DELETE /api/marketing/lists/[id] - Delete list
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const list = await prisma.emailList.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    // Check if list has active campaigns
    const activeCampaigns = await prisma.campaign.count({
      where: {
        listId: params.id,
        status: { in: ['SCHEDULED', 'SENDING'] },
      },
    });

    if (activeCampaigns > 0) {
      return NextResponse.json(
        { error: 'Cannot delete list with active campaigns' },
        { status: 400 }
      );
    }

    await prisma.emailList.delete({
      where: { id: params.id },
    });

    return NextResponse.json({
      success: true,
      message: 'List deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting list:', error);
    return NextResponse.json(
      { error: 'Failed to delete list' },
      { status: 500 }
    );
  }
}
