
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const addSubscriberSchema = z.object({
  email: z.string().email('Invalid email address'),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  company: z.string().optional(),
  phone: z.string().optional(),
  customFields: z.record(z.any()).optional(),
  source: z.string().optional(),
  timezone: z.string().optional(),
  language: z.string().default('en'),
  gdprConsent: z.boolean().default(false),
});

const bulkAddSchema = z.object({
  subscribers: z.array(addSubscriberSchema),
  overrideExisting: z.boolean().default(false),
});

// GET /api/marketing/lists/[id]/subscribers - Get subscribers for list
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '20');
    const search = url.searchParams.get('search') || '';
    const status = url.searchParams.get('status');

    const skip = (page - 1) * limit;

    // Verify list ownership
    const list = await prisma.emailList.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    const where = {
      listId: params.id,
      ...(search && {
        OR: [
          { email: { contains: search, mode: 'insensitive' as const } },
          { firstName: { contains: search, mode: 'insensitive' as const } },
          { lastName: { contains: search, mode: 'insensitive' as const } },
          { company: { contains: search, mode: 'insensitive' as const } },
        ],
      }),
      ...(status && status !== 'all' && { status: status as any }),
    };

    const [subscribers, total] = await Promise.all([
      prisma.listSubscriber.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.listSubscriber.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        subscribers,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Error fetching subscribers:', error);
    return NextResponse.json(
      { error: 'Failed to fetch subscribers' },
      { status: 500 }
    );
  }
}

// POST /api/marketing/lists/[id]/subscribers - Add subscriber to list
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    
    // Check if this is a bulk add operation
    if (body.subscribers && Array.isArray(body.subscribers)) {
      return handleBulkAdd(params.id, body, session.user.id);
    }

    const validatedData = addSubscriberSchema.parse(body);

    // Verify list ownership
    const list = await prisma.emailList.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    // Check if subscriber already exists
    const existingSubscriber = await prisma.listSubscriber.findUnique({
      where: {
        listId_email: {
          listId: params.id,
          email: validatedData.email,
        },
      },
    });

    if (existingSubscriber) {
      return NextResponse.json(
        { error: 'Subscriber already exists in this list' },
        { status: 409 }
      );
    }

    const subscriber = await prisma.listSubscriber.create({
      data: {
        ...validatedData,
        listId: params.id,
        status: list.doubleOptIn ? 'PENDING' : 'CONFIRMED',
        confirmedAt: list.doubleOptIn ? undefined : new Date(),
      },
    });

    // Update list subscriber count
    await prisma.emailList.update({
      where: { id: params.id },
      data: {
        subscriberCount: { increment: 1 },
        activeCount: { increment: list.doubleOptIn ? 0 : 1 },
      },
    });

    return NextResponse.json({
      success: true,
      data: subscriber,
    });
  } catch (error) {
    console.error('Error adding subscriber:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to add subscriber' },
      { status: 500 }
    );
  }
}

async function handleBulkAdd(listId: string, body: any, userId: string) {
  try {
    const validatedData = bulkAddSchema.parse(body);
    
    // Verify list ownership
    const list = await prisma.emailList.findFirst({
      where: {
        id: listId,
        userId,
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    const results = {
      success: 0,
      failed: 0,
      skipped: 0,
      errors: [] as any[],
    };

    for (const subscriberData of validatedData.subscribers) {
      try {
        // Check if subscriber already exists
        const existingSubscriber = await prisma.listSubscriber.findUnique({
          where: {
            listId_email: {
              listId,
              email: subscriberData.email,
            },
          },
        });

        if (existingSubscriber && !validatedData.overrideExisting) {
          results.skipped++;
          continue;
        }

        if (existingSubscriber && validatedData.overrideExisting) {
          // Update existing subscriber
          await prisma.listSubscriber.update({
            where: { id: existingSubscriber.id },
            data: {
              ...subscriberData,
              updatedAt: new Date(),
            },
          });
        } else {
          // Create new subscriber
          await prisma.listSubscriber.create({
            data: {
              ...subscriberData,
              listId,
              status: list.doubleOptIn ? 'PENDING' : 'CONFIRMED',
              confirmedAt: list.doubleOptIn ? undefined : new Date(),
            },
          });
        }

        results.success++;
      } catch (error) {
        results.failed++;
        results.errors.push({
          email: subscriberData.email,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    // Update list subscriber counts
    const totalSubscribers = await prisma.listSubscriber.count({
      where: { listId },
    });
    const activeSubscribers = await prisma.listSubscriber.count({
      where: { 
        listId,
        status: { in: ['CONFIRMED', 'ACTIVE'] },
      },
    });

    await prisma.emailList.update({
      where: { id: listId },
      data: {
        subscriberCount: totalSubscribers,
        activeCount: activeSubscribers,
      },
    });

    return NextResponse.json({
      success: true,
      data: results,
    });
  } catch (error) {
    console.error('Error in bulk add:', error);
    return NextResponse.json(
      { error: 'Failed to process bulk add' },
      { status: 500 }
    );
  }
}
