
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET /api/marketing/analytics - Get overall email marketing analytics
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(request.url);
    const period = url.searchParams.get('period') || '30'; // days
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(period));

    // Get overall statistics
    const [
      totalLists,
      totalSubscribers,
      activeSubscribers,
      totalCampaigns,
      activeCampaigns,
      sentCampaigns,
      totalTemplates,
      totalAutomations,
      activeAutomations,
    ] = await Promise.all([
      prisma.emailList.count({
        where: { userId: session.user.id },
      }),
      prisma.listSubscriber.count({
        where: {
          list: { userId: session.user.id },
        },
      }),
      prisma.listSubscriber.count({
        where: {
          list: { userId: session.user.id },
          status: { in: ['CONFIRMED', 'ACTIVE'] },
        },
      }),
      prisma.campaign.count({
        where: { userId: session.user.id },
      }),
      prisma.campaign.count({
        where: {
          userId: session.user.id,
          status: { in: ['SCHEDULED', 'SENDING'] },
        },
      }),
      prisma.campaign.count({
        where: {
          userId: session.user.id,
          status: 'SENT',
          sentAt: { gte: startDate },
        },
      }),
      prisma.emailTemplate.count({
        where: { userId: session.user.id },
      }),
      prisma.marketingAutomation.count({
        where: { userId: session.user.id },
      }),
      prisma.marketingAutomation.count({
        where: {
          userId: session.user.id,
          isActive: true,
        },
      }),
    ]);

    // Get campaign performance metrics
    const campaignMetrics = await prisma.campaign.aggregate({
      where: {
        userId: session.user.id,
        status: 'SENT',
        sentAt: { gte: startDate },
      },
      _avg: {
        openRate: true,
        clickRate: true,
        unsubscribeRate: true,
        bounceRate: true,
        deliveryRate: true,
      },
      _sum: {
        recipientCount: true,
        sentCount: true,
        deliveredCount: true,
        openCount: true,
        clickCount: true,
        unsubscribeCount: true,
        bounceCount: true,
        complaintCount: true,
      },
    });

    // Get list growth data
    const listGrowthData = await getListGrowthData(session.user.id, parseInt(period));

    // Get campaign performance over time
    const campaignPerformanceData = await getCampaignPerformanceData(session.user.id, parseInt(period));

    // Get top performing campaigns
    const topCampaigns = await prisma.campaign.findMany({
      where: {
        userId: session.user.id,
        status: 'SENT',
        sentAt: { gte: startDate },
      },
      select: {
        id: true,
        name: true,
        subject: true,
        sentAt: true,
        recipientCount: true,
        openRate: true,
        clickRate: true,
        deliveryRate: true,
      },
      orderBy: [
        { openRate: 'desc' },
        { clickRate: 'desc' },
      ],
      take: 10,
    });

    // Get top performing lists
    const topLists = await prisma.emailList.findMany({
      where: { userId: session.user.id },
      select: {
        id: true,
        name: true,
        subscriberCount: true,
        activeCount: true,
        engagementRate: true,
        growthRate: true,
      },
      orderBy: [
        { engagementRate: 'desc' },
        { subscriberCount: 'desc' },
      ],
      take: 10,
    });

    // Get automation performance
    const automationMetrics = await prisma.marketingAutomation.aggregate({
      where: {
        userId: session.user.id,
        isActive: true,
      },
      _avg: {
        completedCount: true,
      },
      _sum: {
        subscriberCount: true,
        completedCount: true,
        activeCount: true,
      },
    });

    const analytics = {
      overview: {
        totalLists,
        totalSubscribers,
        activeSubscribers,
        totalCampaigns,
        activeCampaigns,
        sentCampaigns,
        totalTemplates,
        totalAutomations,
        activeAutomations,
        subscriberGrowthRate: await calculateSubscriberGrowthRate(session.user.id, parseInt(period)),
      },
      campaignPerformance: {
        averageOpenRate: campaignMetrics._avg.openRate || 0,
        averageClickRate: campaignMetrics._avg.clickRate || 0,
        averageUnsubscribeRate: campaignMetrics._avg.unsubscribeRate || 0,
        averageBounceRate: campaignMetrics._avg.bounceRate || 0,
        averageDeliveryRate: campaignMetrics._avg.deliveryRate || 0,
        totalEmailsSent: campaignMetrics._sum.sentCount || 0,
        totalEmailsDelivered: campaignMetrics._sum.deliveredCount || 0,
        totalOpens: campaignMetrics._sum.openCount || 0,
        totalClicks: campaignMetrics._sum.clickCount || 0,
        totalUnsubscribes: campaignMetrics._sum.unsubscribeCount || 0,
        totalBounces: campaignMetrics._sum.bounceCount || 0,
        totalComplaints: campaignMetrics._sum.complaintCount || 0,
      },
      automationPerformance: {
        totalSubscribers: automationMetrics._sum.subscriberCount || 0,
        totalCompleted: automationMetrics._sum.completedCount || 0,
        totalActive: automationMetrics._sum.activeCount || 0,
        averageCompletionRate: automationMetrics._sum.subscriberCount 
          ? ((automationMetrics._sum.completedCount || 0) / automationMetrics._sum.subscriberCount) * 100
          : 0,
      },
      trends: {
        listGrowth: listGrowthData,
        campaignPerformance: campaignPerformanceData,
      },
      topPerformers: {
        campaigns: topCampaigns,
        lists: topLists,
      },
    };

    return NextResponse.json({
      success: true,
      data: analytics,
    });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    );
  }
}

async function getListGrowthData(userId: string, days: number) {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  // Get subscriber additions over time
  const subscriberGrowth = await prisma.listSubscriber.groupBy({
    by: ['createdAt'],
    where: {
      list: { userId },
      createdAt: { gte: startDate },
    },
    _count: {
      id: true,
    },
    orderBy: {
      createdAt: 'asc',
    },
  });

  // Group by day
  const dailyGrowth: { [key: string]: number } = {};
  subscriberGrowth.forEach(item => {
    const date = item.createdAt.toISOString().split('T')[0];
    dailyGrowth[date] = (dailyGrowth[date] || 0) + item._count.id;
  });

  return Object.entries(dailyGrowth).map(([date, count]) => ({
    date,
    subscribers: count,
  }));
}

async function getCampaignPerformanceData(userId: string, days: number) {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  const campaigns = await prisma.campaign.findMany({
    where: {
      userId,
      status: 'SENT',
      sentAt: { gte: startDate },
    },
    select: {
      sentAt: true,
      openRate: true,
      clickRate: true,
      deliveryRate: true,
    },
    orderBy: {
      sentAt: 'asc',
    },
  });

  // Group by week
  const weeklyPerformance: { [key: string]: { openRate: number[]; clickRate: number[]; deliveryRate: number[] } } = {};
  
  campaigns.forEach(campaign => {
    if (!campaign.sentAt) return;
    
    const week = getWeekStart(campaign.sentAt).toISOString().split('T')[0];
    if (!weeklyPerformance[week]) {
      weeklyPerformance[week] = { openRate: [], clickRate: [], deliveryRate: [] };
    }
    
    weeklyPerformance[week].openRate.push(campaign.openRate);
    weeklyPerformance[week].clickRate.push(campaign.clickRate);
    weeklyPerformance[week].deliveryRate.push(campaign.deliveryRate);
  });

  return Object.entries(weeklyPerformance).map(([week, data]) => ({
    week,
    averageOpenRate: data.openRate.length > 0 ? data.openRate.reduce((a, b) => a + b, 0) / data.openRate.length : 0,
    averageClickRate: data.clickRate.length > 0 ? data.clickRate.reduce((a, b) => a + b, 0) / data.clickRate.length : 0,
    averageDeliveryRate: data.deliveryRate.length > 0 ? data.deliveryRate.reduce((a, b) => a + b, 0) / data.deliveryRate.length : 0,
    campaignCount: data.openRate.length,
  }));
}

async function calculateSubscriberGrowthRate(userId: string, days: number) {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  
  const midDate = new Date();
  midDate.setDate(midDate.getDate() - Math.floor(days / 2));

  const [currentCount, previousCount] = await Promise.all([
    prisma.listSubscriber.count({
      where: {
        list: { userId },
        createdAt: { gte: midDate },
      },
    }),
    prisma.listSubscriber.count({
      where: {
        list: { userId },
        createdAt: { gte: startDate, lt: midDate },
      },
    }),
  ]);

  if (previousCount === 0) return 0;
  return ((currentCount - previousCount) / previousCount) * 100;
}

function getWeekStart(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day;
  return new Date(d.setDate(diff));
}
