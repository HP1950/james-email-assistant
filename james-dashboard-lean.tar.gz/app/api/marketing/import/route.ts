
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const importSchema = z.object({
  listId: z.string().min(1, 'List ID is required'),
  data: z.array(z.object({
    email: z.string().email('Invalid email address'),
    firstName: z.string().optional(),
    lastName: z.string().optional(),
    company: z.string().optional(),
    phone: z.string().optional(),
    customFields: z.record(z.any()).optional(),
  })),
  overrideExisting: z.boolean().default(false),
  confirmOptIn: z.boolean().default(false),
});

// POST /api/marketing/import - Import subscribers to list
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = importSchema.parse(body);

    // Verify list ownership
    const list = await prisma.emailList.findFirst({
      where: {
        id: validatedData.listId,
        userId: session.user.id,
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    const importResults = {
      total: validatedData.data.length,
      imported: 0,
      updated: 0,
      skipped: 0,
      errors: [] as any[],
    };

    // Process subscribers in batches
    const batchSize = 100;
    for (let i = 0; i < validatedData.data.length; i += batchSize) {
      const batch = validatedData.data.slice(i, i + batchSize);
      
      for (const subscriberData of batch) {
        try {
          // Check if subscriber already exists
          const existingSubscriber = await prisma.listSubscriber.findUnique({
            where: {
              listId_email: {
                listId: validatedData.listId,
                email: subscriberData.email,
              },
            },
          });

          if (existingSubscriber) {
            if (validatedData.overrideExisting) {
              // Update existing subscriber
              await prisma.listSubscriber.update({
                where: { id: existingSubscriber.id },
                data: {
                  firstName: subscriberData.firstName,
                  lastName: subscriberData.lastName,
                  company: subscriberData.company,
                  phone: subscriberData.phone,
                  customFields: subscriberData.customFields,
                  updatedAt: new Date(),
                },
              });
              importResults.updated++;
            } else {
              importResults.skipped++;
            }
          } else {
            // Create new subscriber
            await prisma.listSubscriber.create({
              data: {
                listId: validatedData.listId,
                email: subscriberData.email,
                firstName: subscriberData.firstName,
                lastName: subscriberData.lastName,
                company: subscriberData.company,
                phone: subscriberData.phone,
                customFields: subscriberData.customFields,
                status: validatedData.confirmOptIn ? 'PENDING' : 'CONFIRMED',
                confirmedAt: validatedData.confirmOptIn ? undefined : new Date(),
                source: 'import',
              },
            });
            importResults.imported++;
          }
        } catch (error) {
          importResults.errors.push({
            email: subscriberData.email,
            error: error instanceof Error ? error.message : 'Unknown error',
          });
        }
      }
    }

    // Update list subscriber counts
    const [totalSubscribers, activeSubscribers] = await Promise.all([
      prisma.listSubscriber.count({
        where: { listId: validatedData.listId },
      }),
      prisma.listSubscriber.count({
        where: {
          listId: validatedData.listId,
          status: { in: ['CONFIRMED', 'ACTIVE'] },
        },
      }),
    ]);

    await prisma.emailList.update({
      where: { id: validatedData.listId },
      data: {
        subscriberCount: totalSubscribers,
        activeCount: activeSubscribers,
      },
    });

    return NextResponse.json({
      success: true,
      data: importResults,
      message: `Import completed: ${importResults.imported} imported, ${importResults.updated} updated, ${importResults.skipped} skipped`,
    });
  } catch (error) {
    console.error('Error importing subscribers:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to import subscribers' },
      { status: 500 }
    );
  }
}
