
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const createTemplateSchema = z.object({
  name: z.string().min(1, 'Template name is required'),
  description: z.string().optional(),
  category: z.string().optional(),
  htmlContent: z.string().min(1, 'HTML content is required'),
  textContent: z.string().optional(),
  subject: z.string().optional(),
  preheader: z.string().optional(),
  isPublic: z.boolean().default(false),
  tags: z.array(z.string()).default([]),
  isMobileOptimized: z.boolean().default(true),
  thumbnailUrl: z.string().optional(),
});

// GET /api/marketing/templates - Get all templates for user
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '12');
    const search = url.searchParams.get('search') || '';
    const category = url.searchParams.get('category');
    const includePublic = url.searchParams.get('includePublic') === 'true';
    const includeSystem = url.searchParams.get('includeSystem') === 'true';

    const skip = (page - 1) * limit;

    const where = {
      OR: [
        { userId: session.user.id },
        ...(includePublic ? [{ isPublic: true }] : []),
        ...(includeSystem ? [{ isSystem: true }] : []),
      ],
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' as const } },
          { description: { contains: search, mode: 'insensitive' as const } },
          { tags: { has: search } },
        ],
      }),
      ...(category && { category }),
    };

    const [templates, total] = await Promise.all([
      prisma.emailTemplate.findMany({
        where,
        skip,
        take: limit,
        include: {
          _count: {
            select: {
              campaigns: true,
            },
          },
        },
        orderBy: [
          { isSystem: 'desc' },
          { usageCount: 'desc' },
          { createdAt: 'desc' },
        ],
      }),
      prisma.emailTemplate.count({ where }),
    ]);

    // Get available categories
    const categories = await prisma.emailTemplate.findMany({
      where: {
        OR: [
          { userId: session.user.id },
          { isPublic: true },
          { isSystem: true },
        ],
        category: { not: null },
      },
      select: { category: true },
      distinct: ['category'],
    });

    return NextResponse.json({
      success: true,
      data: {
        templates,
        categories: categories.map(c => c.category).filter(Boolean),
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Error fetching templates:', error);
    return NextResponse.json(
      { error: 'Failed to fetch templates' },
      { status: 500 }
    );
  }
}

// POST /api/marketing/templates - Create new template
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = createTemplateSchema.parse(body);

    const template = await prisma.emailTemplate.create({
      data: {
        ...validatedData,
        userId: session.user.id,
      },
      include: {
        _count: {
          select: {
            campaigns: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: template,
    });
  } catch (error) {
    console.error('Error creating template:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to create template' },
      { status: 500 }
    );
  }
}
