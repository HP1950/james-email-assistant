
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const cloneTemplateSchema = z.object({
  name: z.string().min(1, 'Template name is required'),
  description: z.string().optional(),
  category: z.string().optional(),
});

// POST /api/marketing/templates/[id]/clone - Clone template
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = cloneTemplateSchema.parse(body);

    const originalTemplate = await prisma.emailTemplate.findFirst({
      where: {
        id: params.id,
        OR: [
          { userId: session.user.id },
          { isPublic: true },
          { isSystem: true },
        ],
      },
    });

    if (!originalTemplate) {
      return NextResponse.json({ error: 'Template not found' }, { status: 404 });
    }

    const clonedTemplate = await prisma.emailTemplate.create({
      data: {
        name: validatedData.name,
        description: validatedData.description || `Copy of ${originalTemplate.name}`,
        category: validatedData.category || originalTemplate.category,
        htmlContent: originalTemplate.htmlContent,
        textContent: originalTemplate.textContent,
        subject: originalTemplate.subject,
        preheader: originalTemplate.preheader,
        tags: originalTemplate.tags,
        isMobileOptimized: originalTemplate.isMobileOptimized,
        thumbnailUrl: originalTemplate.thumbnailUrl,
        userId: session.user.id,
        isPublic: false, // Cloned templates are always private initially
        isSystem: false,
      },
      include: {
        _count: {
          select: {
            campaigns: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: clonedTemplate,
      message: 'Template cloned successfully',
    });
  } catch (error) {
    console.error('Error cloning template:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to clone template' },
      { status: 500 }
    );
  }
}
