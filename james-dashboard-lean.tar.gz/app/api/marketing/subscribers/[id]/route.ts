
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const updateSubscriberSchema = z.object({
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  company: z.string().optional(),
  phone: z.string().optional(),
  customFields: z.record(z.any()).optional(),
  timezone: z.string().optional(),
  language: z.string().optional(),
  preferences: z.record(z.any()).optional(),
  status: z.enum(['PENDING', 'CONFIRMED', 'ACTIVE', 'UNSUBSCRIBED', 'BOUNCED', 'COMPLAINED', 'SUPPRESSED']).optional(),
});

// GET /api/marketing/subscribers/[id] - Get subscriber by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const subscriber = await prisma.listSubscriber.findFirst({
      where: {
        id: params.id,
        list: {
          userId: session.user.id,
        },
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
            type: true,
          },
        },
        campaignStats: {
          include: {
            campaign: {
              select: {
                id: true,
                name: true,
                sentAt: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
        bounces: {
          orderBy: { bouncedAt: 'desc' },
          take: 5,
        },
        complaints: {
          orderBy: { complainedAt: 'desc' },
          take: 5,
        },
      },
    });

    if (!subscriber) {
      return NextResponse.json({ error: 'Subscriber not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: subscriber,
    });
  } catch (error) {
    console.error('Error fetching subscriber:', error);
    return NextResponse.json(
      { error: 'Failed to fetch subscriber' },
      { status: 500 }
    );
  }
}

// PATCH /api/marketing/subscribers/[id] - Update subscriber
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = updateSubscriberSchema.parse(body);

    const subscriber = await prisma.listSubscriber.findFirst({
      where: {
        id: params.id,
        list: {
          userId: session.user.id,
        },
      },
    });

    if (!subscriber) {
      return NextResponse.json({ error: 'Subscriber not found' }, { status: 404 });
    }

    const updatedSubscriber = await prisma.listSubscriber.update({
      where: { id: params.id },
      data: {
        ...validatedData,
        ...(validatedData.status === 'CONFIRMED' && !subscriber.confirmedAt && {
          confirmedAt: new Date(),
        }),
        ...(validatedData.status === 'UNSUBSCRIBED' && !subscriber.unsubscribedAt && {
          unsubscribedAt: new Date(),
        }),
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
            type: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: updatedSubscriber,
    });
  } catch (error) {
    console.error('Error updating subscriber:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to update subscriber' },
      { status: 500 }
    );
  }
}

// DELETE /api/marketing/subscribers/[id] - Delete subscriber
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const subscriber = await prisma.listSubscriber.findFirst({
      where: {
        id: params.id,
        list: {
          userId: session.user.id,
        },
      },
      include: {
        list: true,
      },
    });

    if (!subscriber) {
      return NextResponse.json({ error: 'Subscriber not found' }, { status: 404 });
    }

    await prisma.listSubscriber.delete({
      where: { id: params.id },
    });

    // Update list subscriber count
    await prisma.emailList.update({
      where: { id: subscriber.listId },
      data: {
        subscriberCount: { decrement: 1 },
        ...(subscriber.status === 'CONFIRMED' || subscriber.status === 'ACTIVE') && {
          activeCount: { decrement: 1 },
        },
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Subscriber deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting subscriber:', error);
    return NextResponse.json(
      { error: 'Failed to delete subscriber' },
      { status: 500 }
    );
  }
}
