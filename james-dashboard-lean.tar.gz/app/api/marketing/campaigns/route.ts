
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const createCampaignSchema = z.object({
  name: z.string().min(1, 'Campaign name is required'),
  subject: z.string().min(1, 'Subject is required'),
  preheader: z.string().optional(),
  fromName: z.string().min(1, 'From name is required'),
  fromEmail: z.string().email('Invalid from email'),
  replyToEmail: z.string().email().optional(),
  htmlContent: z.string().optional(),
  textContent: z.string().optional(),
  templateId: z.string().optional(),
  listId: z.string().optional(),
  segmentId: z.string().optional(),
  type: z.enum(['STANDARD', 'AB_TEST', 'AUTOMATION', 'TRANSACTIONAL']).default('STANDARD'),
  scheduledAt: z.string().datetime().optional(),
  sendTimeOptimization: z.boolean().default(false),
  timezone: z.string().default('UTC'),
  isAbTest: z.boolean().default(false),
  abTestType: z.enum(['SUBJECT_LINE', 'FROM_NAME', 'CONTENT', 'SEND_TIME']).optional(),
  abTestPercentage: z.number().min(1).max(50).optional(),
  deliverySpeed: z.enum(['SLOW', 'NORMAL', 'FAST', 'IMMEDIATE']).default('NORMAL'),
  maxDeliveryTime: z.number().optional(),
});

// GET /api/marketing/campaigns - Get all campaigns for user
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '10');
    const search = url.searchParams.get('search') || '';
    const status = url.searchParams.get('status');
    const type = url.searchParams.get('type');
    const listId = url.searchParams.get('listId');

    const skip = (page - 1) * limit;

    const where = {
      userId: session.user.id,
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' as const } },
          { subject: { contains: search, mode: 'insensitive' as const } },
        ],
      }),
      ...(status && status !== 'all' && { status: status as any }),
      ...(type && type !== 'all' && { type: type as any }),
      ...(listId && { listId }),
    };

    const [campaigns, total] = await Promise.all([
      prisma.campaign.findMany({
        where,
        skip,
        take: limit,
        include: {
          list: {
            select: {
              id: true,
              name: true,
            },
          },
          segment: {
            select: {
              id: true,
              name: true,
            },
          },
          template: {
            select: {
              id: true,
              name: true,
            },
          },
          _count: {
            select: {
              subscriberStats: true,
              abTestVariants: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.campaign.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        campaigns,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Error fetching campaigns:', error);
    return NextResponse.json(
      { error: 'Failed to fetch campaigns' },
      { status: 500 }
    );
  }
}

// POST /api/marketing/campaigns - Create new campaign
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = createCampaignSchema.parse(body);

    // Validate that either listId or segmentId is provided
    if (!validatedData.listId && !validatedData.segmentId) {
      return NextResponse.json(
        { error: 'Either listId or segmentId must be provided' },
        { status: 400 }
      );
    }

    // Validate list ownership if listId provided
    if (validatedData.listId) {
      const list = await prisma.emailList.findFirst({
        where: {
          id: validatedData.listId,
          userId: session.user.id,
        },
      });

      if (!list) {
        return NextResponse.json({ error: 'List not found' }, { status: 404 });
      }
    }

    // Validate segment ownership if segmentId provided
    if (validatedData.segmentId) {
      const segment = await prisma.listSegment.findFirst({
        where: {
          id: validatedData.segmentId,
          list: {
            userId: session.user.id,
          },
        },
      });

      if (!segment) {
        return NextResponse.json({ error: 'Segment not found' }, { status: 404 });
      }
    }

    // Validate template ownership if templateId provided
    if (validatedData.templateId) {
      const template = await prisma.emailTemplate.findFirst({
        where: {
          id: validatedData.templateId,
          OR: [
            { userId: session.user.id },
            { isSystem: true },
            { isPublic: true },
          ],
        },
      });

      if (!template) {
        return NextResponse.json({ error: 'Template not found' }, { status: 404 });
      }
    }

    const campaign = await prisma.campaign.create({
      data: {
        ...validatedData,
        userId: session.user.id,
        ...(validatedData.scheduledAt && {
          scheduledAt: new Date(validatedData.scheduledAt),
        }),
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
          },
        },
        segment: {
          select: {
            id: true,
            name: true,
          },
        },
        template: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: campaign,
    });
  } catch (error) {
    console.error('Error creating campaign:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to create campaign' },
      { status: 500 }
    );
  }
}
