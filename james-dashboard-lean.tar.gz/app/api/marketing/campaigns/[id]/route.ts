
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const updateCampaignSchema = z.object({
  name: z.string().min(1).optional(),
  subject: z.string().min(1).optional(),
  preheader: z.string().optional(),
  fromName: z.string().min(1).optional(),
  fromEmail: z.string().email().optional(),
  replyToEmail: z.string().email().optional(),
  htmlContent: z.string().optional(),
  textContent: z.string().optional(),
  templateId: z.string().optional(),
  scheduledAt: z.string().datetime().optional(),
  sendTimeOptimization: z.boolean().optional(),
  timezone: z.string().optional(),
  deliverySpeed: z.enum(['SLOW', 'NORMAL', 'FAST', 'IMMEDIATE']).optional(),
  maxDeliveryTime: z.number().optional(),
  status: z.enum(['DRAFT', 'SCHEDULED', 'SENDING', 'SENT', 'PAUSED', 'CANCELLED', 'FAILED']).optional(),
});

// GET /api/marketing/campaigns/[id] - Get campaign by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
            subscriberCount: true,
          },
        },
        segment: {
          select: {
            id: true,
            name: true,
            subscriberCount: true,
          },
        },
        template: {
          select: {
            id: true,
            name: true,
            htmlContent: true,
            textContent: true,
          },
        },
        abTestVariants: true,
        linkTracking: {
          orderBy: { clickCount: 'desc' },
        },
        subscriberStats: {
          take: 10,
          orderBy: { createdAt: 'desc' },
          include: {
            subscriber: {
              select: {
                email: true,
                firstName: true,
                lastName: true,
              },
            },
          },
        },
        _count: {
          select: {
            subscriberStats: true,
            deliveryLogs: true,
          },
        },
      },
    });

    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: campaign,
    });
  } catch (error) {
    console.error('Error fetching campaign:', error);
    return NextResponse.json(
      { error: 'Failed to fetch campaign' },
      { status: 500 }
    );
  }
}

// PATCH /api/marketing/campaigns/[id] - Update campaign
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = updateCampaignSchema.parse(body);

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
    });

    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }

    // Check if campaign can be edited
    if (campaign.status === 'SENT' || campaign.status === 'SENDING') {
      return NextResponse.json(
        { error: 'Cannot edit sent or sending campaign' },
        { status: 400 }
      );
    }

    // Validate template ownership if templateId provided
    if (validatedData.templateId) {
      const template = await prisma.emailTemplate.findFirst({
        where: {
          id: validatedData.templateId,
          OR: [
            { userId: session.user.id },
            { isSystem: true },
            { isPublic: true },
          ],
        },
      });

      if (!template) {
        return NextResponse.json({ error: 'Template not found' }, { status: 404 });
      }
    }

    const updatedCampaign = await prisma.campaign.update({
      where: { id: params.id },
      data: {
        ...validatedData,
        ...(validatedData.scheduledAt && {
          scheduledAt: new Date(validatedData.scheduledAt),
        }),
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
          },
        },
        segment: {
          select: {
            id: true,
            name: true,
          },
        },
        template: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: updatedCampaign,
    });
  } catch (error) {
    console.error('Error updating campaign:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to update campaign' },
      { status: 500 }
    );
  }
}

// DELETE /api/marketing/campaigns/[id] - Delete campaign
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
    });

    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }

    // Check if campaign can be deleted
    if (campaign.status === 'SENDING') {
      return NextResponse.json(
        { error: 'Cannot delete campaign that is currently sending' },
        { status: 400 }
      );
    }

    await prisma.campaign.delete({
      where: { id: params.id },
    });

    return NextResponse.json({
      success: true,
      message: 'Campaign deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting campaign:', error);
    return NextResponse.json(
      { error: 'Failed to delete campaign' },
      { status: 500 }
    );
  }
}
