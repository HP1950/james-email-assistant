
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET /api/marketing/campaigns/[id]/analytics - Get detailed campaign analytics
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
          },
        },
        segment: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }

    // Get detailed analytics
    const [
      subscriberStats,
      linkTracking,
      deliveryLogs,
      abTestResults,
      timeBasedStats,
      deviceStats,
      locationStats,
    ] = await Promise.all([
      // Subscriber engagement stats
      prisma.campaignSubscriberStat.findMany({
        where: { campaignId: params.id },
        include: {
          subscriber: {
            select: {
              email: true,
              firstName: true,
              lastName: true,
              customFields: true,
            },
          },
        },
      }),
      
      // Link click tracking
      prisma.campaignLinkTracking.findMany({
        where: { campaignId: params.id },
        include: {
          clicks: {
            include: {
              link: true,
            },
          },
        },
        orderBy: { clickCount: 'desc' },
      }),
      
      // Delivery logs
      prisma.campaignDeliveryLog.findMany({
        where: { campaignId: params.id },
        orderBy: { createdAt: 'desc' },
        take: 100,
      }),
      
      // A/B Test results
      prisma.campaignAbTest.findMany({
        where: { campaignId: params.id },
        orderBy: { variant: 'asc' },
      }),
      
      // Mock time-based stats (in a real implementation, you'd calculate these from actual data)
      generateTimeBasedStats(params.id),
      
      // Mock device stats
      generateDeviceStats(params.id),
      
      // Mock location stats
      generateLocationStats(params.id),
    ]);

    // Calculate engagement metrics
    const totalSent = subscriberStats.length;
    const totalOpened = subscriberStats.filter(stat => stat.openedAt).length;
    const totalClicked = subscriberStats.filter(stat => stat.clickedAt).length;
    const totalUnsubscribed = subscriberStats.filter(stat => stat.unsubscribedAt).length;
    const totalBounced = subscriberStats.filter(stat => stat.bouncedAt).length;
    const totalComplained = subscriberStats.filter(stat => stat.complainedAt).length;

    // Calculate rates
    const openRate = totalSent > 0 ? (totalOpened / totalSent) * 100 : 0;
    const clickRate = totalSent > 0 ? (totalClicked / totalSent) * 100 : 0;
    const clickToOpenRate = totalOpened > 0 ? (totalClicked / totalOpened) * 100 : 0;
    const unsubscribeRate = totalSent > 0 ? (totalUnsubscribed / totalSent) * 100 : 0;
    const bounceRate = totalSent > 0 ? (totalBounced / totalSent) * 100 : 0;
    const complaintRate = totalSent > 0 ? (totalComplained / totalSent) * 100 : 0;

    // Top performing links
    const topLinks = linkTracking
      .slice(0, 10)
      .map(link => ({
        url: link.originalUrl,
        linkText: link.linkText,
        clicks: link.clickCount,
        uniqueClicks: link.uniqueClickCount,
        clickRate: totalSent > 0 ? (link.clickCount / totalSent) * 100 : 0,
      }));

    // Engagement timeline
    const engagementTimeline = generateEngagementTimeline(subscriberStats);

    // Top engaged subscribers
    const topEngagedSubscribers = subscriberStats
      .filter(stat => stat.openCount > 0 || stat.clickCount > 0)
      .sort((a, b) => (b.openCount + b.clickCount * 2) - (a.openCount + a.clickCount * 2))
      .slice(0, 20)
      .map(stat => ({
        email: stat.subscriber?.email,
        name: `${stat.subscriber?.firstName || ''} ${stat.subscriber?.lastName || ''}`.trim(),
        opens: stat.openCount,
        clicks: stat.clickCount,
        lastEngagement: stat.lastOpenAt || stat.lastClickAt,
        engagementScore: stat.openCount + (stat.clickCount * 2),
      }));

    const analytics = {
      campaign: {
        id: campaign.id,
        name: campaign.name,
        subject: campaign.subject,
        sentAt: campaign.sentAt,
        status: campaign.status,
      },
      overview: {
        totalSent,
        totalOpened,
        totalClicked,
        totalUnsubscribed,
        totalBounced,
        totalComplained,
        openRate: Math.round(openRate * 100) / 100,
        clickRate: Math.round(clickRate * 100) / 100,
        clickToOpenRate: Math.round(clickToOpenRate * 100) / 100,
        unsubscribeRate: Math.round(unsubscribeRate * 100) / 100,
        bounceRate: Math.round(bounceRate * 100) / 100,
        complaintRate: Math.round(complaintRate * 100) / 100,
      },
      engagement: {
        timeline: engagementTimeline,
        byTime: timeBasedStats,
        byDevice: deviceStats,
        byLocation: locationStats,
      },
      links: {
        topPerforming: topLinks,
        totalLinks: linkTracking.length,
        totalClicks: linkTracking.reduce((sum, link) => sum + link.clickCount, 0),
      },
      subscribers: {
        topEngaged: topEngagedSubscribers,
        recentActivity: subscriberStats
          .filter(stat => stat.openedAt || stat.clickedAt)
          .sort((a, b) => {
            const aTime = Math.max(
              new Date(a.lastOpenAt || 0).getTime(),
              new Date(a.lastClickAt || 0).getTime()
            );
            const bTime = Math.max(
              new Date(b.lastOpenAt || 0).getTime(),
              new Date(b.lastClickAt || 0).getTime()
            );
            return bTime - aTime;
          })
          .slice(0, 50),
      },
      abTest: abTestResults.length > 0 ? {
        variants: abTestResults,
        winner: abTestResults.find(variant => variant.isWinner),
        performance: abTestResults.map(variant => ({
          variant: variant.variant,
          subject: variant.subject,
          openRate: variant.openRate,
          clickRate: variant.clickRate,
          recipients: variant.recipientCount,
        })),
      } : null,
      delivery: {
        successful: deliveryLogs.filter(log => log.status === 'DELIVERED').length,
        failed: deliveryLogs.filter(log => log.status === 'FAILED').length,
        bounced: deliveryLogs.filter(log => log.status === 'BOUNCED').length,
        deferred: deliveryLogs.filter(log => log.status === 'DEFERRED').length,
        recentLogs: deliveryLogs.slice(0, 20),
      },
    };

    return NextResponse.json({
      success: true,
      data: analytics,
    });
  } catch (error) {
    console.error('Error fetching campaign analytics:', error);
    return NextResponse.json(
      { error: 'Failed to fetch campaign analytics' },
      { status: 500 }
    );
  }
}

// Helper functions for generating mock stats (in a real implementation, these would query actual data)
async function generateTimeBasedStats(campaignId: string) {
  // Generate hourly open/click stats for the last 24 hours
  const hours = Array.from({ length: 24 }, (_, i) => {
    const hour = new Date();
    hour.setHours(hour.getHours() - (23 - i));
    return {
      hour: hour.getHours(),
      timestamp: hour,
      opens: Math.floor(Math.random() * 50),
      clicks: Math.floor(Math.random() * 20),
    };
  });
  return hours;
}

async function generateDeviceStats(campaignId: string) {
  return [
    { device: 'Desktop', opens: 45, clicks: 18, percentage: 45 },
    { device: 'Mobile', opens: 35, clicks: 12, percentage: 35 },
    { device: 'Tablet', opens: 20, clicks: 8, percentage: 20 },
  ];
}

async function generateLocationStats(campaignId: string) {
  return [
    { country: 'United States', opens: 120, clicks: 45, percentage: 40 },
    { country: 'United Kingdom', opens: 80, clicks: 30, percentage: 27 },
    { country: 'Canada', opens: 60, clicks: 20, percentage: 20 },
    { country: 'Australia', opens: 40, clicks: 15, percentage: 13 },
  ];
}

function generateEngagementTimeline(subscriberStats: any[]) {
  // Group engagement by hour for the timeline
  const timeline: { [key: string]: { opens: number; clicks: number } } = {};
  
  subscriberStats.forEach(stat => {
    if (stat.openedAt) {
      const hour = new Date(stat.openedAt).toISOString().slice(0, 13);
      if (!timeline[hour]) timeline[hour] = { opens: 0, clicks: 0 };
      timeline[hour].opens += stat.openCount;
    }
    if (stat.clickedAt) {
      const hour = new Date(stat.clickedAt).toISOString().slice(0, 13);
      if (!timeline[hour]) timeline[hour] = { opens: 0, clicks: 0 };
      timeline[hour].clicks += stat.clickCount;
    }
  });

  return Object.entries(timeline)
    .map(([hour, stats]) => ({
      timestamp: new Date(hour + ':00:00Z'),
      opens: stats.opens,
      clicks: stats.clicks,
    }))
    .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
}
