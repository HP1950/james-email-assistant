
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const sendCampaignSchema = z.object({
  sendNow: z.boolean().default(false),
  scheduledAt: z.string().datetime().optional(),
  testEmails: z.array(z.string().email()).optional(),
  testMode: z.boolean().default(false),
});

// POST /api/marketing/campaigns/[id]/send - Send or schedule campaign
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = sendCampaignSchema.parse(body);

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
      include: {
        list: true,
        segment: {
          include: {
            list: true,
          },
        },
      },
    });

    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }

    // Validate campaign can be sent
    if (campaign.status !== 'DRAFT' && campaign.status !== 'SCHEDULED') {
      return NextResponse.json(
        { error: 'Campaign must be in draft or scheduled status to send' },
        { status: 400 }
      );
    }

    // Validate campaign content
    if (!campaign.htmlContent && !campaign.textContent) {
      return NextResponse.json(
        { error: 'Campaign must have content to send' },
        { status: 400 }
      );
    }

    // If test mode, send to test emails only
    if (validatedData.testMode && validatedData.testEmails) {
      return await sendTestCampaign(campaign, validatedData.testEmails);
    }

    // Get recipient count
    let recipientCount = 0;
    if (campaign.listId) {
      recipientCount = await prisma.listSubscriber.count({
        where: {
          listId: campaign.listId,
          status: { in: ['CONFIRMED', 'ACTIVE'] },
        },
      });
    } else if (campaign.segmentId) {
      // For segments, we would need to implement segment criteria evaluation
      // For now, return the static count
      recipientCount = campaign.segment?.subscriberCount || 0;
    }

    if (recipientCount === 0) {
      return NextResponse.json(
        { error: 'No active subscribers found for this campaign' },
        { status: 400 }
      );
    }

    const now = new Date();
    const scheduledTime = validatedData.sendNow 
      ? now 
      : validatedData.scheduledAt 
        ? new Date(validatedData.scheduledAt)
        : campaign.scheduledAt || now;

    const status = validatedData.sendNow ? 'SENDING' : 'SCHEDULED';

    // Update campaign status and schedule
    const updatedCampaign = await prisma.campaign.update({
      where: { id: params.id },
      data: {
        status,
        scheduledAt: scheduledTime,
        recipientCount,
        ...(validatedData.sendNow && {
          sentAt: now,
        }),
      },
    });

    // If sending now, trigger the actual sending process
    if (validatedData.sendNow) {
      // In a real implementation, this would queue the campaign for sending
      // For now, we'll simulate the process
      await simulateCampaignSending(updatedCampaign);
    }

    return NextResponse.json({
      success: true,
      data: {
        campaign: updatedCampaign,
        recipientCount,
        scheduledAt: scheduledTime,
        status,
      },
      message: validatedData.sendNow 
        ? 'Campaign is being sent' 
        : 'Campaign scheduled successfully',
    });
  } catch (error) {
    console.error('Error sending campaign:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to send campaign' },
      { status: 500 }
    );
  }
}

async function sendTestCampaign(campaign: any, testEmails: string[]) {
  try {
    // Create test delivery logs
    const deliveryLogs = await Promise.all(
      testEmails.map(email =>
        prisma.campaignDeliveryLog.create({
          data: {
            campaignId: campaign.id,
            email,
            status: 'SENT',
            deliveryAttempt: 1,
            lastAttemptAt: new Date(),
            provider: 'test',
          },
        })
      )
    );

    return NextResponse.json({
      success: true,
      data: {
        campaign,
        testEmails,
        deliveryLogs,
      },
      message: `Test campaign sent to ${testEmails.length} addresses`,
    });
  } catch (error) {
    console.error('Error sending test campaign:', error);
    return NextResponse.json(
      { error: 'Failed to send test campaign' },
      { status: 500 }
    );
  }
}

async function simulateCampaignSending(campaign: any) {
  try {
    // In a real implementation, this would:
    // 1. Queue the campaign for background processing
    // 2. Process subscribers in batches
    // 3. Handle delivery through SMTP providers
    // 4. Track delivery status and engagement
    
    // For demo purposes, we'll create some mock delivery stats
    const subscribers = await prisma.listSubscriber.findMany({
      where: {
        listId: campaign.listId,
        status: { in: ['CONFIRMED', 'ACTIVE'] },
      },
      take: Math.min(campaign.recipientCount, 100), // Limit for demo
    });

    // Create subscriber stats for tracking
    await Promise.all(
      subscribers.map(subscriber =>
        prisma.campaignSubscriberStat.create({
          data: {
            campaignId: campaign.id,
            subscriberId: subscriber.id,
            status: 'SENT',
            sentAt: new Date(),
          },
        })
      )
    );

    // Update campaign with sent count
    await prisma.campaign.update({
      where: { id: campaign.id },
      data: {
        sentCount: subscribers.length,
        status: 'SENT',
      },
    });

    console.log(`Campaign ${campaign.id} sent to ${subscribers.length} subscribers`);
  } catch (error) {
    console.error('Error in campaign sending simulation:', error);
    
    // Update campaign status to failed
    await prisma.campaign.update({
      where: { id: campaign.id },
      data: {
        status: 'FAILED',
      },
    });
  }
}
