
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const createAutomationSchema = z.object({
  name: z.string().min(1, 'Automation name is required'),
  description: z.string().optional(),
  listId: z.string().min(1, 'List ID is required'),
  type: z.enum(['DRIP_CAMPAIGN', 'WELCOME_SERIES', 'ABANDONED_CART', 'REENGAGEMENT', 'BIRTHDAY', 'ANNIVERSARY', 'BEHAVIORAL']).default('DRIP_CAMPAIGN'),
  trigger: z.object({
    type: z.enum(['list_join', 'email_open', 'link_click', 'date_based', 'behavior', 'custom']),
    conditions: z.any(),
    delay: z.object({
      days: z.number().min(0).default(0),
      hours: z.number().min(0).max(23).default(0),
    }).optional(),
  }),
  workflow: z.object({
    steps: z.array(z.object({
      id: z.string(),
      type: z.enum(['email', 'wait', 'condition', 'action']),
      config: z.any(),
      connections: z.array(z.string()).default([]),
    })),
  }),
  maxSubscribers: z.number().optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
});

// GET /api/marketing/automations - Get all automations for user
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '10');
    const search = url.searchParams.get('search') || '';
    const type = url.searchParams.get('type');
    const isActive = url.searchParams.get('isActive');
    const listId = url.searchParams.get('listId');

    const skip = (page - 1) * limit;

    const where = {
      userId: session.user.id,
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' as const } },
          { description: { contains: search, mode: 'insensitive' as const } },
        ],
      }),
      ...(type && type !== 'all' && { type: type as any }),
      ...(isActive !== null && { isActive: isActive === 'true' }),
      ...(listId && { listId }),
    };

    const [automations, total] = await Promise.all([
      prisma.marketingAutomation.findMany({
        where,
        skip,
        take: limit,
        include: {
          list: {
            select: {
              id: true,
              name: true,
              subscriberCount: true,
            },
          },
          emails: {
            select: {
              id: true,
              stepNumber: true,
              name: true,
              subject: true,
              sentCount: true,
              openRate: true,
              clickRate: true,
            },
            orderBy: { stepNumber: 'asc' },
          },
          _count: {
            select: {
              subscriberStats: true,
              emails: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.marketingAutomation.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        automations,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Error fetching automations:', error);
    return NextResponse.json(
      { error: 'Failed to fetch automations' },
      { status: 500 }
    );
  }
}

// POST /api/marketing/automations - Create new automation
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = createAutomationSchema.parse(body);

    // Verify list ownership
    const list = await prisma.emailList.findFirst({
      where: {
        id: validatedData.listId,
        userId: session.user.id,
      },
    });

    if (!list) {
      return NextResponse.json({ error: 'List not found' }, { status: 404 });
    }

    const automation = await prisma.marketingAutomation.create({
      data: {
        ...validatedData,
        userId: session.user.id,
        ...(validatedData.startDate && {
          startDate: new Date(validatedData.startDate),
        }),
        ...(validatedData.endDate && {
          endDate: new Date(validatedData.endDate),
        }),
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
            subscriberCount: true,
          },
        },
        _count: {
          select: {
            subscriberStats: true,
            emails: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: automation,
    });
  } catch (error) {
    console.error('Error creating automation:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to create automation' },
      { status: 500 }
    );
  }
}
