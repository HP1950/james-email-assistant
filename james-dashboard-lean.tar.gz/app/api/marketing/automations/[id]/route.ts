
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const updateAutomationSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  type: z.enum(['DRIP_CAMPAIGN', 'WELCOME_SERIES', 'ABANDONED_CART', 'REENGAGEMENT', 'BIRTHDAY', 'ANNIVERSARY', 'BEHAVIORAL']).optional(),
  trigger: z.object({
    type: z.enum(['list_join', 'email_open', 'link_click', 'date_based', 'behavior', 'custom']),
    conditions: z.any(),
    delay: z.object({
      days: z.number().min(0),
      hours: z.number().min(0).max(23),
    }).optional(),
  }).optional(),
  workflow: z.object({
    steps: z.array(z.object({
      id: z.string(),
      type: z.enum(['email', 'wait', 'condition', 'action']),
      config: z.any(),
      connections: z.array(z.string()).default([]),
    })),
  }).optional(),
  isActive: z.boolean().optional(),
  maxSubscribers: z.number().optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
});

// GET /api/marketing/automations/[id] - Get automation by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const automation = await prisma.marketingAutomation.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
            subscriberCount: true,
            activeCount: true,
          },
        },
        emails: {
          orderBy: { stepNumber: 'asc' },
        },
        subscriberStats: {
          take: 20,
          orderBy: { startedAt: 'desc' },
          include: {
            subscriber: {
              select: {
                email: true,
                firstName: true,
                lastName: true,
              },
            },
          },
        },
        _count: {
          select: {
            subscriberStats: true,
            emails: true,
          },
        },
      },
    });

    if (!automation) {
      return NextResponse.json({ error: 'Automation not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: automation,
    });
  } catch (error) {
    console.error('Error fetching automation:', error);
    return NextResponse.json(
      { error: 'Failed to fetch automation' },
      { status: 500 }
    );
  }
}

// PATCH /api/marketing/automations/[id] - Update automation
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = updateAutomationSchema.parse(body);

    const automation = await prisma.marketingAutomation.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
    });

    if (!automation) {
      return NextResponse.json({ error: 'Automation not found' }, { status: 404 });
    }

    // If activating automation, check if it has emails
    if (validatedData.isActive && !automation.isActive) {
      const emailCount = await prisma.automationEmail.count({
        where: { automationId: params.id },
      });

      if (emailCount === 0) {
        return NextResponse.json(
          { error: 'Cannot activate automation without emails' },
          { status: 400 }
        );
      }
    }

    const updatedAutomation = await prisma.marketingAutomation.update({
      where: { id: params.id },
      data: {
        ...validatedData,
        ...(validatedData.startDate && {
          startDate: new Date(validatedData.startDate),
        }),
        ...(validatedData.endDate && {
          endDate: new Date(validatedData.endDate),
        }),
      },
      include: {
        list: {
          select: {
            id: true,
            name: true,
            subscriberCount: true,
          },
        },
        _count: {
          select: {
            subscriberStats: true,
            emails: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: updatedAutomation,
    });
  } catch (error) {
    console.error('Error updating automation:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to update automation' },
      { status: 500 }
    );
  }
}

// DELETE /api/marketing/automations/[id] - Delete automation
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const automation = await prisma.marketingAutomation.findFirst({
      where: {
        id: params.id,
        userId: session.user.id,
      },
    });

    if (!automation) {
      return NextResponse.json({ error: 'Automation not found' }, { status: 404 });
    }

    // Check if automation is active
    if (automation.isActive) {
      return NextResponse.json(
        { error: 'Cannot delete active automation. Deactivate it first.' },
        { status: 400 }
      );
    }

    await prisma.marketingAutomation.delete({
      where: { id: params.id },
    });

    return NextResponse.json({
      success: true,
      message: 'Automation deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting automation:', error);
    return NextResponse.json(
      { error: 'Failed to delete automation' },
      { status: 500 }
    );
  }
}
