
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-config';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const exportSchema = z.object({
  type: z.enum(['subscribers', 'campaign_stats', 'analytics']),
  format: z.enum(['csv', 'json']).default('csv'),
  listId: z.string().optional(),
  campaignId: z.string().optional(),
  filters: z.object({
    status: z.array(z.string()).optional(),
    dateRange: z.object({
      start: z.string().datetime().optional(),
      end: z.string().datetime().optional(),
    }).optional(),
  }).optional(),
});

// POST /api/marketing/export - Export marketing data
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const validatedData = exportSchema.parse(body);

    let exportData: any[] = [];
    let analyticsData: any = null;
    let filename = '';

    switch (validatedData.type) {
      case 'subscribers':
        exportData = await exportSubscribers(session.user.id, validatedData);
        filename = `subscribers-${new Date().toISOString().split('T')[0]}`;
        break;
      
      case 'campaign_stats':
        exportData = await exportCampaignStats(session.user.id, validatedData);
        filename = `campaign-stats-${new Date().toISOString().split('T')[0]}`;
        break;
      
      case 'analytics':
        analyticsData = await exportAnalytics(session.user.id, validatedData);
        filename = `analytics-${new Date().toISOString().split('T')[0]}`;
        break;
    }

    if (validatedData.type === 'analytics') {
      // Analytics always returns JSON since it has a complex structure
      return NextResponse.json({
        success: true,
        data: analyticsData,
        filename: `${filename}.json`,
      });
    }

    if (validatedData.format === 'csv') {
      const csv = generateCSV(exportData);
      return new NextResponse(csv, {
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': `attachment; filename="${filename}.csv"`,
        },
      });
    } else {
      return NextResponse.json({
        success: true,
        data: exportData,
        filename: `${filename}.json`,
      });
    }
  } catch (error) {
    console.error('Error exporting data:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid data', details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to export data' },
      { status: 500 }
    );
  }
}

async function exportSubscribers(userId: string, options: any) {
  const where: any = {
    list: { userId },
  };

  if (options.listId) {
    where.listId = options.listId;
  }

  if (options.filters?.status) {
    where.status = { in: options.filters.status };
  }

  if (options.filters?.dateRange?.start || options.filters?.dateRange?.end) {
    where.createdAt = {};
    if (options.filters.dateRange.start) {
      where.createdAt.gte = new Date(options.filters.dateRange.start);
    }
    if (options.filters.dateRange.end) {
      where.createdAt.lte = new Date(options.filters.dateRange.end);
    }
  }

  const subscribers = await prisma.listSubscriber.findMany({
    where,
    include: {
      list: {
        select: {
          name: true,
        },
      },
    },
    orderBy: { createdAt: 'desc' },
  });

  return subscribers.map(subscriber => ({
    email: subscriber.email,
    firstName: subscriber.firstName || '',
    lastName: subscriber.lastName || '',
    company: subscriber.company || '',
    phone: subscriber.phone || '',
    status: subscriber.status,
    list: subscriber.list.name,
    totalOpens: subscriber.totalOpens,
    totalClicks: subscriber.totalClicks,
    engagementScore: subscriber.engagementScore,
    createdAt: subscriber.createdAt.toISOString(),
    confirmedAt: subscriber.confirmedAt?.toISOString() || '',
    lastOpenAt: subscriber.lastOpenAt?.toISOString() || '',
    lastClickAt: subscriber.lastClickAt?.toISOString() || '',
  }));
}

async function exportCampaignStats(userId: string, options: any) {
  const where: any = {
    userId,
  };

  if (options.campaignId) {
    where.id = options.campaignId;
  }

  if (options.filters?.dateRange?.start || options.filters?.dateRange?.end) {
    where.sentAt = {};
    if (options.filters.dateRange.start) {
      where.sentAt.gte = new Date(options.filters.dateRange.start);
    }
    if (options.filters.dateRange.end) {
      where.sentAt.lte = new Date(options.filters.dateRange.end);
    }
  }

  const campaigns = await prisma.campaign.findMany({
    where,
    include: {
      list: {
        select: {
          name: true,
        },
      },
    },
    orderBy: { sentAt: 'desc' },
  });

  return campaigns.map(campaign => ({
    name: campaign.name,
    subject: campaign.subject,
    list: campaign.list?.name || '',
    status: campaign.status,
    recipientCount: campaign.recipientCount,
    sentCount: campaign.sentCount,
    deliveredCount: campaign.deliveredCount,
    openCount: campaign.openCount,
    clickCount: campaign.clickCount,
    unsubscribeCount: campaign.unsubscribeCount,
    bounceCount: campaign.bounceCount,
    complaintCount: campaign.complaintCount,
    openRate: campaign.openRate,
    clickRate: campaign.clickRate,
    unsubscribeRate: campaign.unsubscribeRate,
    bounceRate: campaign.bounceRate,
    deliveryRate: campaign.deliveryRate,
    sentAt: campaign.sentAt?.toISOString() || '',
    createdAt: campaign.createdAt.toISOString(),
  }));
}

async function exportAnalytics(userId: string, options: any) {
  // Export summary analytics data
  const [lists, campaigns, subscribers] = await Promise.all([
    prisma.emailList.findMany({
      where: { userId },
      select: {
        name: true,
        subscriberCount: true,
        activeCount: true,
        engagementRate: true,
        createdAt: true,
      },
    }),
    prisma.campaign.findMany({
      where: { userId, status: 'SENT' },
      select: {
        name: true,
        recipientCount: true,
        openRate: true,
        clickRate: true,
        sentAt: true,
      },
    }),
    prisma.listSubscriber.groupBy({
      by: ['status'],
      where: {
        list: { userId },
      },
      _count: {
        id: true,
      },
    }),
  ]);

  return {
    summary: {
      totalLists: lists.length,
      totalSubscribers: subscribers.reduce((sum, s) => sum + s._count.id, 0),
      totalCampaigns: campaigns.length,
      averageOpenRate: campaigns.length > 0 
        ? campaigns.reduce((sum, c) => sum + c.openRate, 0) / campaigns.length 
        : 0,
      averageClickRate: campaigns.length > 0 
        ? campaigns.reduce((sum, c) => sum + c.clickRate, 0) / campaigns.length 
        : 0,
    },
    lists: lists.map(list => ({
      name: list.name,
      subscribers: list.subscriberCount,
      activeSubscribers: list.activeCount,
      engagementRate: list.engagementRate,
      createdAt: list.createdAt.toISOString(),
    })),
    campaigns: campaigns.map(campaign => ({
      name: campaign.name,
      recipients: campaign.recipientCount,
      openRate: campaign.openRate,
      clickRate: campaign.clickRate,
      sentAt: campaign.sentAt?.toISOString() || '',
    })),
    subscribersByStatus: subscribers.map(s => ({
      status: s.status,
      count: s._count.id,
    })),
  };
}

function generateCSV(data: any[]): string {
  if (data.length === 0) return '';

  const headers = Object.keys(data[0]);
  const csvRows = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header];
        // Escape quotes and wrap in quotes if needed
        if (typeof value === 'string' && (value.includes(',') || value.includes('"') || value.includes('\n'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      }).join(',')
    ),
  ];

  return csvRows.join('\n');
}
