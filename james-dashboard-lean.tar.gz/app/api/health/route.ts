
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
  try {
    // Check database connection
    await prisma.$queryRaw`SELECT 1`;
    
    // Get basic system stats
    const [
      usersCount,
      emailRulesCount,
      emailDraftsCount,
      emailAnalyticsCount
    ] = await Promise.all([
      prisma.user.count(),
      prisma.emailRule.count(),
      prisma.emailDraft.count(),
      prisma.emailAnalytics.count()
    ]);

    const healthData = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: '1.0.0',
      environment: process.env.NODE_ENV,
      domain: 'schulenberg.tech',
      database: {
        status: 'connected',
        users: usersCount,
        emailRules: emailRulesCount,
        emailDrafts: emailDraftsCount,
        emailAnalytics: emailAnalyticsCount
      },
      system: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        nodeVersion: process.version
      },
      features: {
        gmailIntegration: 'available',
        automation: 'active',
        analytics: 'active',
        dashboard: 'active'
      }
    };

    return NextResponse.json(healthData, { status: 200 });
  } catch (error) {
    console.error('Health check failed:', error);
    
    return NextResponse.json(
      {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        error: 'Database connection failed',
        message: 'Service temporarily unavailable'
      },
      { status: 503 }
    );
  } finally {
    await prisma.$disconnect();
  }
}

export const dynamic = 'force-dynamic';
