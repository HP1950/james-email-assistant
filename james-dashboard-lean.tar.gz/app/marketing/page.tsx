
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth-config';
import MarketingLayout from '@/components/marketing/marketing-layout';

export const metadata = {
  title: 'Email Marketing - Gmail Assistant',
  description: 'Manage your email marketing campaigns, lists, and automations',
};

export default async function MarketingPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/auth/signin');
  }

  return <MarketingLayout />;
}
