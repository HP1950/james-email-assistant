

export default function HomePage() {
  return (
    <div>
      <h1>James - Your Email Assistant</h1>
      <p>They Write. James Answers.</p>
      <img src="/james-branding.jpg" alt="James" style={{ width: '200px', height: '200px', borderRadius: '50%' }} />
      <div>
        <a href="/dashboard">Enter Dashboard</a>
        <a href="/email-setup">Setup Email Accounts</a>
      </div>
    </div>
  );
}
