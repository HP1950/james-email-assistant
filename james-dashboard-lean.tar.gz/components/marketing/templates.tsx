
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import {
  Layout,
  Plus,
  Search,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Copy,
  Eye,
  Download,
  Star,
  Smartphone,
  Monitor,
  Code,
  Image,
  Palette,
  Crown,
  Calendar,
} from 'lucide-react';

interface EmailTemplate {
  id: string;
  name: string;
  description?: string;
  category?: string;
  htmlContent: string;
  textContent?: string;
  subject?: string;
  preheader?: string;
  isPublic: boolean;
  isSystem: boolean;
  tags: string[];
  usageCount: number;
  lastUsed?: string;
  isMobileOptimized: boolean;
  thumbnailUrl?: string;
  createdAt: string;
  updatedAt: string;
  _count: {
    campaigns: number;
  };
}

const TEMPLATE_CATEGORIES = [
  'Newsletter',
  'Promotional',
  'Welcome',
  'Transactional',
  'Event',
  'Survey',
  'Announcement',
  'E-commerce',
  'Holiday',
  'Educational',
];

const PREDEFINED_TEMPLATES = [
  {
    id: 'welcome-series',
    name: 'Welcome Series',
    description: 'A beautiful welcome email template for new subscribers',
    category: 'Welcome',
    isSystem: true,
    thumbnailUrl: 'https://assets-global.website-files.com/628288c5cd3e8451380a36c7/63249bba5ccf56cabbca3b9e_thumb-affiliate-welcome-email.png',
    usageCount: 1250,
  },
  {
    id: 'newsletter-modern',
    name: 'Modern Newsletter',
    description: 'Clean and modern newsletter template with image blocks',
    category: 'Newsletter',
    isSystem: true,
    thumbnailUrl: 'https://img.freepik.com/premium-psd/medical-pharmacy-newsletter-email-template-design_285349-58.jpg?size=626&ext=jpg',
    usageCount: 980,
  },
  {
    id: 'promotional-sale',
    name: 'Promotional Sale',
    description: 'Eye-catching promotional template for sales and offers',
    category: 'Promotional',
    isSystem: true,
    thumbnailUrl: 'https://static.wixstatic.com/media/32b7a1_f9d05c9df4054088bf4adebe646980d8~mv2.png/v1/fill/w_980,h_551,al_c,q_90,usm_0.66_1.00_0.01,enc_auto/32b7a1_f9d05c9df4054088bf4adebe646980d8~mv2.png',
    usageCount: 756,
  },
  {
    id: 'event-invitation',
    name: 'Event Invitation',
    description: 'Elegant event invitation template with RSVP button',
    category: 'Event',
    isSystem: true,
    thumbnailUrl: 'https://res.cloudinary.com/mailmodo/image/upload/v1726815706/strapi/template_OG_image_dce420efb2.png',
    usageCount: 423,
  },
];

export default function EmailTemplates() {
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [categories, setCategories] = useState<string[]>([]);
  const { toast } = useToast();

  const [newTemplate, setNewTemplate] = useState({
    name: '',
    description: '',
    category: '',
    subject: '',
    preheader: '',
    htmlContent: '',
    textContent: '',
    tags: [] as string[],
  });

  useEffect(() => {
    fetchTemplates();
  }, [page, searchQuery, categoryFilter]);

  const fetchTemplates = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '12',
        includePublic: 'true',
        includeSystem: 'true',
        ...(searchQuery && { search: searchQuery }),
        ...(categoryFilter !== 'all' && { category: categoryFilter }),
      });

      const response = await fetch(`/api/marketing/templates?${params}`);
      const data = await response.json();

      if (data.success) {
        setTemplates(data.data.templates);
        setCategories(data.data.categories);
        setTotalPages(data.data.pagination.totalPages);
      } else {
        toast({
          title: 'Error',
          description: 'Failed to fetch templates',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error fetching templates:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch templates',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTemplate = async () => {
    try {
      if (!newTemplate.name || !newTemplate.htmlContent) {
        toast({
          title: 'Error',
          description: 'Name and HTML content are required',
          variant: 'destructive',
        });
        return;
      }

      const response = await fetch('/api/marketing/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTemplate),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: 'Success',
          description: 'Template created successfully',
        });
        setIsCreateDialogOpen(false);
        setNewTemplate({
          name: '',
          description: '',
          category: '',
          subject: '',
          preheader: '',
          htmlContent: '',
          textContent: '',
          tags: [],
        });
        fetchTemplates();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to create template',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error creating template:', error);
      toast({
        title: 'Error',
        description: 'Failed to create template',
        variant: 'destructive',
      });
    }
  };

  const handleCloneTemplate = async (templateId: string, newName: string) => {
    try {
      const response = await fetch(`/api/marketing/templates/${templateId}/clone`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName }),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: 'Success',
          description: 'Template cloned successfully',
        });
        fetchTemplates();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to clone template',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error cloning template:', error);
      toast({
        title: 'Error',
        description: 'Failed to clone template',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteTemplate = async (templateId: string) => {
    if (!confirm('Are you sure you want to delete this template? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await fetch(`/api/marketing/templates/${templateId}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: 'Success',
          description: 'Template deleted successfully',
        });
        fetchTemplates();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to delete template',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error deleting template:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete template',
        variant: 'destructive',
      });
    }
  };

  const getCategoryIcon = (category?: string) => {
    switch (category?.toLowerCase()) {
      case 'newsletter': return <Layout className="h-4 w-4" />;
      case 'promotional': return <Star className="h-4 w-4" />;
      case 'welcome': return <Crown className="h-4 w-4" />;
      case 'event': return <Calendar className="h-4 w-4" />;
      default: return <Layout className="h-4 w-4" />;
    }
  };

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = !searchQuery || 
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = categoryFilter === 'all' || template.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  if (loading && templates.length === 0) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Email Templates</h1>
          <p className="text-gray-600 mt-1">Create and manage your email templates</p>
        </div>
        <div className="flex gap-3">
          <div className="flex border rounded-lg">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grid')}
              className="rounded-r-none"
            >
              <Layout className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
              className="rounded-l-none"
            >
              <Code className="h-4 w-4" />
            </Button>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Template
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Template</DialogTitle>
                <DialogDescription>
                  Create a new email template for your campaigns.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Template Name</Label>
                    <Input
                      id="name"
                      value={newTemplate.name}
                      onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                      placeholder="Enter template name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={newTemplate.category} onValueChange={(value) => setNewTemplate({ ...newTemplate, category: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {TEMPLATE_CATEGORIES.map(category => (
                          <SelectItem key={category} value={category}>{category}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newTemplate.description}
                    onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                    placeholder="Optional description"
                    rows={2}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="subject">Default Subject</Label>
                    <Input
                      id="subject"
                      value={newTemplate.subject}
                      onChange={(e) => setNewTemplate({ ...newTemplate, subject: e.target.value })}
                      placeholder="Email subject line"
                    />
                  </div>
                  <div>
                    <Label htmlFor="preheader">Preheader</Label>
                    <Input
                      id="preheader"
                      value={newTemplate.preheader}
                      onChange={(e) => setNewTemplate({ ...newTemplate, preheader: e.target.value })}
                      placeholder="Preview text"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="htmlContent">HTML Content</Label>
                  <Textarea
                    id="htmlContent"
                    value={newTemplate.htmlContent}
                    onChange={(e) => setNewTemplate({ ...newTemplate, htmlContent: e.target.value })}
                    placeholder="Enter HTML content"
                    rows={8}
                    className="font-mono text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="textContent">Text Version (Optional)</Label>
                  <Textarea
                    id="textContent"
                    value={newTemplate.textContent}
                    onChange={(e) => setNewTemplate({ ...newTemplate, textContent: e.target.value })}
                    placeholder="Plain text version"
                    rows={4}
                  />
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateTemplate}>Create Template</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search templates..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* System Templates Section */}
      {page === 1 && searchQuery === '' && categoryFilter === 'all' && (
        <div>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Featured Templates</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {PREDEFINED_TEMPLATES.map((template, index) => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-shadow duration-200 cursor-pointer">
                  <CardContent className="p-4">
                    <div className="aspect-video bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg mb-3 flex items-center justify-center">
                      <Image className="h-8 w-8 text-gray-400" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-sm truncate">{template.name}</h3>
                        <Badge variant="secondary" className="text-xs">
                          <Crown className="h-3 w-3 mr-1" />
                          Pro
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-600 line-clamp-2">{template.description}</p>
                      <div className="flex items-center justify-between text-xs">
                        <Badge variant="outline" className="text-xs">
                          {template.category}
                        </Badge>
                        <span className="text-gray-500">{template.usageCount} uses</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* User Templates */}
      {filteredTemplates.length > 0 && (
        <>
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Your Templates</h2>
            <Badge variant="secondary">{filteredTemplates.length} templates</Badge>
          </div>

          <div className={viewMode === 'grid' 
            ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            : "space-y-4"
          }>
            {filteredTemplates.map((template, index) => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                {viewMode === 'grid' ? (
                  <Card className="hover:shadow-lg transition-shadow duration-200">
                    <CardContent className="p-4">
                      {/* Template Preview */}
                      <div className="aspect-video bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg mb-3 flex items-center justify-center relative">
                        <Layout className="h-8 w-8 text-gray-400" />
                        {template.isMobileOptimized && (
                          <div className="absolute top-2 right-2">
                            <Badge variant="secondary" className="text-xs">
                              <Smartphone className="h-3 w-3 mr-1" />
                              Mobile
                            </Badge>
                          </div>
                        )}
                        {template.isSystem && (
                          <div className="absolute top-2 left-2">
                            <Badge variant="secondary" className="text-xs">
                              <Crown className="h-3 w-3 mr-1" />
                              System
                            </Badge>
                          </div>
                        )}
                      </div>

                      {/* Template Info */}
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <h3 className="font-medium text-sm truncate">{template.name}</h3>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="h-3 w-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                Preview
                              </DropdownMenuItem>
                              {!template.isSystem && (
                                <DropdownMenuItem>
                                  <Edit className="h-4 w-4 mr-2" />
                                  Edit
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem 
                                onClick={() => {
                                  const newName = prompt('Enter name for cloned template:', `${template.name} Copy`);
                                  if (newName) handleCloneTemplate(template.id, newName);
                                }}
                              >
                                <Copy className="h-4 w-4 mr-2" />
                                Clone
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Download className="h-4 w-4 mr-2" />
                                Export
                              </DropdownMenuItem>
                              {!template.isSystem && (
                                <>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem 
                                    className="text-red-600"
                                    onClick={() => handleDeleteTemplate(template.id)}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>

                        {template.description && (
                          <p className="text-xs text-gray-600 line-clamp-2">{template.description}</p>
                        )}

                        <div className="flex items-center justify-between">
                          {template.category && (
                            <Badge variant="outline" className="text-xs">
                              {getCategoryIcon(template.category)}
                              <span className="ml-1">{template.category}</span>
                            </Badge>
                          )}
                          <span className="text-xs text-gray-500">
                            {template.usageCount} uses
                          </span>
                        </div>

                        {template.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {template.tags.slice(0, 2).map((tag, tagIndex) => (
                              <Badge key={tagIndex} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                            {template.tags.length > 2 && (
                              <Badge variant="secondary" className="text-xs">
                                +{template.tags.length - 2}
                              </Badge>
                            )}
                          </div>
                        )}

                        <div className="text-xs text-gray-500">
                          Last used: {template.lastUsed 
                            ? new Date(template.lastUsed).toLocaleDateString()
                            : 'Never'
                          }
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-12 bg-gradient-to-br from-gray-50 to-gray-100 rounded flex items-center justify-center">
                          <Layout className="h-4 w-4 text-gray-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-medium truncate">{template.name}</h3>
                            {template.isSystem && (
                              <Badge variant="secondary" className="text-xs">System</Badge>
                            )}
                            {template.isMobileOptimized && (
                              <Badge variant="outline" className="text-xs">Mobile</Badge>
                            )}
                          </div>
                          {template.description && (
                            <p className="text-sm text-gray-600 truncate">{template.description}</p>
                          )}
                          <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                            {template.category && <span>{template.category}</span>}
                            <span>{template.usageCount} uses</span>
                            <span>Updated {new Date(template.updatedAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-3 w-3 mr-1" />
                            Preview
                          </Button>
                          <Button variant="outline" size="sm">
                            <Copy className="h-3 w-3 mr-1" />
                            Use
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="h-3 w-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              {!template.isSystem && (
                                <DropdownMenuItem>
                                  <Edit className="h-4 w-4 mr-2" />
                                  Edit
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem>
                                <Copy className="h-4 w-4 mr-2" />
                                Clone
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Download className="h-4 w-4 mr-2" />
                                Export
                              </DropdownMenuItem>
                              {!template.isSystem && (
                                <>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem 
                                    className="text-red-600"
                                    onClick={() => handleDeleteTemplate(template.id)}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </motion.div>
            ))}
          </div>
        </>
      )}

      {/* Empty State */}
      {filteredTemplates.length === 0 && !loading && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Layout className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No templates found</h3>
            <p className="text-gray-600 text-center mb-4">
              {searchQuery || categoryFilter !== 'all'
                ? 'Try adjusting your search or filter criteria.'
                : 'Get started by creating your first email template.'
              }
            </p>
            {!searchQuery && categoryFilter === 'all' && (
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Template
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page - 1)}
            disabled={page === 1}
          >
            Previous
          </Button>
          <span className="text-sm text-gray-600">
            Page {page} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page + 1)}
            disabled={page === totalPages}
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
}
