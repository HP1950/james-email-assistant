
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import {
  Mail,
  Plus,
  Search,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Send,
  Pause,
  Play,
  Copy,
  Eye,
  BarChart,
  Calendar,
  Users,
  TrendingUp,
  MousePointer,
  UserMinus,
  AlertTriangle,
  Clock,
  CheckCircle,
  XCircle,
} from 'lucide-react';

interface Campaign {
  id: string;
  name: string;
  subject: string;
  preheader?: string;
  fromName: string;
  fromEmail: string;
  status: string;
  type: string;
  recipientCount: number;
  sentCount: number;
  deliveredCount: number;
  openCount: number;
  clickCount: number;
  unsubscribeCount: number;
  bounceCount: number;
  openRate: number;
  clickRate: number;
  unsubscribeRate: number;
  bounceRate: number;
  deliveryRate: number;
  scheduledAt?: string;
  sentAt?: string;
  createdAt: string;
  list?: {
    id: string;
    name: string;
  };
  template?: {
    id: string;
    name: string;
  };
}

export default function Campaigns() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const { toast } = useToast();

  useEffect(() => {
    fetchCampaigns();
  }, [page, searchQuery, statusFilter, typeFilter]);

  const fetchCampaigns = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '12',
        ...(searchQuery && { search: searchQuery }),
        ...(statusFilter !== 'all' && { status: statusFilter }),
        ...(typeFilter !== 'all' && { type: typeFilter }),
      });

      const response = await fetch(`/api/marketing/campaigns?${params}`);
      const data = await response.json();

      if (data.success) {
        setCampaigns(data.data.campaigns);
        setTotalPages(data.data.pagination.totalPages);
      } else {
        toast({
          title: 'Error',
          description: 'Failed to fetch campaigns',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error fetching campaigns:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch campaigns',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCampaign = async (campaignId: string) => {
    if (!confirm('Are you sure you want to delete this campaign? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await fetch(`/api/marketing/campaigns/${campaignId}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: 'Success',
          description: 'Campaign deleted successfully',
        });
        fetchCampaigns();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to delete campaign',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error deleting campaign:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete campaign',
        variant: 'destructive',
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'DRAFT': return 'bg-gray-100 text-gray-800';
      case 'SCHEDULED': return 'bg-blue-100 text-blue-800';
      case 'SENDING': return 'bg-orange-100 text-orange-800';
      case 'SENT': return 'bg-green-100 text-green-800';
      case 'PAUSED': return 'bg-yellow-100 text-yellow-800';
      case 'CANCELLED': return 'bg-red-100 text-red-800';
      case 'FAILED': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'DRAFT': return <Edit className="h-3 w-3" />;
      case 'SCHEDULED': return <Clock className="h-3 w-3" />;
      case 'SENDING': return <Send className="h-3 w-3 animate-pulse" />;
      case 'SENT': return <CheckCircle className="h-3 w-3" />;
      case 'PAUSED': return <Pause className="h-3 w-3" />;
      case 'CANCELLED': return <XCircle className="h-3 w-3" />;
      case 'FAILED': return <AlertTriangle className="h-3 w-3" />;
      default: return <Edit className="h-3 w-3" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'STANDARD': return 'bg-blue-100 text-blue-800';
      case 'AB_TEST': return 'bg-purple-100 text-purple-800';
      case 'AUTOMATION': return 'bg-green-100 text-green-800';
      case 'TRANSACTIONAL': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredCampaigns = campaigns.filter(campaign => {
    const matchesSearch = !searchQuery || 
      campaign.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      campaign.subject.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || campaign.status === statusFilter;
    const matchesType = typeFilter === 'all' || campaign.type === typeFilter;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  if (loading && campaigns.length === 0) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Email Campaigns</h1>
          <p className="text-gray-600 mt-1">Create, manage, and track your email campaigns</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Create Campaign
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search campaigns..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="DRAFT">Draft</SelectItem>
                <SelectItem value="SCHEDULED">Scheduled</SelectItem>
                <SelectItem value="SENDING">Sending</SelectItem>
                <SelectItem value="SENT">Sent</SelectItem>
                <SelectItem value="PAUSED">Paused</SelectItem>
                <SelectItem value="CANCELLED">Cancelled</SelectItem>
                <SelectItem value="FAILED">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="STANDARD">Standard</SelectItem>
                <SelectItem value="AB_TEST">A/B Test</SelectItem>
                <SelectItem value="AUTOMATION">Automation</SelectItem>
                <SelectItem value="TRANSACTIONAL">Transactional</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Campaigns Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredCampaigns.map((campaign, index) => (
          <motion.div
            key={campaign.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate">{campaign.name}</CardTitle>
                    <p className="text-sm text-gray-600 mt-1 truncate">{campaign.subject}</p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      {campaign.status === 'DRAFT' && (
                        <DropdownMenuItem>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Campaign
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem>
                        <Copy className="h-4 w-4 mr-2" />
                        Duplicate
                      </DropdownMenuItem>
                      {campaign.status === 'SENT' && (
                        <DropdownMenuItem>
                          <BarChart className="h-4 w-4 mr-2" />
                          View Analytics
                        </DropdownMenuItem>
                      )}
                      {(campaign.status === 'DRAFT' || campaign.status === 'SCHEDULED') && (
                        <DropdownMenuItem>
                          <Send className="h-4 w-4 mr-2" />
                          Send Campaign
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        className="text-red-600"
                        onClick={() => handleDeleteCampaign(campaign.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete Campaign
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Badge className={getStatusColor(campaign.status)}>
                    {getStatusIcon(campaign.status)}
                    <span className="ml-1">{campaign.status.toLowerCase()}</span>
                  </Badge>
                  <Badge className={getTypeColor(campaign.type)}>
                    {campaign.type.replace('_', ' ').toLowerCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  {/* Campaign Info */}
                  <div className="text-sm text-gray-600">
                    <p><span className="font-medium">From:</span> {campaign.fromName} &lt;{campaign.fromEmail}&gt;</p>
                    {campaign.list && (
                      <p><span className="font-medium">List:</span> {campaign.list.name}</p>
                    )}
                    {campaign.scheduledAt && (
                      <p>
                        <span className="font-medium">Scheduled:</span>{' '}
                        {new Date(campaign.scheduledAt).toLocaleDateString()}
                      </p>
                    )}
                    {campaign.sentAt && (
                      <p>
                        <span className="font-medium">Sent:</span>{' '}
                        {new Date(campaign.sentAt).toLocaleDateString()}
                      </p>
                    )}
                  </div>

                  {/* Performance Metrics (for sent campaigns) */}
                  {campaign.status === 'SENT' && campaign.recipientCount > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Recipients</span>
                        <span className="font-medium">{campaign.recipientCount.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Delivered</span>
                        <span className="font-medium">{campaign.deliveryRate.toFixed(1)}%</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <Eye className="h-3 w-3 text-blue-600 mr-1" />
                          <span className="text-gray-600">Opens</span>
                        </div>
                        <span className="font-medium text-blue-600">{campaign.openRate.toFixed(1)}%</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <MousePointer className="h-3 w-3 text-green-600 mr-1" />
                          <span className="text-gray-600">Clicks</span>
                        </div>
                        <span className="font-medium text-green-600">{campaign.clickRate.toFixed(1)}%</span>
                      </div>
                      
                      {/* Performance Bars */}
                      <div className="space-y-1 mt-3">
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>Open Rate</span>
                          <span>{campaign.openRate.toFixed(1)}%</span>
                        </div>
                        <Progress value={campaign.openRate} className="h-1" />
                        
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>Click Rate</span>
                          <span>{campaign.clickRate.toFixed(1)}%</span>
                        </div>
                        <Progress value={campaign.clickRate} className="h-1" />
                      </div>

                      {/* Warning indicators */}
                      {campaign.bounceRate > 5 && (
                        <div className="flex items-center text-xs text-orange-600">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          High bounce rate ({campaign.bounceRate.toFixed(1)}%)
                        </div>
                      )}
                      {campaign.unsubscribeRate > 2 && (
                        <div className="flex items-center text-xs text-red-600">
                          <UserMinus className="h-3 w-3 mr-1" />
                          High unsubscribe rate ({campaign.unsubscribeRate.toFixed(1)}%)
                        </div>
                      )}
                    </div>
                  )}

                  {/* Draft/Scheduled Campaign Actions */}
                  {(campaign.status === 'DRAFT' || campaign.status === 'SCHEDULED') && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Recipients</span>
                        <span className="font-medium">{campaign.recipientCount.toLocaleString()}</span>
                      </div>
                      {campaign.template && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Template</span>
                          <span className="font-medium truncate max-w-[120px]">{campaign.template.name}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex gap-2 mt-4 pt-3 border-t">
                  {campaign.status === 'DRAFT' && (
                    <>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                      <Button size="sm" className="flex-1">
                        <Send className="h-3 w-3 mr-1" />
                        Send
                      </Button>
                    </>
                  )}
                  {campaign.status === 'SENT' && (
                    <>
                      <Button variant="outline" size="sm" className="flex-1">
                        <BarChart className="h-3 w-3 mr-1" />
                        Analytics
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Copy className="h-3 w-3 mr-1" />
                        Duplicate
                      </Button>
                    </>
                  )}
                  {campaign.status === 'SCHEDULED' && (
                    <>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Pause className="h-3 w-3 mr-1" />
                        Pause
                      </Button>
                    </>
                  )}
                  {campaign.status === 'SENDING' && (
                    <Button variant="outline" size="sm" className="w-full" disabled>
                      <Send className="h-3 w-3 mr-1 animate-pulse" />
                      Sending...
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredCampaigns.length === 0 && !loading && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Mail className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No campaigns found</h3>
            <p className="text-gray-600 text-center mb-4">
              {searchQuery || statusFilter !== 'all' || typeFilter !== 'all'
                ? 'Try adjusting your search or filter criteria.'
                : 'Get started by creating your first email campaign.'
              }
            </p>
            {!searchQuery && statusFilter === 'all' && typeFilter === 'all' && (
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Campaign
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page - 1)}
            disabled={page === 1}
          >
            Previous
          </Button>
          <span className="text-sm text-gray-600">
            Page {page} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page + 1)}
            disabled={page === totalPages}
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
}
