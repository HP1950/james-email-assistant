
'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import {
  BarChart3,
  Users,
  Mail,
  Layout,
  Zap,
  Settings,
  TrendingUp,
  Target,
  FileText,
} from 'lucide-react';

import MarketingDashboard from './marketing-dashboard';
import EmailLists from './email-lists';
import Campaigns from './campaigns';
import EmailTemplates from './templates';

const MARKETING_TABS = [
  {
    id: 'overview',
    label: 'Overview',
    icon: BarChart3,
    component: MarketingDashboard,
  },
  {
    id: 'lists',
    label: 'Lists',
    icon: Users,
    component: EmailLists,
  },
  {
    id: 'campaigns',
    label: 'Campaigns',
    icon: Mail,
    component: Campaigns,
  },
  {
    id: 'templates',
    label: 'Templates',
    icon: Layout,
    component: EmailTemplates,
  },
  {
    id: 'automations',
    label: 'Automations',
    icon: Zap,
    component: () => (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Zap className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Automations</h3>
          <p className="text-gray-600">Email automation workflows coming soon!</p>
        </div>
      </div>
    ),
  },
  {
    id: 'analytics',
    label: 'Analytics',
    icon: TrendingUp,
    component: () => (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Advanced Analytics</h3>
          <p className="text-gray-600">Detailed campaign analytics coming soon!</p>
        </div>
      </div>
    ),
  },
];

export default function MarketingLayout() {
  const [activeTab, setActiveTab] = useState('overview');

  const ActiveComponent = MARKETING_TABS.find(tab => tab.id === activeTab)?.component || MarketingDashboard;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Navigation Tabs */}
          <Card className="sticky top-4 z-10 shadow-sm">
            <CardContent className="p-4">
              <TabsList className="grid w-full grid-cols-6 h-auto p-1">
                {MARKETING_TABS.map((tab) => (
                  <TabsTrigger
                    key={tab.id}
                    value={tab.id}
                    className="flex flex-col items-center gap-2 px-4 py-3 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700"
                  >
                    <tab.icon className="h-5 w-5" />
                    <span className="text-sm font-medium">{tab.label}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </CardContent>
          </Card>

          {/* Tab Content */}
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {MARKETING_TABS.map((tab) => (
              <TabsContent key={tab.id} value={tab.id} className="mt-0">
                <tab.component />
              </TabsContent>
            ))}
          </motion.div>
        </Tabs>
      </div>
    </div>
  );
}
