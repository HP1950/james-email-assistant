
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import {
  Users,
  Plus,
  Search,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Upload,
  Download,
  TrendingUp,
  Activity,
  Mail,
  UserPlus,
  Settings,
  Eye,
} from 'lucide-react';

interface EmailList {
  id: string;
  name: string;
  description?: string;
  type: string;
  subscriberCount: number;
  activeCount: number;
  engagementRate: number;
  growthRate: number;
  doubleOptIn: boolean;
  welcomeEmail: boolean;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  _count: {
    subscribers: number;
    campaigns: number;
    segments: number;
  };
}

export default function EmailLists() {
  const [lists, setLists] = useState<EmailList[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedList, setSelectedList] = useState<EmailList | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const { toast } = useToast();

  const [newList, setNewList] = useState({
    name: '',
    description: '',
    type: 'STANDARD',
    doubleOptIn: true,
    welcomeEmail: false,
    tags: [] as string[],
  });

  useEffect(() => {
    fetchLists();
  }, [page, searchQuery, typeFilter]);

  const fetchLists = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '12',
        ...(searchQuery && { search: searchQuery }),
        ...(typeFilter !== 'all' && { type: typeFilter }),
      });

      const response = await fetch(`/api/marketing/lists?${params}`);
      const data = await response.json();

      if (data.success) {
        setLists(data.data.lists);
        setTotalPages(data.data.pagination.totalPages);
      } else {
        toast({
          title: 'Error',
          description: 'Failed to fetch email lists',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error fetching lists:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch email lists',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateList = async () => {
    try {
      const response = await fetch('/api/marketing/lists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newList),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: 'Success',
          description: 'Email list created successfully',
        });
        setIsCreateDialogOpen(false);
        setNewList({
          name: '',
          description: '',
          type: 'STANDARD',
          doubleOptIn: true,
          welcomeEmail: false,
          tags: [],
        });
        fetchLists();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to create email list',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error creating list:', error);
      toast({
        title: 'Error',
        description: 'Failed to create email list',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteList = async (listId: string) => {
    if (!confirm('Are you sure you want to delete this list? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await fetch(`/api/marketing/lists/${listId}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: 'Success',
          description: 'Email list deleted successfully',
        });
        fetchLists();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to delete email list',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error deleting list:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete email list',
        variant: 'destructive',
      });
    }
  };

  const getListTypeColor = (type: string) => {
    switch (type) {
      case 'STANDARD': return 'bg-blue-100 text-blue-800';
      case 'IMPORTED': return 'bg-green-100 text-green-800';
      case 'DYNAMIC': return 'bg-purple-100 text-purple-800';
      case 'SUPPRESSION': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredLists = lists.filter(list => {
    const matchesSearch = !searchQuery || 
      list.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      list.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = typeFilter === 'all' || list.type === typeFilter;
    
    return matchesSearch && matchesType;
  });

  if (loading && lists.length === 0) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Email Lists</h1>
          <p className="text-gray-600 mt-1">Organize and manage your subscribers</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create List
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Create New Email List</DialogTitle>
              <DialogDescription>
                Create a new email list to organize your subscribers.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <Label htmlFor="name">List Name</Label>
                <Input
                  id="name"
                  value={newList.name}
                  onChange={(e) => setNewList({ ...newList, name: e.target.value })}
                  placeholder="Enter list name"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newList.description}
                  onChange={(e) => setNewList({ ...newList, description: e.target.value })}
                  placeholder="Optional description"
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="type">List Type</Label>
                <Select value={newList.type} onValueChange={(value) => setNewList({ ...newList, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="STANDARD">Standard</SelectItem>
                    <SelectItem value="IMPORTED">Imported</SelectItem>
                    <SelectItem value="DYNAMIC">Dynamic</SelectItem>
                    <SelectItem value="SUPPRESSION">Suppression</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="doubleOptIn"
                  checked={newList.doubleOptIn}
                  onChange={(e) => setNewList({ ...newList, doubleOptIn: e.target.checked })}
                  className="rounded border-gray-300"
                />
                <Label htmlFor="doubleOptIn">Require double opt-in</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="welcomeEmail"
                  checked={newList.welcomeEmail}
                  onChange={(e) => setNewList({ ...newList, welcomeEmail: e.target.checked })}
                  className="rounded border-gray-300"
                />
                <Label htmlFor="welcomeEmail">Send welcome email</Label>
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateList}>Create List</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search lists..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="STANDARD">Standard</SelectItem>
                <SelectItem value="IMPORTED">Imported</SelectItem>
                <SelectItem value="DYNAMIC">Dynamic</SelectItem>
                <SelectItem value="SUPPRESSION">Suppression</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lists Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredLists.map((list, index) => (
          <motion.div
            key={list.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate">{list.name}</CardTitle>
                    {list.description && (
                      <p className="text-sm text-gray-600 mt-1 line-clamp-2">{list.description}</p>
                    )}
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit List
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <UserPlus className="h-4 w-4 mr-2" />
                        Add Subscribers
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Upload className="h-4 w-4 mr-2" />
                        Import Subscribers
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Download className="h-4 w-4 mr-2" />
                        Export List
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        className="text-red-600"
                        onClick={() => handleDeleteList(list.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete List
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Badge className={getListTypeColor(list.type)}>
                    {list.type.toLowerCase()}
                  </Badge>
                  {list.doubleOptIn && (
                    <Badge variant="outline">Double Opt-in</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  {/* Subscriber Stats */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Users className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600">Subscribers</span>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{list.subscriberCount.toLocaleString()}</p>
                      <p className="text-xs text-gray-500">{list.activeCount.toLocaleString()} active</p>
                    </div>
                  </div>

                  {/* Engagement Rate */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Activity className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600">Engagement</span>
                    </div>
                    <p className="text-sm font-medium">{list.engagementRate.toFixed(1)}%</p>
                  </div>

                  {/* Growth Rate */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <TrendingUp className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600">Growth Rate</span>
                    </div>
                    <p className={`text-sm font-medium ${
                      list.growthRate >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {list.growthRate > 0 ? '+' : ''}{list.growthRate.toFixed(1)}%
                    </p>
                  </div>

                  {/* Campaigns Count */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600">Campaigns</span>
                    </div>
                    <p className="text-sm font-medium">{list._count.campaigns}</p>
                  </div>

                  {/* Tags */}
                  {list.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {list.tags.slice(0, 3).map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {list.tags.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{list.tags.length - 3} more
                        </Badge>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex gap-2 mt-4 pt-3 border-t">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Eye className="h-4 w-4 mr-1" />
                    View
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Settings className="h-4 w-4 mr-1" />
                    Manage
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredLists.length === 0 && !loading && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No email lists found</h3>
            <p className="text-gray-600 text-center mb-4">
              {searchQuery || typeFilter !== 'all' 
                ? 'Try adjusting your search or filter criteria.'
                : 'Get started by creating your first email list.'
              }
            </p>
            {!searchQuery && typeFilter === 'all' && (
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First List
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page - 1)}
            disabled={page === 1}
          >
            Previous
          </Button>
          <span className="text-sm text-gray-600">
            Page {page} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page + 1)}
            disabled={page === totalPages}
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
}
