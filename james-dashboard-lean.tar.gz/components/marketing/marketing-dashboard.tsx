
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
} from 'recharts';
import {
  Mail,
  Users,
  TrendingUp,
  Send,
  Eye,
  MousePointer,
  UserMinus,
  AlertTriangle,
  Plus,
  Filter,
  Download,
  Settings,
  Activity,
  Target,
  Zap,
} from 'lucide-react';

interface MarketingAnalytics {
  overview: {
    totalLists: number;
    totalSubscribers: number;
    activeSubscribers: number;
    totalCampaigns: number;
    activeCampaigns: number;
    sentCampaigns: number;
    totalTemplates: number;
    totalAutomations: number;
    activeAutomations: number;
    subscriberGrowthRate: number;
  };
  campaignPerformance: {
    averageOpenRate: number;
    averageClickRate: number;
    averageUnsubscribeRate: number;
    averageBounceRate: number;
    averageDeliveryRate: number;
    totalEmailsSent: number;
    totalEmailsDelivered: number;
    totalOpens: number;
    totalClicks: number;
    totalUnsubscribes: number;
    totalBounces: number;
    totalComplaints: number;
  };
  automationPerformance: {
    totalSubscribers: number;
    totalCompleted: number;
    totalActive: number;
    averageCompletionRate: number;
  };
  trends: {
    listGrowth: Array<{ date: string; subscribers: number }>;
    campaignPerformance: Array<{
      week: string;
      averageOpenRate: number;
      averageClickRate: number;
      averageDeliveryRate: number;
      campaignCount: number;
    }>;
  };
  topPerformers: {
    campaigns: Array<{
      id: string;
      name: string;
      subject: string;
      sentAt: string;
      recipientCount: number;
      openRate: number;
      clickRate: number;
      deliveryRate: number;
    }>;
    lists: Array<{
      id: string;
      name: string;
      subscriberCount: number;
      activeCount: number;
      engagementRate: number;
      growthRate: number;
    }>;
  };
}

const COLORS = ['#60B5FF', '#FF9149', '#FF9898', '#FF90BB', '#80D8C3', '#A19AD3'];

export default function MarketingDashboard() {
  const [analytics, setAnalytics] = useState<MarketingAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('30');

  useEffect(() => {
    fetchAnalytics();
  }, [period]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/marketing/analytics?period=${period}`);
      const data = await response.json();
      
      if (data.success) {
        setAnalytics(data.data);
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Failed to load analytics data</p>
      </div>
    );
  }

  const { overview, campaignPerformance, automationPerformance, trends, topPerformers } = analytics;

  const overviewCards = [
    {
      title: 'Total Lists',
      value: overview.totalLists,
      icon: Mail,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Total Subscribers',
      value: overview.totalSubscribers.toLocaleString(),
      subtitle: `${overview.activeSubscribers.toLocaleString()} active`,
      icon: Users,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      title: 'Total Campaigns',
      value: overview.totalCampaigns,
      subtitle: `${overview.activeCampaigns} active`,
      icon: Send,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
    },
    {
      title: 'Growth Rate',
      value: `${overview.subscriberGrowthRate > 0 ? '+' : ''}${overview.subscriberGrowthRate.toFixed(1)}%`,
      icon: TrendingUp,
      color: overview.subscriberGrowthRate >= 0 ? 'text-green-600' : 'text-red-600',
      bgColor: overview.subscriberGrowthRate >= 0 ? 'bg-green-50' : 'bg-red-50',
    },
  ];

  const performanceCards = [
    {
      title: 'Avg Open Rate',
      value: `${campaignPerformance.averageOpenRate.toFixed(1)}%`,
      icon: Eye,
      color: 'text-blue-600',
    },
    {
      title: 'Avg Click Rate',
      value: `${campaignPerformance.averageClickRate.toFixed(1)}%`,
      icon: MousePointer,
      color: 'text-green-600',
    },
    {
      title: 'Unsubscribe Rate',
      value: `${campaignPerformance.averageUnsubscribeRate.toFixed(1)}%`,
      icon: UserMinus,
      color: 'text-orange-600',
    },
    {
      title: 'Bounce Rate',
      value: `${campaignPerformance.averageBounceRate.toFixed(1)}%`,
      icon: AlertTriangle,
      color: 'text-red-600',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Email Marketing</h1>
          <p className="text-gray-600 mt-1">Manage campaigns, subscribers, and track performance</p>
        </div>
        <div className="flex gap-3">
          <select
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            className="rounded-md border border-gray-300 px-3 py-2 text-sm"
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
          </select>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button size="sm">
            <Plus className="h-4 w-4 mr-2" />
            New Campaign
          </Button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {overviewCards.map((card, index) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-shadow duration-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{card.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{card.value}</p>
                    {card.subtitle && (
                      <p className="text-sm text-gray-500 mt-1">{card.subtitle}</p>
                    )}
                  </div>
                  <div className={`rounded-full p-3 ${card.bgColor}`}>
                    <card.icon className={`h-6 w-6 ${card.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Performance Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Campaign Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {performanceCards.map((card, index) => (
              <div key={card.title} className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <card.icon className={`h-5 w-5 ${card.color} mr-2`} />
                  <span className="text-sm font-medium text-gray-600">{card.title}</span>
                </div>
                <p className="text-2xl font-bold text-gray-900">{card.value}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* List Growth Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Subscriber Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trends.listGrowth}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString()}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    labelFormatter={(value) => new Date(value).toLocaleDateString()}
                    formatter={(value) => [value, 'New Subscribers']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="subscribers" 
                    stroke="#60B5FF" 
                    strokeWidth={2}
                    dot={{ fill: '#60B5FF', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Campaign Performance Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Weekly Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={trends.campaignPerformance}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="week" 
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString()}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    labelFormatter={(value) => `Week of ${new Date(value).toLocaleDateString()}`}
                    formatter={(value, name) => [`${Number(value).toFixed(1)}%`, name]}
                  />
                  <Legend />
                  <Bar dataKey="averageOpenRate" fill="#60B5FF" name="Open Rate" />
                  <Bar dataKey="averageClickRate" fill="#FF9149" name="Click Rate" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Performers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Campaigns */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Top Performing Campaigns</CardTitle>
            <Badge variant="secondary">{topPerformers.campaigns.length} campaigns</Badge>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topPerformers.campaigns.slice(0, 5).map((campaign, index) => (
                <div key={campaign.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{campaign.name}</p>
                    <p className="text-xs text-gray-500 truncate">{campaign.subject}</p>
                    <p className="text-xs text-gray-400">
                      {campaign.recipientCount.toLocaleString()} recipients
                    </p>
                  </div>
                  <div className="text-right ml-4">
                    <p className="text-sm font-medium text-green-600">
                      {campaign.openRate.toFixed(1)}% open
                    </p>
                    <p className="text-xs text-blue-600">
                      {campaign.clickRate.toFixed(1)}% click
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Lists */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Top Performing Lists</CardTitle>
            <Badge variant="secondary">{topPerformers.lists.length} lists</Badge>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topPerformers.lists.slice(0, 5).map((list, index) => (
                <div key={list.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{list.name}</p>
                    <p className="text-xs text-gray-500">
                      {list.subscriberCount.toLocaleString()} subscribers 
                      ({list.activeCount.toLocaleString()} active)
                    </p>
                  </div>
                  <div className="text-right ml-4">
                    <p className="text-sm font-medium text-green-600">
                      {list.engagementRate.toFixed(1)}% engagement
                    </p>
                    <p className="text-xs text-blue-600">
                      {list.growthRate > 0 ? '+' : ''}{list.growthRate.toFixed(1)}% growth
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button variant="outline" className="h-16 flex flex-col items-center justify-center">
              <Plus className="h-5 w-5 mb-1" />
              <span className="text-sm">Create Campaign</span>
            </Button>
            <Button variant="outline" className="h-16 flex flex-col items-center justify-center">
              <Users className="h-5 w-5 mb-1" />
              <span className="text-sm">Manage Lists</span>
            </Button>
            <Button variant="outline" className="h-16 flex flex-col items-center justify-center">
              <Target className="h-5 w-5 mb-1" />
              <span className="text-sm">Build Automation</span>
            </Button>
            <Button variant="outline" className="h-16 flex flex-col items-center justify-center">
              <Activity className="h-5 w-5 mb-1" />
              <span className="text-sm">View Reports</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
