
'use client';

import { useEffect, useState } from 'react';
import { usePWA } from './pwa-provider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Bell, BellOff, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function PushNotificationManager() {
  const { isSupported } = usePWA();
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [showPrompt, setShowPrompt] = useState(false);
  const [subscription, setSubscription] = useState<PushSubscription | null>(null);

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }

    // Show notification prompt after a delay if not already granted or denied
    if (permission === 'default' && isSupported) {
      const timer = setTimeout(() => {
        const notificationPromptDismissed = localStorage.getItem('notification-prompt-dismissed');
        if (!notificationPromptDismissed) {
          setShowPrompt(true);
        }
      }, 10000); // Show after 10 seconds
      return () => clearTimeout(timer);
    }
  }, [permission, isSupported]);

  const requestPermission = async () => {
    if ('Notification' in window && 'serviceWorker' in navigator) {
      try {
        const permission = await Notification.requestPermission();
        setPermission(permission);
        
        if (permission === 'granted') {
          await subscribeToPush();
          setShowPrompt(false);
        }
      } catch (error) {
        console.error('Error requesting notification permission:', error);
      }
    }
  };

  const subscribeToPush = async () => {
    try {
      const registration = await navigator.serviceWorker.ready;
      
      // Create a simple VAPID key for demonstration
      // In production, you would use your own VAPID keys
      const vapidPublicKey = 'BEl62iUYgUivxIkv69yViEuiBIa40HI80jKkbNgSK_9o-LSW5hhEFdGUySmzrFYkWG0RPmfF5c0iVIhZY6mXdBs';
      
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: vapidPublicKey,
      });
      
      setSubscription(subscription);
      
      // In a real app, you would send this subscription to your server
      console.log('Push subscription created:', subscription);
      
      // Store subscription in localStorage for demo purposes
      localStorage.setItem('push-subscription', JSON.stringify(subscription));
      
    } catch (error) {
      console.error('Error subscribing to push notifications:', error);
    }
  };

  const unsubscribeFromPush = async () => {
    if (subscription) {
      try {
        await subscription.unsubscribe();
        setSubscription(null);
        localStorage.removeItem('push-subscription');
        console.log('Unsubscribed from push notifications');
      } catch (error) {
        console.error('Error unsubscribing from push notifications:', error);
      }
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('notification-prompt-dismissed', 'true');
  };

  if (!isSupported || permission === 'denied') {
    return null;
  }

  return (
    <AnimatePresence>
      {showPrompt && permission === 'default' && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-sm mx-4"
        >
          <Card className="shadow-xl border-2 border-primary/20 bg-background/95 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Bell className="h-5 w-5 text-primary" />
                  <CardTitle className="text-sm">Enable Notifications</CardTitle>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleDismiss}
                  className="h-6 w-6 p-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <CardDescription className="text-xs">
                Get notified about urgent emails and important updates
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  onClick={requestPermission}
                  className="flex-1 text-xs h-8"
                >
                  <Bell className="h-3 w-3 mr-1" />
                  Enable
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDismiss}
                  className="flex-1 text-xs h-8"
                >
                  Not Now
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
