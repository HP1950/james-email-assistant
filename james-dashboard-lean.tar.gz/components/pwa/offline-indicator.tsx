
'use client';

import { usePWA } from './pwa-provider';
import { motion, AnimatePresence } from 'framer-motion';
import { WifiOff, Wifi, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function OfflineIndicator() {
  const { isOnline, updateAvailable, reloadApp } = usePWA();

  if (isOnline && !updateAvailable) {
    return null;
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -50 }}
        className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50"
      >
        {!isOnline && (
          <div className="bg-destructive text-destructive-foreground px-4 py-2 rounded-lg shadow-lg flex items-center space-x-2 text-sm">
            <WifiOff className="h-4 w-4" />
            <span>You're offline. Some features may be limited.</span>
          </div>
        )}
        
        {updateAvailable && (
          <div className="bg-primary text-primary-foreground px-4 py-2 rounded-lg shadow-lg flex items-center space-x-2 text-sm">
            <RotateCcw className="h-4 w-4" />
            <span>Update available!</span>
            <Button
              size="sm"
              variant="secondary"
              onClick={reloadApp}
              className="h-6 px-2 text-xs ml-2"
            >
              Reload
            </Button>
          </div>
        )}
        
        {isOnline && !updateAvailable && (
          <div className="bg-success text-success-foreground px-4 py-2 rounded-lg shadow-lg flex items-center space-x-2 text-sm">
            <Wifi className="h-4 w-4" />
            <span>Back online!</span>
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
