
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  ListFilter,
  Play,
  Pause,
  Save,
  X
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface AutomationRule {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  conditionType: 'sender' | 'subject' | 'content' | 'domain';
  conditionOperator: 'contains' | 'equals' | 'startsWith' | 'endsWith';
  conditionValue: string;
  actionType: 'categorize' | 'forward' | 'autoReply' | 'delete' | 'markSpam';
  actionValue: string;
  timesTriggered: number;
  lastTriggered?: Date;
  createdAt: Date;
}

export function RulesManager() {
  const [rules, setRules] = useState<AutomationRule[]>([
    {
      id: '1',
      name: 'Urgent Support Emails',
      description: 'Forward urgent support emails to the support team',
      isActive: true,
      conditionType: 'subject',
      conditionOperator: 'contains',
      conditionValue: 'urgent',
      actionType: 'forward',
      actionValue: 'support@company.com',
      timesTriggered: 45,
      lastTriggered: new Date(Date.now() - 2 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    },
    {
      id: '2',
      name: 'Newsletter Auto-Archive',
      description: 'Automatically categorize newsletter emails',
      isActive: true,
      conditionType: 'sender',
      conditionOperator: 'contains',
      conditionValue: 'newsletter',
      actionType: 'categorize',
      actionValue: 'Newsletter',
      timesTriggered: 128,
      lastTriggered: new Date(Date.now() - 30 * 60 * 1000),
      createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000)
    },
    {
      id: '3',
      name: 'Promotional Email Filter',
      description: 'Mark promotional emails from unknown senders as spam',
      isActive: false,
      conditionType: 'content',
      conditionOperator: 'contains',
      conditionValue: 'limited time offer',
      actionType: 'markSpam',
      actionValue: '',
      timesTriggered: 23,
      lastTriggered: new Date(Date.now() - 4 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
    }
  ]);

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<AutomationRule | null>(null);
  const [newRule, setNewRule] = useState<Partial<AutomationRule>>({
    name: '',
    description: '',
    conditionType: 'sender',
    conditionOperator: 'contains',
    conditionValue: '',
    actionType: 'categorize',
    actionValue: '',
    isActive: true
  });

  const handleCreateRule = () => {
    if (!newRule.name || !newRule.conditionValue) return;

    const rule: AutomationRule = {
      id: Date.now().toString(),
      name: newRule.name!,
      description: newRule.description || '',
      isActive: newRule.isActive ?? true,
      conditionType: newRule.conditionType!,
      conditionOperator: newRule.conditionOperator!,
      conditionValue: newRule.conditionValue!,
      actionType: newRule.actionType!,
      actionValue: newRule.actionValue || '',
      timesTriggered: 0,
      createdAt: new Date()
    };

    setRules(prev => [...prev, rule]);
    setNewRule({
      name: '',
      description: '',
      conditionType: 'sender',
      conditionOperator: 'contains',
      conditionValue: '',
      actionType: 'categorize',
      actionValue: '',
      isActive: true
    });
    setIsCreateModalOpen(false);
  };

  const handleToggleRule = (ruleId: string) => {
    setRules(prev => prev.map(rule => 
      rule.id === ruleId ? { ...rule, isActive: !rule.isActive } : rule
    ));
  };

  const handleDeleteRule = (ruleId: string) => {
    setRules(prev => prev.filter(rule => rule.id !== ruleId));
  };

  const getActionDescription = (actionType: string, actionValue: string) => {
    switch (actionType) {
      case 'categorize':
        return `Categorize as "${actionValue}"`;
      case 'forward':
        return `Forward to ${actionValue}`;
      case 'autoReply':
        return 'Send auto-reply';
      case 'delete':
        return 'Delete email';
      case 'markSpam':
        return 'Mark as spam';
      default:
        return actionType;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">
            {rules.length} Custom Rules
          </h2>
          <p className="text-sm text-muted-foreground">
            Manage automated email processing rules and conditions
          </p>
        </div>
        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create New Rule
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Automation Rule</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Information */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Rule Name</Label>
                  <Input
                    placeholder="Enter rule name"
                    value={newRule.name || ''}
                    onChange={(e) => setNewRule(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Description (Optional)</Label>
                  <Input
                    placeholder="Describe what this rule does"
                    value={newRule.description || ''}
                    onChange={(e) => setNewRule(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
              </div>

              {/* Condition */}
              <div className="space-y-4">
                <h4 className="font-medium">IF (Condition)</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Email Field</Label>
                    <Select
                      value={newRule.conditionType}
                      onValueChange={(value: 'sender' | 'subject' | 'content' | 'domain') =>
                        setNewRule(prev => ({ ...prev, conditionType: value }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sender">Sender</SelectItem>
                        <SelectItem value="subject">Subject</SelectItem>
                        <SelectItem value="content">Content</SelectItem>
                        <SelectItem value="domain">Domain</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Operator</Label>
                    <Select
                      value={newRule.conditionOperator}
                      onValueChange={(value: 'contains' | 'equals' | 'startsWith' | 'endsWith') =>
                        setNewRule(prev => ({ ...prev, conditionOperator: value }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contains">Contains</SelectItem>
                        <SelectItem value="equals">Equals</SelectItem>
                        <SelectItem value="startsWith">Starts With</SelectItem>
                        <SelectItem value="endsWith">Ends With</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Value</Label>
                    <Input
                      placeholder="Enter value"
                      value={newRule.conditionValue || ''}
                      onChange={(e) => setNewRule(prev => ({ ...prev, conditionValue: e.target.value }))}
                    />
                  </div>
                </div>
              </div>

              {/* Action */}
              <div className="space-y-4">
                <h4 className="font-medium">THEN (Action)</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Action</Label>
                    <Select
                      value={newRule.actionType}
                      onValueChange={(value: 'categorize' | 'forward' | 'autoReply' | 'delete' | 'markSpam') =>
                        setNewRule(prev => ({ ...prev, actionType: value }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="categorize">Categorize</SelectItem>
                        <SelectItem value="forward">Forward</SelectItem>
                        <SelectItem value="autoReply">Auto Reply</SelectItem>
                        <SelectItem value="delete">Delete</SelectItem>
                        <SelectItem value="markSpam">Mark as Spam</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {(newRule.actionType === 'categorize' || newRule.actionType === 'forward') && (
                    <div className="space-y-2">
                      <Label>
                        {newRule.actionType === 'categorize' ? 'Category' : 'Email Address'}
                      </Label>
                      <Input
                        placeholder={
                          newRule.actionType === 'categorize' 
                            ? 'Enter category name'
                            : 'Enter email address'
                        }
                        value={newRule.actionValue || ''}
                        onChange={(e) => setNewRule(prev => ({ ...prev, actionValue: e.target.value }))}
                      />
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between pt-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={newRule.isActive ?? true}
                    onCheckedChange={(checked) => 
                      setNewRule(prev => ({ ...prev, isActive: checked }))
                    }
                  />
                  <Label>Enable rule immediately</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsCreateModalOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleCreateRule}>
                    <Save className="h-4 w-4 mr-2" />
                    Create Rule
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Rules List */}
      <div className="space-y-4">
        {rules.map((rule) => (
          <Card key={rule.id} className="bg-white border border-border hover:shadow-md transition-shadow">
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <CardTitle className="text-lg">{rule.name}</CardTitle>
                    <Switch
                      checked={rule.isActive}
                      onCheckedChange={() => handleToggleRule(rule.id)}
                    />
                    <Badge variant={rule.isActive ? "default" : "secondary"}>
                      {rule.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  {rule.description && (
                    <p className="text-sm text-muted-foreground">{rule.description}</p>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <Edit3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteRule(rule.id)}
                    className="text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-foreground">Condition</h4>
                  <div className="bg-muted/30 border border-border rounded-lg p-3">
                    <p className="text-sm">
                      <span className="font-medium">IF</span> {rule.conditionType}{' '}
                      <span className="font-medium">{rule.conditionOperator}</span>{' '}
                      "<span className="font-medium">{rule.conditionValue}</span>"
                    </p>
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-foreground">Action</h4>
                  <div className="bg-muted/30 border border-border rounded-lg p-3">
                    <p className="text-sm">
                      <span className="font-medium">THEN</span>{' '}
                      {getActionDescription(rule.actionType, rule.actionValue)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border text-sm text-muted-foreground">
                <div className="flex items-center space-x-4">
                  <span>Triggered {rule.timesTriggered} times</span>
                  {rule.lastTriggered && (
                    <span>
                      Last: {formatDistanceToNow(rule.lastTriggered, { addSuffix: true })}
                    </span>
                  )}
                </div>
                <span>
                  Created {formatDistanceToNow(rule.createdAt, { addSuffix: true })}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {rules.length === 0 && (
        <Card className="bg-white border border-border">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ListFilter className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No rules created yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Create your first automation rule to start filtering and organizing emails automatically.
            </p>
            <Button onClick={() => setIsCreateModalOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Rule
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
