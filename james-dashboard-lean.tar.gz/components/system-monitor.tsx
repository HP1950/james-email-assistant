
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

interface SystemStatus {
  status: string;
  gmailAccounts: { [key: string]: boolean };
  domains: { [key: string]: boolean };
  loadStats: {
    domains: Array<{
      id: string;
      domain: string;
      currentLoad: number;
      maxCapacity: number;
      isActive: boolean;
    }>;
    totalUsers: number;
    totalEmails: number;
  };
  totalUsers: number;
  totalEmailsToday: number;
}

export function SystemMonitor() {
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  const fetchSystemStatus = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/trial-signup');
      if (response.ok) {
        const data = await response.json();
        setSystemStatus(data);
        setLastUpdate(new Date());
      }
    } catch (error) {
      console.error('Failed to fetch system status:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSystemStatus();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchSystemStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status: boolean) => {
    if (status) {
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    }
    return <XCircle className="w-4 h-4 text-red-500" />;
  };

  const getLoadColor = (current: number, max: number) => {
    const percentage = (current / max) * 100;
    if (percentage < 60) return 'bg-green-500';
    if (percentage < 85) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  if (!systemStatus) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-2" />
          <p>Loading system status...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">System Monitor</h2>
          <p className="text-muted-foreground">
            Domain load balancing and system health
          </p>
        </div>
        <div className="flex items-center space-x-4">
          {lastUpdate && (
            <p className="text-sm text-muted-foreground">
              Last updated: {lastUpdate.toLocaleTimeString()}
            </p>
          )}
          <Button onClick={fetchSystemStatus} disabled={loading} size="sm">
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold">{systemStatus.totalUsers}</div>
            <p className="text-xs text-muted-foreground">Total Users</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold">{systemStatus.totalEmailsToday}</div>
            <p className="text-xs text-muted-foreground">Emails Today</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold">
              {systemStatus.loadStats.domains.filter(d => d.isActive).length}
            </div>
            <p className="text-xs text-muted-foreground">Active Domains</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              {systemStatus.status === 'operational' ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-yellow-500" />
              )}
              <div className="text-lg font-semibold">
                {systemStatus.status === 'operational' ? 'Operational' : 'Issues'}
              </div>
            </div>
            <p className="text-xs text-muted-foreground">System Status</p>
          </CardContent>
        </Card>
      </div>

      {/* Domain Load Balancing */}
      <Card>
        <CardHeader>
          <CardTitle>Domain Load Balancing</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {systemStatus.loadStats.domains.map((domain) => {
              const loadPercentage = (domain.currentLoad / domain.maxCapacity) * 100;
              return (
                <div key={domain.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{domain.domain}</span>
                      <Badge variant={domain.isActive ? 'default' : 'secondary'}>
                        {domain.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {domain.currentLoad}/{domain.maxCapacity} emails
                    </div>
                  </div>
                  <Progress 
                    value={loadPercentage} 
                    className="h-2"
                    style={{ 
                      backgroundColor: loadPercentage > 85 ? '#fee2e2' : loadPercentage > 60 ? '#fef3c7' : '#f0fdf4' 
                    }}
                  />
                  <div className="text-xs text-muted-foreground">
                    {loadPercentage.toFixed(1)}% capacity used
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Gmail Accounts Status */}
      <Card>
        <CardHeader>
          <CardTitle>Gmail Accounts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(systemStatus.gmailAccounts).map(([email, status]) => (
              <div key={email} className="flex items-center justify-between p-3 border rounded-lg">
                <span className="font-medium">{email}</span>
                <div className="flex items-center space-x-2">
                  {getStatusIcon(status)}
                  <Badge variant={status ? 'default' : 'destructive'}>
                    {status ? 'Connected' : 'Failed'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Domain Connections */}
      <Card>
        <CardHeader>
          <CardTitle>Domain Connections</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(systemStatus.domains).map(([domain, status]) => (
              <div key={domain} className="flex items-center justify-between p-3 border rounded-lg">
                <span className="font-medium">{domain}</span>
                <div className="flex items-center space-x-2">
                  {getStatusIcon(status)}
                  <Badge variant={status ? 'default' : 'destructive'}>
                    {status ? 'Connected' : 'Failed'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Alerts */}
      {systemStatus.loadStats.domains.some(d => (d.currentLoad / d.maxCapacity) > 0.85) && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5 text-yellow-600" />
              <span>Capacity Warnings</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {systemStatus.loadStats.domains
                .filter(d => (d.currentLoad / d.maxCapacity) > 0.85)
                .map(domain => (
                  <div key={domain.id} className="text-sm">
                    <strong>{domain.domain}</strong> is at{' '}
                    {((domain.currentLoad / domain.maxCapacity) * 100).toFixed(1)}% capacity
                  </div>
                ))
              }
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
