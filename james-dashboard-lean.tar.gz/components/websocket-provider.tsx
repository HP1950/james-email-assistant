
'use client';

import React, { createContext, useContext, useEffect, ReactNode } from 'react';
import { useWebSocket } from '@/hooks/use-websocket';
import { useRealtimeEmails } from '@/hooks/use-realtime-emails';
import { useRealtimeNotifications } from '@/hooks/use-realtime-notifications';
import { useRealtimeCollaboration } from '@/hooks/use-realtime-collaboration';
import { WebSocketState } from '@/lib/websocket-types';

interface WebSocketContextValue {
  websocket: ReturnType<typeof useWebSocket>;
  emails: ReturnType<typeof useRealtimeEmails>;
  notifications: ReturnType<typeof useRealtimeNotifications>;
  collaboration: ReturnType<typeof useRealtimeCollaboration>;
}

const WebSocketContext = createContext<WebSocketContextValue | null>(null);

interface WebSocketProviderProps {
  children: ReactNode;
  autoConnect?: boolean;
}

export function WebSocketProvider({ children, autoConnect = true }: WebSocketProviderProps) {
  const websocket = useWebSocket({
    autoConnect,
    onConnect: () => {
      console.log('WebSocket Provider: Connected');
    },
    onDisconnect: (reason) => {
      console.log('WebSocket Provider: Disconnected:', reason);
    },
    onError: (error) => {
      console.error('WebSocket Provider: Error:', error);
    },
    onReconnect: (attemptNumber) => {
      console.log('WebSocket Provider: Reconnected after', attemptNumber, 'attempts');
    },
  });

  const emails = useRealtimeEmails();
  const notifications = useRealtimeNotifications();
  const collaboration = useRealtimeCollaboration();

  // Log connection status changes
  useEffect(() => {
    if (websocket.state.connected) {
      console.log('WebSocket Provider: Successfully connected and authenticated');
    }
  }, [websocket.state.connected, websocket.state.authenticated]);

  const contextValue: WebSocketContextValue = {
    websocket,
    emails,
    notifications,
    collaboration,
  };

  return (
    <WebSocketContext.Provider value={contextValue}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocketContext(): WebSocketContextValue {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error('useWebSocketContext must be used within a WebSocketProvider');
  }
  return context;
}

// Individual context hooks for specific features
export function useWebSocketEmails() {
  const { emails } = useWebSocketContext();
  return emails;
}

export function useWebSocketNotifications() {
  const { notifications } = useWebSocketContext();
  return notifications;
}

export function useWebSocketCollaboration() {
  const { collaboration } = useWebSocketContext();
  return collaboration;
}

export function useWebSocketConnection() {
  const { websocket } = useWebSocketContext();
  return websocket;
}
