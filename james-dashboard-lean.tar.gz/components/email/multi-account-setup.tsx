

'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Plus, 
  Trash2, 
  TestTube, 
  CheckCircle, 
  XCircle, 
  Mail,
  Settings,
  Info
} from 'lucide-react';
import { GmailAccount, EmailConfig } from '@/lib/email-config';

export function MultiAccountSetup() {
  const [config, setConfig] = useState<EmailConfig>({
    mainReceivingEmail: 'james@schulenberg.tech',
    gmailAccounts: [],
    imapConfig: {
      host: 'imap.hostinger.com',
      port: 993,
      secure: true,
      auth: {
        user: 'james@schulenberg.tech',
        pass: ''
      }
    }
  });
  
  const [testResults, setTestResults] = useState<{[key: string]: boolean}>({});
  const [isTesting, setIsTesting] = useState(false);

  // Add new Gmail account
  const addGmailAccount = () => {
    const newAccount: GmailAccount = {
      id: `gmail${config.gmailAccounts.length + 1}`,
      email: '',
      displayName: '',
      smtp: {
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
          user: '',
          pass: ''
        }
      },
      isActive: true
    };

    setConfig(prev => ({
      ...prev,
      gmailAccounts: [...prev.gmailAccounts, newAccount]
    }));
  };

  // Remove Gmail account
  const removeGmailAccount = (id: string) => {
    setConfig(prev => ({
      ...prev,
      gmailAccounts: prev.gmailAccounts.filter(account => account.id !== id)
    }));
  };

  // Update Gmail account
  const updateGmailAccount = (id: string, updates: Partial<GmailAccount>) => {
    setConfig(prev => ({
      ...prev,
      gmailAccounts: prev.gmailAccounts.map(account => 
        account.id === id ? { ...account, ...updates } : account
      )
    }));
  };

  // Test connections
  const testConnections = async () => {
    setIsTesting(true);
    // Simulate API call to test connections
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const results: {[key: string]: boolean} = {};
    config.gmailAccounts.forEach(account => {
      // Simulate random success/failure for demo
      results[account.email] = Math.random() > 0.3;
    });
    
    setTestResults(results);
    setIsTesting(false);
  };

  // Save configuration
  const saveConfiguration = () => {
    localStorage.setItem('jamesEmailConfig', JSON.stringify(config));
    alert('Configuration saved successfully!');
  };

  // Load saved configuration
  useEffect(() => {
    const saved = localStorage.getItem('jamesEmailConfig');
    if (saved) {
      try {
        setConfig(JSON.parse(saved));
      } catch (error) {
        console.error('Error loading saved config:', error);
      }
    }
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Mail className="h-5 w-5" />
            <span>Multi-Account Gmail Setup</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Configure forwarding from your Gmail accounts to <strong>{config.mainReceivingEmail}</strong>, 
              then add those accounts below so James can reply using the original Gmail addresses.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Main Receiving Email */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Main Receiving Email (James)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="mainEmail">Email Address</Label>
            <Input
              id="mainEmail"
              value={config.mainReceivingEmail}
              onChange={(e) => setConfig(prev => ({ ...prev, mainReceivingEmail: e.target.value }))}
              placeholder="james@schulenberg.tech"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="imapHost">IMAP Host</Label>
              <Input
                id="imapHost"
                value={config.imapConfig.host}
                onChange={(e) => setConfig(prev => ({
                  ...prev,
                  imapConfig: { ...prev.imapConfig, host: e.target.value }
                }))}
                placeholder="imap.hostinger.com"
              />
            </div>
            <div>
              <Label htmlFor="imapPort">IMAP Port</Label>
              <Input
                id="imapPort"
                type="number"
                value={config.imapConfig.port}
                onChange={(e) => setConfig(prev => ({
                  ...prev,
                  imapConfig: { ...prev.imapConfig, port: parseInt(e.target.value) }
                }))}
                placeholder="993"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="imapPassword">IMAP Password</Label>
            <Input
              id="imapPassword"
              type="password"
              value={config.imapConfig.auth.pass}
              onChange={(e) => setConfig(prev => ({
                ...prev,
                imapConfig: { ...prev.imapConfig, auth: { ...prev.imapConfig.auth, pass: e.target.value } }
              }))}
              placeholder="Your james@schulenberg.tech password"
            />
          </div>
        </CardContent>
      </Card>

      {/* Gmail Accounts */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Gmail Accounts ({config.gmailAccounts.length}/10)</CardTitle>
          <Button onClick={addGmailAccount} size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Gmail Account
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {config.gmailAccounts.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No Gmail accounts configured. Click "Add Gmail Account" to get started.
            </div>
          ) : (
            config.gmailAccounts.map((account, index) => (
              <Card key={account.id} className="border-l-4 border-l-blue-500">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium">
                      Gmail Account #{index + 1}
                      {testResults[account.email] !== undefined && (
                        testResults[account.email] ? (
                          <CheckCircle className="inline ml-2 h-4 w-4 text-green-500" />
                        ) : (
                          <XCircle className="inline ml-2 h-4 w-4 text-red-500" />
                        )
                      )}
                    </CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeGmailAccount(account.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor={`email-${account.id}`}>Gmail Address</Label>
                      <Input
                        id={`email-${account.id}`}
                        value={account.email}
                        onChange={(e) => updateGmailAccount(account.id, { 
                          email: e.target.value,
                          smtp: { ...account.smtp, auth: { ...account.smtp.auth, user: e.target.value } }
                        })}
                        placeholder="your-email@gmail.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`name-${account.id}`}>Display Name</Label>
                      <Input
                        id={`name-${account.id}`}
                        value={account.displayName}
                        onChange={(e) => updateGmailAccount(account.id, { displayName: e.target.value })}
                        placeholder="My Main Account"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor={`password-${account.id}`}>Gmail App Password</Label>
                    <Input
                      id={`password-${account.id}`}
                      type="password"
                      value={account.smtp.auth.pass}
                      onChange={(e) => updateGmailAccount(account.id, {
                        smtp: { ...account.smtp, auth: { ...account.smtp.auth, pass: e.target.value } }
                      })}
                      placeholder="Gmail App Password (not regular password)"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Generate this in Gmail Settings → Security → App Passwords
                    </p>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Badge variant={account.isActive ? "default" : "secondary"}>
                      {account.isActive ? "Active" : "Inactive"}
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateGmailAccount(account.id, { isActive: !account.isActive })}
                    >
                      {account.isActive ? "Deactivate" : "Activate"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </CardContent>
      </Card>

      {/* Actions */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <Button 
              onClick={testConnections} 
              disabled={isTesting || config.gmailAccounts.length === 0}
              variant="outline"
            >
              <TestTube className="h-4 w-4 mr-2" />
              {isTesting ? 'Testing...' : 'Test Connections'}
            </Button>
            
            <Button 
              onClick={saveConfiguration}
              disabled={config.gmailAccounts.length === 0}
            >
              <Settings className="h-4 w-4 mr-2" />
              Save Configuration
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-blue-800">Setup Instructions</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-blue-700 space-y-2">
          <p><strong>Step 1:</strong> For each Gmail account, go to Settings → Forwarding and add <code>{config.mainReceivingEmail}</code></p>
          <p><strong>Step 2:</strong> Enable 2-Factor Authentication on each Gmail account</p>
          <p><strong>Step 3:</strong> Generate App Passwords for each Gmail account (Settings → Security → App Passwords)</p>
          <p><strong>Step 4:</strong> Add the Gmail accounts above with their App Passwords</p>
          <p><strong>Step 5:</strong> Test connections and save configuration</p>
        </CardContent>
      </Card>
    </div>
  );
}
