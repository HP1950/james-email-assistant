

'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mail, ArrowRight, Sparkles } from 'lucide-react';
import Link from 'next/link';

export function SimpleEntryPage() {
  const [isEntering, setIsEntering] = useState(false);

  const handleEnterDashboard = () => {
    setIsEntering(true);
    // Small delay for visual feedback, then navigate
    setTimeout(() => {
      window.location.href = '/dashboard';
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-8 text-center">
        {/* Logo & Title */}
        <div className="space-y-4">
          <div className="mx-auto bg-gradient-to-br from-blue-600 to-indigo-600 text-white p-4 rounded-2xl w-fit shadow-lg">
            <Mail className="h-12 w-12" />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-4xl font-bold text-gray-900">
              Gmail Assistant
            </h1>
            <p className="text-lg text-gray-600">
              AI-Powered Email Management
            </p>
          </div>
        </div>

        {/* Entry Card */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardContent className="p-8 space-y-6">
            <div className="space-y-3">
              <div className="flex items-center justify-center space-x-2 text-blue-600">
                <Sparkles className="h-5 w-5" />
                <span className="text-sm font-medium">Ready to Transform Your Email</span>
                <Sparkles className="h-5 w-5" />
              </div>
              
              <p className="text-gray-600">
                Experience intelligent email automation, smart categorization, 
                and powerful workflow management.
              </p>
            </div>

            <Button 
              onClick={handleEnterDashboard}
              disabled={isEntering}
              size="lg" 
              className="w-full text-lg py-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transition-all duration-300"
            >
              {isEntering ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent mr-3"></div>
                  Loading Dashboard...
                </>
              ) : (
                <>
                  Enter Dashboard
                  <ArrowRight className="ml-3 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </Button>

            <div className="pt-4 border-t border-gray-200">
              <p className="text-xs text-gray-500">
                No sign-up required • Instant access • Full features available
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Quick Features Preview */}
        <div className="grid grid-cols-3 gap-4 pt-4">
          {[
            { icon: '🤖', label: 'AI Intelligence' },
            { icon: '⚡', label: 'Automation' },
            { icon: '📊', label: 'Analytics' }
          ].map((feature, index) => (
            <div key={index} className="text-center">
              <div className="text-2xl mb-1">{feature.icon}</div>
              <div className="text-xs text-gray-600">{feature.label}</div>
            </div>
          ))}
        </div>

        {/* Future Auth Hook - Hidden for now */}
        <div className="hidden">
          <p className="text-xs text-gray-400">
            <Link href="/auth/signin" className="hover:text-gray-600 transition-colors">
              Sign in for personalized experience
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
