

'use client';

import { useState, useEffect } from 'react';
import { SessionProvider } from 'next-auth/react';
import { PWAProvider } from '@/components/pwa/pwa-provider';
import { ThemeProvider } from '@/components/theme-provider';

interface ProvidersProps {
  children: React.ReactNode;
}

export function Providers({ children }: ProvidersProps) {
  const [hasMounted, setHasMounted] = useState(false);

  useEffect(() => {
    setHasMounted(true);
  }, []);

  if (!hasMounted) {
    return null;
  }

  return (
    <SessionProvider>
      <PWAProvider>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
        </ThemeProvider>
      </PWAProvider>
    </SessionProvider>
  );
}
