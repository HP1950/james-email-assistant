
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Pause, 
  Plus, 
  Settings, 
  Mail, 
  Clock, 
  GitBranch,
  Zap,
  Target,
  Users,
  BarChart3,
  Eye,
  Copy,
  Trash2
} from 'lucide-react';
import { 
  AdvancedTriggerType, 
  AutomationStepType, 
  ParticipantStatus,
  AdvancedAutomationData,
  AutomationStepData,
  AutomationParticipantData 
} from '@/lib/types';
import { motion } from 'framer-motion';

interface AdvancedAutomationBuilderProps {
  userId: string;
}

// Visual workflow builder component
interface WorkflowNode {
  id: string;
  type: AutomationStepType;
  name: string;
  config: any;
  position: { x: number; y: number };
  connections: string[];
}

export default function AdvancedAutomationBuilder({ userId }: AdvancedAutomationBuilderProps) {
  const [automations, setAutomations] = useState<AdvancedAutomationData[]>([]);
  const [selectedAutomation, setSelectedAutomation] = useState<AdvancedAutomationData | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [workflowNodes, setWorkflowNodes] = useState<WorkflowNode[]>([]);
  const [loading, setLoading] = useState(true);

  // Form state for creating automations
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    triggerType: AdvancedTriggerType.LIST_JOIN,
    triggerConditions: '{}',
    allowMultipleEntries: false,
    entryLimit: undefined as number | undefined,
    goalType: '',
    goalValue: undefined as number | undefined
  });

  useEffect(() => {
    fetchAutomations();
  }, []);

  const fetchAutomations = async () => {
    try {
      const response = await fetch('/api/advanced/automations');
      const data = await response.json();
      
      if (data.success) {
        setAutomations(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch automations:', error);
    } finally {
      setLoading(false);
    }
  };

  const createAutomation = async () => {
    try {
      const response = await fetch('/api/advanced/automations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          triggerConditions: JSON.parse(formData.triggerConditions),
          workflowData: { nodes: workflowNodes }
        })
      });

      const data = await response.json();
      
      if (data.success) {
        setAutomations([data.data, ...automations]);
        setIsCreateDialogOpen(false);
        resetForm();
      }
    } catch (error) {
      console.error('Failed to create automation:', error);
    }
  };

  const toggleAutomation = async (automationId: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/advanced/automations/${automationId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !isActive })
      });

      if (response.ok) {
        setAutomations(automations.map(automation => 
          automation.id === automationId ? { ...automation, isActive: !isActive } : automation
        ));
      }
    } catch (error) {
      console.error('Failed to toggle automation:', error);
    }
  };

  const addWorkflowNode = useCallback((type: AutomationStepType) => {
    const newNode: WorkflowNode = {
      id: `node-${Date.now()}`,
      type,
      name: getDefaultNodeName(type),
      config: getDefaultNodeConfig(type),
      position: { x: 100 + workflowNodes.length * 200, y: 100 },
      connections: []
    };
    
    setWorkflowNodes(prev => [...prev, newNode]);
  }, [workflowNodes.length]);

  const updateWorkflowNode = useCallback((nodeId: string, updates: Partial<WorkflowNode>) => {
    setWorkflowNodes(prev => prev.map(node => 
      node.id === nodeId ? { ...node, ...updates } : node
    ));
  }, []);

  const deleteWorkflowNode = useCallback((nodeId: string) => {
    setWorkflowNodes(prev => prev.filter(node => node.id !== nodeId));
  }, []);

  const connectNodes = useCallback((fromNodeId: string, toNodeId: string) => {
    setWorkflowNodes(prev => prev.map(node => 
      node.id === fromNodeId 
        ? { ...node, connections: [...node.connections, toNodeId] }
        : node
    ));
  }, []);

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      category: '',
      triggerType: AdvancedTriggerType.LIST_JOIN,
      triggerConditions: '{}',
      allowMultipleEntries: false,
      entryLimit: undefined,
      goalType: '',
      goalValue: undefined
    });
    setWorkflowNodes([]);
  };

  const getDefaultNodeName = (type: AutomationStepType): string => {
    switch (type) {
      case AutomationStepType.EMAIL: return 'Send Email';
      case AutomationStepType.WAIT: return 'Wait';
      case AutomationStepType.CONDITION: return 'If/Then';
      case AutomationStepType.ACTION: return 'Action';
      case AutomationStepType.WEBHOOK: return 'Webhook';
      case AutomationStepType.UPDATE_FIELD: return 'Update Field';
      case AutomationStepType.ADD_TAG: return 'Add Tag';
      case AutomationStepType.REMOVE_TAG: return 'Remove Tag';
      case AutomationStepType.MOVE_TO_LIST: return 'Move to List';
      case AutomationStepType.GOAL_CHECK: return 'Goal Check';
      default: return 'Step';
    }
  };

  const getDefaultNodeConfig = (type: AutomationStepType): any => {
    switch (type) {
      case AutomationStepType.EMAIL:
        return { templateId: '', subject: '', delayHours: 0 };
      case AutomationStepType.WAIT:
        return { waitDays: 1, waitHours: 0 };
      case AutomationStepType.CONDITION:
        return { condition: '', trueAction: '', falseAction: '' };
      default:
        return {};
    }
  };

  const getNodeIcon = (type: AutomationStepType) => {
    switch (type) {
      case AutomationStepType.EMAIL: return <Mail className="w-4 h-4" />;
      case AutomationStepType.WAIT: return <Clock className="w-4 h-4" />;
      case AutomationStepType.CONDITION: return <GitBranch className="w-4 h-4" />;
      case AutomationStepType.ACTION: return <Zap className="w-4 h-4" />;
      case AutomationStepType.GOAL_CHECK: return <Target className="w-4 h-4" />;
      default: return <Settings className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: ParticipantStatus) => {
    switch (status) {
      case ParticipantStatus.ACTIVE: return 'bg-blue-500';
      case ParticipantStatus.COMPLETED: return 'bg-green-500';
      case ParticipantStatus.PAUSED: return 'bg-yellow-500';
      case ParticipantStatus.EXITED: return 'bg-gray-500';
      case ParticipantStatus.FAILED: return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading automations...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Advanced Automations</h2>
          <p className="text-muted-foreground">Create sophisticated email marketing workflows with conditional logic</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Automation
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Advanced Automation</DialogTitle>
              <DialogDescription>
                Build sophisticated email workflows with triggers, conditions, and actions
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="setup" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="setup">Setup</TabsTrigger>
                <TabsTrigger value="workflow">Workflow</TabsTrigger>
                <TabsTrigger value="goals">Goals</TabsTrigger>
              </TabsList>
              
              <TabsContent value="setup" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Automation Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., Welcome Series"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="welcome">Welcome Series</SelectItem>
                        <SelectItem value="nurture">Lead Nurture</SelectItem>
                        <SelectItem value="reengagement">Re-engagement</SelectItem>
                        <SelectItem value="educational">Educational</SelectItem>
                        <SelectItem value="promotional">Promotional</SelectItem>
                        <SelectItem value="retention">Customer Retention</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe the purpose and flow of this automation"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="triggerType">Trigger Type</Label>
                    <Select
                      value={formData.triggerType}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, triggerType: value as AdvancedTriggerType }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={AdvancedTriggerType.LIST_JOIN}>List Join</SelectItem>
                        <SelectItem value={AdvancedTriggerType.EMAIL_OPEN}>Email Open</SelectItem>
                        <SelectItem value={AdvancedTriggerType.LINK_CLICK}>Link Click</SelectItem>
                        <SelectItem value={AdvancedTriggerType.EMAIL_REPLY}>Email Reply</SelectItem>
                        <SelectItem value={AdvancedTriggerType.DATE_BASED}>Date Based</SelectItem>
                        <SelectItem value={AdvancedTriggerType.BEHAVIOR_SCORE}>Behavior Score</SelectItem>
                        <SelectItem value={AdvancedTriggerType.CUSTOM_EVENT}>Custom Event</SelectItem>
                        <SelectItem value={AdvancedTriggerType.TAG_ADDED}>Tag Added</SelectItem>
                        <SelectItem value={AdvancedTriggerType.FIELD_UPDATED}>Field Updated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="entryLimit">Entry Limit (optional)</Label>
                    <Input
                      id="entryLimit"
                      type="number"
                      value={formData.entryLimit || ''}
                      onChange={(e) => setFormData(prev => ({ 
                        ...prev, 
                        entryLimit: e.target.value ? parseInt(e.target.value) : undefined 
                      }))}
                      placeholder="No limit"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="triggerConditions">Trigger Conditions (JSON)</Label>
                  <Textarea
                    id="triggerConditions"
                    value={formData.triggerConditions}
                    onChange={(e) => setFormData(prev => ({ ...prev, triggerConditions: e.target.value }))}
                    placeholder='{"listId": "...", "minScore": 50}'
                    className="font-mono text-sm"
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="allowMultipleEntries"
                    checked={formData.allowMultipleEntries}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, allowMultipleEntries: checked }))}
                  />
                  <Label htmlFor="allowMultipleEntries">Allow multiple entries per subscriber</Label>
                </div>
              </TabsContent>
              
              <TabsContent value="workflow" className="space-y-4">
                {/* Workflow Builder */}
                <div className="border rounded-lg p-4 min-h-[400px] bg-gray-50">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium">Workflow Builder</h3>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addWorkflowNode(AutomationStepType.EMAIL)}
                      >
                        <Mail className="w-4 h-4 mr-1" />
                        Email
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addWorkflowNode(AutomationStepType.WAIT)}
                      >
                        <Clock className="w-4 h-4 mr-1" />
                        Wait
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addWorkflowNode(AutomationStepType.CONDITION)}
                      >
                        <GitBranch className="w-4 h-4 mr-1" />
                        Condition
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addWorkflowNode(AutomationStepType.ACTION)}
                      >
                        <Zap className="w-4 h-4 mr-1" />
                        Action
                      </Button>
                    </div>
                  </div>

                  {/* Visual Workflow Canvas */}
                  <div className="relative">
                    {workflowNodes.length === 0 ? (
                      <div className="text-center py-12 text-muted-foreground">
                        <GitBranch className="w-12 h-12 mx-auto mb-4" />
                        <p>Add workflow steps to build your automation</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {workflowNodes.map((node, index) => (
                          <motion.div
                            key={node.id}
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="relative"
                          >
                            <Card className="w-64">
                              <CardHeader className="pb-2">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-2">
                                    <div className="p-1 bg-blue-100 rounded">
                                      {getNodeIcon(node.type)}
                                    </div>
                                    <span className="font-medium text-sm">{node.name}</span>
                                  </div>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => deleteWorkflowNode(node.id)}
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </Button>
                                </div>
                              </CardHeader>
                              <CardContent className="pt-0">
                                <div className="text-xs text-muted-foreground">
                                  {node.type.replace('_', ' ')}
                                </div>
                                {/* Node configuration would go here */}
                              </CardContent>
                            </Card>
                            {index < workflowNodes.length - 1 && (
                              <div className="flex justify-center my-2">
                                <div className="w-px h-6 bg-gray-300" />
                              </div>
                            )}
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="goals" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="goalType">Goal Type</Label>
                    <Select
                      value={formData.goalType}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, goalType: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select goal type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="email_open">Email Open</SelectItem>
                        <SelectItem value="link_click">Link Click</SelectItem>
                        <SelectItem value="purchase">Purchase</SelectItem>
                        <SelectItem value="form_submit">Form Submit</SelectItem>
                        <SelectItem value="engagement_score">Engagement Score</SelectItem>
                        <SelectItem value="custom_event">Custom Event</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="goalValue">Goal Value</Label>
                    <Input
                      id="goalValue"
                      type="number"
                      value={formData.goalValue || ''}
                      onChange={(e) => setFormData(prev => ({ 
                        ...prev, 
                        goalValue: e.target.value ? parseFloat(e.target.value) : undefined 
                      }))}
                      placeholder="e.g., 100 for score, 1 for count"
                    />
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium mb-2">Goal Tracking</h4>
                  <p className="text-sm text-muted-foreground">
                    Goals help measure the success of your automation. Subscribers who achieve the goal
                    will be marked as converted, and you can track conversion rates and performance.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={createAutomation} disabled={!formData.name || workflowNodes.length === 0}>
                Create Automation
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Automations Grid */}
      <div className="grid gap-4">
        {automations.map((automation) => (
          <motion.div
            key={automation.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="group"
          >
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{automation.name}</CardTitle>
                    <CardDescription>{automation.description}</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={automation.isActive ? 'default' : 'secondary'}>
                      {automation.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                    {automation.category && (
                      <Badge variant="outline">{automation.category}</Badge>
                    )}
                    {automation.isAbTest && (
                      <Badge className="bg-purple-100 text-purple-800">A/B Test</Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{automation.totalEntries}</div>
                    <div className="text-sm text-muted-foreground">Total Entries</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{automation.activeParticipants}</div>
                    <div className="text-sm text-muted-foreground">Active</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">{automation.completedParticipants}</div>
                    <div className="text-sm text-muted-foreground">Completed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{(automation.conversionRate * 100).toFixed(1)}%</div>
                    <div className="text-sm text-muted-foreground">Conversion</div>
                  </div>
                </div>

                {/* Trigger Info */}
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Zap className="w-4 h-4" />
                      <span>{automation.triggerType.replace('_', ' ')}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="w-4 h-4" />
                      <span>{automation.steps?.length || 0} steps</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div>Version {automation.version}</div>
                    {automation.lastEditedBy && (
                      <div>Edited by {automation.lastEditedBy}</div>
                    )}
                  </div>
                </div>

                {/* Conversion Progress */}
                {automation.conversionRate > 0 && (
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Conversion Progress</span>
                      <span>{(automation.conversionRate * 100).toFixed(1)}%</span>
                    </div>
                    <Progress value={automation.conversionRate * 100} className="h-2" />
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={automation.isActive}
                      onCheckedChange={() => toggleAutomation(automation.id, automation.isActive)}
                    />
                    <span className="text-sm">
                      {automation.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedAutomation(automation)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View Details
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setIsBuilderOpen(true)}
                    >
                      <Settings className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      <Copy className="w-4 h-4 mr-1" />
                      Clone
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {automations.length === 0 && !loading && (
        <Card className="text-center py-12">
          <CardContent>
            <GitBranch className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium mb-2">No automations created</h3>
            <p className="text-muted-foreground mb-4">
              Create your first advanced automation to build sophisticated email workflows
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Automation
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Automation Details Dialog */}
      {selectedAutomation && (
        <Dialog open={!!selectedAutomation} onOpenChange={() => setSelectedAutomation(null)}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedAutomation.name}</DialogTitle>
              <DialogDescription>{selectedAutomation.description}</DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="participants">Participants</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
                <TabsTrigger value="workflow">Workflow</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-blue-600">{selectedAutomation.totalEntries}</div>
                      <div className="text-sm text-muted-foreground">Total Entries</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-green-600">{selectedAutomation.activeParticipants}</div>
                      <div className="text-sm text-muted-foreground">Active Participants</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-purple-600">{selectedAutomation.completedParticipants}</div>
                      <div className="text-sm text-muted-foreground">Completed</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold">{(selectedAutomation.conversionRate * 100).toFixed(1)}%</div>
                      <div className="text-sm text-muted-foreground">Conversion Rate</div>
                    </CardContent>
                  </Card>
                </div>

                {/* Goal Information */}
                {selectedAutomation.goalType && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center">
                        <Target className="w-5 h-5 mr-2" />
                        Goal Tracking
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Goal Type</Label>
                          <div className="p-2 bg-muted rounded mt-1">{selectedAutomation.goalType}</div>
                        </div>
                        <div>
                          <Label>Target Value</Label>
                          <div className="p-2 bg-muted rounded mt-1">{selectedAutomation.goalValue}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              
              <TabsContent value="participants" className="space-y-4">
                {selectedAutomation.participants?.slice(0, 10).map((participant) => (
                  <Card key={participant.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(participant.status)}`} />
                          <div>
                            <div className="font-medium">Subscriber #{participant.subscriberId.slice(-8)}</div>
                            <div className="text-sm text-muted-foreground">
                              Entered {new Date(participant.entryDate).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium">{participant.status}</div>
                          <div className="text-sm text-muted-foreground">
                            {participant.stepsCompleted.length} steps completed
                          </div>
                        </div>
                      </div>
                      {participant.goalAchieved && (
                        <div className="mt-2 p-2 bg-green-50 rounded text-sm text-green-700">
                          ✅ Goal achieved {participant.goalAchievedAt && `on ${new Date(participant.goalAchievedAt).toLocaleDateString()}`}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              
              <TabsContent value="performance" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Performance Analytics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">
                      <BarChart3 className="w-12 h-12 mx-auto mb-2" />
                      Detailed performance analytics will be displayed here
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="workflow" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Workflow Steps</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedAutomation.steps?.map((step, index) => (
                      <div key={step.id} className="flex items-center space-x-3 py-3 border-b last:border-b-0">
                        <div className="flex-shrink-0">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            {getNodeIcon(step.stepType)}
                          </div>
                        </div>
                        <div className="flex-1">
                          <div className="font-medium">{step.name}</div>
                          <div className="text-sm text-muted-foreground">{step.stepType.replace('_', ' ')}</div>
                        </div>
                        <div className="text-right text-sm text-muted-foreground">
                          <div>{step.totalExecutions} executions</div>
                          <div>{step.successfulExecutions} successful</div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
