
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, Plus, Shield, Download, Upload, Search, Filter, Eye, Trash2, CheckCircle, XCircle } from 'lucide-react';
import { 
  SuppressionScope, 
  SuppressionReason, 
  SuppressionSource,
  GlobalSuppressionListData,
  SuppressionEntryData 
} from '@/lib/types';
import { motion } from 'framer-motion';

interface SuppressionManagerProps {
  userId: string;
}

export default function SuppressionManager({ userId }: SuppressionManagerProps) {
  const [suppressionLists, setSuppressionLists] = useState<GlobalSuppressionListData[]>([]);
  const [selectedList, setSelectedList] = useState<GlobalSuppressionListData | null>(null);
  const [suppressions, setSuppressions] = useState<SuppressionEntryData[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isCheckDialogOpen, setIsCheckDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [emailCheckResults, setEmailCheckResults] = useState<{allowed: string[], suppressed: any[]} | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    scope: SuppressionScope.USER,
    autoAddBounces: true,
    autoAddComplaints: true,
    autoAddUnsubscribes: true,
    appliedToAllLists: false,
    specificLists: [] as string[]
  });

  // Email check state
  const [emailsToCheck, setEmailsToCheck] = useState('');

  useEffect(() => {
    fetchSuppressionLists();
  }, []);

  useEffect(() => {
    if (selectedList) {
      fetchSuppressions(selectedList.id);
    }
  }, [selectedList]);

  const fetchSuppressionLists = async () => {
    try {
      const response = await fetch('/api/advanced/suppressions');
      const data = await response.json();
      
      if (data.success) {
        setSuppressionLists(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch suppression lists:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSuppressions = async (listId: string, page = 1) => {
    try {
      const response = await fetch(`/api/advanced/suppressions/${listId}?page=${page}&limit=50`);
      const data = await response.json();
      
      if (data.success) {
        setSuppressions(data.data.suppressions);
      }
    } catch (error) {
      console.error('Failed to fetch suppressions:', error);
    }
  };

  const createSuppressionList = async () => {
    try {
      const response = await fetch('/api/advanced/suppressions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();
      
      if (data.success) {
        setSuppressionLists([data.data, ...suppressionLists]);
        setIsCreateDialogOpen(false);
        resetForm();
      }
    } catch (error) {
      console.error('Failed to create suppression list:', error);
    }
  };

  const checkEmails = async () => {
    try {
      const emails = emailsToCheck.split('\n').map(email => email.trim()).filter(email => email);
      
      const response = await fetch('/api/advanced/suppressions/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emails })
      });

      const data = await response.json();
      
      if (data.success) {
        setEmailCheckResults(data.data);
      }
    } catch (error) {
      console.error('Failed to check emails:', error);
    }
  };

  const exportSuppressions = async (listId: string) => {
    try {
      const response = await fetch(`/api/advanced/suppressions/${listId}/export`, {
        method: 'GET'
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `suppressions-${listId}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Failed to export suppressions:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      scope: SuppressionScope.USER,
      autoAddBounces: true,
      autoAddComplaints: true,
      autoAddUnsubscribes: true,
      appliedToAllLists: false,
      specificLists: []
    });
  };

  const getReasonColor = (reason: SuppressionReason) => {
    switch (reason) {
      case SuppressionReason.HARD_BOUNCE:
        return 'bg-red-100 text-red-800';
      case SuppressionReason.SOFT_BOUNCE:
        return 'bg-yellow-100 text-yellow-800';
      case SuppressionReason.COMPLAINT:
        return 'bg-orange-100 text-orange-800';
      case SuppressionReason.UNSUBSCRIBE:
        return 'bg-blue-100 text-blue-800';
      case SuppressionReason.MANUAL:
        return 'bg-gray-100 text-gray-800';
      case SuppressionReason.GDPR_REQUEST:
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getScopeColor = (scope: SuppressionScope) => {
    switch (scope) {
      case SuppressionScope.GLOBAL:
        return 'bg-red-100 text-red-800';
      case SuppressionScope.ORGANIZATION:
        return 'bg-blue-100 text-blue-800';
      case SuppressionScope.USER:
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading suppression lists...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Global Suppression Manager</h2>
          <p className="text-muted-foreground">Manage email suppressions and maintain list hygiene across all campaigns</p>
        </div>
        <div className="flex space-x-2">
          <Dialog open={isCheckDialogOpen} onOpenChange={setIsCheckDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Search className="w-4 h-4 mr-2" />
                Check Emails
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Check Email Suppressions</DialogTitle>
                <DialogDescription>
                  Check multiple emails against all suppression lists
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="emails">Email Addresses (one per line)</Label>
                  <Textarea
                    id="emails"
                    value={emailsToCheck}
                    onChange={(e) => setEmailsToCheck(e.target.value)}
                    placeholder="email1@example.com&#10;email2@example.com&#10;email3@example.com"
                    rows={8}
                  />
                </div>
                
                <Button onClick={checkEmails} disabled={!emailsToCheck.trim()}>
                  <Search className="w-4 h-4 mr-2" />
                  Check Emails
                </Button>

                {emailCheckResults && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium flex items-center mb-2">
                        <CheckCircle className="w-4 h-4 mr-1 text-green-600" />
                        Allowed Emails ({emailCheckResults.allowed.length})
                      </h4>
                      <div className="max-h-32 overflow-y-auto space-y-1">
                        {emailCheckResults.allowed.map((email, index) => (
                          <div key={index} className="text-sm p-2 bg-green-50 rounded">
                            {email}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium flex items-center mb-2">
                        <XCircle className="w-4 h-4 mr-1 text-red-600" />
                        Suppressed Emails ({emailCheckResults.suppressed.length})
                      </h4>
                      <div className="max-h-32 overflow-y-auto space-y-1">
                        {emailCheckResults.suppressed.map((suppression, index) => (
                          <div key={index} className="text-sm p-2 bg-red-50 rounded">
                            <div className="font-medium">{suppression.email}</div>
                            <div className="text-muted-foreground">
                              Reason: {suppression.reason} • List: {suppression.suppressionList}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create List
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Suppression List</DialogTitle>
                <DialogDescription>
                  Create a new suppression list to manage blocked email addresses
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">List Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., Hard Bounces"
                    />
                  </div>
                  <div>
                    <Label htmlFor="scope">Scope</Label>
                    <Select
                      value={formData.scope}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, scope: value as SuppressionScope }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={SuppressionScope.USER}>User</SelectItem>
                        <SelectItem value={SuppressionScope.ORGANIZATION}>Organization</SelectItem>
                        <SelectItem value={SuppressionScope.GLOBAL}>Global</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of this suppression list"
                    rows={3}
                  />
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Auto-Management Settings</Label>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm">Auto-add Hard Bounces</div>
                      <div className="text-xs text-muted-foreground">Automatically add emails that hard bounce</div>
                    </div>
                    <Switch
                      checked={formData.autoAddBounces}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, autoAddBounces: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm">Auto-add Complaints</div>
                      <div className="text-xs text-muted-foreground">Automatically add emails that file spam complaints</div>
                    </div>
                    <Switch
                      checked={formData.autoAddComplaints}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, autoAddComplaints: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm">Auto-add Unsubscribes</div>
                      <div className="text-xs text-muted-foreground">Automatically add emails that unsubscribe</div>
                    </div>
                    <Switch
                      checked={formData.autoAddUnsubscribes}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, autoAddUnsubscribes: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm">Apply to All Lists</div>
                      <div className="text-xs text-muted-foreground">Apply suppressions across all email lists</div>
                    </div>
                    <Switch
                      checked={formData.appliedToAllLists}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, appliedToAllLists: checked }))}
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 mt-6">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={createSuppressionList} disabled={!formData.name}>
                  Create List
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Suppression Lists */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Suppression Lists
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {suppressionLists.map((list) => (
                <motion.div
                  key={list.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                    selectedList?.id === list.id ? 'bg-blue-50 border-blue-200' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedList(list)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm">{list.name}</h4>
                    <Badge className={getScopeColor(list.scope)}>
                      {list.scope}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground mb-2">
                    {list.description}
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span>{list.suppressionCount} entries</span>
                    <span>{list.emailsBlocked} blocked</span>
                  </div>
                </motion.div>
              ))}

              {suppressionLists.length === 0 && (
                <div className="text-center py-6 text-muted-foreground">
                  <Shield className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">No suppression lists</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Suppression Entries */}
        <div className="lg:col-span-2">
          {selectedList ? (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{selectedList.name}</CardTitle>
                    <CardDescription>{selectedList.description}</CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => exportSuppressions(selectedList.id)}
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Export
                    </Button>
                    <Button size="sm" variant="outline">
                      <Upload className="w-4 h-4 mr-1" />
                      Import
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                {/* List Settings Overview */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <div className="text-2xl font-bold">{selectedList.suppressionCount}</div>
                    <div className="text-sm text-muted-foreground">Total Entries</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <div className="text-2xl font-bold">{selectedList.emailsBlocked}</div>
                    <div className="text-sm text-muted-foreground">Emails Blocked</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <div className="text-2xl font-bold">
                      {selectedList.autoAddBounces ? '✓' : '✗'}
                    </div>
                    <div className="text-sm text-muted-foreground">Auto Bounces</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <div className="text-2xl font-bold">
                      {selectedList.appliedToAllLists ? '✓' : '✗'}
                    </div>
                    <div className="text-sm text-muted-foreground">All Lists</div>
                  </div>
                </div>

                {/* Suppression Entries */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Suppressed Emails</h4>
                    <div className="flex items-center space-x-2">
                      <Input
                        placeholder="Search emails..."
                        className="w-64"
                      />
                      <Button size="sm" variant="outline">
                        <Filter className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="border rounded-lg">
                    <div className="grid grid-cols-12 gap-4 p-3 bg-gray-50 font-medium text-sm border-b">
                      <div className="col-span-4">Email</div>
                      <div className="col-span-2">Reason</div>
                      <div className="col-span-2">Source</div>
                      <div className="col-span-2">Date</div>
                      <div className="col-span-2">Actions</div>
                    </div>
                    
                    <div className="max-h-96 overflow-y-auto">
                      {suppressions.map((suppression) => (
                        <div
                          key={suppression.id}
                          className="grid grid-cols-12 gap-4 p-3 border-b last:border-b-0 hover:bg-gray-50"
                        >
                          <div className="col-span-4 font-mono text-sm">
                            {suppression.email}
                          </div>
                          <div className="col-span-2">
                            <Badge className={getReasonColor(suppression.reason)}>
                              {suppression.reason.replace('_', ' ')}
                            </Badge>
                          </div>
                          <div className="col-span-2 text-sm text-muted-foreground">
                            {suppression.sourceType.replace('_', ' ')}
                          </div>
                          <div className="col-span-2 text-sm text-muted-foreground">
                            {new Date(suppression.createdAt).toLocaleDateString()}
                          </div>
                          <div className="col-span-2">
                            <div className="flex space-x-1">
                              <Button size="sm" variant="ghost">
                                <Eye className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="ghost">
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {suppressions.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        <AlertTriangle className="w-8 h-8 mx-auto mb-2" />
                        <p>No suppressed emails in this list</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">Select a Suppression List</h3>
                <p className="text-muted-foreground">
                  Choose a suppression list from the left to view and manage suppressed emails
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {suppressionLists.length === 0 && !loading && (
        <Card className="text-center py-12">
          <CardContent>
            <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium mb-2">No suppression lists</h3>
            <p className="text-muted-foreground mb-4">
              Create your first suppression list to manage email blocks and maintain list hygiene
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Suppression List
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

