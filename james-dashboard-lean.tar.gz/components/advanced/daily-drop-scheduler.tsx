
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Plus, 
  Clock, 
  Send, 
  Pause, 
  Play, 
  Calendar,
  Users,
  Mail,
  Settings,
  BarChart3,
  TrendingUp,
  Eye
} from 'lucide-react';
import { 
  DropScheduleType, 
  BatchPriority, 
  BatchStatus,
  DailyDropSchedulerData,
  DropBatchData 
} from '@/lib/types';
import { motion } from 'framer-motion';

interface DailyDropSchedulerProps {
  userId: string;
}

interface TimeSlot {
  hour: number;
  minute: number;
  timezone: string;
  maxEmails: number;
}

export default function DailyDropScheduler({ userId }: DailyDropSchedulerProps) {
  const [schedulers, setSchedulers] = useState<DailyDropSchedulerData[]>([]);
  const [selectedScheduler, setSelectedScheduler] = useState<DailyDropSchedulerData | null>(null);
  const [schedulerStatus, setSchedulerStatus] = useState<any>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isScheduleDialogOpen, setIsScheduleDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  // Form state for creating schedulers
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    scheduleType: DropScheduleType.DAILY,
    maxDailyEmails: 10000,
    maxHourlyEmails: 1000,
    batchSize: 100,
    batchDelay: 60,
    optimizeForTimezone: true,
    optimizeForEngagement: true,
    timeSlots: [
      { hour: 9, minute: 0, timezone: 'UTC', maxEmails: 2500 },
      { hour: 13, minute: 0, timezone: 'UTC', maxEmails: 2500 },
      { hour: 17, minute: 0, timezone: 'UTC', maxEmails: 2500 }
    ] as TimeSlot[]
  });

  // Campaign scheduling state
  const [scheduleFormData, setScheduleFormData] = useState({
    campaignId: '',
    priority: BatchPriority.NORMAL,
    startDate: '',
    recipients: [] as any[]
  });

  useEffect(() => {
    fetchSchedulers();
  }, []);

  useEffect(() => {
    if (selectedScheduler) {
      fetchSchedulerStatus(selectedScheduler.id);
      // Poll status every 30 seconds
      const interval = setInterval(() => {
        fetchSchedulerStatus(selectedScheduler.id);
      }, 30000);
      return () => clearInterval(interval);
    }
  }, [selectedScheduler]);

  const fetchSchedulers = async () => {
    try {
      const response = await fetch('/api/advanced/daily-drop');
      const data = await response.json();
      
      if (data.success) {
        setSchedulers(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch schedulers:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSchedulerStatus = async (schedulerId: string) => {
    try {
      const response = await fetch(`/api/advanced/daily-drop/${schedulerId}/status`);
      const data = await response.json();
      
      if (data.success) {
        setSchedulerStatus(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch scheduler status:', error);
    }
  };

  const createScheduler = async () => {
    try {
      const response = await fetch('/api/advanced/daily-drop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();
      
      if (data.success) {
        setSchedulers([data.data, ...schedulers]);
        setIsCreateDialogOpen(false);
        resetForm();
      }
    } catch (error) {
      console.error('Failed to create scheduler:', error);
    }
  };

  const scheduleEmails = async () => {
    if (!selectedScheduler) return;
    
    try {
      const response = await fetch(`/api/advanced/daily-drop/${selectedScheduler.id}/schedule`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(scheduleFormData)
      });

      const data = await response.json();
      
      if (data.success) {
        setIsScheduleDialogOpen(false);
        // Refresh scheduler status
        fetchSchedulerStatus(selectedScheduler.id);
      }
    } catch (error) {
      console.error('Failed to schedule emails:', error);
    }
  };

  const toggleScheduler = async (schedulerId: string, isActive: boolean) => {
    try {
      const endpoint = isActive ? 'pause' : 'resume';
      const response = await fetch(`/api/advanced/daily-drop/${schedulerId}/${endpoint}`, {
        method: 'POST'
      });

      if (response.ok) {
        setSchedulers(schedulers.map(scheduler => 
          scheduler.id === schedulerId ? { ...scheduler, isActive: !isActive } : scheduler
        ));
      }
    } catch (error) {
      console.error('Failed to toggle scheduler:', error);
    }
  };

  const addTimeSlot = () => {
    setFormData(prev => ({
      ...prev,
      timeSlots: [
        ...prev.timeSlots,
        { hour: 12, minute: 0, timezone: 'UTC', maxEmails: 1000 }
      ]
    }));
  };

  const updateTimeSlot = (index: number, updates: Partial<TimeSlot>) => {
    setFormData(prev => ({
      ...prev,
      timeSlots: prev.timeSlots.map((slot, i) => 
        i === index ? { ...slot, ...updates } : slot
      )
    }));
  };

  const removeTimeSlot = (index: number) => {
    setFormData(prev => ({
      ...prev,
      timeSlots: prev.timeSlots.filter((_, i) => i !== index)
    }));
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      scheduleType: DropScheduleType.DAILY,
      maxDailyEmails: 10000,
      maxHourlyEmails: 1000,
      batchSize: 100,
      batchDelay: 60,
      optimizeForTimezone: true,
      optimizeForEngagement: true,
      timeSlots: [
        { hour: 9, minute: 0, timezone: 'UTC', maxEmails: 2500 },
        { hour: 13, minute: 0, timezone: 'UTC', maxEmails: 2500 },
        { hour: 17, minute: 0, timezone: 'UTC', maxEmails: 2500 }
      ]
    });
  };

  const getBatchStatusColor = (status: BatchStatus) => {
    switch (status) {
      case BatchStatus.COMPLETED:
        return 'bg-green-500';
      case BatchStatus.PROCESSING:
        return 'bg-blue-500';
      case BatchStatus.FAILED:
        return 'bg-red-500';
      case BatchStatus.PENDING:
        return 'bg-yellow-500';
      case BatchStatus.PAUSED:
        return 'bg-gray-500';
      default:
        return 'bg-gray-500';
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading daily drop schedulers...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Daily Drop Scheduler</h2>
          <p className="text-muted-foreground">Advanced batch email delivery with time optimization and throttling</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Scheduler
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Daily Drop Scheduler</DialogTitle>
              <DialogDescription>
                Set up advanced email delivery scheduling with time optimization and throttling
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="basic">Basic Settings</TabsTrigger>
                <TabsTrigger value="schedule">Time Slots</TabsTrigger>
                <TabsTrigger value="limits">Limits & Throttling</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Scheduler Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., Morning Newsletter Drop"
                    />
                  </div>
                  <div>
                    <Label htmlFor="scheduleType">Schedule Type</Label>
                    <Select
                      value={formData.scheduleType}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, scheduleType: value as DropScheduleType }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={DropScheduleType.IMMEDIATE}>Immediate</SelectItem>
                        <SelectItem value={DropScheduleType.DAILY}>Daily</SelectItem>
                        <SelectItem value={DropScheduleType.WEEKLY}>Weekly</SelectItem>
                        <SelectItem value={DropScheduleType.MONTHLY}>Monthly</SelectItem>
                        <SelectItem value={DropScheduleType.CUSTOM}>Custom</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe the purpose and schedule for this email drop"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="optimizeForTimezone"
                      checked={formData.optimizeForTimezone}
                      onChange={(e) => setFormData(prev => ({ ...prev, optimizeForTimezone: e.target.checked }))}
                    />
                    <Label htmlFor="optimizeForTimezone">Optimize for recipient timezones</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="optimizeForEngagement"
                      checked={formData.optimizeForEngagement}
                      onChange={(e) => setFormData(prev => ({ ...prev, optimizeForEngagement: e.target.checked }))}
                    />
                    <Label htmlFor="optimizeForEngagement">Optimize for engagement patterns</Label>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="schedule" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium">Delivery Time Slots</h4>
                  <Button size="sm" onClick={addTimeSlot}>
                    <Plus className="w-4 h-4 mr-1" />
                    Add Slot
                  </Button>
                </div>

                <div className="space-y-3">
                  {formData.timeSlots.map((slot, index) => (
                    <Card key={index} className="p-4">
                      <div className="grid grid-cols-5 gap-4 items-end">
                        <div>
                          <Label>Hour</Label>
                          <Select
                            value={slot.hour.toString()}
                            onValueChange={(value) => updateTimeSlot(index, { hour: parseInt(value) })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({ length: 24 }, (_, i) => (
                                <SelectItem key={i} value={i.toString()}>
                                  {i.toString().padStart(2, '0')}:00
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Timezone</Label>
                          <Select
                            value={slot.timezone}
                            onValueChange={(value) => updateTimeSlot(index, { timezone: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="UTC">UTC</SelectItem>
                              <SelectItem value="America/New_York">Eastern</SelectItem>
                              <SelectItem value="America/Chicago">Central</SelectItem>
                              <SelectItem value="America/Denver">Mountain</SelectItem>
                              <SelectItem value="America/Los_Angeles">Pacific</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Max Emails</Label>
                          <Input
                            type="number"
                            value={slot.maxEmails}
                            onChange={(e) => updateTimeSlot(index, { maxEmails: parseInt(e.target.value) })}
                          />
                        </div>
                        <div className="col-span-2 flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => removeTimeSlot(index)}
                            disabled={formData.timeSlots.length <= 1}
                          >
                            Remove
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="limits" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="maxDailyEmails">Max Daily Emails</Label>
                    <Input
                      id="maxDailyEmails"
                      type="number"
                      value={formData.maxDailyEmails}
                      onChange={(e) => setFormData(prev => ({ ...prev, maxDailyEmails: parseInt(e.target.value) }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="maxHourlyEmails">Max Hourly Emails</Label>
                    <Input
                      id="maxHourlyEmails"
                      type="number"
                      value={formData.maxHourlyEmails}
                      onChange={(e) => setFormData(prev => ({ ...prev, maxHourlyEmails: parseInt(e.target.value) }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="batchSize">Batch Size</Label>
                    <Input
                      id="batchSize"
                      type="number"
                      value={formData.batchSize}
                      onChange={(e) => setFormData(prev => ({ ...prev, batchSize: parseInt(e.target.value) }))}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Number of emails to send in each batch
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="batchDelay">Batch Delay (seconds)</Label>
                    <Input
                      id="batchDelay"
                      type="number"
                      value={formData.batchDelay}
                      onChange={(e) => setFormData(prev => ({ ...prev, batchDelay: parseInt(e.target.value) }))}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Delay between batches for throttling
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium mb-2">Throttling Overview</h4>
                  <div className="text-sm text-muted-foreground">
                    <p>• Daily limit: {formData.maxDailyEmails.toLocaleString()} emails</p>
                    <p>• Hourly limit: {formData.maxHourlyEmails.toLocaleString()} emails</p>
                    <p>• Batch size: {formData.batchSize} emails per batch</p>
                    <p>• Batch delay: {formData.batchDelay} seconds between batches</p>
                    <p>• Estimated hourly throughput: ~{Math.floor((3600 / formData.batchDelay) * formData.batchSize).toLocaleString()} emails</p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={createScheduler} disabled={!formData.name || formData.timeSlots.length === 0}>
                Create Scheduler
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Schedulers List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                Schedulers
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {schedulers.map((scheduler) => (
                <motion.div
                  key={scheduler.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                    selectedScheduler?.id === scheduler.id ? 'bg-blue-50 border-blue-200' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedScheduler(scheduler)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm">{scheduler.name}</h4>
                    <Badge variant={scheduler.isActive ? 'default' : 'secondary'}>
                      {scheduler.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground mb-2">
                    {scheduler.description}
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-muted-foreground">Sent:</span>
                      <span className="ml-1 font-medium">{scheduler.totalEmailsSent.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Queued:</span>
                      <span className="ml-1 font-medium">{scheduler.totalEmailsQueued.toLocaleString()}</span>
                    </div>
                  </div>
                </motion.div>
              ))}

              {schedulers.length === 0 && (
                <div className="text-center py-6 text-muted-foreground">
                  <Clock className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">No schedulers created</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Scheduler Details */}
        <div className="lg:col-span-2">
          {selectedScheduler ? (
            <div className="space-y-6">
              {/* Status Overview */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{selectedScheduler.name}</CardTitle>
                      <CardDescription>{selectedScheduler.description}</CardDescription>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant={selectedScheduler.isActive ? 'outline' : 'default'}
                        onClick={() => toggleScheduler(selectedScheduler.id, selectedScheduler.isActive)}
                      >
                        {selectedScheduler.isActive ? (
                          <>
                            <Pause className="w-4 h-4 mr-1" />
                            Pause
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-1" />
                            Resume
                          </>
                        )}
                      </Button>
                      <Dialog open={isScheduleDialogOpen} onOpenChange={setIsScheduleDialogOpen}>
                        <DialogTrigger asChild>
                          <Button size="sm">
                            <Send className="w-4 h-4 mr-1" />
                            Schedule Emails
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Schedule Email Delivery</DialogTitle>
                            <DialogDescription>
                              Schedule emails to be sent through this drop scheduler
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="space-y-4">
                            <div>
                              <Label htmlFor="campaignId">Campaign</Label>
                              <Select
                                value={scheduleFormData.campaignId}
                                onValueChange={(value) => setScheduleFormData(prev => ({ ...prev, campaignId: value }))}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Select campaign" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="camp1">Newsletter #1</SelectItem>
                                  <SelectItem value="camp2">Product Launch</SelectItem>
                                  <SelectItem value="camp3">Weekly Update</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="priority">Priority</Label>
                                <Select
                                  value={scheduleFormData.priority}
                                  onValueChange={(value) => setScheduleFormData(prev => ({ ...prev, priority: value as BatchPriority }))}
                                >
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value={BatchPriority.LOW}>Low</SelectItem>
                                    <SelectItem value={BatchPriority.NORMAL}>Normal</SelectItem>
                                    <SelectItem value={BatchPriority.HIGH}>High</SelectItem>
                                    <SelectItem value={BatchPriority.URGENT}>Urgent</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <Label htmlFor="startDate">Start Date</Label>
                                <Input
                                  id="startDate"
                                  type="datetime-local"
                                  value={scheduleFormData.startDate}
                                  onChange={(e) => setScheduleFormData(prev => ({ ...prev, startDate: e.target.value }))}
                                />
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex justify-end space-x-2 mt-6">
                            <Button variant="outline" onClick={() => setIsScheduleDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button onClick={scheduleEmails} disabled={!scheduleFormData.campaignId}>
                              Schedule
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  {schedulerStatus && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-gray-50 rounded">
                        <div className="text-2xl font-bold text-blue-600">{schedulerStatus.dailyEmailsSent}</div>
                        <div className="text-sm text-muted-foreground">Daily Sent</div>
                        <Progress 
                          value={(schedulerStatus.dailyEmailsSent / selectedScheduler.maxDailyEmails) * 100} 
                          className="mt-2 h-1"
                        />
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded">
                        <div className="text-2xl font-bold text-green-600">{schedulerStatus.hourlyEmailsSent}</div>
                        <div className="text-sm text-muted-foreground">Hourly Sent</div>
                        <Progress 
                          value={(schedulerStatus.hourlyEmailsSent / selectedScheduler.maxHourlyEmails) * 100} 
                          className="mt-2 h-1"
                        />
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded">
                        <div className="text-2xl font-bold text-yellow-600">{schedulerStatus.pendingBatches}</div>
                        <div className="text-sm text-muted-foreground">Pending</div>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded">
                        <div className="text-2xl font-bold text-purple-600">{schedulerStatus.processingBatches}</div>
                        <div className="text-sm text-muted-foreground">Processing</div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Recent Batches */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Mail className="w-5 h-5 mr-2" />
                    Recent Batches
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedScheduler.batches && selectedScheduler.batches.length > 0 ? (
                    <div className="space-y-3">
                      {selectedScheduler.batches.slice(0, 5).map((batch) => (
                        <div key={batch.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className={`w-3 h-3 rounded-full ${getBatchStatusColor(batch.status)}`} />
                            <div>
                              <div className="font-medium">Batch #{batch.batchNumber}</div>
                              <div className="text-sm text-muted-foreground">
                                {batch.recipientCount} recipients • {new Date(batch.scheduledAt).toLocaleString()}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium">{batch.status}</div>
                            <div className="text-sm text-muted-foreground">
                              {batch.sentCount}/{batch.recipientCount} sent
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Mail className="w-8 h-8 mx-auto mb-2" />
                      <p>No batches scheduled</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Settings className="w-5 h-5 mr-2" />
                    Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Schedule Type</Label>
                      <div className="p-2 bg-muted rounded mt-1">{selectedScheduler.scheduleType}</div>
                    </div>
                    <div>
                      <Label>Batch Size</Label>
                      <div className="p-2 bg-muted rounded mt-1">{selectedScheduler.batchSize}</div>
                    </div>
                    <div>
                      <Label>Max Daily Emails</Label>
                      <div className="p-2 bg-muted rounded mt-1">{selectedScheduler.maxDailyEmails.toLocaleString()}</div>
                    </div>
                    <div>
                      <Label>Max Hourly Emails</Label>
                      <div className="p-2 bg-muted rounded mt-1">{selectedScheduler.maxHourlyEmails.toLocaleString()}</div>
                    </div>
                  </div>

                  <div className="mt-4">
                    <Label>Time Slots</Label>
                    <div className="mt-2 space-y-2">
                      {selectedScheduler.timeSlots && Array.isArray(selectedScheduler.timeSlots) && 
                        selectedScheduler.timeSlots.map((slot: any, index: number) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                          <span>{slot.hour?.toString().padStart(2, '0')}:{slot.minute?.toString().padStart(2, '0')} {slot.timezone}</span>
                          <span>{slot.maxEmails?.toLocaleString()} emails</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">Select a Scheduler</h3>
                <p className="text-muted-foreground">
                  Choose a scheduler from the left to view details and manage email drops
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {schedulers.length === 0 && !loading && (
        <Card className="text-center py-12">
          <CardContent>
            <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium mb-2">No schedulers created</h3>
            <p className="text-muted-foreground mb-4">
              Create your first daily drop scheduler to manage advanced email delivery
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Scheduler
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

