
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Pause, 
  Trash2, 
  Plus, 
  Settings, 
  Clock, 
  CheckCircle, 
  XCircle,
  Activity,
  Calendar,
  Timer,
  RotateCcw
} from 'lucide-react';
import { JobType, JobPriority, JobExecutionStatus, JobSchedulerData, JobExecutionData } from '@/lib/types';
import { motion } from 'framer-motion';

interface JobSchedulerDashboardProps {
  userId: string;
}

export default function JobSchedulerDashboard({ userId }: JobSchedulerDashboardProps) {
  const [jobs, setJobs] = useState<JobSchedulerData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedJob, setSelectedJob] = useState<JobSchedulerData | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [deleteJobId, setDeleteJobId] = useState<string | null>(null);

  // Form state for creating/editing jobs
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    jobType: JobType.EMAIL_CAMPAIGN,
    cronExpression: '0 9 * * *', // Daily at 9 AM
    timezone: 'UTC',
    priority: JobPriority.NORMAL,
    config: '{}',
    maxRetries: 3,
    retryDelay: 5,
    timeout: 300
  });

  useEffect(() => {
    fetchJobs();
    // Set up polling for real-time updates
    const interval = setInterval(fetchJobs, 30000); // Every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchJobs = async () => {
    try {
      const response = await fetch('/api/advanced/jobs');
      const data = await response.json();
      
      if (data.success) {
        setJobs(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const createJob = async () => {
    try {
      const response = await fetch('/api/advanced/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          config: JSON.parse(formData.config)
        })
      });

      const data = await response.json();
      
      if (data.success) {
        setJobs([data.data, ...jobs]);
        setIsCreateDialogOpen(false);
        resetForm();
      }
    } catch (error) {
      console.error('Failed to create job:', error);
    }
  };

  const toggleJob = async (jobId: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/advanced/jobs/${jobId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !isActive })
      });

      if (response.ok) {
        setJobs(jobs.map(job => 
          job.id === jobId ? { ...job, isActive: !isActive } : job
        ));
      }
    } catch (error) {
      console.error('Failed to toggle job:', error);
    }
  };

  const executeJob = async (jobId: string) => {
    try {
      const response = await fetch(`/api/advanced/jobs/${jobId}/execute`, {
        method: 'POST'
      });

      if (response.ok) {
        // Refresh jobs to see execution status
        fetchJobs();
      }
    } catch (error) {
      console.error('Failed to execute job:', error);
    }
  };

  const deleteJob = async (jobId: string) => {
    try {
      const response = await fetch(`/api/advanced/jobs/${jobId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setJobs(jobs.filter(job => job.id !== jobId));
        setDeleteJobId(null);
      }
    } catch (error) {
      console.error('Failed to delete job:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      jobType: JobType.EMAIL_CAMPAIGN,
      cronExpression: '0 9 * * *',
      timezone: 'UTC',
      priority: JobPriority.NORMAL,
      config: '{}',
      maxRetries: 3,
      retryDelay: 5,
      timeout: 300
    });
  };

  const getStatusColor = (status: JobExecutionStatus) => {
    switch (status) {
      case JobExecutionStatus.COMPLETED:
        return 'bg-green-500';
      case JobExecutionStatus.RUNNING:
        return 'bg-blue-500';
      case JobExecutionStatus.FAILED:
        return 'bg-red-500';
      case JobExecutionStatus.PENDING:
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getJobTypeIcon = (type: JobType) => {
    switch (type) {
      case JobType.EMAIL_CAMPAIGN:
        return <Activity className="w-4 h-4" />;
      case JobType.AUTOMATION_TRIGGER:
        return <Settings className="w-4 h-4" />;
      case JobType.LIST_CLEANUP:
        return <Trash2 className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading jobs...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Job Scheduler</h2>
          <p className="text-muted-foreground">Manage automated tasks and job execution</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Job
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Job</DialogTitle>
              <DialogDescription>
                Set up a new scheduled job for automation
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Job Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Daily Campaign Send"
                  />
                </div>
                <div>
                  <Label htmlFor="jobType">Job Type</Label>
                  <Select
                    value={formData.jobType}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, jobType: value as JobType }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={JobType.EMAIL_CAMPAIGN}>Email Campaign</SelectItem>
                      <SelectItem value={JobType.AUTOMATION_TRIGGER}>Automation Trigger</SelectItem>
                      <SelectItem value={JobType.LIST_CLEANUP}>List Cleanup</SelectItem>
                      <SelectItem value={JobType.ANALYTICS_AGGREGATION}>Analytics Aggregation</SelectItem>
                      <SelectItem value={JobType.IP_WARMUP}>IP Warmup</SelectItem>
                      <SelectItem value={JobType.SUPPRESSION_SYNC}>Suppression Sync</SelectItem>
                      <SelectItem value={JobType.BOUNCE_PROCESSING}>Bounce Processing</SelectItem>
                      <SelectItem value={JobType.REPORT_GENERATION}>Report Generation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe what this job does..."
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="cronExpression">Cron Expression</Label>
                  <Input
                    id="cronExpression"
                    value={formData.cronExpression}
                    onChange={(e) => setFormData(prev => ({ ...prev, cronExpression: e.target.value }))}
                    placeholder="0 9 * * *"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Daily at 9 AM
                  </p>
                </div>
                <div>
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select
                    value={formData.timezone}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, timezone: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UTC">UTC</SelectItem>
                      <SelectItem value="America/New_York">Eastern Time</SelectItem>
                      <SelectItem value="America/Chicago">Central Time</SelectItem>
                      <SelectItem value="America/Denver">Mountain Time</SelectItem>
                      <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value as JobPriority }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={JobPriority.LOW}>Low</SelectItem>
                      <SelectItem value={JobPriority.NORMAL}>Normal</SelectItem>
                      <SelectItem value={JobPriority.HIGH}>High</SelectItem>
                      <SelectItem value={JobPriority.CRITICAL}>Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="config">Configuration (JSON)</Label>
                <Textarea
                  id="config"
                  value={formData.config}
                  onChange={(e) => setFormData(prev => ({ ...prev, config: e.target.value }))}
                  placeholder='{"campaignId": "...", "listId": "..."}'
                  className="font-mono text-sm"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="maxRetries">Max Retries</Label>
                  <Input
                    id="maxRetries"
                    type="number"
                    value={formData.maxRetries}
                    onChange={(e) => setFormData(prev => ({ ...prev, maxRetries: parseInt(e.target.value) }))}
                  />
                </div>
                <div>
                  <Label htmlFor="retryDelay">Retry Delay (min)</Label>
                  <Input
                    id="retryDelay"
                    type="number"
                    value={formData.retryDelay}
                    onChange={(e) => setFormData(prev => ({ ...prev, retryDelay: parseInt(e.target.value) }))}
                  />
                </div>
                <div>
                  <Label htmlFor="timeout">Timeout (sec)</Label>
                  <Input
                    id="timeout"
                    type="number"
                    value={formData.timeout}
                    onChange={(e) => setFormData(prev => ({ ...prev, timeout: parseInt(e.target.value) }))}
                  />
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={createJob}>
                Create Job
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Jobs Grid */}
      <div className="grid gap-4">
        {jobs.map((job) => (
          <motion.div
            key={job.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="group"
          >
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${job.isActive ? 'bg-green-100' : 'bg-gray-100'}`}>
                      {getJobTypeIcon(job.jobType)}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{job.name}</CardTitle>
                      <CardDescription>{job.description}</CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={job.isActive ? 'default' : 'secondary'}>
                      {job.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                    <Badge variant="outline">
                      {job.jobType.replace('_', ' ')}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{job.successfulRuns}</div>
                    <div className="text-sm text-muted-foreground">Successful</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">{job.failedRuns}</div>
                    <div className="text-sm text-muted-foreground">Failed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{job.averageRuntime}ms</div>
                    <div className="text-sm text-muted-foreground">Avg Runtime</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{job.totalRuns}</div>
                    <div className="text-sm text-muted-foreground">Total Runs</div>
                  </div>
                </div>

                {/* Recent Executions */}
                {job.executions && job.executions.length > 0 && (
                  <div className="mb-4">
                    <h4 className="text-sm font-medium mb-2">Recent Executions</h4>
                    <div className="flex space-x-1">
                      {job.executions.slice(0, 5).map((execution) => (
                        <div
                          key={execution.id}
                          className={`w-3 h-3 rounded-full ${getStatusColor(execution.status)}`}
                          title={`${execution.status} - ${execution.startedAt}`}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* Schedule Info */}
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{job.cronExpression}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Timer className="w-4 h-4" />
                      <span>{job.timezone}</span>
                    </div>
                  </div>
                  {job.nextRunAt && (
                    <div className="text-right">
                      <div>Next run:</div>
                      <div className="font-medium">
                        {new Date(job.nextRunAt).toLocaleString()}
                      </div>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={job.isActive}
                      onCheckedChange={() => toggleJob(job.id, job.isActive)}
                    />
                    <span className="text-sm">
                      {job.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => executeJob(job.id)}
                    >
                      <Play className="w-4 h-4 mr-1" />
                      Run Now
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedJob(job)}
                    >
                      <Settings className="w-4 h-4 mr-1" />
                      Details
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setDeleteJobId(job.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {jobs.length === 0 && !loading && (
        <Card className="text-center py-12">
          <CardContent>
            <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium mb-2">No jobs scheduled</h3>
            <p className="text-muted-foreground mb-4">
              Create your first scheduled job to automate your email marketing tasks
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Job
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteJobId} onOpenChange={() => setDeleteJobId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Job</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this job? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteJobId && deleteJob(deleteJobId)}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Job Details Dialog */}
      {selectedJob && (
        <Dialog open={!!selectedJob} onOpenChange={() => setSelectedJob(null)}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>{selectedJob.name}</DialogTitle>
              <DialogDescription>{selectedJob.description}</DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="executions">Executions</TabsTrigger>
                <TabsTrigger value="config">Configuration</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-green-600">{selectedJob.successfulRuns}</div>
                      <div className="text-sm text-muted-foreground">Successful Runs</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-red-600">{selectedJob.failedRuns}</div>
                      <div className="text-sm text-muted-foreground">Failed Runs</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold">{selectedJob.averageRuntime}ms</div>
                      <div className="text-sm text-muted-foreground">Avg Runtime</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold">{selectedJob.totalRuns}</div>
                      <div className="text-sm text-muted-foreground">Total Runs</div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="executions" className="space-y-4">
                {selectedJob.executions?.map((execution) => (
                  <Card key={execution.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(execution.status)}`} />
                          <div>
                            <div className="font-medium">{execution.status}</div>
                            <div className="text-sm text-muted-foreground">
                              {new Date(execution.startedAt).toLocaleString()}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          {execution.runtime && (
                            <div className="text-sm">{execution.runtime}ms</div>
                          )}
                          <div className="text-sm text-muted-foreground">
                            Attempt {execution.attempt}
                          </div>
                        </div>
                      </div>
                      {execution.error && (
                        <div className="mt-2 p-2 bg-red-50 rounded text-sm text-red-600">
                          {execution.error}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              
              <TabsContent value="config" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Job Type</Label>
                    <div className="p-2 bg-muted rounded">{selectedJob.jobType}</div>
                  </div>
                  <div>
                    <Label>Priority</Label>
                    <div className="p-2 bg-muted rounded">{selectedJob.priority}</div>
                  </div>
                  <div>
                    <Label>Cron Expression</Label>
                    <div className="p-2 bg-muted rounded font-mono">{selectedJob.cronExpression}</div>
                  </div>
                  <div>
                    <Label>Timezone</Label>
                    <div className="p-2 bg-muted rounded">{selectedJob.timezone}</div>
                  </div>
                </div>
                <div>
                  <Label>Configuration</Label>
                  <pre className="p-4 bg-muted rounded text-sm overflow-auto">
                    {JSON.stringify(selectedJob.config, null, 2)}
                  </pre>
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
