
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle, Plus, Eye, Zap, TestTube, BarChart3, Sparkles, Copy, Download } from 'lucide-react';
import { SpinTextTemplateData, SpinTextVariationData } from '@/lib/types';
import { motion } from 'framer-motion';

interface SpinTextEditorProps {
  userId: string;
}

export default function SpinTextEditor({ userId }: SpinTextEditorProps) {
  const [templates, setTemplates] = useState<SpinTextTemplateData[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<SpinTextTemplateData | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [previewVariations, setPreviewVariations] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    originalText: '',
    spinTextContent: '',
    maxVariations: 50
  });

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await fetch('/api/advanced/spin-text');
      const data = await response.json();
      
      if (data.success) {
        setTemplates(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch templates:', error);
    } finally {
      setLoading(false);
    }
  };

  const createTemplate = async () => {
    try {
      const response = await fetch('/api/advanced/spin-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();
      
      if (data.success) {
        setTemplates([data.data, ...templates]);
        setIsCreateDialogOpen(false);
        resetForm();
      }
    } catch (error) {
      console.error('Failed to create template:', error);
    }
  };

  const testSpamScore = async (templateId: string) => {
    try {
      const response = await fetch(`/api/advanced/spin-text/${templateId}/test-spam`, {
        method: 'POST'
      });

      const data = await response.json();
      
      if (data.success) {
        // Update template in list
        setTemplates(templates.map(t => 
          t.id === templateId ? data.data : t
        ));
        
        if (selectedTemplate?.id === templateId) {
          setSelectedTemplate(data.data);
        }
      }
    } catch (error) {
      console.error('Failed to test spam score:', error);
    }
  };

  const optimizeWithAI = async (templateId: string) => {
    try {
      const response = await fetch(`/api/advanced/spin-text/${templateId}/optimize`, {
        method: 'POST'
      });

      const data = await response.json();
      
      if (data.success) {
        // Update template in list
        setTemplates(templates.map(t => 
          t.id === templateId ? data.data : t
        ));
        
        if (selectedTemplate?.id === templateId) {
          setSelectedTemplate(data.data);
        }
      }
    } catch (error) {
      console.error('Failed to optimize with AI:', error);
    }
  };

  const previewVariationsFromText = (spinText: string) => {
    // Simple preview generation - in reality this would use the SpinTextEngine
    const variations = generateSimpleVariations(spinText);
    setPreviewVariations(variations.slice(0, 10));
  };

  const generateSimpleVariations = (text: string): string[] => {
    // Basic spin-text parsing for preview
    const variations: string[] = [];
    const spinRegex = /\{([^}]+)\}/g;
    
    function generate(currentText: string): string {
      return currentText.replace(spinRegex, (match, content) => {
        const options = content.split('|');
        return options[Math.floor(Math.random() * options.length)];
      });
    }
    
    for (let i = 0; i < 10; i++) {
      variations.push(generate(text));
    }
    
    return variations;
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      category: '',
      originalText: '',
      spinTextContent: '',
      maxVariations: 50
    });
    setPreviewVariations([]);
  };

  const getQualityColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getSpamScoreColor = (score: number) => {
    if (score <= 3) return 'text-green-600';
    if (score <= 6) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading spin-text templates...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Spin-Text Engine</h2>
          <p className="text-muted-foreground">Create dynamic content variations to improve deliverability</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Template
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Spin-Text Template</DialogTitle>
              <DialogDescription>
                Create dynamic content variations for better email deliverability
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Template Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Welcome Email Variations"
                  />
                </div>
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="subject-lines">Subject Lines</SelectItem>
                      <SelectItem value="greetings">Greetings</SelectItem>
                      <SelectItem value="call-to-action">Call to Action</SelectItem>
                      <SelectItem value="product-descriptions">Product Descriptions</SelectItem>
                      <SelectItem value="closings">Email Closings</SelectItem>
                      <SelectItem value="full-emails">Full Emails</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Brief description of this template"
                />
              </div>

              <div>
                <Label htmlFor="originalText">Original Text</Label>
                <Textarea
                  id="originalText"
                  value={formData.originalText}
                  onChange={(e) => setFormData(prev => ({ ...prev, originalText: e.target.value }))}
                  placeholder="Enter your original text without variations"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="spinTextContent">Spin-Text Content</Label>
                <Textarea
                  id="spinTextContent"
                  value={formData.spinTextContent}
                  onChange={(e) => {
                    setFormData(prev => ({ ...prev, spinTextContent: e.target.value }));
                    previewVariationsFromText(e.target.value);
                  }}
                  placeholder="Use {option1|option2|option3} for variations"
                  rows={6}
                  className="font-mono text-sm"
                />
                <div className="text-sm text-muted-foreground mt-1">
                  Use curly braces and pipes to create variations: {'{'}Hello|Hi|Greetings{'}'} {'{'}friend|there|everyone{'}'}
                </div>
              </div>

              <div>
                <Label htmlFor="maxVariations">Max Variations</Label>
                <Input
                  id="maxVariations"
                  type="number"
                  value={formData.maxVariations}
                  onChange={(e) => setFormData(prev => ({ ...prev, maxVariations: parseInt(e.target.value) }))}
                  min="1"
                  max="1000"
                />
              </div>

              {/* Preview */}
              {previewVariations.length > 0 && (
                <div>
                  <Label>Preview Variations</Label>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {previewVariations.map((variation, index) => (
                      <div key={index} className="p-2 bg-muted rounded text-sm">
                        <span className="text-muted-foreground mr-2">{index + 1}.</span>
                        {variation}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={createTemplate} disabled={!formData.name || !formData.spinTextContent}>
                Create Template
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Templates Grid */}
      <div className="grid gap-4">
        {templates.map((template) => (
          <motion.div
            key={template.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="group"
          >
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                    <CardDescription>{template.description}</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    {template.category && (
                      <Badge variant="outline">{template.category}</Badge>
                    )}
                    {template.aiOptimized && (
                      <Badge className="bg-purple-100 text-purple-800">
                        <Sparkles className="w-3 h-3 mr-1" />
                        AI Optimized
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{template.variations?.length || 0}</div>
                    <div className="text-sm text-muted-foreground">Variations</div>
                  </div>
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${getQualityColor(template.qualityScore || 0)}`}>
                      {template.qualityScore?.toFixed(0) || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Quality Score</div>
                  </div>
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${getSpamScoreColor(template.averageSpamScore || 0)}`}>
                      {template.averageSpamScore?.toFixed(1) || 'N/A'}
                    </div>
                    <div className="text-sm text-muted-foreground">Spam Score</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{template.usageCount}</div>
                    <div className="text-sm text-muted-foreground">Times Used</div>
                  </div>
                </div>

                {/* Spam Score Warning */}
                {template.averageSpamScore && template.averageSpamScore > 6 && (
                  <div className="flex items-center space-x-2 p-3 bg-red-50 rounded-lg mb-4">
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                    <span className="text-sm text-red-700">
                      High spam score detected. Consider revising content.
                    </span>
                  </div>
                )}

                {/* Preview Text */}
                <div className="mb-4">
                  <Label className="text-sm font-medium">Original Text:</Label>
                  <div className="p-2 bg-muted rounded text-sm mt-1">
                    {template.originalText.length > 150 
                      ? `${template.originalText.substring(0, 150)}...`
                      : template.originalText
                    }
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedTemplate(template)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View Details
                    </Button>
                    {!template.spamScoreChecked && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => testSpamScore(template.id)}
                      >
                        <TestTube className="w-4 h-4 mr-1" />
                        Test Spam
                      </Button>
                    )}
                    {!template.aiOptimized && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => optimizeWithAI(template.id)}
                      >
                        <Sparkles className="w-4 h-4 mr-1" />
                        AI Optimize
                      </Button>
                    )}
                  </div>
                  
                  <div className="text-sm text-muted-foreground">
                    {template.lastUsed 
                      ? `Last used ${new Date(template.lastUsed).toLocaleDateString()}`
                      : 'Never used'
                    }
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {templates.length === 0 && !loading && (
        <Card className="text-center py-12">
          <CardContent>
            <Zap className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium mb-2">No spin-text templates</h3>
            <p className="text-muted-foreground mb-4">
              Create your first spin-text template to generate dynamic content variations
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Template
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Template Details Dialog */}
      {selectedTemplate && (
        <Dialog open={!!selectedTemplate} onOpenChange={() => setSelectedTemplate(null)}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedTemplate.name}</DialogTitle>
              <DialogDescription>{selectedTemplate.description}</DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="variations" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="variations">Variations</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
                <TabsTrigger value="content">Content</TabsTrigger>
                <TabsTrigger value="ai-suggestions">AI Suggestions</TabsTrigger>
              </TabsList>
              
              <TabsContent value="variations" className="space-y-4">
                <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                  {selectedTemplate.variations_list?.map((variation, index) => (
                    <Card key={variation.id} className="p-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge variant="outline">#{index + 1}</Badge>
                            {variation.spamScore && (
                              <Badge 
                                variant={variation.spamScore <= 3 ? 'default' : 'destructive'}
                                className="text-xs"
                              >
                                Spam: {variation.spamScore.toFixed(1)}
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm">{variation.content}</div>
                        </div>
                        <div className="flex items-center space-x-2 ml-4">
                          <div className="text-right text-xs text-muted-foreground">
                            <div>Used: {variation.usageCount}</div>
                            <div>Open: {(variation.openRate * 100).toFixed(1)}%</div>
                            <div>Click: {(variation.clickRate * 100).toFixed(1)}%</div>
                          </div>
                          <Button size="sm" variant="ghost">
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="performance" className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className={`text-2xl font-bold ${getQualityColor(selectedTemplate.qualityScore || 0)}`}>
                        {selectedTemplate.qualityScore?.toFixed(0) || 0}
                      </div>
                      <div className="text-sm text-muted-foreground">Quality Score</div>
                      <Progress 
                        value={selectedTemplate.qualityScore || 0} 
                        className="mt-2"
                      />
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className={`text-2xl font-bold ${getSpamScoreColor(selectedTemplate.averageSpamScore || 0)}`}>
                        {selectedTemplate.averageSpamScore?.toFixed(1) || 'N/A'}
                      </div>
                      <div className="text-sm text-muted-foreground">Avg Spam Score</div>
                      <Progress 
                        value={Math.max(0, 100 - (selectedTemplate.averageSpamScore || 0) * 10)} 
                        className="mt-2"
                      />
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold">{selectedTemplate.usageCount}</div>
                      <div className="text-sm text-muted-foreground">Total Usage</div>
                    </CardContent>
                  </Card>
                </div>

                {/* Performance Chart would go here */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Variation Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">
                      <BarChart3 className="w-12 h-12 mx-auto mb-2" />
                      Performance analytics will be displayed here
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="content" className="space-y-4">
                <div>
                  <Label>Original Text</Label>
                  <Textarea 
                    value={selectedTemplate.originalText} 
                    readOnly 
                    className="mt-1" 
                    rows={4}
                  />
                </div>
                <div>
                  <Label>Spin-Text Content</Label>
                  <Textarea 
                    value={selectedTemplate.spinTextContent} 
                    readOnly 
                    className="mt-1 font-mono text-sm" 
                    rows={8}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Max Variations</Label>
                    <div className="p-2 bg-muted rounded mt-1">{selectedTemplate.maxVariations}</div>
                  </div>
                  <div>
                    <Label>Generated Variations</Label>
                    <div className="p-2 bg-muted rounded mt-1">{selectedTemplate.variations_list?.length || 0}</div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="ai-suggestions" className="space-y-4">
                {selectedTemplate.aiOptimized ? (
                  <div>
                    <div className="flex items-center space-x-2 mb-4">
                      <Sparkles className="w-5 h-5 text-purple-600" />
                      <span className="font-medium">AI Optimization Complete</span>
                      <Badge className="bg-purple-100 text-purple-800">
                        {selectedTemplate.aiOptimizedAt && new Date(selectedTemplate.aiOptimizedAt).toLocaleDateString()}
                      </Badge>
                    </div>
                    
                    {selectedTemplate.aiSuggestions && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">AI Suggestions</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <pre className="text-sm whitespace-pre-wrap">
                            {JSON.stringify(selectedTemplate.aiSuggestions, null, 2)}
                          </pre>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-medium mb-2">AI Optimization Available</h3>
                    <p className="text-muted-foreground mb-4">
                      Use AI to optimize this template for better performance and deliverability
                    </p>
                    <Button onClick={() => optimizeWithAI(selectedTemplate.id)}>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Optimize with AI
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
