
'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mail, 
  Brain, 
  Tags, 
  CheckCircle, 
  AlertCircle, 
  Clock,
  Loader2 
} from 'lucide-react';
import { useWebSocketEmails } from '@/components/websocket-provider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

const processingStages = {
  parsing: { label: 'Parsing Email', icon: Mail, color: 'text-blue-500' },
  ai_analysis: { label: 'AI Analysis', icon: Brain, color: 'text-purple-500' },
  categorization: { label: 'Categorizing', icon: Tags, color: 'text-green-500' },
  task_extraction: { label: 'Extracting Tasks', icon: CheckCircle, color: 'text-orange-500' },
  completed: { label: 'Completed', icon: CheckCircle, color: 'text-green-600' },
};

export function RealtimeEmailProcessing() {
  const { processing, connected } = useWebSocketEmails();
  const [processingEmails, setProcessingEmails] = useState(Object.values(processing));

  useEffect(() => {
    setProcessingEmails(Object.values(processing));
  }, [processing]);

  if (!connected) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-red-500" />
            Email Processing
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-32 text-muted-foreground">
            <div className="text-center">
              <AlertCircle className="h-8 w-8 mx-auto mb-2" />
              <p className="text-sm">Not connected to real-time updates</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Brain className="h-4 w-4" />
          Email Processing
        </CardTitle>
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-green-500" />
          <span className="text-xs text-muted-foreground">Live</span>
        </div>
      </CardHeader>
      <CardContent>
        <AnimatePresence>
          {processingEmails.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
              <Clock className="h-8 w-8 mb-2" />
              <p className="text-sm">No emails being processed</p>
            </div>
          ) : (
            <div className="space-y-4">
              {processingEmails.map((email) => {
                const stage = processingStages[email.stage as keyof typeof processingStages];
                const Icon = stage?.icon || Loader2;
                
                return (
                  <motion.div
                    key={email.emailId}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="p-4 rounded-lg border bg-card/50"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Icon className={`h-4 w-4 ${stage?.color || 'text-gray-500'} ${
                          email.stage !== 'completed' ? 'animate-spin' : ''
                        }`} />
                        <span className="text-sm font-medium">
                          {stage?.label || 'Processing'}
                        </span>
                      </div>
                      
                      <Badge variant={email.stage === 'completed' ? 'default' : 'secondary'}>
                        {email.progress}%
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <Progress value={email.progress} className="h-2" />
                      
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>{email.message}</span>
                        {email.estimatedTimeRemaining && email.stage !== 'completed' && (
                          <span>~{email.estimatedTimeRemaining}s remaining</span>
                        )}
                      </div>
                    </div>
                    
                    {email.stage === 'completed' && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="mt-3 p-2 rounded bg-green-500/10 border border-green-500/20"
                      >
                        <div className="flex items-center gap-2 text-green-600">
                          <CheckCircle className="h-3 w-3" />
                          <span className="text-xs font-medium">Processing completed successfully</span>
                        </div>
                      </motion.div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}
