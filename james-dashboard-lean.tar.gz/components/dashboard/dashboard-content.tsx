

'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Mail, 
  Inbox, 
  Send, 
  BarChart3, 
  Settings, 
  Brain, 
  Zap, 
  Clock,
  CheckCircle,
  AlertCircle,
  TrendingUp
} from 'lucide-react';

export function DashboardContent() {
  const stats = [
    { icon: Mail, label: 'Total Emails', value: '1,234', change: '+12%', color: 'text-blue-600' },
    { icon: Inbox, label: 'Unread', value: '23', change: '-8%', color: 'text-orange-600' },
    { icon: Send, label: 'Sent Today', value: '45', change: '+15%', color: 'text-green-600' },
    { icon: CheckCircle, label: 'Processed', value: '98%', change: '+2%', color: 'text-purple-600' },
  ];

  const quickActions = [
    { icon: Mail, label: 'Compose Email', description: 'Create and send new emails', href: '/compose' },
    { icon: Inbox, label: 'View Inbox', description: 'Check your latest messages', href: '/inbox' },
    { icon: Brain, label: 'AI Analysis', description: 'Review smart categorization', href: '/analytics' },
    { icon: Settings, label: 'Automation Rules', description: 'Manage email workflows', href: '/rules' },
  ];

  const recentActivity = [
    { type: 'success', message: 'Processed 15 marketing emails', time: '2 min ago' },
    { type: 'info', message: 'New automation rule created', time: '5 min ago' },
    { type: 'warning', message: '3 emails require review', time: '10 min ago' },
    { type: 'success', message: 'Daily backup completed', time: '1 hour ago' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold text-gray-900">
            Gmail Assistant Dashboard
          </h1>
          <p className="text-gray-600 mt-2">
            Welcome to your AI-powered email management center
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
            System Active
          </Badge>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-600">{stat.change}</span>
                  </div>
                </div>
                <div className={`p-3 rounded-full bg-gray-100 ${stat.color}`}>
                  <stat.icon className="h-6 w-6" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold text-gray-900">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <Card key={index} className="hover:shadow-lg transition-all duration-300 cursor-pointer group">
              <CardContent className="p-6 text-center">
                <div className="mx-auto bg-blue-100 text-blue-600 p-3 rounded-full w-fit mb-4 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <action.icon className="h-6 w-6" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{action.label}</h3>
                <p className="text-sm text-gray-600">{action.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-2xl font-semibold text-gray-900">Recent Activity</h2>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                System Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 rounded-lg bg-gray-50">
                  <div className={`flex-shrink-0 ${
                    activity.type === 'success' ? 'text-green-600' :
                    activity.type === 'warning' ? 'text-orange-600' :
                    'text-blue-600'
                  }`}>
                    {activity.type === 'success' ? <CheckCircle className="h-5 w-5" /> :
                     activity.type === 'warning' ? <AlertCircle className="h-5 w-5" /> :
                     <Mail className="h-5 w-5" />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">{activity.message}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* System Status */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-gray-900">System Status</h2>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="h-5 w-5 mr-2" />
                Performance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Email Processing</span>
                    <span className="text-green-600">98%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '98%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>AI Analysis</span>
                    <span className="text-blue-600">95%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '95%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Automation</span>
                    <span className="text-purple-600">92%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-purple-600 h-2 rounded-full" style={{ width: '92%' }}></div>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-200">
                <Button variant="outline" size="sm" className="w-full">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  View Detailed Analytics
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Future Features */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-gray-600">Coming Soon</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="text-sm text-gray-600 space-y-1">
                <div>🎤 Voice Commands</div>
                <div>📧 Advanced Compose</div>
                <div>🔧 MCP Architecture</div>
                <div>🤖 Enhanced AI</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
