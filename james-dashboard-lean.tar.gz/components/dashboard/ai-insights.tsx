
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Brain, 
  Lightbulb, 
  TrendingUp, 
  Clock, 
  Users, 
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Target
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Insight {
  id: string;
  type: 'optimization' | 'warning' | 'opportunity' | 'achievement';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  actionable: boolean;
  confidence: number;
  category: 'productivity' | 'communication' | 'time-management' | 'relationships';
  metrics?: {
    current: number;
    potential: number;
    unit: string;
  };
}

export function AIInsights() {
  const [isLoading, setIsLoading] = useState(true);
  const [insights, setInsights] = useState<Insight[]>([]);

  useEffect(() => {
    const fetchInsights = async () => {
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      const mockInsights: Insight[] = [
        {
          id: '1',
          type: 'optimization',
          title: 'Optimize Email Response Patterns',
          description: 'Your response time is 40% faster in the morning. Consider scheduling complex email reviews for 9-11 AM.',
          impact: 'high',
          actionable: true,
          confidence: 0.89,
          category: 'productivity',
          metrics: {
            current: 32,
            potential: 22,
            unit: 'minutes avg response time'
          }
        },
        {
          id: '2',
          type: 'warning',
          title: 'High Priority Email Overload',
          description: 'You have 40% more urgent emails than usual this week. Consider adjusting email filters or delegation.',
          impact: 'high',
          actionable: true,
          confidence: 0.94,
          category: 'time-management',
          metrics: {
            current: 28,
            potential: 18,
            unit: 'urgent emails per day'
          }
        },
        {
          id: '3',
          type: 'opportunity',
          title: 'Automate Routine Responses',
          description: '65% of your emails contain similar response patterns. Smart templates could save significant time.',
          impact: 'medium',
          actionable: true,
          confidence: 0.82,
          category: 'productivity',
          metrics: {
            current: 45,
            potential: 68,
            unit: 'minutes saved daily'
          }
        },
        {
          id: '4',
          type: 'achievement',
          title: 'Response Time Improvement',
          description: 'Great job! Your average response time improved by 25% this month compared to last month.',
          impact: 'medium',
          actionable: false,
          confidence: 0.96,
          category: 'communication'
        },
        {
          id: '5',
          type: 'opportunity',
          title: 'Strengthen Key Relationships',
          description: 'Your interaction frequency with top 5 contacts has decreased. Consider scheduling catch-up meetings.',
          impact: 'medium',
          actionable: true,
          confidence: 0.77,
          category: 'relationships',
          metrics: {
            current: 2.3,
            potential: 4.1,
            unit: 'interactions per week'
          }
        }
      ];
      
      setInsights(mockInsights);
      setIsLoading(false);
    };

    fetchInsights();
  }, []);

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'optimization':
        return <TrendingUp className="h-4 w-4" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4" />;
      case 'opportunity':
        return <Lightbulb className="h-4 w-4" />;
      case 'achievement':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <Brain className="h-4 w-4" />;
    }
  };

  const getInsightColor = (type: string) => {
    switch (type) {
      case 'optimization':
        return 'bg-blue-600/20 text-blue-400 border-blue-600/30';
      case 'warning':
        return 'bg-red-600/20 text-red-400 border-red-600/30';
      case 'opportunity':
        return 'bg-yellow-600/20 text-yellow-400 border-yellow-600/30';
      case 'achievement':
        return 'bg-green-600/20 text-green-400 border-green-600/30';
      default:
        return 'bg-slate-600/20 text-slate-400 border-slate-600/30';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'bg-red-600/20 text-red-400 border-red-600/30';
      case 'medium':
        return 'bg-yellow-600/20 text-yellow-400 border-yellow-600/30';
      case 'low':
        return 'bg-green-600/20 text-green-400 border-green-600/30';
      default:
        return 'bg-slate-600/20 text-slate-400 border-slate-600/30';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'productivity':
        return <Target className="h-3 w-3" />;
      case 'communication':
        return <Users className="h-3 w-3" />;
      case 'time-management':
        return <Clock className="h-3 w-3" />;
      case 'relationships':
        return <Users className="h-3 w-3" />;
      default:
        return <Brain className="h-3 w-3" />;
    }
  };

  return (
    <Card className="glass-dark border-slate-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-400" />
            <CardTitle className="text-xl text-white">AI Insights</CardTitle>
            <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30">
              <Sparkles className="h-3 w-3 mr-1" />
              ML-Powered
            </Badge>
          </div>
          <Button
            size="sm"
            variant="outline"
            className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
          >
            Refresh Insights
          </Button>
        </div>
        <p className="text-sm text-slate-400">
          Personalized recommendations based on your email patterns and productivity data
        </p>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="space-y-3 animate-pulse">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-slate-700 rounded-full"></div>
                  <div className="h-4 bg-slate-700 rounded w-1/3"></div>
                </div>
                <div className="h-3 bg-slate-700 rounded w-full"></div>
                <div className="h-3 bg-slate-700 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {insights.map((insight, index) => (
              <div
                key={insight.id}
                className="p-4 rounded-lg bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-all duration-200 animate-slide-in-bottom"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Badge className={cn('text-xs', getInsightColor(insight.type))}>
                      {getInsightIcon(insight.type)}
                      <span className="ml-1 capitalize">{insight.type}</span>
                    </Badge>
                    <Badge className={cn('text-xs', getImpactColor(insight.impact))}>
                      {insight.impact.toUpperCase()} IMPACT
                    </Badge>
                  </div>
                  
                  <div className="flex items-center space-x-2 text-xs text-slate-500">
                    {getCategoryIcon(insight.category)}
                    <span className="capitalize">{insight.category}</span>
                    <span>•</span>
                    <span>{Math.round(insight.confidence * 100)}% confidence</span>
                  </div>
                </div>
                
                <h4 className="font-semibold text-white mb-2">
                  {insight.title}
                </h4>
                
                <p className="text-sm text-slate-400 mb-3">
                  {insight.description}
                </p>
                
                {insight.metrics && (
                  <div className="grid grid-cols-2 gap-4 mb-3">
                    <div className="text-center p-2 bg-slate-800 rounded">
                      <p className="text-xs text-slate-500">Current</p>
                      <p className="font-semibold text-white">{insight.metrics.current}</p>
                      <p className="text-xs text-slate-400">{insight.metrics.unit}</p>
                    </div>
                    <div className="text-center p-2 bg-slate-800 rounded">
                      <p className="text-xs text-slate-500">Potential</p>
                      <p className="font-semibold text-green-400">{insight.metrics.potential}</p>
                      <p className="text-xs text-slate-400">{insight.metrics.unit}</p>
                    </div>
                  </div>
                )}
                
                {insight.actionable && (
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      className="bg-indigo-600 hover:bg-indigo-700 text-white"
                    >
                      Take Action
                      <ArrowRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                )}
              </div>
            ))}
            
            <div className="text-center pt-4">
              <Button
                variant="outline"
                className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
              >
                View All Insights
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
