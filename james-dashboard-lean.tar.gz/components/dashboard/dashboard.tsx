

'use client';

import { useSession } from 'next-auth/react';
import { Loader2 } from 'lucide-react';
import { JamesGreeting } from '@/components/james/james-greeting';

export function Dashboard() {
  const { data: session, status } = useSession() || {};

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Dashboard content will be loaded from existing pages */}
      <div className="p-6">
        {/* James Personalized Greeting */}
        <JamesGreeting />
        
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Dashboard Overview
          </h1>
          <p className="text-gray-600 mt-2">
            Your Gmail Assistant dashboard is ready. Navigate using the sidebar to access all features.
          </p>
        </div>
      </div>
    </div>
  );
}
