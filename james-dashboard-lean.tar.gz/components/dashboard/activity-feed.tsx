
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Activity, 
  Mail, 
  CheckCircle, 
  Zap, 
  Brain, 
  Users, 
  Clock,
  Bot,
  Workflow
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ActivityItem {
  id: string;
  type: 'email_processed' | 'task_completed' | 'ai_action' | 'workflow_executed' | 'collaboration';
  title: string;
  description: string;
  timestamp: Date;
  status: 'success' | 'warning' | 'info';
  metadata?: any;
}

export function ActivityFeed() {
  const [isLoading, setIsLoading] = useState(true);
  const [activities, setActivities] = useState<ActivityItem[]>([]);

  useEffect(() => {
    const fetchActivities = async () => {
      await new Promise(resolve => setTimeout(resolve, 600));
      
      const mockActivities: ActivityItem[] = [
        {
          id: '1',
          type: 'ai_action',
          title: 'AI Summarized Long Email',
          description: 'Quarterly Business Review email summarized and key points extracted',
          timestamp: new Date(Date.now() - 5 * 60 * 1000),
          status: 'success',
          metadata: { emailId: 'email_1', actionType: 'summarize' }
        },
        {
          id: '2',
          type: 'workflow_executed',
          title: 'High Priority Email Processor',
          description: 'Auto-tagged urgent email and created task',
          timestamp: new Date(Date.now() - 15 * 60 * 1000),
          status: 'success',
          metadata: { workflowName: 'urgent_email_handler' }
        },
        {
          id: '3',
          type: 'email_processed',
          title: 'Email Analyzed',
          description: 'Sentiment: Negative, Priority: Urgent, Confidence: 97%',
          timestamp: new Date(Date.now() - 30 * 60 * 1000),
          status: 'warning',
          metadata: { sentiment: 'negative', priority: 'urgent' }
        },
        {
          id: '4',
          type: 'task_completed',
          title: 'Task Completed',
          description: 'Review server performance metrics - completed automatically',
          timestamp: new Date(Date.now() - 45 * 60 * 1000),
          status: 'success',
          metadata: { taskId: 'task_1' }
        },
        {
          id: '5',
          type: 'collaboration',
          title: 'Email Shared',
          description: 'Sarah Johnson shared "Q4 Business Review" with team',
          timestamp: new Date(Date.now() - 60 * 60 * 1000),
          status: 'info',
          metadata: { sharedWith: ['team'] }
        },
        {
          id: '6',
          type: 'ai_action',
          title: 'Contact Insights Updated',
          description: 'Relationship intelligence refreshed for Mike Chen',
          timestamp: new Date(Date.now() - 90 * 60 * 1000),
          status: 'info',
          metadata: { contactId: 'contact_1' }
        }
      ];
      
      setActivities(mockActivities);
      setIsLoading(false);
    };

    fetchActivities();

    // Simulate real-time updates
    const interval = setInterval(() => {
      const newActivity: ActivityItem = {
        id: `activity_${Date.now()}`,
        type: 'ai_action',
        title: 'Real-time AI Processing',
        description: 'New email analyzed and prioritized',
        timestamp: new Date(),
        status: 'success'
      };
      
      setActivities(prev => [newActivity, ...prev.slice(0, 5)]);
    }, 30000); // Add new activity every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'email_processed':
        return <Mail className="h-4 w-4" />;
      case 'task_completed':
        return <CheckCircle className="h-4 w-4" />;
      case 'ai_action':
        return <Brain className="h-4 w-4" />;
      case 'workflow_executed':
        return <Workflow className="h-4 w-4" />;
      case 'collaboration':
        return <Users className="h-4 w-4" />;
      default:
        return <Activity className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-600/20 text-green-400 border-green-600/30';
      case 'warning':
        return 'bg-yellow-600/20 text-yellow-400 border-yellow-600/30';
      case 'info':
        return 'bg-blue-600/20 text-blue-400 border-blue-600/30';
      default:
        return 'bg-slate-600/20 text-slate-400 border-slate-600/30';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) {
      return `${hours}h ago`;
    }
    return `${minutes}m ago`;
  };

  return (
    <Card className="glass-dark border-slate-700">
      <CardHeader className="pb-4">
        <div className="flex items-center space-x-2">
          <Activity className="h-5 w-5 text-green-400" />
          <CardTitle className="text-xl text-white">Activity Feed</CardTitle>
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
        </div>
        <p className="text-sm text-slate-400">
          Real-time updates on AI actions and system events
        </p>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-start space-x-3 animate-pulse">
                <div className="w-8 h-8 bg-slate-700 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                  <div className="h-3 bg-slate-700 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4 max-h-80 overflow-y-auto custom-scrollbar">
            {activities.map((activity, index) => (
              <div
                key={activity.id}
                className="flex items-start space-x-3 p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-all duration-200 animate-slide-in-right"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className={cn(
                  'p-2 rounded-full',
                  getStatusColor(activity.status)
                )}>
                  {getActivityIcon(activity.type)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-medium text-white truncate">
                      {activity.title}
                    </h4>
                    <div className="flex items-center text-xs text-slate-500">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatTimeAgo(activity.timestamp)}
                    </div>
                  </div>
                  
                  <p className="text-xs text-slate-400 line-clamp-2">
                    {activity.description}
                  </p>
                  
                  {activity.metadata && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {Object.entries(activity.metadata).slice(0, 2).map(([key, value]) => (
                        <Badge
                          key={key}
                          className="text-xs bg-slate-700 text-slate-300 border-slate-600"
                        >
                          {key}: {String(value)}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
        
        <div className="mt-4 pt-4 border-t border-slate-700 text-center">
          <Badge className="bg-slate-700 text-slate-300 border-slate-600">
            <Bot className="h-3 w-3 mr-1" />
            Powered by AI
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}
