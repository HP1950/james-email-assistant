
'use client';

import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { EnhancedStatsCards } from './enhanced-stats-cards';
import { SmartInboxPreview } from './smart-inbox-preview';
import { EnhancedActivityFeed } from './enhanced-activity-feed';
import { EnhancedProductivityChart } from './enhanced-productivity-chart';
import { EnhancedQuickActions } from './enhanced-quick-actions';
import { EnhancedAIInsights } from './enhanced-ai-insights';
import { AIEmailAssistant } from './ai-email-assistant';
import { RealtimeActivityFeed } from './realtime-activity-feed';
import { RealtimeEmailProcessing } from './realtime-email-processing';
import { RealtimeNotifications } from './realtime-notifications';
import { RealtimeCollaboration } from './realtime-collaboration';
import { SystemStatus } from './system-status';
import { useWebSocketContext } from '@/components/websocket-provider';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  Sparkles, 
  Settings, 
  Download,
  RefreshCw,
  Bell,
  Filter,
  Wifi,
  WifiOff
} from 'lucide-react';

export function EnhancedDashboardClient() {
  const { websocket, notifications } = useWebSocketContext();
  const [isLoaded, setIsLoaded] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    setIsLoaded(true);
    
    // Auto-refresh every 5 minutes
    const interval = setInterval(() => {
      setLastUpdated(new Date());
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    // Simulate refresh delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    setLastUpdated(new Date());
    setIsRefreshing(false);
  };

  if (!isLoaded) {
    return (
      <MainLayout>
        <div className="flex h-full items-center justify-center">
          <motion.div 
            className="flex items-center space-x-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="h-8 w-8 border-2 border-indigo-600 border-t-transparent rounded-full"
            />
            <span className="text-slate-400 text-lg">Loading AI-powered dashboard...</span>
          </motion.div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="p-6 space-y-6 max-w-7xl mx-auto">
        {/* Header Section */}
        <motion.div 
          className="space-y-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <div className="flex items-center space-x-3">
                <LayoutDashboard className="h-8 w-8 text-indigo-400" />
                <h1 className="text-3xl font-bold text-white">AI Email Dashboard</h1>
                <Badge className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 text-purple-400 border-purple-600/30">
                  <Sparkles className="h-3 w-3 mr-1" />
                  AI-Powered
                </Badge>
              </div>
              <p className="text-slate-400 text-lg">
                Intelligent email management with advanced AI analytics and automation
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-400 hover:text-white"
              >
                <Bell className="h-4 w-4 mr-2" />
                Alerts
                {notifications.unreadCount > 0 && (
                  <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 text-xs">
                    {notifications.unreadCount}
                  </Badge>
                )}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-400 hover:text-white"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="border-slate-600 text-slate-400 hover:text-white"
              >
                <motion.div
                  animate={isRefreshing ? { rotate: 360 } : {}}
                  transition={{ duration: 1, repeat: isRefreshing ? Infinity : 0, ease: "linear" }}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                </motion.div>
                Refresh
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-400 hover:text-white"
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-400 hover:text-white"
              >
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
          
          {/* Status Bar */}
          <div className="flex items-center justify-between text-sm text-slate-500 bg-slate-800/30 rounded-lg p-3 border border-slate-700">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <div className={`h-2 w-2 rounded-full ${websocket.state.connected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`}></div>
                <span>
                  {websocket.state.connected ? 'Real-time connected' : 'Offline mode'}
                </span>
                {websocket.state.connected ? (
                  <Wifi className="h-3 w-3 text-green-400" />
                ) : (
                  <WifiOff className="h-3 w-3 text-red-400" />
                )}
              </div>
              <div className="flex items-center space-x-2">
                <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span>AI Confidence: 94%</span>
              <span>Processing Speed: 1.2s avg</span>
              {websocket.state.reconnectAttempts > 0 && (
                <span className="text-yellow-400">
                  Reconnect attempts: {websocket.state.reconnectAttempts}
                </span>
              )}
            </div>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <EnhancedStatsCards />

        {/* Real-time Dashboard Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800/50">
            <TabsTrigger value="overview" className="data-[state=active]:bg-indigo-600">
              Overview
            </TabsTrigger>
            <TabsTrigger value="realtime" className="data-[state=active]:bg-indigo-600">
              Real-time
            </TabsTrigger>
            <TabsTrigger value="collaboration" className="data-[state=active]:bg-indigo-600">
              Collaboration
            </TabsTrigger>
            <TabsTrigger value="system" className="data-[state=active]:bg-indigo-600">
              System
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Main Dashboard Grid - Overview */}
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
              {/* Left Column - Main Content */}
              <div className="xl:col-span-3 space-y-6">
                {/* Analytics Chart */}
                <EnhancedProductivityChart />
                
                {/* Inbox and AI Assistant Row */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <SmartInboxPreview />
                  <AIEmailAssistant />
                </div>
                
                {/* AI Insights */}
                <EnhancedAIInsights />
              </div>

              {/* Right Column - Sidebar */}
              <div className="space-y-6">
                <EnhancedQuickActions />
                <EnhancedActivityFeed />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="realtime" className="space-y-6">
            {/* Real-time Features Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              {/* Left Column - Real-time Activity and Processing */}
              <div className="xl:col-span-2 space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <RealtimeActivityFeed />
                  <RealtimeEmailProcessing />
                </div>
                
                {/* Analytics Chart for Real-time */}
                <EnhancedProductivityChart />
                
                {/* Real-time Inbox */}
                <SmartInboxPreview />
              </div>

              {/* Right Column - Real-time Sidebar */}
              <div className="space-y-6">
                <RealtimeNotifications />
                <EnhancedQuickActions />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="collaboration" className="space-y-6">
            {/* Collaboration Features Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
              {/* Left Column - Collaboration Main */}
              <div className="xl:col-span-3 space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <RealtimeCollaboration />
                  <RealtimeNotifications />
                </div>
                
                <SmartInboxPreview />
                <AIEmailAssistant />
              </div>

              {/* Right Column - Collaboration Sidebar */}
              <div className="space-y-6">
                <RealtimeActivityFeed />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="system" className="space-y-6">
            {/* System Monitoring Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
              {/* Left Column - System Main */}
              <div className="xl:col-span-3 space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <SystemStatus />
                  <RealtimeEmailProcessing />
                </div>
                
                <EnhancedProductivityChart />
                <EnhancedAIInsights />
              </div>

              {/* Right Column - System Sidebar */}
              <div className="space-y-6">
                <RealtimeActivityFeed />
                <RealtimeNotifications />
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        {/* Footer Stats */}
        <motion.div
          className="mt-8 p-4 bg-gradient-to-r from-indigo-900/20 to-purple-900/20 rounded-lg border border-indigo-800/30"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-indigo-400">2.4k</p>
              <p className="text-sm text-slate-400">Emails Processed</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-purple-400">18.2h</p>
              <p className="text-sm text-slate-400">Time Saved</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-green-400">94%</p>
              <p className="text-sm text-slate-400">Automation Rate</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-400">847</p>
              <p className="text-sm text-slate-400">AI Actions</p>
            </div>
          </div>
        </motion.div>
      </div>
    </MainLayout>
  );
}
