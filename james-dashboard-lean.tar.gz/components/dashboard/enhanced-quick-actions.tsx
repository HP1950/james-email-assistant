
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Zap, 
  Send, 
  Brain, 
  Archive, 
  Star,
  Filter,
  Search,
  Calendar,
  FileText,
  Settings,
  BarChart3,
  Users,
  Bell,
  Download,
  Upload,
  RefreshCw,
  Plus,
  Trash2,
  Edit
} from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

interface QuickAction {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  action: () => void;
  badge?: string;
  shortcut?: string;
  category: 'primary' | 'ai' | 'email' | 'utility';
}

export function EnhancedQuickActions() {
  const [isExecuting, setIsExecuting] = useState<string | null>(null);

  const executeAction = async (actionId: string, actionFn: () => void) => {
    setIsExecuting(actionId);
    try {
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate action
      actionFn();
      toast.success('Action completed successfully!');
    } catch (error) {
      toast.error('Action failed. Please try again.');
    } finally {
      setIsExecuting(null);
    }
  };

  const quickActions: QuickAction[] = [
    {
      id: 'compose',
      title: 'Compose Email',
      description: 'Start writing a new email',
      icon: Send,
      color: 'text-blue-400',
      bgColor: 'bg-blue-600/10 hover:bg-blue-600/20',
      action: () => toast.info('Opening email composer...'),
      shortcut: 'Ctrl+N',
      category: 'primary',
    },
    {
      id: 'ai-analyze',
      title: 'AI Batch Analysis',
      description: 'Analyze all unread emails with AI',
      icon: Brain,
      color: 'text-purple-400',
      bgColor: 'bg-purple-600/10 hover:bg-purple-600/20',
      action: () => toast.info('Starting AI analysis...'),
      badge: 'Smart',
      category: 'ai',
    },
    {
      id: 'smart-reply',
      title: 'Generate Smart Replies',
      description: 'AI-powered response suggestions',
      icon: Zap,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-600/10 hover:bg-yellow-600/20',
      action: () => toast.info('Generating smart replies...'),
      badge: 'AI',
      category: 'ai',
    },
    {
      id: 'archive-old',
      title: 'Archive Old Emails',
      description: 'Auto-archive emails older than 30 days',
      icon: Archive,
      color: 'text-green-400',
      bgColor: 'bg-green-600/10 hover:bg-green-600/20',
      action: () => toast.info('Archiving old emails...'),
      category: 'email',
    },
    {
      id: 'priority-filter',
      title: 'Filter High Priority',
      description: 'Show only urgent and high priority emails',
      icon: Filter,
      color: 'text-red-400',
      bgColor: 'bg-red-600/10 hover:bg-red-600/20',
      action: () => toast.info('Filtering high priority emails...'),
      shortcut: 'Ctrl+P',
      category: 'email',
    },
    {
      id: 'search',
      title: 'Advanced Search',
      description: 'Search emails with natural language',
      icon: Search,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-600/10 hover:bg-indigo-600/20',
      action: () => toast.info('Opening advanced search...'),
      shortcut: 'Ctrl+F',
      category: 'utility',
    },
    {
      id: 'schedule',
      title: 'Schedule Meeting',
      description: 'Create calendar event from email',
      icon: Calendar,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-600/10 hover:bg-cyan-600/20',
      action: () => toast.info('Opening calendar scheduler...'),
      category: 'utility',
    },
    {
      id: 'export-data',
      title: 'Export Analytics',
      description: 'Download productivity report',
      icon: Download,
      color: 'text-slate-400',
      bgColor: 'bg-slate-600/10 hover:bg-slate-600/20',
      action: () => toast.info('Preparing analytics export...'),
      category: 'utility',
    },
    {
      id: 'bulk-actions',
      title: 'Bulk Actions',
      description: 'Perform actions on multiple emails',
      icon: Users,
      color: 'text-orange-400',
      bgColor: 'bg-orange-600/10 hover:bg-orange-600/20',
      action: () => toast.info('Opening bulk actions panel...'),
      category: 'email',
    },
    {
      id: 'notifications',
      title: 'Notification Settings',
      description: 'Manage email notifications',
      icon: Bell,
      color: 'text-pink-400',
      bgColor: 'bg-pink-600/10 hover:bg-pink-600/20',
      action: () => toast.info('Opening notification settings...'),
      category: 'utility',
    },
    {
      id: 'templates',
      title: 'Email Templates',
      description: 'Manage and create email templates',
      icon: FileText,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-600/10 hover:bg-emerald-600/20',
      action: () => toast.info('Opening email templates...'),
      badge: 'New',
      category: 'email',
    },
    {
      id: 'analytics',
      title: 'View Analytics',
      description: 'Detailed email productivity insights',
      icon: BarChart3,
      color: 'text-violet-400',
      bgColor: 'bg-violet-600/10 hover:bg-violet-600/20',
      action: () => toast.info('Opening analytics dashboard...'),
      category: 'utility',
    },
  ];

  const categories = [
    { id: 'primary', label: 'Primary', actions: quickActions.filter(a => a.category === 'primary') },
    { id: 'ai', label: 'AI Features', actions: quickActions.filter(a => a.category === 'ai') },
    { id: 'email', label: 'Email Management', actions: quickActions.filter(a => a.category === 'email') },
    { id: 'utility', label: 'Utilities', actions: quickActions.filter(a => a.category === 'utility') },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <Card className="glass-dark border-slate-700 hover:border-slate-600 transition-all duration-300">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-yellow-400" />
              <CardTitle className="text-xl text-white">Quick Actions</CardTitle>
              <Badge className="bg-yellow-600/20 text-yellow-400">
                {quickActions.length} actions
              </Badge>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="border-slate-600 text-slate-400 hover:text-white"
            >
              <Settings className="h-4 w-4 mr-2" />
              Customize
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {categories.map((category, categoryIndex) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: categoryIndex * 0.1 }}
              className="space-y-3"
            >
              <h3 className="text-sm font-medium text-slate-300 uppercase tracking-wide">
                {category.label}
              </h3>
              
              <div className="grid grid-cols-1 gap-2">
                {category.actions.map((action, actionIndex) => {
                  const Icon = action.icon;
                  const isActionExecuting = isExecuting === action.id;
                  
                  return (
                    <motion.div
                      key={action.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: (categoryIndex * 0.1) + (actionIndex * 0.05) }}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button
                        variant="ghost"
                        className={`w-full justify-start h-auto p-4 ${action.bgColor} border border-slate-700/50 hover:border-slate-600`}
                        onClick={() => executeAction(action.id, action.action)}
                        disabled={isActionExecuting}
                      >
                        <div className="flex items-center w-full">
                          <div className={`p-2 rounded-lg bg-slate-800 ${action.color} mr-3 shrink-0`}>
                            {isActionExecuting ? (
                              <motion.div
                                animate={{ rotate: 360 }}
                                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              >
                                <RefreshCw className="h-5 w-5" />
                              </motion.div>
                            ) : (
                              <Icon className="h-5 w-5" />
                            )}
                          </div>
                          
                          <div className="flex-1 text-left">
                            <div className="flex items-center justify-between mb-1">
                              <h4 className="text-sm font-medium text-white">
                                {action.title}
                              </h4>
                              <div className="flex items-center space-x-2 shrink-0">
                                {action.badge && (
                                  <Badge className="text-xs bg-slate-700 text-slate-300">
                                    {action.badge}
                                  </Badge>
                                )}
                                {action.shortcut && (
                                  <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                                    {action.shortcut}
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <p className="text-xs text-slate-400">
                              {action.description}
                            </p>
                          </div>
                        </div>
                      </Button>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          ))}
          
          {/* Add Custom Action */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="pt-4 border-t border-slate-700"
          >
            <Button
              variant="outline"
              className="w-full border-dashed border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700/50"
              onClick={() => toast.info('Custom action builder coming soon!')}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Custom Action
            </Button>
          </motion.div>
          
          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="pt-4 border-t border-slate-700"
          >
            <div className="text-xs text-slate-500 text-center">
              Actions executed today: <span className="text-green-400 font-medium">47</span> • 
              Time saved: <span className="text-blue-400 font-medium">2.3 hours</span>
            </div>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
