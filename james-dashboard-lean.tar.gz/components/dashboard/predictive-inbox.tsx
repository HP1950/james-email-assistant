
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mail, Star, Clock, ArrowRight, Brain, Flame, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PriorityEmail {
  id: string;
  subject: string;
  sender: string;
  snippet: string;
  priority: 'URGENT' | 'HIGH' | 'MEDIUM';
  sentiment: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  confidence: number;
  receivedAt: Date;
  aiReason: string;
}

export function PredictiveInbox() {
  const [isLoading, setIsLoading] = useState(true);
  const [emails, setEmails] = useState<PriorityEmail[]>([]);

  useEffect(() => {
    const fetchPriorityEmails = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockEmails: PriorityEmail[] = [
        {
          id: '1',
          subject: 'Urgent: Server Performance Issues - Action Required',
          sender: 'Mike Chen',
          snippet: 'Our monitoring systems have detected critical performance degradation...',
          priority: 'URGENT',
          sentiment: 'NEGATIVE',
          confidence: 0.97,
          receivedAt: new Date(Date.now() - 30 * 60 * 1000),
          aiReason: 'Urgent keywords detected, infrastructure-related, requires immediate attention'
        },
        {
          id: '2',
          subject: 'Quarterly Business Review - Q4 2024 Results',
          sender: 'Sarah Johnson',
          snippet: 'Please find attached our Q4 2024 business review with key metrics...',
          priority: 'HIGH',
          sentiment: 'POSITIVE',
          confidence: 0.92,
          receivedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
          aiReason: 'Important business document, high-priority sender, requires review'
        },
        {
          id: '3',
          subject: 'Project Proposal: AI-Powered Customer Service Enhancement',
          sender: 'Dr. Amanda Rodriguez',
          snippet: 'I am excited to present our comprehensive proposal for implementing...',
          priority: 'HIGH',
          sentiment: 'POSITIVE',
          confidence: 0.89,
          receivedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
          aiReason: 'Business proposal, new opportunity, financial implications detected'
        },
        {
          id: '4',
          subject: 'Team Meeting Reschedule Request',
          sender: 'Lisa Park',
          snippet: 'Hi everyone, I need to reschedule our weekly team meeting...',
          priority: 'MEDIUM',
          sentiment: 'NEUTRAL',
          confidence: 0.76,
          receivedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
          aiReason: 'Meeting coordination, affects multiple people, moderate priority'
        }
      ];
      
      setEmails(mockEmails);
      setIsLoading(false);
    };

    fetchPriorityEmails();
  }, []);

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'URGENT':
        return <Flame className="h-4 w-4" />;
      case 'HIGH':
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <Mail className="h-4 w-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'URGENT':
        return 'priority-urgent';
      case 'HIGH':
        return 'priority-high';
      case 'MEDIUM':
        return 'priority-medium';
      default:
        return 'priority-low';
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'POSITIVE':
        return 'sentiment-positive';
      case 'NEGATIVE':
        return 'sentiment-negative';
      default:
        return 'sentiment-neutral';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) {
      return `${hours}h ago`;
    }
    return `${minutes}m ago`;
  };

  return (
    <Card className="glass-dark border-slate-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-indigo-400" />
            <CardTitle className="text-xl text-white">Predictive Inbox</CardTitle>
          </div>
          <Badge className="bg-indigo-600/20 text-indigo-400 border-indigo-600/30">
            AI-Powered
          </Badge>
        </div>
        <p className="text-sm text-slate-400">
          Emails prioritized by AI based on urgency, sender importance, and content analysis
        </p>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="space-y-2 animate-pulse">
                <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                <div className="h-3 bg-slate-700 rounded w-1/2"></div>
                <div className="h-3 bg-slate-700 rounded w-full"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {emails.map((email, index) => (
              <div
                key={email.id}
                className="p-4 rounded-lg bg-slate-800 border border-slate-700 hover:border-slate-600 transition-all duration-200 cursor-pointer group animate-slide-in-left"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Badge className={cn('text-xs', getPriorityColor(email.priority))}>
                      {getPriorityIcon(email.priority)}
                      <span className="ml-1">{email.priority}</span>
                    </Badge>
                    <Badge className={cn('text-xs', getSentimentColor(email.sentiment))}>
                      {email.sentiment}
                    </Badge>
                    <span className="text-xs text-slate-500">
                      {Math.round(email.confidence * 100)}% confidence
                    </span>
                  </div>
                  <div className="flex items-center text-xs text-slate-400">
                    <Clock className="h-3 w-3 mr-1" />
                    {formatTimeAgo(email.receivedAt)}
                  </div>
                </div>
                
                <h4 className="font-semibold text-white mb-1 group-hover:text-indigo-300 transition-colors">
                  {email.subject}
                </h4>
                
                <p className="text-sm text-slate-400 mb-2">
                  From: <span className="text-slate-300">{email.sender}</span>
                </p>
                
                <p className="text-sm text-slate-400 mb-3 line-clamp-2">
                  {email.snippet}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1 text-xs text-slate-500">
                    <Brain className="h-3 w-3" />
                    <span>{email.aiReason}</span>
                  </div>
                  
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-indigo-400 hover:text-white hover:bg-indigo-600/20 group-hover:translate-x-1 transition-all"
                  >
                    Open
                    <ArrowRight className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              </div>
            ))}
            
            <div className="flex justify-center pt-4">
              <Button
                variant="outline"
                className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
              >
                View All Priority Emails
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
