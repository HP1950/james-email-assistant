
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Clock,
  Mail,
  Database,
  Wifi,
  Shield,
  Zap
} from 'lucide-react';

interface SystemService {
  name: string;
  status: 'operational' | 'degraded' | 'down';
  lastChecked: Date;
  description: string;
  icon: React.ElementType;
}

export function SystemStatus() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const services: SystemService[] = [
    {
      name: 'Gmail API',
      status: 'operational',
      lastChecked: new Date(Date.now() - 2 * 60 * 1000),
      description: 'Email processing and synchronization',
      icon: Mail
    },
    {
      name: 'AI Processing',
      status: 'operational',
      lastChecked: new Date(Date.now() - 1 * 60 * 1000),
      description: 'Draft generation and analysis',
      icon: Zap
    },
    {
      name: 'Database',
      status: 'operational',
      lastChecked: new Date(Date.now() - 30 * 1000),
      description: 'Data storage and retrieval',
      icon: Database
    },
    {
      name: 'Spam Detection',
      status: 'operational',
      lastChecked: new Date(Date.now() - 45 * 1000),
      description: 'Email filtering and protection',
      icon: Shield
    }
  ];

  const getStatusIcon = (status: SystemService['status']) => {
    switch (status) {
      case 'operational':
        return <CheckCircle className="h-4 w-4 text-success" />;
      case 'degraded':
        return <AlertTriangle className="h-4 w-4 text-warning" />;
      case 'down':
        return <XCircle className="h-4 w-4 text-destructive" />;
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: SystemService['status']) => {
    switch (status) {
      case 'operational':
        return <Badge variant="default" className="bg-success/10 text-success border-success/20">Operational</Badge>;
      case 'degraded':
        return <Badge variant="default" className="bg-warning/10 text-warning border-warning/20">Degraded</Badge>;
      case 'down':
        return <Badge variant="destructive">Down</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const formatTimeAgo = (date: Date) => {
    if (!mounted) return 'Loading...';
    
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    const hours = Math.floor(diffInMinutes / 60);
    if (hours < 24) return `${hours} hours ago`;
    const days = Math.floor(hours / 24);
    return `${days} days ago`;
  };

  const overallStatus = services.every(s => s.status === 'operational') 
    ? 'operational' 
    : services.some(s => s.status === 'down') 
    ? 'down' 
    : 'degraded';

  return (
    <Card className="bg-white border border-border">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getStatusIcon(overallStatus)}
            <span>System Status</span>
          </div>
          {getStatusBadge(overallStatus)}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {overallStatus === 'operational' && (
            <div className="bg-success/5 border border-success/20 rounded-lg p-4 mb-4">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-success" />
                <div>
                  <p className="text-sm font-medium text-success">All Systems Operational</p>
                  <p className="text-xs text-success/80">Your email assistant is running smoothly</p>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-3">
            <h4 className="text-sm font-medium text-foreground">Service Details</h4>
            {services.map((service) => (
              <div key={service.name} className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:bg-muted/30 transition-colors">
                <div className="flex items-center space-x-3">
                  <service.icon className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="flex items-center space-x-2">
                      <p className="text-sm font-medium text-foreground">{service.name}</p>
                      {getStatusIcon(service.status)}
                    </div>
                    <p className="text-xs text-muted-foreground">{service.description}</p>
                    <p className="text-xs text-muted-foreground">
                      Last checked {formatTimeAgo(service.lastChecked)}
                    </p>
                  </div>
                </div>
                {getStatusBadge(service.status)}
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-border">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Next check in 2 minutes</span>
              <div className="flex items-center space-x-1">
                <Wifi className="h-3 w-3" />
                <span>Auto-refresh enabled</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
