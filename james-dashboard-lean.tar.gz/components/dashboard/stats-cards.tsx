
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Mail, Clock, CheckCircle, Zap, TrendingUp, Brain } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: number;
  suffix?: string;
  icon: React.ElementType;
  color: string;
  change?: number;
  isLoading?: boolean;
}

function StatCard({ title, value, suffix = '', icon: Icon, color, change, isLoading }: StatCardProps) {
  const [animatedValue, setAnimatedValue] = useState(0);

  useEffect(() => {
    if (isLoading) return;
    
    const startTime = Date.now();
    const duration = 1500;
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const currentValue = Math.floor(easeOutQuart * value);
      
      setAnimatedValue(currentValue);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    animate();
  }, [value, isLoading]);

  return (
    <Card className="glass-dark border-slate-700 card-hover">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-400">{title}</p>
            <div className="flex items-baseline space-x-1">
              <span className={`text-3xl font-bold ${color} animate-count-up`}>
                {isLoading ? (
                  <div className="h-8 w-16 bg-slate-700 rounded animate-pulse"></div>
                ) : (
                  `${animatedValue.toLocaleString()}${suffix}`
                )}
              </span>
              {change !== undefined && !isLoading && (
                <span className={`text-sm flex items-center ${
                  change >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  <TrendingUp className={`h-3 w-3 mr-1 ${change < 0 ? 'rotate-180' : ''}`} />
                  {Math.abs(change)}%
                </span>
              )}
            </div>
          </div>
          <div className={`p-3 rounded-lg ${color.replace('text-', 'bg-').replace('400', '600/20')}`}>
            <Icon className={`h-6 w-6 ${color}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function StatsCards() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    emailsProcessed: 0,
    timeSaved: 0,
    priorityEmails: 0,
    aiActions: 0,
    responseTime: 0,
    productivity: 0
  });

  useEffect(() => {
    // Simulate API call
    const fetchStats = async () => {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      setStats({
        emailsProcessed: 247,
        timeSaved: 128,
        priorityEmails: 12,
        aiActions: 89,
        responseTime: 24,
        productivity: 94
      });
      setIsLoading(false);
    };

    fetchStats();
  }, []);

  const statCards = [
    {
      title: 'Emails Processed Today',
      value: stats.emailsProcessed,
      icon: Mail,
      color: 'text-blue-400',
      change: 12
    },
    {
      title: 'Time Saved by AI',
      value: stats.timeSaved,
      suffix: ' min',
      icon: Zap,
      color: 'text-yellow-400',
      change: 18
    },
    {
      title: 'Priority Inbox Count',
      value: stats.priorityEmails,
      icon: CheckCircle,
      color: 'text-red-400',
      change: -8
    },
    {
      title: 'AI Actions Used',
      value: stats.aiActions,
      icon: Brain,
      color: 'text-purple-400',
      change: 25
    },
    {
      title: 'Avg Response Time',
      value: stats.responseTime,
      suffix: ' min',
      icon: Clock,
      color: 'text-green-400',
      change: -15
    },
    {
      title: 'Productivity Score',
      value: stats.productivity,
      suffix: '%',
      icon: TrendingUp,
      color: 'text-indigo-400',
      change: 7
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-slide-in-bottom">
      {statCards.map((stat, index) => (
        <div
          key={stat.title}
          style={{ animationDelay: `${index * 0.1}s` }}
          className="animate-fade-in"
        >
          <StatCard
            {...stat}
            isLoading={isLoading}
          />
        </div>
      ))}
    </div>
  );
}
