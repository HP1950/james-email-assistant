
'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Activity, 
  Mail, 
  Send, 
  Eye, 
  CheckCircle, 
  Bot, 
  Zap, 
  Clock,
  AlertCircle 
} from 'lucide-react';
import { useWebSocketContext } from '@/components/websocket-provider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatDistanceToNow } from 'date-fns';

interface ActivityItem {
  id: string;
  type: 'email_received' | 'email_sent' | 'email_read' | 'task_created' | 'ai_analysis' | 'workflow_run';
  description: string;
  metadata: any;
  createdAt: Date;
  user?: {
    name: string;
    email: string;
    avatar?: string;
  };
}

const activityIcons = {
  email_received: Mail,
  email_sent: Send,
  email_read: Eye,
  task_created: CheckCircle,
  ai_analysis: Bot,
  workflow_run: Zap,
};

const activityColors = {
  email_received: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  email_sent: 'bg-green-500/10 text-green-600 border-green-500/20',
  email_read: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  task_created: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  ai_analysis: 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20',
  workflow_run: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
};

export function RealtimeActivityFeed() {
  const { websocket } = useWebSocketContext();
  const [activities, setActivities] = useState<ActivityItem[]>([
    // Demo data
    {
      id: '1',
      type: 'email_received',
      description: 'New email from client about project update',
      metadata: { emailId: 'email_1', subject: 'Project Update Required' },
      createdAt: new Date(Date.now() - 5 * 60 * 1000),
      user: { name: 'Sarah Johnson', email: 'sarah@company.com' },
    },
    {
      id: '2',
      type: 'ai_analysis',
      description: 'AI analysis completed for urgent email',
      metadata: { confidence: 0.95, priority: 'HIGH' },
      createdAt: new Date(Date.now() - 10 * 60 * 1000),
    },
  ]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    setIsConnected(websocket.state.connected);
  }, [websocket.state.connected]);

  useEffect(() => {
    if (websocket.state.connected) {
      websocket.on('activity:new', (data) => {
        const newActivity: ActivityItem = {
          id: data.activity.id,
          type: data.activity.type,
          description: data.activity.description,
          metadata: data.activity.metadata,
          createdAt: new Date(data.activity.createdAt),
        };

        setActivities(prev => [newActivity, ...prev.slice(0, 49)]); // Keep max 50 items
      });

      websocket.on('activity:bulk', (activities) => {
        const newActivities = activities.map(data => ({
          id: data.activity.id,
          type: data.activity.type,
          description: data.activity.description,
          metadata: data.activity.metadata,
          createdAt: new Date(data.activity.createdAt),
        }));

        setActivities(prev => [...newActivities, ...prev].slice(0, 50));
      });

      return () => {
        websocket.off('activity:new');
        websocket.off('activity:bulk');
      };
    }
  }, [websocket]);

  const getActivityIcon = (type: ActivityItem['type']) => {
    const Icon = activityIcons[type] || Activity;
    return Icon;
  };

  const getActivityColor = (type: ActivityItem['type']) => {
    return activityColors[type] || 'bg-gray-500/10 text-gray-600 border-gray-500/20';
  };

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Activity className="h-4 w-4" />
          Real-time Activity
        </CardTitle>
        <div className="flex items-center gap-2">
          <div className={`h-2 w-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-xs text-muted-foreground">
            {isConnected ? 'Live' : 'Disconnected'}
          </span>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px] px-6 pb-6">
          <AnimatePresence>
            {activities.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
                <Clock className="h-8 w-8 mb-2" />
                <p className="text-sm">No recent activity</p>
              </div>
            ) : (
              <div className="space-y-3">
                {activities.map((activity, index) => {
                  const Icon = getActivityIcon(activity.type);
                  const colorClass = getActivityColor(activity.type);

                  return (
                    <motion.div
                      key={activity.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-start gap-3 p-3 rounded-lg border bg-card/50 hover:bg-card transition-colors"
                    >
                      <div className={`p-2 rounded-full border ${colorClass}`}>
                        <Icon className="h-3 w-3" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <p className="text-sm font-medium text-foreground line-clamp-2">
                              {activity.description}
                            </p>
                            
                            {activity.metadata && (
                              <div className="flex items-center gap-2 mt-1">
                                {activity.metadata.priority && (
                                  <Badge 
                                    variant={activity.metadata.priority === 'HIGH' ? 'destructive' : 'secondary'}
                                    className="text-xs"
                                  >
                                    {activity.metadata.priority}
                                  </Badge>
                                )}
                                {activity.metadata.confidence && (
                                  <span className="text-xs text-muted-foreground">
                                    {Math.round(activity.metadata.confidence * 100)}% confidence
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                          
                          <div className="flex flex-col items-end gap-1">
                            <span className="text-xs text-muted-foreground">
                              {formatDistanceToNow(activity.createdAt, { addSuffix: true })}
                            </span>
                            
                            {activity.user && (
                              <div className="flex items-center gap-1">
                                <Avatar className="h-4 w-4">
                                  <AvatarImage src={activity.user.avatar} />
                                  <AvatarFallback className="text-xs">
                                    {activity.user.name.charAt(0)}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-xs text-muted-foreground">
                                  {activity.user.name}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </AnimatePresence>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
