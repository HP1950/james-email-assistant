
'use client';

import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { StatsCards } from './stats-cards';
import { PredictiveInbox } from './predictive-inbox';
import { ActivityFeed } from './activity-feed';
import { ProductivityChart } from './productivity-chart';
import { QuickActions } from './quick-actions';
import { AIInsights } from './ai-insights';

export function DashboardClient() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  if (!isLoaded) {
    return (
      <MainLayout>
        <div className="flex h-full items-center justify-center">
          <div className="flex items-center space-x-2">
            <div className="h-4 w-4 animate-pulse rounded-full bg-indigo-600"></div>
            <div className="h-4 w-4 animate-pulse rounded-full bg-indigo-600 delay-100"></div>
            <div className="h-4 w-4 animate-pulse rounded-full bg-indigo-600 delay-200"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="p-6 space-y-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400">
            AI-powered overview of your email productivity and insights
          </p>
        </div>

        {/* Stats Cards */}
        <StatsCards />

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            <PredictiveInbox />
            <ProductivityChart />
            <AIInsights />
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <QuickActions />
            <ActivityFeed />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
