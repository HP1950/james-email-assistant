
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Activity, 
  Mail, 
  Brain, 
  CheckCircle, 
  Clock, 
  Zap,
  Star,
  Archive,
  Reply,
  Forward,
  Trash2,
  Filter,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';

interface ActivityItem {
  id: string;
  type: 'email_received' | 'email_sent' | 'ai_action' | 'task_completed' | 'workflow_executed';
  title: string;
  description: string;
  timestamp: Date;
  metadata?: {
    emailId?: string;
    priority?: string;
    sentiment?: string;
    confidence?: number;
    sender?: string;
    subject?: string;
  };
  status?: 'success' | 'warning' | 'error' | 'info';
}

export function EnhancedActivityFeed() {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchActivities();
  }, []);

  const fetchActivities = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/analytics/dashboard');
      if (!response.ok) {
        throw new Error('Failed to fetch activity data');
      }
      
      const result = await response.json();
      if (result.success) {
        // Transform email data into activity feed items
        const emailActivities = result.data.recentActivity.map((email: any) => ({
          id: `email-${email.id}`,
          type: 'email_received' as const,
          title: 'New Email Received',
          description: email.subject,
          timestamp: new Date(email.receivedAt),
          metadata: {
            emailId: email.id,
            priority: email.priority,
            sentiment: email.sentiment,
            sender: email.fromName || email.fromAddress,
            subject: email.subject,
          },
          status: email.priority === 'URGENT' ? 'error' as const : 
                 email.priority === 'HIGH' ? 'warning' as const : 'info' as const,
        }));

        // Add mock AI and workflow activities
        const aiActivities = [
          {
            id: 'ai-1',
            type: 'ai_action' as const,
            title: 'Email Categorized by AI',
            description: 'Automatically categorized 5 emails as Work-related',
            timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
            metadata: { confidence: 0.95 },
            status: 'success' as const,
          },
          {
            id: 'ai-2',
            type: 'ai_action' as const,
            title: 'Smart Reply Generated',
            description: 'Generated reply for meeting invitation from Sarah',
            timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
            metadata: { confidence: 0.88 },
            status: 'success' as const,
          },
          {
            id: 'task-1',
            type: 'task_completed' as const,
            title: 'Task Completed',
            description: 'Review Q4 financial report - Marked as complete',
            timestamp: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
            status: 'success' as const,
          },
          {
            id: 'workflow-1',
            type: 'workflow_executed' as const,
            title: 'Workflow Executed',
            description: 'Auto-archived 12 newsletter emails',
            timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
            status: 'info' as const,
          },
        ];

        const allActivities = [...emailActivities, ...aiActivities]
          .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
          .slice(0, 20); // Limit to 20 most recent

        setActivities(allActivities);
      } else {
        throw new Error(result.error || 'Failed to fetch data');
      }
    } catch (error) {
      console.error('Failed to fetch activities:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      
      // Fallback to mock data
      const mockActivities: ActivityItem[] = [
        {
          id: '1',
          type: 'email_received',
          title: 'High Priority Email',
          description: 'Q4 Financial Report - Action Required',
          timestamp: new Date(Date.now() - 1000 * 60 * 5),
          metadata: {
            priority: 'HIGH',
            sentiment: 'NEUTRAL',
            sender: 'Sarah Chen',
            subject: 'Q4 Financial Report - Action Required',
          },
          status: 'warning',
        },
        {
          id: '2',
          type: 'ai_action',
          title: 'AI Analysis Complete',
          description: 'Analyzed sentiment and priority for 3 new emails',
          timestamp: new Date(Date.now() - 1000 * 60 * 10),
          metadata: { confidence: 0.94 },
          status: 'success',
        },
        {
          id: '3',
          type: 'email_received',
          title: 'Security Alert',
          description: 'New login detected from unknown device',
          timestamp: new Date(Date.now() - 1000 * 60 * 15),
          metadata: {
            priority: 'URGENT',
            sentiment: 'NEGATIVE',
            sender: 'Security Team',
          },
          status: 'error',
        },
        {
          id: '4',
          type: 'task_completed',
          title: 'Task Completed',
          description: 'Follow up with client about project timeline',
          timestamp: new Date(Date.now() - 1000 * 60 * 20),
          status: 'success',
        },
        {
          id: '5',
          type: 'workflow_executed',
          title: 'Workflow Executed',
          description: 'Auto-categorized 15 promotional emails',
          timestamp: new Date(Date.now() - 1000 * 60 * 30),
          status: 'info',
        },
        {
          id: '6',
          type: 'ai_action',
          title: 'Smart Reply Generated',
          description: 'Generated professional reply for meeting request',
          timestamp: new Date(Date.now() - 1000 * 60 * 35),
          metadata: { confidence: 0.89 },
          status: 'success',
        },
      ];
      
      setActivities(mockActivities);
    } finally {
      setIsLoading(false);
    }
  };

  const getActivityIcon = (type: ActivityItem['type']) => {
    switch (type) {
      case 'email_received':
      case 'email_sent':
        return Mail;
      case 'ai_action':
        return Brain;
      case 'task_completed':
        return CheckCircle;
      case 'workflow_executed':
        return Zap;
      default:
        return Activity;
    }
  };

  const getActivityColor = (status: ActivityItem['status']) => {
    switch (status) {
      case 'success':
        return 'text-green-400';
      case 'warning':
        return 'text-yellow-400';
      case 'error':
        return 'text-red-400';
      case 'info':
      default:
        return 'text-blue-400';
    }
  };

  const getStatusBadgeColor = (status: ActivityItem['status']) => {
    switch (status) {
      case 'success':
        return 'bg-green-600/20 text-green-400 border-green-600/30';
      case 'warning':
        return 'bg-yellow-600/20 text-yellow-400 border-yellow-600/30';
      case 'error':
        return 'bg-red-600/20 text-red-400 border-red-600/30';
      case 'info':
      default:
        return 'bg-blue-600/20 text-blue-400 border-blue-600/30';
    }
  };

  const activityTypes = [
    { value: 'all', label: 'All Activities' },
    { value: 'email_received', label: 'Emails' },
    { value: 'ai_action', label: 'AI Actions' },
    { value: 'task_completed', label: 'Tasks' },
    { value: 'workflow_executed', label: 'Workflows' },
  ];

  const filteredActivities = filter === 'all' 
    ? activities 
    : activities.filter(activity => activity.type === filter);

  if (isLoading) {
    return (
      <Card className="glass-dark border-slate-700">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Activity className="h-5 w-5 text-green-400" />
            <CardTitle className="text-xl text-white">Activity Feed</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-start space-x-3">
                  <div className="h-8 w-8 bg-slate-700 rounded-full shrink-0"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                    <div className="h-3 bg-slate-700 rounded w-1/2"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="glass-dark border-slate-700 hover:border-slate-600 transition-all duration-300">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-green-400" />
              <CardTitle className="text-xl text-white">Activity Feed</CardTitle>
              <Badge className="bg-green-600/20 text-green-400">
                Real-time
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={fetchActivities}
                className="border-slate-600 text-slate-400 hover:text-white"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {error && (
            <div className="mt-3 p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
              <p className="text-amber-400 text-sm">⚠️ Using demo data: {error}</p>
            </div>
          )}

          {/* Activity Type Filter */}
          <div className="flex items-center space-x-2 mt-4 overflow-x-auto">
            {activityTypes.map((type) => (
              <Button
                key={type.value}
                size="sm"
                variant={filter === type.value ? "default" : "ghost"}
                onClick={() => setFilter(type.value)}
                className={`shrink-0 ${
                  filter === type.value
                    ? "bg-slate-700 text-white"
                    : "text-slate-400 hover:text-white hover:bg-slate-700"
                }`}
              >
                {type.label}
                <Badge variant="secondary" className="ml-2 bg-slate-600 text-white">
                  {type.value === 'all' 
                    ? activities.length 
                    : activities.filter(a => a.type === type.value).length
                  }
                </Badge>
              </Button>
            ))}
          </div>
        </CardHeader>

        <CardContent>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            <AnimatePresence>
              {filteredActivities.map((activity, index) => {
                const Icon = getActivityIcon(activity.type);
                const activityColor = getActivityColor(activity.status);
                
                return (
                  <motion.div
                    key={activity.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-start space-x-3 p-3 bg-slate-800/30 rounded-lg border border-slate-700/50 hover:bg-slate-700/30 transition-all duration-200 group"
                  >
                    <div className={`p-2 rounded-full bg-slate-800 ${activityColor} shrink-0`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium text-white truncate">
                          {activity.title}
                        </h4>
                        <div className="flex items-center space-x-2 shrink-0">
                          {activity.metadata?.confidence && (
                            <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                              {Math.round(activity.metadata.confidence * 100)}% confidence
                            </Badge>
                          )}
                          {activity.metadata?.priority && (
                            <Badge className={`text-xs ${
                              activity.metadata.priority === 'URGENT' ? 'bg-red-600/20 text-red-400' :
                              activity.metadata.priority === 'HIGH' ? 'bg-orange-600/20 text-orange-400' :
                              'bg-yellow-600/20 text-yellow-400'
                            }`}>
                              {activity.metadata.priority}
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <p className="text-sm text-slate-400 truncate mb-2">
                        {activity.description}
                      </p>
                      
                      {activity.metadata?.sender && (
                        <p className="text-xs text-slate-500 mb-1">
                          From: {activity.metadata.sender}
                        </p>
                      )}
                      
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-500">
                          {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
                        </span>
                        
                        {activity.status && (
                          <Badge className={`text-xs ${getStatusBadgeColor(activity.status)}`}>
                            {activity.status}
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    {/* Quick Action Button */}
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 shrink-0">
                      {activity.type === 'email_received' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 w-8 p-0 text-slate-400 hover:text-blue-400"
                        >
                          <Reply className="h-4 w-4" />
                        </Button>
                      )}
                      {activity.type === 'ai_action' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 w-8 p-0 text-slate-400 hover:text-purple-400"
                        >
                          <Brain className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
            
            {filteredActivities.length === 0 && (
              <div className="text-center py-8">
                <Activity className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400 text-sm">No activities found</p>
              </div>
            )}
          </div>
          
          <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
            <span>{filteredActivities.length} activities</span>
            <span>Auto-refreshes every 30 seconds</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
