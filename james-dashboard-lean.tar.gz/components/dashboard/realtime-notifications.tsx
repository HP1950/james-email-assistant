
'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, 
  X, 
  AlertTriangle, 
  Info, 
  CheckCircle, 
  AlertCircle,
  Settings,
  BellOff 
} from 'lucide-react';
import { useWebSocketNotifications } from '@/components/websocket-provider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { formatDistanceToNow } from 'date-fns';

const notificationIcons = {
  email: Bell,
  task: CheckCircle,
  system: AlertCircle,
  collaboration: Info,
};

const priorityColors = {
  urgent: 'bg-red-500/10 text-red-600 border-red-500/20',
  high: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  medium: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  low: 'bg-gray-500/10 text-gray-600 border-gray-500/20',
};

export function RealtimeNotifications() {
  const { 
    notifications, 
    unreadCount, 
    settings, 
    markAsRead, 
    clearAll, 
    updateSettings,
    connected 
  } = useWebSocketNotifications();
  
  const [showSettings, setShowSettings] = useState(false);

  const handleNotificationClick = (notificationId: string, actionUrl?: string) => {
    markAsRead(notificationId);
    if (actionUrl) {
      window.open(actionUrl, '_blank');
    }
  };

  const recentNotifications = notifications.slice(0, 5);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <div className="relative">
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <div className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full" />
            )}
          </div>
          Notifications
          {unreadCount > 0 && (
            <Badge variant="destructive" className="text-xs">
              {unreadCount}
            </Badge>
          )}
        </CardTitle>
        
        <div className="flex items-center gap-2">
          <Popover open={showSettings} onOpenChange={setShowSettings}>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="sm">
                <Settings className="h-3 w-3" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-4">
                <h4 className="font-medium">Notification Settings</h4>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Email Notifications</span>
                    <Switch
                      checked={settings.emailNotifications}
                      onCheckedChange={(checked) => 
                        updateSettings({ emailNotifications: checked })
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Push Notifications</span>
                    <Switch
                      checked={settings.pushNotifications}
                      onCheckedChange={(checked) => 
                        updateSettings({ pushNotifications: checked })
                      }
                    />
                  </div>
                </div>
                
                <div className="pt-2 border-t">
                  <h5 className="text-sm font-medium mb-2">Notification Types</h5>
                  <div className="space-y-2">
                    {['email', 'task', 'system', 'collaboration'].map((type) => (
                      <div key={type} className="flex items-center justify-between">
                        <span className="text-sm capitalize">{type}</span>
                        <Switch
                          checked={settings.enabledTypes.includes(type)}
                          onCheckedChange={(checked) => {
                            const newTypes = checked
                              ? [...settings.enabledTypes, type]
                              : settings.enabledTypes.filter(t => t !== type);
                            updateSettings({ enabledTypes: newTypes });
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>
          
          {notifications.length > 0 && (
            <Button variant="ghost" size="sm" onClick={clearAll}>
              <X className="h-3 w-3" />
            </Button>
          )}
          
          <div className={`h-2 w-2 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'}`} />
        </div>
      </CardHeader>
      
      <CardContent>
        {!connected ? (
          <div className="flex items-center justify-center h-32 text-muted-foreground">
            <div className="text-center">
              <BellOff className="h-8 w-8 mx-auto mb-2" />
              <p className="text-sm">Notifications disconnected</p>
            </div>
          </div>
        ) : recentNotifications.length === 0 ? (
          <div className="flex items-center justify-center h-32 text-muted-foreground">
            <div className="text-center">
              <Bell className="h-8 w-8 mx-auto mb-2" />
              <p className="text-sm">No new notifications</p>
            </div>
          </div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="space-y-3">
              <AnimatePresence>
                {recentNotifications.map((notification, index) => {
                  const Icon = notificationIcons[notification.type as keyof typeof notificationIcons] || Bell;
                  const priorityColor = priorityColors[notification.priority as keyof typeof priorityColors];
                  
                  return (
                    <motion.div
                      key={notification.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ delay: index * 0.05 }}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors hover:bg-card/80 ${
                        priorityColor
                      }`}
                      onClick={() => handleNotificationClick(notification.id, notification.actionUrl)}
                    >
                      <div className="flex items-start gap-3">
                        <Icon className="h-4 w-4 mt-0.5 flex-shrink-0" />
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <h4 className="text-sm font-medium line-clamp-1">
                                {notification.title}
                              </h4>
                              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                                {notification.message}
                              </p>
                            </div>
                            
                            <div className="flex flex-col items-end gap-1">
                              <Badge variant="outline" className="text-xs">
                                {notification.priority}
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                {formatDistanceToNow(new Date(), { addSuffix: true })}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
