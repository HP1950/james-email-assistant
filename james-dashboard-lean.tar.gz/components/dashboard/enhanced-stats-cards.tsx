
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Mail, Clock, CheckCircle, Zap, TrendingUp, Brain, Activity, Target } from 'lucide-react';
import { motion } from 'framer-motion';

interface StatCardProps {
  title: string;
  value: number;
  suffix?: string;
  icon: React.ElementType;
  color: string;
  change?: number;
  isLoading?: boolean;
  description?: string;
}

function StatCard({ title, value, suffix = '', icon: Icon, color, change, isLoading, description }: StatCardProps) {
  const [animatedValue, setAnimatedValue] = useState(0);

  useEffect(() => {
    if (isLoading) return;
    
    const startTime = Date.now();
    const duration = 1500;
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const currentValue = Math.floor(easeOutQuart * value);
      
      setAnimatedValue(currentValue);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    animate();
  }, [value, isLoading]);

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <Card className="glass-dark border-slate-700 card-hover overflow-hidden group">
        <CardContent className="p-6 relative">
          {/* Background gradient effect */}
          <div className={`absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity duration-300 ${color.replace('text-', 'bg-').replace('400', '600')}`} />
          
          <div className="flex items-center justify-between relative z-10">
            <div className="space-y-2 flex-1">
              <p className="text-sm font-medium text-slate-400">{title}</p>
              {description && (
                <p className="text-xs text-slate-500">{description}</p>
              )}
              <div className="flex items-baseline space-x-2">
                <motion.span 
                  className={`text-3xl font-bold ${color}`}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                >
                  {isLoading ? (
                    <div className="h-8 w-16 bg-slate-700 rounded animate-pulse"></div>
                  ) : (
                    `${animatedValue.toLocaleString()}${suffix}`
                  )}
                </motion.span>
                {change !== undefined && !isLoading && (
                  <motion.span 
                    className={`text-sm flex items-center px-2 py-1 rounded-full ${
                      change >= 0 
                        ? 'text-green-400 bg-green-400/10' 
                        : 'text-red-400 bg-red-400/10'
                    }`}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    <TrendingUp className={`h-3 w-3 mr-1 ${change < 0 ? 'rotate-180' : ''}`} />
                    {Math.abs(change)}%
                  </motion.span>
                )}
              </div>
            </div>
            <motion.div 
              className={`p-3 rounded-xl ${color.replace('text-', 'bg-').replace('400', '600/10')} group-hover:scale-110 transition-transform duration-300`}
              whileHover={{ rotate: [0, -10, 10, 0] }}
              transition={{ duration: 0.5 }}
            >
              <Icon className={`h-6 w-6 ${color}`} />
            </motion.div>
          </div>
          
          {/* Subtle animated border */}
          <motion.div
            className={`absolute inset-x-0 bottom-0 h-0.5 ${color.replace('text-', 'bg-')} opacity-0 group-hover:opacity-100`}
            layoutId="border"
            transition={{ duration: 0.3 }}
          />
        </CardContent>
      </Card>
    </motion.div>
  );
}

export function EnhancedStatsCards() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    emailsProcessed: 0,
    timeSaved: 0,
    priorityEmails: 0,
    aiActions: 0,
    responseTime: 0,
    productivity: 0,
    totalEmails: 0,
    avgConfidence: 0
  });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/analytics/dashboard?period=7d');
      if (!response.ok) {
        throw new Error('Failed to fetch dashboard stats');
      }
      
      const result = await response.json();
      if (result.success) {
        const { overview } = result.data;
        setStats({
          emailsProcessed: overview.processedEmails,
          timeSaved: overview.timeSaved,
          priorityEmails: overview.highPriorityEmails,
          aiActions: overview.aiActionsUsed,
          responseTime: overview.avgResponseTime,
          productivity: overview.productivityScore,
          totalEmails: overview.totalEmails,
          avgConfidence: overview.avgConfidence,
        });
      } else {
        throw new Error(result.error || 'Failed to fetch stats');
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      
      // Fallback to demo data
      setStats({
        emailsProcessed: 247,
        timeSaved: 128,
        priorityEmails: 12,
        aiActions: 89,
        responseTime: 24,
        productivity: 94,
        totalEmails: 268,
        avgConfidence: 87,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const statCards = [
    {
      title: 'Emails Processed Today',
      value: stats.emailsProcessed,
      icon: Mail,
      color: 'text-blue-400',
      change: 12,
      description: `${stats.totalEmails} total received`
    },
    {
      title: 'Time Saved by AI',
      value: stats.timeSaved,
      suffix: ' min',
      icon: Zap,
      color: 'text-yellow-400',
      change: 18,
      description: 'Automated processing'
    },
    {
      title: 'Priority Inbox Count',
      value: stats.priorityEmails,
      icon: CheckCircle,
      color: 'text-red-400',
      change: -8,
      description: 'Requires attention'
    },
    {
      title: 'AI Actions Used',
      value: stats.aiActions,
      icon: Brain,
      color: 'text-purple-400',
      change: 25,
      description: 'Smart suggestions & analysis'
    },
    {
      title: 'Avg Response Time',
      value: stats.responseTime,
      suffix: ' min',
      icon: Clock,
      color: 'text-green-400',
      change: -15,
      description: 'Faster than yesterday'
    },
    {
      title: 'Productivity Score',
      value: stats.productivity,
      suffix: '%',
      icon: Target,
      color: 'text-indigo-400',
      change: 7,
      description: `${stats.avgConfidence}% AI confidence`
    }
  ];

  return (
    <div className="space-y-4">
      {error && (
        <motion.div 
          className="p-3 bg-amber-900/20 border border-amber-800 rounded-lg"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <p className="text-amber-400 text-sm">⚠️ Using demo data: {error}</p>
        </motion.div>
      )}
      
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ staggerChildren: 0.1 }}
      >
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <StatCard
              {...stat}
              isLoading={isLoading}
            />
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
