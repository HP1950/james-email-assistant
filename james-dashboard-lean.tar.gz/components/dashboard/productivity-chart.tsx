
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BarChart3, TrendingUp, Download, Calendar } from 'lucide-react';

interface ChartData {
  date: string;
  emailsReceived: number;
  emailsProcessed: number;
  aiActions: number;
  responseTime: number;
}

export function ProductivityChart() {
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState<ChartData[]>([]);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('7d');

  useEffect(() => {
    const fetchChartData = async () => {
      setIsLoading(true);
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const mockData: ChartData[] = [
        { date: 'Jan 1', emailsReceived: 45, emailsProcessed: 42, aiActions: 28, responseTime: 35 },
        { date: 'Jan 2', emailsReceived: 52, emailsProcessed: 48, aiActions: 35, responseTime: 32 },
        { date: 'Jan 3', emailsReceived: 38, emailsProcessed: 36, aiActions: 24, responseTime: 28 },
        { date: 'Jan 4', emailsReceived: 61, emailsProcessed: 58, aiActions: 42, responseTime: 38 },
        { date: 'Jan 5', emailsReceived: 55, emailsProcessed: 52, aiActions: 38, responseTime: 30 },
        { date: 'Jan 6', emailsReceived: 48, emailsProcessed: 45, aiActions: 32, responseTime: 25 },
        { date: 'Jan 7', emailsReceived: 42, emailsProcessed: 40, aiActions: 29, responseTime: 24 }
      ];
      
      setData(mockData);
      setIsLoading(false);
    };

    fetchChartData();
  }, [timeRange]);

  const totalEmails = data.reduce((sum, item) => sum + item.emailsReceived, 0);
  const totalProcessed = data.reduce((sum, item) => sum + item.emailsProcessed, 0);
  const efficiencyRate = totalEmails > 0 ? Math.round((totalProcessed / totalEmails) * 100) : 0;
  const avgResponseTime = data.length > 0 ? Math.round(data.reduce((sum, item) => sum + item.responseTime, 0) / data.length) : 0;

  const timeRangeOptions = [
    { value: '7d' as const, label: '7 Days' },
    { value: '30d' as const, label: '30 Days' },
    { value: '90d' as const, label: '90 Days' }
  ];

  if (isLoading) {
    return (
      <Card className="glass-dark border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-blue-400" />
              <CardTitle className="text-xl text-white">Productivity Analytics</CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-80 flex items-center justify-center">
            <div className="flex items-center space-x-2">
              <div className="spinner h-6 w-6"></div>
              <span className="text-slate-400">Loading analytics...</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-dark border-slate-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BarChart3 className="h-5 w-5 text-blue-400" />
            <CardTitle className="text-xl text-white">Productivity Analytics</CardTitle>
          </div>
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              {timeRangeOptions.map((option) => (
                <Button
                  key={option.value}
                  size="sm"
                  variant={timeRange === option.value ? "default" : "outline"}
                  onClick={() => setTimeRange(option.value)}
                  className={
                    timeRange === option.value
                      ? "bg-indigo-600 hover:bg-indigo-700 text-white"
                      : "border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
                  }
                >
                  {option.label}
                </Button>
              ))}
            </div>
            <Button
              size="sm"
              variant="outline"
              className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
        
        {/* Key Metrics */}
        <div className="grid grid-cols-3 gap-4 mt-4">
          <div className="text-center p-3 bg-slate-800/50 rounded-lg">
            <p className="text-sm text-slate-400">Efficiency Rate</p>
            <p className="text-2xl font-bold text-green-400">{efficiencyRate}%</p>
            <div className="flex items-center justify-center text-xs text-green-400 mt-1">
              <TrendingUp className="h-3 w-3 mr-1" />
              +5% from last period
            </div>
          </div>
          
          <div className="text-center p-3 bg-slate-800/50 rounded-lg">
            <p className="text-sm text-slate-400">Avg Response Time</p>
            <p className="text-2xl font-bold text-blue-400">{avgResponseTime}m</p>
            <div className="flex items-center justify-center text-xs text-blue-400 mt-1">
              <TrendingUp className="h-3 w-3 mr-1 rotate-180" />
              -12% improvement
            </div>
          </div>
          
          <div className="text-center p-3 bg-slate-800/50 rounded-lg">
            <p className="text-sm text-slate-400">Total Processed</p>
            <p className="text-2xl font-bold text-purple-400">{totalProcessed}</p>
            <div className="flex items-center justify-center text-xs text-purple-400 mt-1">
              <TrendingUp className="h-3 w-3 mr-1" />
              +18% from last period
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="h-80 flex items-center justify-center">
          <div className="text-center">
            <BarChart3 className="h-16 w-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400 mb-2">Interactive Chart</p>
            <p className="text-sm text-slate-500">
              Chart visualization will render with recharts library
            </p>
          </div>
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Badge className="bg-blue-600/20 text-blue-400 border-blue-600/30">
              <Calendar className="h-3 w-3 mr-1" />
              Last {timeRange === '7d' ? '7 days' : timeRange === '30d' ? '30 days' : '90 days'}
            </Badge>
          </div>
          
          <p className="text-xs text-slate-500">
            Data refreshed every 5 minutes • Last updated: Just now
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
