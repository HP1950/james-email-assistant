
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Plus, 
  Mic, 
  Workflow, 
  Users, 
  Settings, 
  Zap,
  Brain,
  BarChart3,
  Shield,
  Search
} from 'lucide-react';
import { toast } from 'sonner';

export function QuickActions() {
  const [isVoiceActive, setIsVoiceActive] = useState(false);

  const handleComposeEmail = () => {
    toast.success('Opening AI-powered email composer...');
    // TODO: Open compose modal
  };

  const handleVoiceCommand = () => {
    setIsVoiceActive(!isVoiceActive);
    if (!isVoiceActive) {
      toast.info('Voice command activated. Listening...');
      // TODO: Activate voice recognition
      setTimeout(() => {
        setIsVoiceActive(false);
        toast.success('Voice command processed: "Show priority emails"');
      }, 3000);
    } else {
      toast.info('Voice command deactivated.');
    }
  };

  const handleCreateWorkflow = () => {
    toast.success('Opening workflow builder...');
    // TODO: Navigate to workflow builder
  };

  const handleAIInsights = () => {
    toast.success('Generating AI insights...');
    // TODO: Open AI insights modal
  };

  const quickActions = [
    {
      title: 'Compose Email',
      description: 'AI-powered composition',
      icon: Plus,
      color: 'bg-indigo-600 hover:bg-indigo-700',
      action: handleComposeEmail
    },
    {
      title: 'Voice Command',
      description: 'Hands-free control',
      icon: Mic,
      color: isVoiceActive 
        ? 'bg-red-600 hover:bg-red-700 animate-pulse' 
        : 'bg-green-600 hover:bg-green-700',
      action: handleVoiceCommand
    },
    {
      title: 'Create Workflow',
      description: 'Automate processes',
      icon: Workflow,
      color: 'bg-purple-600 hover:bg-purple-700',
      action: handleCreateWorkflow
    },
    {
      title: 'AI Insights',
      description: 'Smart recommendations',
      icon: Brain,
      color: 'bg-blue-600 hover:bg-blue-700',
      action: handleAIInsights
    }
  ];

  const shortcuts = [
    { label: 'Search Emails', icon: Search, shortcut: 'Ctrl+K' },
    { label: 'View Analytics', icon: BarChart3, shortcut: 'Ctrl+A' },
    { label: 'Manage Contacts', icon: Users, shortcut: 'Ctrl+C' },
    { label: 'Security Center', icon: Shield, shortcut: 'Ctrl+S' },
    { label: 'Settings', icon: Settings, shortcut: 'Ctrl+,' }
  ];

  return (
    <Card className="glass-dark border-slate-700">
      <CardHeader className="pb-4">
        <div className="flex items-center space-x-2">
          <Zap className="h-5 w-5 text-yellow-400" />
          <CardTitle className="text-xl text-white">Quick Actions</CardTitle>
        </div>
        <p className="text-sm text-slate-400">
          Instant access to AI-powered features
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Primary Actions */}
        <div className="grid grid-cols-2 gap-3">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Button
                key={action.title}
                onClick={action.action}
                className={`${action.color} text-white p-4 h-auto flex flex-col items-center space-y-2 btn-glow animate-slide-in-bottom`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <Icon className="h-6 w-6" />
                <div className="text-center">
                  <p className="font-medium text-sm">{action.title}</p>
                  <p className="text-xs opacity-80">{action.description}</p>
                </div>
              </Button>
            );
          })}
        </div>

        {/* Keyboard Shortcuts */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-white flex items-center">
            <Settings className="h-4 w-4 mr-2 text-slate-400" />
            Keyboard Shortcuts
          </h4>
          
          <div className="space-y-2">
            {shortcuts.map((shortcut, index) => {
              const Icon = shortcut.icon;
              return (
                <div
                  key={shortcut.label}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-all duration-200 animate-fade-in"
                  style={{ animationDelay: `${(index + 4) * 0.05}s` }}
                >
                  <div className="flex items-center space-x-2">
                    <Icon className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-300">{shortcut.label}</span>
                  </div>
                  <kbd className="px-2 py-1 text-xs bg-slate-700 text-slate-300 rounded border border-slate-600">
                    {shortcut.shortcut}
                  </kbd>
                </div>
              );
            })}
          </div>
        </div>

        {/* Status Indicators */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-white">System Status</h4>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm text-slate-300">AI Processing</span>
              </div>
              <span className="text-xs text-green-400">Active</span>
            </div>
            
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span className="text-sm text-slate-300">Email Sync</span>
              </div>
              <span className="text-xs text-blue-400">Connected</span>
            </div>
            
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                <span className="text-sm text-slate-300">Voice Commands</span>
              </div>
              <span className="text-xs text-purple-400">
                {isVoiceActive ? 'Listening' : 'Ready'}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
