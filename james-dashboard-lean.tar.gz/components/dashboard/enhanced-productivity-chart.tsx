
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BarChart3, TrendingUp, Download, Calendar, Activity, Clock, Zap } from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Area,
  AreaChart,
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

interface ChartData {
  date: string;
  emailsReceived: number;
  emailsProcessed: number;
  aiActions: number;
  responseTime: number;
  timeSaved: number;
}

interface ProductivityMetrics {
  totalEmails: number;
  processedEmails: number;
  avgResponseTime: number;
  timeSaved: number;
  productivityScore: number;
}

export function EnhancedProductivityChart() {
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState<ChartData[]>([]);
  const [metrics, setMetrics] = useState<ProductivityMetrics | null>(null);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('7d');
  const [activeChart, setActiveChart] = useState<'overview' | 'productivity' | 'ai'>('overview');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchChartData();
  }, [timeRange]);

  const fetchChartData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch(`/api/analytics/dashboard?period=${timeRange}`);
      if (!response.ok) {
        throw new Error('Failed to fetch analytics data');
      }
      
      const result = await response.json();
      if (result.success) {
        setData(result.data.chartData);
        setMetrics({
          totalEmails: result.data.overview.totalEmails,
          processedEmails: result.data.overview.processedEmails,
          avgResponseTime: result.data.overview.avgResponseTime,
          timeSaved: result.data.overview.timeSaved,
          productivityScore: result.data.overview.productivityScore,
        });
      } else {
        throw new Error(result.error || 'Failed to fetch data');
      }
    } catch (error) {
      console.error('Failed to fetch chart data:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      
      // Fallback to mock data for demo
      const mockData: ChartData[] = [
        { date: 'Jan 1', emailsReceived: 45, emailsProcessed: 42, aiActions: 28, responseTime: 35, timeSaved: 65 },
        { date: 'Jan 2', emailsReceived: 52, emailsProcessed: 48, aiActions: 35, responseTime: 32, timeSaved: 78 },
        { date: 'Jan 3', emailsReceived: 38, emailsProcessed: 36, aiActions: 24, responseTime: 28, timeSaved: 52 },
        { date: 'Jan 4', emailsReceived: 61, emailsProcessed: 58, aiActions: 42, responseTime: 38, timeSaved: 89 },
        { date: 'Jan 5', emailsReceived: 55, emailsProcessed: 52, aiActions: 38, responseTime: 30, timeSaved: 72 },
        { date: 'Jan 6', emailsReceived: 48, emailsProcessed: 45, aiActions: 32, responseTime: 25, timeSaved: 68 },
        { date: 'Jan 7', emailsReceived: 42, emailsProcessed: 40, aiActions: 29, responseTime: 24, timeSaved: 58 }
      ];
      
      setData(mockData);
      setMetrics({
        totalEmails: 341,
        processedEmails: 321,
        avgResponseTime: 30,
        timeSaved: 482,
        productivityScore: 94,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const timeRangeOptions = [
    { value: '7d' as const, label: '7 Days' },
    { value: '30d' as const, label: '30 Days' },
    { value: '90d' as const, label: '90 Days' }
  ];

  const chartTypes = [
    { value: 'overview' as const, label: 'Overview', icon: BarChart3 },
    { value: 'productivity' as const, label: 'Productivity', icon: TrendingUp },
    { value: 'ai' as const, label: 'AI Usage', icon: Zap },
  ];

  const efficiencyRate = metrics ? Math.round((metrics.processedEmails / metrics.totalEmails) * 100) : 0;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-slate-800/95 backdrop-blur-sm border border-slate-700 rounded-lg p-3 shadow-xl"
        >
          <p className="text-slate-300 text-sm font-medium mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value}
              {entry.dataKey === 'responseTime' ? ' min' : 
               entry.dataKey === 'timeSaved' ? ' min' : ''}
            </p>
          ))}
        </motion.div>
      );
    }
    return null;
  };

  if (isLoading) {
    return (
      <Card className="glass-dark border-slate-700">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <BarChart3 className="h-5 w-5 text-blue-400" />
            <CardTitle className="text-xl text-white">Productivity Analytics</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-80 flex items-center justify-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="h-8 w-8 border-2 border-blue-400 border-t-transparent rounded-full"
            />
            <span className="text-slate-400 ml-3">Loading analytics...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  const renderChart = () => {
    switch (activeChart) {
      case 'overview':
        return (
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={data}>
              <defs>
                <linearGradient id="emailsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#60A5FA" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#60A5FA" stopOpacity={0.05}/>
                </linearGradient>
                <linearGradient id="processedGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#34D399" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#34D399" stopOpacity={0.05}/>
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="date" 
                tickLine={false}
                tick={{ fontSize: 10, fill: '#94A3B8' }}
                axisLine={false}
              />
              <YAxis 
                tickLine={false}
                tick={{ fontSize: 10, fill: '#94A3B8' }}
                axisLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ fontSize: 11 }}
                iconType="circle"
              />
              <Area
                type="monotone"
                dataKey="emailsReceived"
                stackId="1"
                stroke="#60A5FA"
                fill="url(#emailsGradient)"
                strokeWidth={2}
                name="Emails Received"
              />
              <Area
                type="monotone"
                dataKey="emailsProcessed"
                stackId="2"
                stroke="#34D399"
                fill="url(#processedGradient)"
                strokeWidth={2}
                name="Emails Processed"
              />
            </AreaChart>
          </ResponsiveContainer>
        );
      
      case 'productivity':
        return (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <XAxis 
                dataKey="date" 
                tickLine={false}
                tick={{ fontSize: 10, fill: '#94A3B8' }}
                axisLine={false}
              />
              <YAxis 
                tickLine={false}
                tick={{ fontSize: 10, fill: '#94A3B8' }}
                axisLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Line
                type="monotone"
                dataKey="responseTime"
                stroke="#F59E0B"
                strokeWidth={3}
                dot={{ fill: '#F59E0B', strokeWidth: 2, r: 4 }}
                name="Response Time (min)"
                connectNulls
              />
              <Line
                type="monotone"
                dataKey="timeSaved"
                stroke="#8B5CF6"
                strokeWidth={3}
                dot={{ fill: '#8B5CF6', strokeWidth: 2, r: 4 }}
                name="Time Saved (min)"
                connectNulls
              />
            </LineChart>
          </ResponsiveContainer>
        );
      
      case 'ai':
        return (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <XAxis 
                dataKey="date" 
                tickLine={false}
                tick={{ fontSize: 10, fill: '#94A3B8' }}
                axisLine={false}
              />
              <YAxis 
                tickLine={false}
                tick={{ fontSize: 10, fill: '#94A3B8' }}
                axisLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar
                dataKey="aiActions"
                fill="#EC4899"
                radius={[4, 4, 0, 0]}
                name="AI Actions"
              />
            </BarChart>
          </ResponsiveContainer>
        );
      
      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glass-dark border-slate-700 hover:border-slate-600 transition-all duration-300">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-blue-400" />
              <CardTitle className="text-xl text-white">Productivity Analytics</CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                {timeRangeOptions.map((option) => (
                  <Button
                    key={option.value}
                    size="sm"
                    variant={timeRange === option.value ? "default" : "outline"}
                    onClick={() => setTimeRange(option.value)}
                    className={
                      timeRange === option.value
                        ? "bg-indigo-600 hover:bg-indigo-700 text-white"
                        : "border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
                    }
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
              <Button
                size="sm"
                variant="outline"
                className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
                onClick={() => {/* TODO: Implement export */}}
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
          
          {/* Chart Type Selector */}
          <div className="flex items-center space-x-2 mt-4">
            {chartTypes.map((type) => {
              const Icon = type.icon;
              return (
                <Button
                  key={type.value}
                  size="sm"
                  variant={activeChart === type.value ? "default" : "ghost"}
                  onClick={() => setActiveChart(type.value)}
                  className={
                    activeChart === type.value
                      ? "bg-slate-700 text-white"
                      : "text-slate-400 hover:text-white hover:bg-slate-700"
                  }
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {type.label}
                </Button>
              );
            })}
          </div>
          
          {/* Key Metrics */}
          {metrics && (
            <motion.div 
              className="grid grid-cols-3 gap-4 mt-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <div className="text-center p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                <p className="text-sm text-slate-400">Efficiency Rate</p>
                <p className="text-2xl font-bold text-green-400">{efficiencyRate}%</p>
                <div className="flex items-center justify-center text-xs text-green-400 mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +5% from last period
                </div>
              </div>
              
              <div className="text-center p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                <p className="text-sm text-slate-400">Avg Response Time</p>
                <p className="text-2xl font-bold text-blue-400">{metrics.avgResponseTime}m</p>
                <div className="flex items-center justify-center text-xs text-blue-400 mt-1">
                  <Clock className="h-3 w-3 mr-1" />
                  -12% improvement
                </div>
              </div>
              
              <div className="text-center p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                <p className="text-sm text-slate-400">Productivity Score</p>
                <p className="text-2xl font-bold text-purple-400">{metrics.productivityScore}</p>
                <div className="flex items-center justify-center text-xs text-purple-400 mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +7% from last period
                </div>
              </div>
            </motion.div>
          )}
        </CardHeader>
        
        <CardContent>
          {error && (
            <div className="mb-4 p-3 bg-red-900/20 border border-red-800 rounded-lg">
              <p className="text-red-400 text-sm">⚠️ Using demo data: {error}</p>
            </div>
          )}
          
          <AnimatePresence mode="wait">
            <motion.div
              key={activeChart}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderChart()}
            </motion.div>
          </AnimatePresence>
          
          <div className="mt-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Badge className="bg-blue-600/20 text-blue-400 border-blue-600/30">
                <Calendar className="h-3 w-3 mr-1" />
                Last {timeRange === '7d' ? '7 days' : timeRange === '30d' ? '30 days' : '90 days'}
              </Badge>
            </div>
            
            <p className="text-xs text-slate-500">
              Data refreshed every 5 minutes • Last updated: Just now
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
