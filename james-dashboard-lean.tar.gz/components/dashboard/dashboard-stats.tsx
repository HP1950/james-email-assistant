
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Mail, 
  MailCheck, 
  Trash2, 
  Zap,
  TrendingUp
} from 'lucide-react';
import Link from 'next/link';

interface StatCard {
  title: string;
  value: number;
  iconName: string;
  description: string;
  href: string;
  color: string;
  change?: string;
}

export function DashboardStats() {
  const [mounted, setMounted] = useState(false);
  const [animatedValues, setAnimatedValues] = useState<Record<string, number>>({});

  const stats: StatCard[] = [
    {
      title: 'Drafts to Approve',
      value: 7,
      iconName: 'MailCheck',
      description: 'AI-composed emails pending review',
      href: '/drafts',
      color: 'text-primary',
      change: '+3 today'
    },
    {
      title: 'Emails Processed',
      value: 142,
      iconName: 'Mail',
      description: 'Processed in the last 24 hours',
      href: '/analytics',
      color: 'text-success',
      change: '+28% vs yesterday'
    },
    {
      title: 'Spam Deleted',
      value: 23,
      iconName: 'Trash2',
      description: 'Automatically deleted today',
      href: '/analytics',
      color: 'text-destructive',
      change: '12 saved actions'
    },
    {
      title: 'Actions Taken',
      value: 89,
      iconName: 'Zap',
      description: 'Automated actions this week',
      href: '/analytics',
      color: 'text-warning',
      change: 'Active automation'
    }
  ];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'MailCheck':
        return MailCheck;
      case 'Mail':
        return Mail;
      case 'Trash2':
        return Trash2;
      case 'Zap':
        return Zap;
      default:
        return Mail;
    }
  };

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;

    const animateValues = () => {
      stats.forEach((stat, index) => {
        let currentValue = 0;
        const increment = stat.value / 30;
        const timer = setInterval(() => {
          currentValue += increment;
          if (currentValue >= stat.value) {
            currentValue = stat.value;
            clearInterval(timer);
          }
          setAnimatedValues(prev => ({
            ...prev,
            [stat.title]: Math.floor(currentValue)
          }));
        }, 50 + index * 10);
      });
    };

    const timeout = setTimeout(animateValues, 100);
    return () => clearTimeout(timeout);
  }, [mounted]);

  if (!mounted) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const IconComponent = getIcon(stat.iconName);
          return (
            <Card key={stat.title} className="bg-white border border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <IconComponent className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-foreground">
                  {stat.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stat.description}
                </p>
                {stat.change && (
                  <div className="flex items-center space-x-1">
                    <TrendingUp className="h-3 w-3 text-success" />
                    <span className="text-xs text-success font-medium">
                      {stat.change}
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          );
        })}
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const IconComponent = getIcon(stat.iconName);
        return (
          <Link key={stat.title} href={stat.href}>
            <Card className="hover:shadow-lg transition-all duration-200 hover:scale-105 cursor-pointer bg-white border border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <IconComponent className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-foreground animate-counter">
                  {animatedValues[stat.title] || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stat.description}
                </p>
                {stat.change && (
                  <div className="flex items-center space-x-1">
                    <TrendingUp className="h-3 w-3 text-success" />
                    <span className="text-xs text-success font-medium">
                      {stat.change}
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </Link>
        );
      })}
    </div>
  );
}
