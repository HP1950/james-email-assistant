
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Inbox, 
  Star, 
  Archive, 
  Trash2, 
  Forward, 
  Reply, 
  Clock,
  Brain,
  AlertCircle,
  CheckCircle,
  Filter,
  Search,
  MoreHorizontal
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';

interface EmailPreview {
  id: string;
  subject: string;
  fromAddress: string;
  fromName?: string;
  snippet?: string;
  isRead: boolean;
  isStarred: boolean;
  priority?: string;
  sentiment?: string;
  aiSummary?: string;
  receivedAt: Date;
  category?: string;
  tags: string[];
}

interface CategoryFilter {
  name: string;
  count: number;
  color: string;
  icon: React.ElementType;
}

export function SmartInboxPreview() {
  const [emails, setEmails] = useState<EmailPreview[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedEmail, setSelectedEmail] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchEmailPreviews();
  }, []);

  const fetchEmailPreviews = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch('/api/analytics/dashboard');
      if (!response.ok) {
        throw new Error('Failed to fetch email previews');
      }
      
      const result = await response.json();
      if (result.success) {
        // Transform the activity data into email previews
        const emailPreviews = result.data.recentActivity.map((email: any) => ({
          id: email.id,
          subject: email.subject,
          fromAddress: email.fromAddress,
          fromName: email.fromName,
          snippet: email.aiSummary || email.subject,
          isRead: email.isRead,
          isStarred: false,
          priority: email.priority,
          sentiment: email.sentiment,
          aiSummary: email.aiSummary,
          receivedAt: new Date(email.receivedAt),
          category: getEmailCategory(email.fromAddress),
          tags: [],
        }));
        
        setEmails(emailPreviews);
      } else {
        throw new Error(result.error || 'Failed to fetch data');
      }
    } catch (error) {
      console.error('Failed to fetch email previews:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      
      // Fallback to mock data
      const mockEmails: EmailPreview[] = [
        {
          id: '1',
          subject: 'Q4 Financial Report - Action Required',
          fromAddress: 'finance@company.com',
          fromName: 'Sarah Chen',
          snippet: 'The quarterly financial report is ready for your review. Please provide feedback by EOD Friday.',
          isRead: false,
          isStarred: true,
          priority: 'HIGH',
          sentiment: 'NEUTRAL',
          aiSummary: 'Financial report requires urgent review and feedback by Friday.',
          receivedAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
          category: 'Work',
          tags: ['finance', 'urgent'],
        },
        {
          id: '2',
          subject: 'Team Lunch Tomorrow - Confirm Attendance',
          fromAddress: 'team@company.com',
          fromName: 'Mike Johnson',
          snippet: 'Hey team! Just confirming attendance for tomorrow\'s lunch at 12:30 PM. Please reply if you can make it.',
          isRead: true,
          isStarred: false,
          priority: 'LOW',
          sentiment: 'POSITIVE',
          aiSummary: 'Casual team lunch invitation requiring RSVP confirmation.',
          receivedAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
          category: 'Social',
          tags: ['team', 'lunch'],
        },
        {
          id: '3',
          subject: 'Security Alert: New Login Detected',
          fromAddress: 'security@platform.com',
          fromName: 'Security Team',
          snippet: 'We detected a new login to your account from a different device. If this wasn\'t you, please secure your account.',
          isRead: false,
          isStarred: false,
          priority: 'URGENT',
          sentiment: 'NEGATIVE',
          aiSummary: 'Security alert about unauthorized login attempt requiring immediate attention.',
          receivedAt: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
          category: 'Security',
          tags: ['security', 'alert'],
        },
        {
          id: '4',
          subject: 'Your Order Has Been Shipped!',
          fromAddress: 'orders@ecommerce.com',
          fromName: 'E-Commerce Store',
          snippet: 'Great news! Your order #12345 has been shipped and is on its way. Track your package with the link below.',
          isRead: true,
          isStarred: false,
          priority: 'MEDIUM',
          sentiment: 'POSITIVE',
          aiSummary: 'Order shipment notification with tracking information.',
          receivedAt: new Date(Date.now() - 1000 * 60 * 60 * 4), // 4 hours ago
          category: 'Shopping',
          tags: ['order', 'shipping'],
        },
        {
          id: '5',
          subject: 'Weekly Newsletter - AI & Technology Trends',
          fromAddress: 'newsletter@techblog.com',
          fromName: 'Tech Blog',
          snippet: 'This week: Latest developments in AI, breakthrough in quantum computing, and new startup funding rounds.',
          isRead: false,
          isStarred: false,
          priority: 'VERY_LOW',
          sentiment: 'NEUTRAL',
          aiSummary: 'Weekly technology newsletter covering AI and startup news.',
          receivedAt: new Date(Date.now() - 1000 * 60 * 60 * 6), // 6 hours ago
          category: 'Newsletter',
          tags: ['newsletter', 'tech'],
        },
      ];
      
      setEmails(mockEmails);
    } finally {
      setIsLoading(false);
    }
  };

  const getEmailCategory = (fromAddress: string): string => {
    if (fromAddress.includes('company.com')) return 'Work';
    if (fromAddress.includes('security')) return 'Security';
    if (fromAddress.includes('orders') || fromAddress.includes('shop')) return 'Shopping';
    if (fromAddress.includes('newsletter') || fromAddress.includes('blog')) return 'Newsletter';
    return 'Personal';
  };

  const categories: CategoryFilter[] = [
    { name: 'all', count: emails.length, color: 'text-slate-400', icon: Inbox },
    { name: 'Work', count: emails.filter(e => e.category === 'Work').length, color: 'text-blue-400', icon: CheckCircle },
    { name: 'Security', count: emails.filter(e => e.category === 'Security').length, color: 'text-red-400', icon: AlertCircle },
    { name: 'Shopping', count: emails.filter(e => e.category === 'Shopping').length, color: 'text-green-400', icon: Archive },
    { name: 'Newsletter', count: emails.filter(e => e.category === 'Newsletter').length, color: 'text-purple-400', icon: Star },
    { name: 'Social', count: emails.filter(e => e.category === 'Social').length, color: 'text-yellow-400', icon: Clock },
  ];

  const filteredEmails = selectedCategory === 'all' 
    ? emails 
    : emails.filter(email => email.category === selectedCategory);

  const getPriorityColor = (priority?: string) => {
    switch (priority) {
      case 'URGENT': return 'bg-red-600/20 text-red-400 border-red-600/30';
      case 'HIGH': return 'bg-orange-600/20 text-orange-400 border-orange-600/30';
      case 'MEDIUM': return 'bg-yellow-600/20 text-yellow-400 border-yellow-600/30';
      case 'LOW': return 'bg-green-600/20 text-green-400 border-green-600/30';
      case 'VERY_LOW': return 'bg-slate-600/20 text-slate-400 border-slate-600/30';
      default: return 'bg-slate-600/20 text-slate-400 border-slate-600/30';
    }
  };

  const getSentimentIcon = (sentiment?: string) => {
    switch (sentiment) {
      case 'VERY_POSITIVE':
      case 'POSITIVE':
        return '😊';
      case 'NEUTRAL':
        return '😐';
      case 'NEGATIVE':
      case 'VERY_NEGATIVE':
        return '😟';
      default:
        return '📧';
    }
  };

  const handleEmailAction = (emailId: string, action: string) => {
    setEmails(prevEmails => 
      prevEmails.map(email => 
        email.id === emailId 
          ? { 
              ...email, 
              isRead: action === 'markRead' ? true : email.isRead,
              isStarred: action === 'star' ? !email.isStarred : email.isStarred 
            }
          : email
      )
    );
  };

  if (isLoading) {
    return (
      <Card className="glass-dark border-slate-700">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-blue-400" />
            <CardTitle className="text-xl text-white">Smart Inbox Preview</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center space-x-3 p-3 bg-slate-800/30 rounded-lg">
                  <div className="h-10 w-10 bg-slate-700 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                    <div className="h-3 bg-slate-700 rounded w-1/2"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glass-dark border-slate-700 hover:border-slate-600 transition-all duration-300">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-blue-400" />
              <CardTitle className="text-xl text-white">Smart Inbox Preview</CardTitle>
              <Badge className="bg-blue-600/20 text-blue-400">
                AI-Powered
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button size="sm" variant="outline" className="border-slate-600 text-slate-400">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
              <Button size="sm" variant="outline" className="border-slate-600 text-slate-400">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
          
          {error && (
            <div className="mt-3 p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
              <p className="text-amber-400 text-sm">⚠️ Using demo data: {error}</p>
            </div>
          )}
          
          {/* Category Filters */}
          <div className="flex items-center space-x-2 mt-4 overflow-x-auto">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <Button
                  key={category.name}
                  size="sm"
                  variant={selectedCategory === category.name ? "default" : "ghost"}
                  onClick={() => setSelectedCategory(category.name)}
                  className={`shrink-0 ${
                    selectedCategory === category.name
                      ? "bg-slate-700 text-white"
                      : `${category.color} hover:text-white hover:bg-slate-700`
                  }`}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {category.name === 'all' ? 'All' : category.name}
                  {category.count > 0 && (
                    <Badge variant="secondary" className="ml-2 bg-slate-600 text-white">
                      {category.count}
                    </Badge>
                  )}
                </Button>
              );
            })}
          </div>
        </CardHeader>

        <CardContent>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            <AnimatePresence>
              {filteredEmails.map((email, index) => (
                <motion.div
                  key={email.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ delay: index * 0.05 }}
                  className={`p-3 rounded-lg border transition-all duration-200 cursor-pointer group ${
                    selectedEmail === email.id
                      ? 'bg-slate-700/50 border-blue-600/50'
                      : email.isRead
                      ? 'bg-slate-800/30 border-slate-700/50 hover:bg-slate-700/30'
                      : 'bg-slate-800/50 border-slate-600/50 hover:bg-slate-700/40'
                  }`}
                  onClick={() => setSelectedEmail(selectedEmail === email.id ? null : email.id)}
                >
                  <div className="flex items-start space-x-3">
                    <Avatar className="h-10 w-10 shrink-0">
                      <AvatarFallback className="bg-slate-700 text-slate-300 text-sm">
                        {email.fromName?.split(' ').map(n => n[0]).join('') || 
                         email.fromAddress.split('@')[0].slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center space-x-2 min-w-0">
                          <p className={`text-sm font-medium truncate ${
                            email.isRead ? 'text-slate-300' : 'text-white'
                          }`}>
                            {email.fromName || email.fromAddress.split('@')[0]}
                          </p>
                          {email.priority && (
                            <Badge className={getPriorityColor(email.priority)}>
                              {email.priority}
                            </Badge>
                          )}
                          <span className="text-lg">{getSentimentIcon(email.sentiment)}</span>
                        </div>
                        <div className="flex items-center space-x-2 shrink-0">
                          <span className="text-xs text-slate-500">
                            {formatDistanceToNow(email.receivedAt, { addSuffix: true })}
                          </span>
                          {email.isStarred && (
                            <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          )}
                        </div>
                      </div>
                      
                      <p className={`text-sm mb-2 truncate ${
                        email.isRead ? 'text-slate-400' : 'text-slate-300 font-medium'
                      }`}>
                        {email.subject}
                      </p>
                      
                      <p className="text-xs text-slate-500 line-clamp-2">
                        {email.aiSummary || email.snippet}
                      </p>
                      
                      {email.tags.length > 0 && (
                        <div className="flex items-center space-x-1 mt-2">
                          {email.tags.map((tag, tagIndex) => (
                            <Badge key={tagIndex} variant="outline" className="text-xs border-slate-600 text-slate-400">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    {/* Quick Actions */}
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center space-x-1 shrink-0">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEmailAction(email.id, 'star');
                        }}
                        className="h-8 w-8 p-0 text-slate-400 hover:text-yellow-400"
                      >
                        <Star className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEmailAction(email.id, 'reply');
                        }}
                        className="h-8 w-8 p-0 text-slate-400 hover:text-blue-400"
                      >
                        <Reply className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEmailAction(email.id, 'archive');
                        }}
                        className="h-8 w-8 p-0 text-slate-400 hover:text-green-400"
                      >
                        <Archive className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                        }}
                        className="h-8 w-8 p-0 text-slate-400 hover:text-slate-300"
                      >
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            
            {filteredEmails.length === 0 && (
              <div className="text-center py-8">
                <Inbox className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400 text-sm">No emails in this category</p>
              </div>
            )}
          </div>
          
          <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
            <span>{filteredEmails.length} emails</span>
            <span>Last updated: Just now</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
