
'use client';

import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  Brain, 
  Send, 
  Lightbulb, 
  MessageSquare, 
  BarChart3, 
  Zap,
  Copy,
  RefreshCw,
  Sparkles,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

interface AIAnalysis {
  sentiment?: {
    sentiment: string;
    confidence: number;
    reasoning: string;
  };
  priority?: {
    priority: string;
    confidence: number;
    reasoning: string;
  };
  summary?: {
    summary: string;
  };
  tasks?: {
    tasks: string[];
    confidence: number;
  };
  category?: {
    category: string;
    confidence: number;
    tags: string[];
  };
}

interface AISuggestion {
  reply?: {
    reply: string;
    tone: string;
    confidence: number;
  };
  smartActions?: {
    actions: Array<{
      type: string;
      label: string;
      priority: string;
    }>;
    confidence: number;
  };
  insights?: {
    insights: string[];
    senderAnalysis: string;
    recommendations: string[];
    confidence: number;
  };
}

export function AIEmailAssistant() {
  const [emailContent, setEmailContent] = useState('');
  const [analysis, setAnalysis] = useState<AIAnalysis | null>(null);
  const [suggestions, setSuggestions] = useState<AISuggestion | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'analyze' | 'suggest'>('analyze');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const sampleEmails = [
    {
      title: "Meeting Request",
      content: "Hi, I hope this email finds you well. I wanted to reach out regarding the upcoming project deadline. We need to schedule a meeting to discuss the final deliverables and ensure everything is on track. Would you be available next Tuesday at 2 PM? Please let me know if this works for your schedule. Best regards, John"
    },
    {
      title: "Urgent Issue",
      content: "URGENT: The server is down and our customers are unable to access the application. This is affecting our sales and customer satisfaction. We need immediate action to resolve this issue. Please prioritize this and let me know the estimated time for resolution. This is critical for our business operations."
    },
    {
      title: "Thank You Note",
      content: "Dear Team, I wanted to express my heartfelt gratitude for all your hard work on the recent project. Your dedication and effort made it a huge success! The client was extremely pleased with the results. Looking forward to working on more exciting projects together. Thank you once again!"
    }
  ];

  const analyzeEmail = async (type: string) => {
    if (!emailContent.trim()) {
      toast.error('Please enter email content to analyze');
      return;
    }

    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/ai/email-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          emailContent: emailContent.trim(),
          analysisType: type,
        }),
      });

      const result = await response.json();
      
      if (result.success) {
        setAnalysis(prev => ({
          ...prev,
          [type]: result.data.result,
        }));
        toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} analysis completed!`);
      } else {
        throw new Error(result.error || 'Analysis failed');
      }
    } catch (error) {
      console.error('Analysis error:', error);
      toast.error('Failed to analyze email. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const generateSuggestions = async (type: string) => {
    if (!emailContent.trim()) {
      toast.error('Please enter email content to generate suggestions');
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai/email-suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          emailContent: emailContent.trim(),
          suggestionType: type,
        }),
      });

      const result = await response.json();
      
      if (result.success) {
        setSuggestions(prev => ({
          ...prev,
          [type]: result.data.result,
        }));
        toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} suggestions generated!`);
      } else {
        throw new Error(result.error || 'Suggestion generation failed');
      }
    } catch (error) {
      console.error('Suggestion error:', error);
      toast.error('Failed to generate suggestions. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  const loadSample = (sample: typeof sampleEmails[0]) => {
    setEmailContent(sample.content);
    setAnalysis(null);
    setSuggestions(null);
    toast.info(`Loaded: ${sample.title}`);
  };

  const clearAll = () => {
    setEmailContent('');
    setAnalysis(null);
    setSuggestions(null);
    toast.info('Cleared all content');
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'VERY_POSITIVE': return 'text-green-400 bg-green-400/10';
      case 'POSITIVE': return 'text-green-300 bg-green-300/10';
      case 'NEUTRAL': return 'text-gray-400 bg-gray-400/10';
      case 'NEGATIVE': return 'text-red-300 bg-red-300/10';
      case 'VERY_NEGATIVE': return 'text-red-400 bg-red-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'URGENT': return 'text-red-400 bg-red-400/10';
      case 'VERY_HIGH': return 'text-red-300 bg-red-300/10';
      case 'HIGH': return 'text-orange-400 bg-orange-400/10';
      case 'MEDIUM': return 'text-yellow-400 bg-yellow-400/10';
      case 'LOW': return 'text-green-300 bg-green-300/10';
      case 'VERY_LOW': return 'text-green-400 bg-green-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glass-dark border-slate-700 hover:border-slate-600 transition-all duration-300">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-purple-400" />
              <CardTitle className="text-xl text-white">AI Email Assistant</CardTitle>
              <Sparkles className="h-4 w-4 text-yellow-400" />
            </div>
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant={activeTab === 'analyze' ? 'default' : 'outline'}
                onClick={() => setActiveTab('analyze')}
                className={activeTab === 'analyze' ? 'bg-purple-600' : 'border-slate-600'}
              >
                <BarChart3 className="h-4 w-4 mr-2" />
                Analyze
              </Button>
              <Button
                size="sm"
                variant={activeTab === 'suggest' ? 'default' : 'outline'}
                onClick={() => setActiveTab('suggest')}
                className={activeTab === 'suggest' ? 'bg-purple-600' : 'border-slate-600'}
              >
                <Lightbulb className="h-4 w-4 mr-2" />
                Suggest
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Email Input */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-300">Email Content</label>
              <div className="flex items-center space-x-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={clearAll}
                  className="text-slate-400 hover:text-white"
                >
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Clear
                </Button>
              </div>
            </div>
            <Textarea
              ref={textareaRef}
              value={emailContent}
              onChange={(e) => setEmailContent(e.target.value)}
              placeholder="Paste your email content here for AI analysis and suggestions..."
              className="min-h-32 bg-slate-800/50 border-slate-600 text-white placeholder-slate-500 resize-none"
              rows={6}
            />
            
            {/* Sample Emails */}
            <div className="flex flex-wrap gap-2">
              <span className="text-xs text-slate-500">Quick samples:</span>
              {sampleEmails.map((sample, index) => (
                <Button
                  key={index}
                  size="sm"
                  variant="ghost"
                  onClick={() => loadSample(sample)}
                  className="text-xs text-slate-400 hover:text-white h-6"
                >
                  {sample.title}
                </Button>
              ))}
            </div>
          </div>

          <AnimatePresence mode="wait">
            {activeTab === 'analyze' && (
              <motion.div
                key="analyze"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                {/* Analysis Controls */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                  {[
                    { type: 'sentiment', label: 'Sentiment', icon: MessageSquare },
                    { type: 'priority', label: 'Priority', icon: Zap },
                    { type: 'summary', label: 'Summary', icon: BarChart3 },
                    { type: 'tasks', label: 'Tasks', icon: ThumbsUp },
                    { type: 'category', label: 'Category', icon: Brain },
                  ].map(({ type, label, icon: Icon }) => (
                    <Button
                      key={type}
                      size="sm"
                      variant="outline"
                      onClick={() => analyzeEmail(type)}
                      disabled={isAnalyzing || !emailContent.trim()}
                      className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700"
                    >
                      <Icon className="h-4 w-4 mr-2" />
                      {label}
                    </Button>
                  ))}
                </div>

                {/* Analysis Results */}
                <div className="space-y-4">
                  {analysis?.sentiment && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">Sentiment Analysis</h4>
                        <Badge className={getSentimentColor(analysis.sentiment.sentiment)}>
                          {analysis.sentiment.sentiment.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-300 mb-2">{analysis.sentiment.reasoning}</p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-slate-500">Confidence:</span>
                        <span className="text-xs text-green-400">{Math.round(analysis.sentiment.confidence * 100)}%</span>
                      </div>
                    </motion.div>
                  )}

                  {analysis?.priority && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">Priority Analysis</h4>
                        <Badge className={getPriorityColor(analysis.priority.priority)}>
                          {analysis.priority.priority.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-300 mb-2">{analysis.priority.reasoning}</p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-slate-500">Confidence:</span>
                        <span className="text-xs text-green-400">{Math.round(analysis.priority.confidence * 100)}%</span>
                      </div>
                    </motion.div>
                  )}

                  {analysis?.summary && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">AI Summary</h4>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(analysis.summary?.summary || '')}
                          className="text-slate-400 hover:text-white"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-slate-300">{analysis.summary.summary}</p>
                    </motion.div>
                  )}

                  {analysis?.tasks && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">Extracted Tasks</h4>
                        <span className="text-xs text-green-400">{Math.round(analysis.tasks.confidence * 100)}% confidence</span>
                      </div>
                      <div className="space-y-2">
                        {analysis.tasks.tasks.map((task, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <ThumbsUp className="h-4 w-4 text-blue-400" />
                            <span className="text-sm text-slate-300">{task}</span>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {analysis?.category && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">Category & Tags</h4>
                        <Badge className="bg-blue-600/20 text-blue-400">
                          {analysis.category.category}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {analysis.category.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="border-slate-600 text-slate-300">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            )}

            {activeTab === 'suggest' && (
              <motion.div
                key="suggest"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                {/* Suggestion Controls */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  {[
                    { type: 'reply', label: 'Generate Reply', icon: Send },
                    { type: 'smartActions', label: 'Smart Actions', icon: Zap },
                    { type: 'insights', label: 'AI Insights', icon: Brain },
                  ].map(({ type, label, icon: Icon }) => (
                    <Button
                      key={type}
                      size="sm"
                      variant="outline"
                      onClick={() => generateSuggestions(type)}
                      disabled={isGenerating || !emailContent.trim()}
                      className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700"
                    >
                      <Icon className="h-4 w-4 mr-2" />
                      {label}
                    </Button>
                  ))}
                </div>

                {/* Suggestion Results */}
                <div className="space-y-4">
                  {suggestions?.reply && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">Generated Reply</h4>
                        <div className="flex items-center space-x-2">
                          <Badge className="bg-purple-600/20 text-purple-400">
                            {suggestions.reply.tone}
                          </Badge>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(suggestions.reply?.reply || '')}
                            className="text-slate-400 hover:text-white"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="p-3 bg-slate-900/50 rounded border border-slate-600">
                        <p className="text-sm text-slate-300 whitespace-pre-wrap">{suggestions.reply.reply}</p>
                      </div>
                      <div className="flex items-center justify-between mt-3">
                        <span className="text-xs text-slate-500">
                          Confidence: {Math.round(suggestions.reply.confidence * 100)}%
                        </span>
                        <div className="flex items-center space-x-2">
                          <Button size="sm" variant="ghost" className="text-green-400 hover:text-green-300">
                            <ThumbsUp className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300">
                            <ThumbsDown className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {suggestions?.smartActions && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">Smart Actions</h4>
                        <span className="text-xs text-green-400">
                          {Math.round(suggestions.smartActions.confidence * 100)}% confidence
                        </span>
                      </div>
                      <div className="space-y-2">
                        {suggestions.smartActions.actions.map((action, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-slate-900/50 rounded">
                            <div className="flex items-center space-x-2">
                              <Badge className={`${
                                action.priority === 'high' ? 'bg-red-600/20 text-red-400' :
                                action.priority === 'medium' ? 'bg-yellow-600/20 text-yellow-400' :
                                'bg-green-600/20 text-green-400'
                              }`}>
                                {action.type}
                              </Badge>
                              <span className="text-sm text-slate-300">{action.label}</span>
                            </div>
                            <Button size="sm" variant="outline" className="border-slate-600 text-slate-300">
                              Execute
                            </Button>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {suggestions?.insights && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-white">AI Insights</h4>
                        <span className="text-xs text-green-400">
                          {Math.round(suggestions.insights.confidence * 100)}% confidence
                        </span>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <h5 className="text-sm font-medium text-slate-300 mb-2">Key Insights</h5>
                          <ul className="space-y-1">
                            {suggestions.insights.insights.map((insight, index) => (
                              <li key={index} className="text-sm text-slate-400 flex items-start">
                                <span className="text-blue-400 mr-2">•</span>
                                {insight}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h5 className="text-sm font-medium text-slate-300 mb-2">Sender Analysis</h5>
                          <p className="text-sm text-slate-400">{suggestions.insights.senderAnalysis}</p>
                        </div>
                        
                        <div>
                          <h5 className="text-sm font-medium text-slate-300 mb-2">Recommendations</h5>
                          <ul className="space-y-1">
                            {suggestions.insights.recommendations.map((rec, index) => (
                              <li key={index} className="text-sm text-slate-400 flex items-start">
                                <span className="text-green-400 mr-2">→</span>
                                {rec}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {(isAnalyzing || isGenerating) && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center justify-center py-8"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="h-8 w-8 border-2 border-purple-400 border-t-transparent rounded-full mr-3"
              />
              <span className="text-slate-400">
                {isAnalyzing ? 'Analyzing email...' : 'Generating suggestions...'}
              </span>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
