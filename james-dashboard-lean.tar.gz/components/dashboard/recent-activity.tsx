
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Mail, 
  Trash2, 
  FolderOpen, 
  Shield,
  Clock,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

interface ActivityItem {
  id: string;
  type: 'draft_created' | 'spam_deleted' | 'email_categorized' | 'rule_triggered' | 'draft_approved';
  description: string;
  timestamp: Date;
  status: 'success' | 'warning' | 'error';
  metadata?: {
    sender?: string;
    subject?: string;
    category?: string;
    rule?: string;
  };
}

export function RecentActivity() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const activities: ActivityItem[] = [
    {
      id: '1',
      type: 'draft_created',
      description: 'AI composed reply to customer inquiry',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      status: 'success',
      metadata: {
        sender: 'sarah.johnson@example.com',
        subject: 'Product support question'
      }
    },
    {
      id: '2',
      type: 'spam_deleted',
      description: 'Deleted promotional email',
      timestamp: new Date(Date.now() - 12 * 60 * 1000),
      status: 'success',
      metadata: {
        sender: 'promotions@spam-site.com',
        subject: 'Limited time offer!!!'
      }
    },
    {
      id: '3',
      type: 'email_categorized',
      description: 'Categorized email as Business',
      timestamp: new Date(Date.now() - 18 * 60 * 1000),
      status: 'success',
      metadata: {
        sender: 'team@company.com',
        category: 'Business'
      }
    },
    {
      id: '4',
      type: 'rule_triggered',
      description: 'Auto-forwarded email to assistant',
      timestamp: new Date(Date.now() - 25 * 60 * 1000),
      status: 'success',
      metadata: {
        rule: 'Forward urgent emails',
        sender: 'support@client.com'
      }
    },
    {
      id: '5',
      type: 'draft_approved',
      description: 'Draft approved and sent successfully',
      timestamp: new Date(Date.now() - 35 * 60 * 1000),
      status: 'success',
      metadata: {
        sender: 'contact@partner.com',
        subject: 'Meeting confirmation'
      }
    }
  ];

  const getActivityIcon = (type: ActivityItem['type']) => {
    switch (type) {
      case 'draft_created':
        return <Mail className="h-4 w-4 text-primary" />;
      case 'spam_deleted':
        return <Trash2 className="h-4 w-4 text-destructive" />;
      case 'email_categorized':
        return <FolderOpen className="h-4 w-4 text-success" />;
      case 'rule_triggered':
        return <Shield className="h-4 w-4 text-warning" />;
      case 'draft_approved':
        return <CheckCircle className="h-4 w-4 text-success" />;
      default:
        return <Mail className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: ActivityItem['status']) => {
    switch (status) {
      case 'success':
        return <Badge variant="default" className="bg-success/10 text-success border-success/20">Success</Badge>;
      case 'warning':
        return <Badge variant="default" className="bg-warning/10 text-warning border-warning/20">Warning</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const formatTimeAgo = (date: Date) => {
    if (!mounted) return 'Loading...';
    
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    const hours = Math.floor(diffInMinutes / 60);
    if (hours < 24) return `${hours} hours ago`;
    const days = Math.floor(hours / 24);
    return `${days} days ago`;
  };

  return (
    <Card className="bg-white border border-border">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Clock className="h-5 w-5 text-primary" />
          <span>Recent Activity</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
              <div className="flex-shrink-0 mt-0.5">
                {getActivityIcon(activity.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-medium text-foreground">
                    {activity.description}
                  </p>
                  {getStatusBadge(activity.status)}
                </div>
                {activity.metadata && (
                  <div className="space-y-1">
                    {activity.metadata.sender && (
                      <p className="text-xs text-muted-foreground">
                        From: {activity.metadata.sender}
                      </p>
                    )}
                    {activity.metadata.subject && (
                      <p className="text-xs text-muted-foreground">
                        Subject: {activity.metadata.subject}
                      </p>
                    )}
                    {activity.metadata.category && (
                      <p className="text-xs text-muted-foreground">
                        Category: {activity.metadata.category}
                      </p>
                    )}
                    {activity.metadata.rule && (
                      <p className="text-xs text-muted-foreground">
                        Rule: {activity.metadata.rule}
                      </p>
                    )}
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-1">
                  {formatTimeAgo(activity.timestamp)}
                </p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 pt-4 border-t border-border">
          <button className="text-sm text-primary hover:text-primary/80 font-medium">
            View all activity →
          </button>
        </div>
      </CardContent>
    </Card>
  );
}
