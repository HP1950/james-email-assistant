
'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, 
  Circle, 
  MessageSquare, 
  Share, 
  Eye,
  UserPlus 
} from 'lucide-react';
import { useWebSocketCollaboration } from '@/components/websocket-provider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const statusColors = {
  online: 'text-green-500',
  away: 'text-yellow-500',
  busy: 'text-red-500',
  offline: 'text-gray-500',
};

export function RealtimeCollaboration() {
  const { onlineUsers, typingUsers, sharedEmails, connected } = useWebSocketCollaboration();
  const [activeCollaborators, setActiveCollaborators] = useState(onlineUsers);

  useEffect(() => {
    setActiveCollaborators(onlineUsers);
  }, [onlineUsers]);

  const totalSharedEmails = Object.keys(sharedEmails).length;
  const activeTypingCount = Object.values(typingUsers).reduce((acc, users) => acc + users.length, 0);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Users className="h-4 w-4" />
          Collaboration
          {activeCollaborators.length > 0 && (
            <Badge variant="secondary" className="text-xs">
              {activeCollaborators.length} online
            </Badge>
          )}
        </CardTitle>
        
        <div className="flex items-center gap-2">
          <div className={`h-2 w-2 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-xs text-muted-foreground">
            {connected ? 'Live' : 'Offline'}
          </span>
        </div>
      </CardHeader>
      
      <CardContent>
        {!connected ? (
          <div className="flex items-center justify-center h-32 text-muted-foreground">
            <div className="text-center">
              <Users className="h-8 w-8 mx-auto mb-2" />
              <p className="text-sm">Collaboration features offline</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Online Users */}
            <div>
              <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                <Eye className="h-3 w-3" />
                Online Now
              </h4>
              
              {activeCollaborators.length === 0 ? (
                <div className="text-center py-4 text-muted-foreground">
                  <UserPlus className="h-6 w-6 mx-auto mb-2" />
                  <p className="text-xs">No other users online</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <AnimatePresence>
                    {activeCollaborators.map((user, index) => (
                      <motion.div
                        key={user.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ delay: index * 0.05 }}
                        className="flex items-center gap-3 p-2 rounded-lg bg-card/50"
                      >
                        <div className="relative">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback className="text-xs">
                              {user.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-background bg-green-500`} />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{user.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                        </div>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger>
                              <Circle className={`h-2 w-2 fill-current ${statusColors.online}`} />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Online</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>

            {/* Activity Summary */}
            <div className="grid grid-cols-2 gap-3 pt-4 border-t">
              <div className="text-center p-3 rounded-lg bg-card/30">
                <Share className="h-4 w-4 mx-auto mb-1 text-blue-500" />
                <p className="text-lg font-semibold">{totalSharedEmails}</p>
                <p className="text-xs text-muted-foreground">Shared Emails</p>
              </div>
              
              <div className="text-center p-3 rounded-lg bg-card/30">
                <MessageSquare className="h-4 w-4 mx-auto mb-1 text-green-500" />
                <p className="text-lg font-semibold">{activeTypingCount}</p>
                <p className="text-xs text-muted-foreground">Typing Now</p>
              </div>
            </div>

            {/* Typing Indicators */}
            {activeTypingCount > 0 && (
              <div className="pt-2 border-t">
                <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                  <MessageSquare className="h-3 w-3" />
                  Currently Typing
                </h4>
                <div className="space-y-1">
                  {Object.entries(typingUsers).map(([emailId, users]) =>
                    users.length > 0 ? (
                      <motion.div
                        key={emailId}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="flex items-center gap-2 text-xs text-muted-foreground"
                      >
                        <div className="flex -space-x-1">
                          {users.slice(0, 3).map((userId) => {
                            const user = activeCollaborators.find(u => u.id === userId);
                            return user ? (
                              <Avatar key={userId} className="h-4 w-4 border border-background">
                                <AvatarFallback className="text-xs">
                                  {user.name.charAt(0)}
                                </AvatarFallback>
                              </Avatar>
                            ) : null;
                          })}
                        </div>
                        <span>
                          {users.length === 1 ? 'is' : 'are'} typing in email {emailId.slice(-8)}...
                        </span>
                      </motion.div>
                    ) : null
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
