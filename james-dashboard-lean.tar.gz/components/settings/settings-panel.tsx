
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Mail,
  CheckCircle,
  AlertCircle,
  Bell,
  Shield,
  Clock,
  User,
  Save,
  Unlink,
  RefreshCw
} from 'lucide-react';

interface UserSettings {
  // Gmail integration
  gmailConnected: boolean;
  gmailAccount: string;
  lastSyncAt: Date;
  
  // Notifications
  emailNotificationsEnabled: boolean;
  dailySummaryEnabled: boolean;
  approvalNotificationsEnabled: boolean;
  
  // Processing preferences
  timezone: string;
  language: string;
  
  // Security
  twoFactorEnabled: boolean;
  sessionTimeout: number;
}

export function SettingsPanel() {
  const [settings, setSettings] = useState<UserSettings>({
    gmailConnected: true,
    gmailAccount: 'user@example.com',
    lastSyncAt: new Date(Date.now() - 15 * 60 * 1000),
    emailNotificationsEnabled: true,
    dailySummaryEnabled: true,
    approvalNotificationsEnabled: true,
    timezone: 'UTC',
    language: 'English',
    twoFactorEnabled: false,
    sessionTimeout: 30
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [isDisconnecting, setIsDisconnecting] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsSaving(false);
    setSaved(true);
    
    setTimeout(() => setSaved(false), 3000);
  };

  const handleDisconnectGmail = async () => {
    setIsDisconnecting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setSettings(prev => ({
      ...prev,
      gmailConnected: false,
      gmailAccount: '',
      lastSyncAt: new Date()
    }));
    setIsDisconnecting(false);
  };

  const formatLastSync = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    const hours = Math.floor(diffInMinutes / 60);
    if (hours < 24) return `${hours} hours ago`;
    const days = Math.floor(hours / 24);
    return `${days} days ago`;
  };

  return (
    <div className="space-y-6">
      {/* Gmail Account Status */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Mail className="h-5 w-5 text-primary" />
            <span>Gmail Account</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {settings.gmailConnected ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium text-foreground">{settings.gmailAccount}</span>
                    <Badge variant="default" className="bg-success/10 text-success border-success/20">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Connected
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Last synced: {formatLastSync(settings.lastSyncAt)}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Sync Now
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleDisconnectGmail}
                    disabled={isDisconnecting}
                    className="text-destructive hover:bg-destructive/10"
                  >
                    <Unlink className="h-4 w-4 mr-2" />
                    {isDisconnecting ? 'Disconnecting...' : 'Disconnect'}
                  </Button>
                </div>
              </div>
              
              <div className="bg-success/5 border border-success/20 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-success mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-success">Gmail Integration Active</h4>
                    <p className="text-sm text-success/80">
                      Your Gmail account is connected and emails are being processed automatically.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-warning/5 border border-warning/20 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="h-5 w-5 text-warning mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-warning">Gmail Not Connected</h4>
                    <p className="text-sm text-warning/80">
                      Connect your Gmail account to start using the email assistant features.
                    </p>
                  </div>
                </div>
              </div>
              <Button className="w-full">
                <Mail className="h-4 w-4 mr-2" />
                Connect Gmail Account
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bell className="h-5 w-5 text-primary" />
            <span>Notification Preferences</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label className="text-sm font-medium">Email Notifications</Label>
                <p className="text-xs text-muted-foreground">
                  Receive email notifications for important updates
                </p>
              </div>
              <Switch
                checked={settings.emailNotificationsEnabled}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, emailNotificationsEnabled: checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label className="text-sm font-medium">Daily Summary</Label>
                <p className="text-xs text-muted-foreground">
                  Get a daily summary of email processing activities
                </p>
              </div>
              <Switch
                checked={settings.dailySummaryEnabled}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, dailySummaryEnabled: checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label className="text-sm font-medium">Draft Approval Alerts</Label>
                <p className="text-xs text-muted-foreground">
                  Notify me when new drafts require approval
                </p>
              </div>
              <Switch
                checked={settings.approvalNotificationsEnabled}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, approvalNotificationsEnabled: checked }))
                }
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* General Preferences */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-primary" />
            <span>General Preferences</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium">Timezone</Label>
              <Select
                value={settings.timezone}
                onValueChange={(value) => 
                  setSettings(prev => ({ ...prev, timezone: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="UTC">UTC</SelectItem>
                  <SelectItem value="America/New_York">Eastern Time</SelectItem>
                  <SelectItem value="America/Chicago">Central Time</SelectItem>
                  <SelectItem value="America/Denver">Mountain Time</SelectItem>
                  <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                  <SelectItem value="Europe/London">London</SelectItem>
                  <SelectItem value="Europe/Paris">Paris</SelectItem>
                  <SelectItem value="Asia/Tokyo">Tokyo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium">Language</Label>
              <Select
                value={settings.language}
                onValueChange={(value) => 
                  setSettings(prev => ({ ...prev, language: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="English">English</SelectItem>
                  <SelectItem value="Spanish">Spanish</SelectItem>
                  <SelectItem value="French">French</SelectItem>
                  <SelectItem value="German">German</SelectItem>
                  <SelectItem value="Japanese">Japanese</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-primary" />
            <span>Security Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-sm font-medium">Two-Factor Authentication</Label>
              <p className="text-xs text-muted-foreground">
                Add an extra layer of security to your account
              </p>
            </div>
            <Switch
              checked={settings.twoFactorEnabled}
              onCheckedChange={(checked) => 
                setSettings(prev => ({ ...prev, twoFactorEnabled: checked }))
              }
            />
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">Session Timeout (minutes)</Label>
            <Select
              value={settings.sessionTimeout.toString()}
              onValueChange={(value) => 
                setSettings(prev => ({ ...prev, sessionTimeout: parseInt(value) }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15 minutes</SelectItem>
                <SelectItem value="30">30 minutes</SelectItem>
                <SelectItem value="60">1 hour</SelectItem>
                <SelectItem value="120">2 hours</SelectItem>
                <SelectItem value="480">8 hours</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Automatically log out after this period of inactivity
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex items-center justify-end space-x-4">
        {saved && (
          <div className="flex items-center space-x-2 text-success">
            <CheckCircle className="h-4 w-4" />
            <span className="text-sm">Settings saved successfully</span>
          </div>
        )}
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
}
