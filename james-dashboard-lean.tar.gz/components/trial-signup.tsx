
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Mail, 
  CheckCircle, 
  Loader2, 
  Copy,
  ExternalLink,
  Info,
  Settings
} from 'lucide-react';

interface TrialSignupResponse {
  success: boolean;
  userId: string;
  userEmail: string;
  jamesEmail: string;
  assignedDomain: string;
  welcomeEmailSent: boolean;
  message: string;
  error?: string;
}

export function TrialSignup() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TrialSignupResponse | null>(null);
  const [step, setStep] = useState<'signup' | 'success' | 'setup'>('signup');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      alert('Please enter your email address');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/trial-signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userEmail: email,
          userName: name
        }),
      });

      const data: TrialSignupResponse = await response.json();
      
      if (data.success) {
        setResult(data);
        setStep('success');
      } else {
        alert(data.error || 'Failed to sign up for trial');
      }
    } catch (error) {
      console.error('Trial signup error:', error);
      alert('Failed to sign up for trial. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // You could add a toast notification here
  };

  if (step === 'success' && result) {
    return (
      <div className="space-y-6">
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <span>Welcome to James! 🎉</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <Info className="w-4 h-4" />
              <AlertDescription>
                You've been successfully registered for a <strong>4-week free trial</strong>. 
                Your account has been assigned to our load-balanced infrastructure.
              </AlertDescription>
            </Alert>

            <div className="bg-white p-4 rounded-lg border">
              <h3 className="font-semibold mb-2">🔑 Your James Email Address:</h3>
              <div className="flex items-center space-x-2">
                <code className="bg-gray-100 px-3 py-2 rounded flex-1 font-mono text-sm">
                  {result.jamesEmail}
                </code>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => copyToClipboard(result.jamesEmail)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Forward your Gmail accounts to this address
              </p>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">📧 Check Your Email!</h3>
              <p className="text-sm">
                {result.welcomeEmailSent 
                  ? "We've sent you a welcome email with detailed setup instructions."
                  : "Welcome email sending failed, but you can still proceed with setup."
                }
              </p>
            </div>

            <div className="bg-white p-4 rounded-lg border">
              <h3 className="font-semibold mb-2">📊 Your Assignment Details:</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>User ID:</span>
                  <Badge variant="outline">{result.userId}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Assigned Domain:</span>
                  <Badge>{result.assignedDomain}</Badge>
                </div>
              </div>
            </div>

            <div className="flex space-x-4">
              <Button onClick={() => setStep('setup')} className="flex-1">
                <Settings className="w-4 h-4 mr-2" />
                Set Up Gmail Forwarding
              </Button>
              <Button variant="outline" asChild>
                <a href="/dashboard" className="flex items-center">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Go to Dashboard
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'setup' && result) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>📧 Gmail Forwarding Setup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert>
            <Info className="w-4 h-4" />
            <AlertDescription>
              Follow these steps to forward your Gmail accounts to James. 
              You can add up to 10 Gmail accounts during your trial.
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">⚠️ Important: Use App Passwords</h3>
              <p className="text-sm text-muted-foreground">
                Don't use your regular Gmail password. Generate App Passwords for each Gmail account.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold">Step 1: Enable Gmail Forwarding</h3>
              <ol className="list-decimal list-inside space-y-2 text-sm ml-4">
                <li>Go to Gmail Settings → Forwarding and POP/IMAP</li>
                <li>Click "Add a forwarding address"</li>
                <li>Enter: <code className="bg-gray-100 px-2 py-1 rounded">{result.jamesEmail}</code></li>
                <li>Verify the forwarding address (check your email)</li>
                <li>Set forwarding to "Forward a copy of incoming mail"</li>
              </ol>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold">Step 2: Generate App Password</h3>
              <ol className="list-decimal list-inside space-y-2 text-sm ml-4">
                <li>Enable 2-Factor Authentication on your Gmail</li>
                <li>Go to Google Account → Security → App passwords</li>
                <li>Generate password for "Mail" app</li>
                <li>Copy the 16-character password</li>
              </ol>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold">Step 3: Configure in James</h3>
              <p className="text-sm text-muted-foreground">
                Use the Email Setup page to add your Gmail accounts with their App Passwords.
              </p>
            </div>
          </div>

          <div className="flex space-x-4">
            <Button asChild className="flex-1">
              <a href="/email-setup">
                <Settings className="w-4 h-4 mr-2" />
                Go to Email Setup
              </a>
            </Button>
            <Button variant="outline" asChild>
              <a href="/dashboard">
                Go to Dashboard
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Mail className="w-6 h-6" />
          <span>Start Your Free Trial</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Alert>
            <Info className="w-4 h-4" />
            <AlertDescription>
              Get 4 weeks free access to James Email Assistant with full domain load balancing.
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Name (Optional)</Label>
            <Input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your Name"
            />
          </div>

          <div className="bg-blue-50 p-3 rounded-lg">
            <h4 className="font-semibold text-sm mb-1">What you'll get:</h4>
            <ul className="text-xs space-y-1">
              <li>✅ Personal James email address</li>
              <li>✅ Multi-account Gmail forwarding</li>
              <li>✅ AI-powered email responses</li>
              <li>✅ Voice command integration</li>
              <li>✅ Load-balanced infrastructure</li>
              <li>✅ 4 weeks completely free</li>
            </ul>
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Setting up your account...
              </>
            ) : (
              'Start Free Trial'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
