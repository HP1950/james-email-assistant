
/**
 * James Adaptive Tone Drafting Component
 * Block 2: Mirror user's writing style and contextual tone matching
 */

'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  Wand2, 
  Brain, 
  Target, 
  FileText, 
  MessageSquare, 
  Sparkles,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Copy,
  Download,
  RefreshCw,
  User,
  Settings
} from 'lucide-react';
import { toast } from 'sonner';

interface ToneProfile {
  formality_level: number;
  enthusiasm_level: number;
  directness_level: number;
  emoji_usage: number;
  sentence_length: 'short' | 'medium' | 'long';
  greeting_style: 'formal' | 'casual' | 'friendly' | 'professional';
  closing_style: 'formal' | 'casual' | 'warm' | 'brief';
  vocabulary_complexity: 'simple' | 'moderate' | 'complex';
  punctuation_style: 'minimal' | 'standard' | 'expressive';
}

interface GeneratedDraft {
  subject: string;
  body: string;
  tone_analysis: {
    predicted_tone: ToneProfile;
    confidence_score: number;
    mirror_accuracy: number;
  };
  alternatives: Array<{
    body: string;
    tone_variant: string;
    use_case: string;
  }>;
  explanation: string;
  estimated_edit_probability: number;
}

interface ToneProfileData {
  formality_level: number;
  enthusiasm_level: number;
  directness_level: number;
  emoji_usage: number;
  learned_samples: number;
  mirror_mode_accuracy: number;
  last_updated: string;
}

export function AdaptiveToneDrafting() {
  const [draftForm, setDraftForm] = useState({
    recipient_email: '',
    recipient_context: 'work',
    subject: '',
    key_points: '',
    draft_intent: 'new',
    mirror_mode: false,
    original_email: ''
  });

  const [generatedDraft, setGeneratedDraft] = useState<GeneratedDraft | null>(null);
  const [toneProfile, setToneProfile] = useState<ToneProfileData | null>(null);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [mirrorModeReady, setMirrorModeReady] = useState(false);

  useEffect(() => {
    loadToneProfile();
  }, []);

  const loadToneProfile = async () => {
    try {
      const response = await fetch('/api/james/tone/analyze');
      const data = await response.json();
      
      if (data.success && data.data.profile) {
        setToneProfile(data.data.profile);
        setMirrorModeReady(data.data.ready_for_mirror_mode);
      }
    } catch (error) {
      console.error('Failed to load tone profile:', error);
    }
  };

  const analyzeTone = async () => {
    if (!draftForm.original_email.trim()) {
      toast.error('Please provide email content to analyze');
      return;
    }

    setAnalyzing(true);
    
    try {
      const response = await fetch('/api/james/tone/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: draftForm.original_email,
          context: draftForm.recipient_context,
          learn_from_sample: true
        })
      });

      const data = await response.json();
      
      if (data.success) {
        toast.success('Tone analyzed and learned from sample!');
        loadToneProfile(); // Refresh profile
      } else {
        toast.error(data.error || 'Failed to analyze tone');
      }
    } catch (error) {
      console.error('Tone analysis error:', error);
      toast.error('Failed to analyze tone');
    } finally {
      setAnalyzing(false);
    }
  };

  const generateDraft = async () => {
    if (!draftForm.recipient_email || !draftForm.subject || !draftForm.key_points) {
      toast.error('Please fill in recipient email, subject, and key points');
      return;
    }

    setLoading(true);
    
    try {
      const keyPointsArray = draftForm.key_points
        .split('\n')
        .map(point => point.trim())
        .filter(point => point.length > 0);

      const response = await fetch('/api/james/tone/draft', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recipient_email: draftForm.recipient_email,
          recipient_context: draftForm.recipient_context,
          subject: draftForm.subject,
          key_points: keyPointsArray,
          draft_intent: draftForm.draft_intent,
          mirror_mode: draftForm.mirror_mode,
          original_email: draftForm.original_email ? {
            content: draftForm.original_email,
            sender: draftForm.recipient_email
          } : undefined
        })
      });

      const data = await response.json();
      
      if (data.success) {
        setGeneratedDraft(data.data.draft);
        toast.success('Draft generated with James intelligence!');
      } else {
        toast.error(data.error || 'Failed to generate draft');
      }
    } catch (error) {
      console.error('Draft generation error:', error);
      toast.error('Failed to generate draft');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success('Copied to clipboard!');
    } catch (error) {
      toast.error('Failed to copy to clipboard');
    }
  };

  const getToneBar = (label: string, value: number, color: string = 'bg-blue-500') => (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span className="font-medium">{label}</span>
        <span className="text-muted-foreground">{Math.round(value * 100)}%</span>
      </div>
      <Progress value={value * 100} className={`h-2 ${color}`} />
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Adaptive Tone Drafting</h2>
          <p className="text-muted-foreground">
            James learns your writing style and mirrors your tone perfectly
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          {mirrorModeReady && (
            <Badge className="bg-green-100 text-green-800">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Mirror Mode Ready
            </Badge>
          )}
          
          <Button 
            onClick={loadToneProfile}
            variant="outline"
            size="sm"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Samples Analyzed</p>
                <p className="text-2xl font-bold">{toneProfile?.learned_samples || 0}</p>
                <p className="text-xs text-muted-foreground">Need 5+ for Mirror Mode</p>
              </div>
              <Brain className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Mirror Accuracy</p>
                <p className="text-2xl font-bold">
                  {Math.round((toneProfile?.mirror_mode_accuracy || 0) * 100)}%
                </p>
                <p className="text-xs text-muted-foreground">Target: {'<'}15% edits</p>
              </div>
              <Target className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Formality Level</p>
                <p className="text-2xl font-bold">
                  {Math.round((toneProfile?.formality_level || 0.6) * 100)}%
                </p>
                <p className="text-xs text-muted-foreground">Your typical style</p>
              </div>
              <User className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Edit Rate</p>
                <p className="text-2xl font-bold">
                  {generatedDraft ? 
                    `${Math.round(generatedDraft.estimated_edit_probability * 100)}%` : 
                    'N/A'
                  }
                </p>
                <p className="text-xs text-muted-foreground">Lower is better</p>
              </div>
              <TrendingUp className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="draft" className="w-full">
        <TabsList>
          <TabsTrigger value="draft">Generate Draft</TabsTrigger>
          <TabsTrigger value="analyze">Analyze Tone</TabsTrigger>
          <TabsTrigger value="profile">Your Style Profile</TabsTrigger>
          <TabsTrigger value="templates">Role Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="draft" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Draft Form */}
            <Card>
              <CardHeader>
                <CardTitle>Email Draft Generator</CardTitle>
                <CardDescription>
                  Let James craft your email with perfect tone and style
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="recipient">Recipient Email</Label>
                    <Input
                      id="recipient"
                      placeholder="colleague@company.com"
                      value={draftForm.recipient_email}
                      onChange={(e) => setDraftForm(prev => ({
                        ...prev,
                        recipient_email: e.target.value
                      }))}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="context">Context</Label>
                    <Select
                      value={draftForm.recipient_context}
                      onValueChange={(value) => setDraftForm(prev => ({
                        ...prev,
                        recipient_context: value
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="work">Work</SelectItem>
                        <SelectItem value="personal">Personal</SelectItem>
                        <SelectItem value="vendor">Vendor</SelectItem>
                        <SelectItem value="family">Family</SelectItem>
                        <SelectItem value="formal">Formal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="subject">Subject Line</Label>
                  <Input
                    id="subject"
                    placeholder="Project Update - Q4 Review"
                    value={draftForm.subject}
                    onChange={(e) => setDraftForm(prev => ({
                      ...prev,
                      subject: e.target.value
                    }))}
                  />
                </div>

                <div>
                  <Label htmlFor="keypoints">Key Points (one per line)</Label>
                  <Textarea
                    id="keypoints"
                    placeholder="• Meeting scheduled for Friday&#10;• Budget approved for new features&#10;• Timeline moved to end of month"
                    className="min-h-[100px]"
                    value={draftForm.key_points}
                    onChange={(e) => setDraftForm(prev => ({
                      ...prev,
                      key_points: e.target.value
                    }))}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="intent">Draft Type</Label>
                    <Select
                      value={draftForm.draft_intent}
                      onValueChange={(value) => setDraftForm(prev => ({
                        ...prev,
                        draft_intent: value
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">New Email</SelectItem>
                        <SelectItem value="reply">Reply</SelectItem>
                        <SelectItem value="forward">Forward</SelectItem>
                        <SelectItem value="follow_up">Follow Up</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center space-x-2 pt-6">
                    <Switch
                      id="mirror-mode"
                      checked={draftForm.mirror_mode}
                      onCheckedChange={(checked) => setDraftForm(prev => ({
                        ...prev,
                        mirror_mode: checked
                      }))}
                      disabled={!mirrorModeReady}
                    />
                    <Label htmlFor="mirror-mode" className="text-sm">
                      Mirror Mode
                      {!mirrorModeReady && (
                        <Badge variant="secondary" className="ml-2">
                          Need more samples
                        </Badge>
                      )}
                    </Label>
                  </div>
                </div>

                <Button 
                  onClick={generateDraft}
                  disabled={loading}
                  className="w-full"
                >
                  <Wand2 className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                  {loading ? 'Generating Draft...' : 'Generate Draft with James'}
                </Button>
              </CardContent>
            </Card>

            {/* Generated Draft Display */}
            <Card>
              <CardHeader>
                <CardTitle>Generated Draft</CardTitle>
                <CardDescription>
                  James-crafted email with your personal style
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!generatedDraft ? (
                  <div className="text-center py-8">
                    <MessageSquare className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">
                      Fill out the form and click "Generate Draft" to see James in action
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Subject */}
                    <div>
                      <Label className="text-sm font-medium">Subject</Label>
                      <div className="mt-1 p-2 bg-muted rounded border font-medium">
                        {generatedDraft.subject}
                      </div>
                    </div>

                    {/* Body */}
                    <div>
                      <Label className="text-sm font-medium">Email Body</Label>
                      <div className="mt-1 p-4 bg-muted rounded border whitespace-pre-wrap font-mono text-sm">
                        {generatedDraft.body}
                      </div>
                    </div>

                    {/* Analysis */}
                    <div className="grid grid-cols-3 gap-4 py-2">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {Math.round(generatedDraft.tone_analysis.confidence_score * 100)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Confidence</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          {Math.round(generatedDraft.tone_analysis.mirror_accuracy * 100)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Mirror Accuracy</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">
                          {Math.round(generatedDraft.estimated_edit_probability * 100)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Edit Probability</div>
                      </div>
                    </div>

                    {/* Explanation */}
                    <div className="bg-blue-50 p-3 rounded text-sm">
                      <strong>James Explanation:</strong> {generatedDraft.explanation}
                    </div>

                    {/* Actions */}
                    <div className="flex space-x-2">
                      <Button 
                        onClick={() => copyToClipboard(generatedDraft.body)}
                        variant="outline"
                        size="sm"
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copy Draft
                      </Button>
                      
                      <Button 
                        onClick={() => copyToClipboard(`Subject: ${generatedDraft.subject}\n\n${generatedDraft.body}`)}
                        variant="outline"
                        size="sm"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Copy Full Email
                      </Button>
                    </div>

                    {/* Alternatives */}
                    {generatedDraft.alternatives.length > 0 && (
                      <div>
                        <Separator className="my-4" />
                        <Label className="text-sm font-medium">Alternative Versions</Label>
                        <div className="mt-2 space-y-3">
                          {generatedDraft.alternatives.map((alt, index) => (
                            <div key={index} className="border rounded p-3">
                              <div className="flex justify-between items-center mb-2">
                                <Badge variant="outline">{alt.tone_variant}</Badge>
                                <Button 
                                  onClick={() => copyToClipboard(alt.body)}
                                  size="sm"
                                  variant="ghost"
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                              </div>
                              <p className="text-xs text-muted-foreground mb-2">{alt.use_case}</p>
                              <div className="text-sm whitespace-pre-wrap font-mono bg-muted p-2 rounded">
                                {alt.body.substring(0, 200)}...
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analyze" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tone Analysis & Learning</CardTitle>
              <CardDescription>
                Analyze your writing samples to improve James' Mirror Mode accuracy
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="sample-email">Email Sample for Analysis</Label>
                <Textarea
                  id="sample-email"
                  placeholder="Paste one of your previously sent emails here for James to analyze and learn from..."
                  className="min-h-[200px]"
                  value={draftForm.original_email}
                  onChange={(e) => setDraftForm(prev => ({
                    ...prev,
                    original_email: e.target.value
                  }))}
                />
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex-1">
                  <Label>Context</Label>
                  <Select
                    value={draftForm.recipient_context}
                    onValueChange={(value) => setDraftForm(prev => ({
                      ...prev,
                      recipient_context: value
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="work">Work</SelectItem>
                      <SelectItem value="personal">Personal</SelectItem>
                      <SelectItem value="vendor">Vendor</SelectItem>
                      <SelectItem value="family">Family</SelectItem>
                      <SelectItem value="formal">Formal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={analyzeTone}
                  disabled={analyzing}
                >
                  <Brain className={`w-4 h-4 mr-2 ${analyzing ? 'animate-pulse' : ''}`} />
                  {analyzing ? 'Analyzing...' : 'Analyze & Learn'}
                </Button>
              </div>

              <div className="bg-yellow-50 p-4 rounded">
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-yellow-600" />
                  <span className="font-medium text-yellow-800">Tip</span>
                </div>
                <p className="text-sm text-yellow-700 mt-1">
                  Provide 5+ email samples from different contexts to unlock Mirror Mode with high accuracy.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Writing Style Profile</CardTitle>
              <CardDescription>
                How James understands your unique communication style
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!toneProfile ? (
                <div className="text-center py-8">
                  <AlertCircle className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No tone profile available yet. Analyze some email samples to get started.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      {getToneBar('Formality Level', toneProfile.formality_level, 'bg-purple-500')}
                      {getToneBar('Enthusiasm Level', toneProfile.enthusiasm_level, 'bg-orange-500')}
                      {getToneBar('Directness Level', toneProfile.directness_level, 'bg-red-500')}
                      {getToneBar('Emoji Usage', toneProfile.emoji_usage, 'bg-yellow-500')}
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Profile Summary</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Samples Analyzed:</span>
                            <span className="font-medium">{toneProfile.learned_samples}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Mirror Mode Accuracy:</span>
                            <span className="font-medium">{Math.round(toneProfile.mirror_mode_accuracy * 100)}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Last Updated:</span>
                            <span className="font-medium">
                              {new Date(toneProfile.last_updated).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-2">Style Characteristics</h4>
                        <div className="space-y-1 text-sm">
                          <Badge variant="outline">
                            {toneProfile.formality_level > 0.7 ? 'Formal' : 
                             toneProfile.formality_level > 0.4 ? 'Professional' : 'Casual'} Writer
                          </Badge>
                          <Badge variant="outline">
                            {toneProfile.enthusiasm_level > 0.6 ? 'Enthusiastic' : 
                             toneProfile.enthusiasm_level > 0.4 ? 'Balanced' : 'Reserved'} Tone
                          </Badge>
                          <Badge variant="outline">
                            {toneProfile.directness_level > 0.6 ? 'Direct' : 
                             toneProfile.directness_level > 0.4 ? 'Moderate' : 'Diplomatic'} Approach
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Role-based templates will be implemented here */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Coming Soon</CardTitle>
                <CardDescription>Role-based response templates</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Pre-configured templates for different professional roles and contexts.
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
