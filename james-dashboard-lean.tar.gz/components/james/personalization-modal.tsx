

'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { User, Mic, Clock, Heart } from 'lucide-react';

interface PersonalizationModalProps {
  isOpen: boolean;
  onComplete: (preferences: UserPreferences) => void;
}

interface UserPreferences {
  preferredName: string;
  genderPreference: 'male' | 'female' | 'neutral';
  voiceType: 'professional' | 'friendly' | 'warm' | 'energetic';
  timeGreeting: boolean;
}

export function PersonalizationModal({ isOpen, onComplete }: PersonalizationModalProps) {
  const [step, setStep] = useState(1);
  const [preferences, setPreferences] = useState<UserPreferences>({
    preferredName: '',
    genderPreference: 'neutral',
    voiceType: 'professional',
    timeGreeting: true
  });

  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    if (hour < 21) return 'Good evening';
    return 'Good night';
  };

  const handleComplete = () => {
    // Save to localStorage for persistence
    localStorage.setItem('jamesPreferences', JSON.stringify(preferences));
    onComplete(preferences);
  };

  const getVoiceDescription = (voiceType: string) => {
    const descriptions = {
      professional: "Clear, confident, and business-focused tone",
      friendly: "Warm, approachable, and conversational style", 
      warm: "Caring, empathetic, and personally connected",
      energetic: "Upbeat, enthusiastic, and motivating"
    };
    return descriptions[voiceType as keyof typeof descriptions] || '';
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Heart className="h-5 w-5 text-blue-500" />
            <span>Let's Personalize James</span>
          </DialogTitle>
          <DialogDescription>
            Help James provide a personalized experience tailored just for you.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <User className="h-5 w-5" />
                  <span>How should James address you?</span>
                </CardTitle>
                <CardDescription>
                  James will use this name in all interactions and greetings.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="preferredName">Preferred Name</Label>
                  <Input
                    id="preferredName"
                    placeholder="e.g., John, Sarah, Dr. Smith, etc."
                    value={preferences.preferredName}
                    onChange={(e) => setPreferences({ ...preferences, preferredName: e.target.value })}
                    className="mt-1"
                  />
                </div>
                
                {preferences.preferredName && (
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-700">
                      <strong>Preview:</strong> "{getTimeOfDay()}, {preferences.preferredName}! 
                      How can I assist you with your emails today?"
                    </p>
                  </div>
                )}

                <div className="flex justify-between pt-4">
                  <div /> {/* Spacer */}
                  <Button 
                    onClick={() => setStep(2)} 
                    disabled={!preferences.preferredName.trim()}
                  >
                    Continue
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <User className="h-5 w-5" />
                  <span>Communication Style</span>
                </CardTitle>
                <CardDescription>
                  Choose how you'd like James to communicate with you.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Gender Preference for James</Label>
                  <RadioGroup
                    value={preferences.genderPreference}
                    onValueChange={(value) => setPreferences({ 
                      ...preferences, 
                      genderPreference: value as 'male' | 'female' | 'neutral' 
                    })}
                    className="mt-2"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male">Male (He/Him) - More direct approach</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female">Female (She/Her) - More nurturing approach</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="neutral" id="neutral" />
                      <Label htmlFor="neutral">Neutral (They/Them) - Balanced approach</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="flex justify-between pt-4">
                  <Button variant="outline" onClick={() => setStep(1)}>
                    Back
                  </Button>
                  <Button onClick={() => setStep(3)}>
                    Continue
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {step === 3 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <Mic className="h-5 w-5" />
                  <span>Voice & Tone</span>
                </CardTitle>
                <CardDescription>
                  Select James's communication personality.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="voiceType">Voice Type</Label>
                  <Select
                    value={preferences.voiceType}
                    onValueChange={(value) => setPreferences({ 
                      ...preferences, 
                      voiceType: value as 'professional' | 'friendly' | 'warm' | 'energetic'
                    })}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select voice type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional & Confident</SelectItem>
                      <SelectItem value="friendly">Friendly & Conversational</SelectItem>
                      <SelectItem value="warm">Warm & Empathetic</SelectItem>
                      <SelectItem value="energetic">Energetic & Upbeat</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500 mt-1">
                    {getVoiceDescription(preferences.voiceType)}
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="timeGreeting"
                    checked={preferences.timeGreeting}
                    onChange={(e) => setPreferences({ 
                      ...preferences, 
                      timeGreeting: e.target.checked 
                    })}
                    className="rounded"
                  />
                  <Label htmlFor="timeGreeting" className="text-sm">
                    Use time-based greetings (Good morning, Good afternoon, etc.)
                  </Label>
                </div>

                {preferences.preferredName && (
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="text-sm text-green-700">
                      <strong>Final Preview:</strong><br />
                      "{preferences.timeGreeting ? getTimeOfDay() + ', ' : 'Hello, '}{preferences.preferredName}! 
                      I'm James, your {preferences.genderPreference === 'male' ? 'email assistant' : 
                      preferences.genderPreference === 'female' ? 'email assistant' : 'email assistant'}. 
                      Ready to help you with {preferences.voiceType} support!"
                    </p>
                  </div>
                )}

                <div className="flex justify-between pt-4">
                  <Button variant="outline" onClick={() => setStep(2)}>
                    Back
                  </Button>
                  <Button onClick={handleComplete} className="bg-blue-600 hover:bg-blue-700">
                    Complete Setup
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
