
/**
 * James Role-Based Response Templates
 * Pre-configured templates for different professional contexts
 */

'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Briefcase, 
  Users, 
  ShoppingCart, 
  Phone, 
  MessageCircle, 
  CheckCircle,
  Copy,
  Edit3,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner';

interface RoleTemplate {
  id: string;
  name: string;
  role: string;
  context: string;
  icon: React.ReactNode;
  tone_profile: {
    formality_level: number;
    enthusiasm_level: number;
    directness_level: number;
    key_phrases: string[];
  };
  templates: {
    greeting: string;
    body_structure: string;
    closing: string;
    sample_scenarios: string[];
  };
}

const ROLE_TEMPLATES: RoleTemplate[] = [
  {
    id: 'executive',
    name: 'Executive Communication',
    role: 'C-Suite / Senior Management',
    context: 'High-level business communications',
    icon: <Briefcase className="w-6 h-6" />,
    tone_profile: {
      formality_level: 0.9,
      enthusiasm_level: 0.4,
      directness_level: 0.8,
      key_phrases: ['strategic initiative', 'stakeholder alignment', 'executive summary', 'key metrics']
    },
    templates: {
      greeting: 'Dear {name},',
      body_structure: 'Executive summary → Key points → Next steps → Timeline',
      closing: 'Best regards,',
      sample_scenarios: [
        'Board meeting updates',
        'Strategic initiative announcements',
        'Stakeholder communications',
        'Executive decision notifications'
      ]
    }
  },
  {
    id: 'sales',
    name: 'Sales Outreach',
    role: 'Sales Representative',
    context: 'Client acquisition and relationship management',
    icon: <Users className="w-6 h-6" />,
    tone_profile: {
      formality_level: 0.6,
      enthusiasm_level: 0.8,
      directness_level: 0.7,
      key_phrases: ['excited to connect', 'value proposition', 'mutual benefit', 'next steps']
    },
    templates: {
      greeting: 'Hi {name}!',
      body_structure: 'Personal connection → Value proposition → Social proof → Call to action',
      closing: 'Looking forward to connecting,',
      sample_scenarios: [
        'Initial prospect outreach',
        'Follow-up after demo',
        'Proposal presentations',
        'Client relationship management'
      ]
    }
  },
  {
    id: 'customer_support',
    name: 'Customer Support',
    role: 'Support Representative',
    context: 'Customer service and issue resolution',
    icon: <MessageCircle className="w-6 h-6" />,
    tone_profile: {
      formality_level: 0.7,
      enthusiasm_level: 0.6,
      directness_level: 0.6,
      key_phrases: ['thank you for contacting', 'happy to help', 'resolve this quickly', 'additional assistance']
    },
    templates: {
      greeting: 'Hello {name},\n\nThank you for contacting us.',
      body_structure: 'Acknowledgment → Solution/Steps → Verification → Additional support offer',
      closing: 'Please don\'t hesitate to reach out if you need further assistance.\n\nBest regards,',
      sample_scenarios: [
        'Issue resolution',
        'Product troubleshooting',
        'Account assistance',
        'Feature explanations'
      ]
    }
  },
  {
    id: 'vendor_management',
    name: 'Vendor Management',
    role: 'Procurement / Vendor Relations',
    context: 'Supplier and contractor communications',
    icon: <ShoppingCart className="w-6 h-6" />,
    tone_profile: {
      formality_level: 0.8,
      enthusiasm_level: 0.3,
      directness_level: 0.9,
      key_phrases: ['procurement requirements', 'compliance standards', 'deliverable timeline', 'contract terms']
    },
    templates: {
      greeting: 'Dear {name},',
      body_structure: 'Reference → Requirements → Timeline → Compliance → Next steps',
      closing: 'We look forward to your response.\n\nRegards,',
      sample_scenarios: [
        'RFP communications',
        'Contract negotiations',
        'Performance reviews',
        'Compliance requirements'
      ]
    }
  },
  {
    id: 'internal_team',
    name: 'Internal Team',
    role: 'Team Member / Manager',
    context: 'Internal team collaboration',
    icon: <Users className="w-6 h-6" />,
    tone_profile: {
      formality_level: 0.4,
      enthusiasm_level: 0.7,
      directness_level: 0.6,
      key_phrases: ['team update', 'collaboration', 'great work', 'let\'s sync']
    },
    templates: {
      greeting: 'Hey team!',
      body_structure: 'Context → Updates → Action items → Questions/Support',
      closing: 'Thanks everyone!',
      sample_scenarios: [
        'Project updates',
        'Meeting follow-ups',
        'Team announcements',
        'Collaboration requests'
      ]
    }
  },
  {
    id: 'client_relations',
    name: 'Client Relations',
    role: 'Account Manager',
    context: 'Ongoing client relationship management',
    icon: <Phone className="w-6 h-6" />,
    tone_profile: {
      formality_level: 0.7,
      enthusiasm_level: 0.6,
      directness_level: 0.5,
      key_phrases: ['partnership', 'value delivery', 'client success', 'strategic alignment']
    },
    templates: {
      greeting: 'Hello {name},\n\nI hope this email finds you well.',
      body_structure: 'Relationship acknowledgment → Update/Request → Value reinforcement → Next steps',
      closing: 'Thank you for your continued partnership.\n\nBest regards,',
      sample_scenarios: [
        'Quarterly business reviews',
        'Service updates',
        'Contract renewals',
        'Strategic planning'
      ]
    }
  }
];

export function RoleTemplates() {
  const [selectedTemplate, setSelectedTemplate] = useState<RoleTemplate | null>(null);
  const [customization, setCustomization] = useState({
    recipient_name: '',
    scenario: '',
    key_points: '',
    custom_tone: {
      formality_level: 0.7,
      enthusiasm_level: 0.5,
      directness_level: 0.6
    }
  });
  const [generatedEmail, setGeneratedEmail] = useState('');

  const selectTemplate = (template: RoleTemplate) => {
    setSelectedTemplate(template);
    setCustomization(prev => ({
      ...prev,
      custom_tone: {
        formality_level: template.tone_profile.formality_level,
        enthusiasm_level: template.tone_profile.enthusiasm_level,
        directness_level: template.tone_profile.directness_level
      }
    }));
  };

  const generateFromTemplate = () => {
    if (!selectedTemplate) return;

    const greeting = selectedTemplate.templates.greeting.replace('{name}', customization.recipient_name || 'there');
    const keyPoints = customization.key_points.split('\n').map(point => point.trim()).filter(point => point.length > 0);
    
    let body = '';
    if (keyPoints.length > 0) {
      body = keyPoints.map(point => `• ${point}`).join('\n');
    } else {
      body = `I wanted to reach out regarding ${customization.scenario || 'our upcoming discussion'}.`;
    }

    const closing = selectedTemplate.templates.closing;
    
    const fullEmail = `${greeting}\n\n${body}\n\n${closing}`;
    setGeneratedEmail(fullEmail);
    toast.success('Email generated from template!');
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success('Copied to clipboard!');
    } catch (error) {
      toast.error('Failed to copy to clipboard');
    }
  };

  return (
    <div className="space-y-6">
      {/* Template Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {ROLE_TEMPLATES.map((template) => (
          <Card
            key={template.id}
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedTemplate?.id === template.id ? 'ring-2 ring-blue-500' : ''
            }`}
            onClick={() => selectTemplate(template)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
                  {template.icon}
                </div>
                <div>
                  <CardTitle className="text-base">{template.name}</CardTitle>
                  <CardDescription className="text-sm">{template.role}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-muted-foreground mb-3">{template.context}</p>
              
              <div className="space-y-2">
                <div className="flex flex-wrap gap-1">
                  <Badge variant="outline" className="text-xs">
                    Formality: {Math.round(template.tone_profile.formality_level * 100)}%
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    Energy: {Math.round(template.tone_profile.enthusiasm_level * 100)}%
                  </Badge>
                </div>
                
                <div className="text-xs text-muted-foreground">
                  <strong>Scenarios:</strong> {template.templates.sample_scenarios.slice(0, 2).join(', ')}
                  {template.templates.sample_scenarios.length > 2 && '...'}
                </div>
              </div>

              {selectedTemplate?.id === template.id && (
                <div className="mt-3 pt-3 border-t">
                  <Badge className="bg-green-100 text-green-800">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Selected
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Template Customization */}
      {selectedTemplate && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Customization Form */}
          <Card>
            <CardHeader>
              <CardTitle>Customize Template</CardTitle>
              <CardDescription>
                Personalize the {selectedTemplate.name.toLowerCase()} template for your specific needs
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="recipient">Recipient Name</Label>
                <Input
                  id="recipient"
                  placeholder="John Smith"
                  value={customization.recipient_name}
                  onChange={(e) => setCustomization(prev => ({
                    ...prev,
                    recipient_name: e.target.value
                  }))}
                />
              </div>

              <div>
                <Label htmlFor="scenario">Scenario</Label>
                <Select
                  value={customization.scenario}
                  onValueChange={(value) => setCustomization(prev => ({
                    ...prev,
                    scenario: value
                  }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a scenario" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedTemplate.templates.sample_scenarios.map((scenario, index) => (
                      <SelectItem key={index} value={scenario}>
                        {scenario}
                      </SelectItem>
                    ))}
                    <SelectItem value="custom">Custom scenario</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="keypoints">Key Points (one per line)</Label>
                <Textarea
                  id="keypoints"
                  placeholder="• First key point&#10;• Second important item&#10;• Action needed"
                  className="min-h-[100px]"
                  value={customization.key_points}
                  onChange={(e) => setCustomization(prev => ({
                    ...prev,
                    key_points: e.target.value
                  }))}
                />
              </div>

              <div className="space-y-3">
                <Label>Tone Adjustments</Label>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Formality</span>
                    <span className="text-sm text-muted-foreground">
                      {Math.round(customization.custom_tone.formality_level * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={customization.custom_tone.formality_level * 100}
                    onChange={(e) => setCustomization(prev => ({
                      ...prev,
                      custom_tone: {
                        ...prev.custom_tone,
                        formality_level: parseInt(e.target.value) / 100
                      }
                    }))}
                    className="w-full"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Enthusiasm</span>
                    <span className="text-sm text-muted-foreground">
                      {Math.round(customization.custom_tone.enthusiasm_level * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={customization.custom_tone.enthusiasm_level * 100}
                    onChange={(e) => setCustomization(prev => ({
                      ...prev,
                      custom_tone: {
                        ...prev.custom_tone,
                        enthusiasm_level: parseInt(e.target.value) / 100
                      }
                    }))}
                    className="w-full"
                  />
                </div>
              </div>

              <Button 
                onClick={generateFromTemplate}
                className="w-full"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Email from Template
              </Button>
            </CardContent>
          </Card>

          {/* Generated Email Preview */}
          <Card>
            <CardHeader>
              <CardTitle>Generated Email</CardTitle>
              <CardDescription>
                Preview of your customized email based on the template
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!generatedEmail ? (
                <div className="text-center py-8">
                  <Edit3 className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    Fill out the form and click "Generate Email" to see your customized template
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded border whitespace-pre-wrap font-mono text-sm">
                    {generatedEmail}
                  </div>

                  <div className="flex space-x-2">
                    <Button 
                      onClick={() => copyToClipboard(generatedEmail)}
                      size="sm"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Email
                    </Button>
                    
                    <Button 
                      onClick={() => setGeneratedEmail('')}
                      variant="outline"
                      size="sm"
                    >
                      Clear
                    </Button>
                  </div>

                  <div className="bg-blue-50 p-3 rounded text-sm">
                    <strong>Template Used:</strong> {selectedTemplate.name} - {selectedTemplate.templates.body_structure}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
