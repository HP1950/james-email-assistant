
/**
 * James Deep Attachments Handling Component
 * Block 4: PDF parsing, image analysis, document summarization, attachment-based insights
 */

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  FileText, 
  Image, 
  Upload, 
  Eye, 
  Brain,
  BarChart3,
  FileCheck2,
  Clock,
  Users,
  DollarSign,
  Calendar,
  AlertTriangle,
  TrendingUp,
  Download,
  RefreshCw,
  Zap,
  CheckCircle2,
  XCircle,
  Loader2,
  FileImage,
  FileSpreadsheet,
  Settings,
  Search,
  Filter,
  ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';
import { useDropzone } from 'react-dropzone';

interface AttachmentMetadata {
  id: string;
  filename: string;
  size: number;
  mime_type: string;
  processing_status: 'pending' | 'processing' | 'completed' | 'failed';
  uploaded_at: string;
  processed_at?: string;
  capabilities: {
    textExtraction: boolean;
    imageAnalysis: boolean;
    structuredData: boolean;
    ocrCapable: boolean;
  };
  analysis_summary?: {
    summary: string;
    confidence_score: number;
    data_quality: 'excellent' | 'good' | 'fair' | 'poor';
    processing_time: number;
  };
}

interface AttachmentAnalysis {
  summary: string;
  key_topics: string[];
  action_items: {
    total: number;
    by_priority: {
      high: number;
      medium: number;
      low: number;
    };
    items: Array<{
      id: string;
      description: string;
      priority: 'high' | 'medium' | 'low';
      status: 'pending' | 'in_progress' | 'completed';
      assignee?: string;
      confidence: number;
    }>;
  };
  financial_data: {
    total_entries: number;
    total_amount_usd: number;
    by_type: Record<string, number>;
    entries: Array<{
      id: string;
      type: string;
      amount: number;
      currency: string;
      context: string;
      confidence: number;
    }>;
  };
  important_dates: {
    total: number;
    upcoming: number;
    by_type: Record<string, number>;
    dates: Array<{
      id: string;
      date: string;
      type: string;
      description: string;
      importance: 'high' | 'medium' | 'low';
      confidence: number;
    }>;
  };
  stakeholders: {
    total: number;
    with_email: number;
    with_phone: number;
    contacts: Array<{
      id: string;
      name: string;
      email?: string;
      phone?: string;
      company?: string;
      role?: string;
      confidence: number;
    }>;
  };
}

interface AttachmentInsights {
  analyzed_attachments: number;
  insight_summary: {
    total_action_items: number;
    high_priority_actions: number;
    upcoming_deadlines: number;
    financial_impact: number;
    unique_stakeholders: number;
    risk_indicators: number;
    opportunity_indicators: number;
  };
}

export function DeepAttachmentsHandling() {
  const [attachments, setAttachments] = useState<AttachmentMetadata[]>([]);
  const [selectedAttachment, setSelectedAttachment] = useState<string | null>(null);
  const [attachmentAnalysis, setAttachmentAnalysis] = useState<AttachmentAnalysis | null>(null);
  const [insights, setInsights] = useState<AttachmentInsights | null>(null);
  const [processing, setProcessing] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [processingStats, setProcessingStats] = useState({
    totalAttachments: 0,
    completedProcessing: 0,
    successRate: 0,
    avgConfidenceScore: 0
  });

  useEffect(() => {
    loadAttachments();
    loadInsights();
  }, []);

  const loadAttachments = async () => {
    try {
      const response = await fetch('/api/james/attachments/process');
      const data = await response.json();
      
      if (data.success) {
        setAttachments(data.data.attachments);
        setProcessingStats({
          totalAttachments: data.data.statistics.total_attachments,
          completedProcessing: data.data.statistics.completed_processing,
          successRate: data.data.statistics.success_rate,
          avgConfidenceScore: data.data.statistics.avg_confidence_score
        });
      }
    } catch (error) {
      console.error('Failed to load attachments:', error);
    }
  };

  const loadInsights = async () => {
    try {
      const response = await fetch('/api/james/attachments/insights?type=summary');
      const data = await response.json();
      
      if (data.success) {
        setInsights({
          analyzed_attachments: data.data.summary_statistics.documents_analyzed,
          insight_summary: {
            total_action_items: data.data.summary_statistics.total_action_items,
            high_priority_actions: Math.floor(data.data.summary_statistics.total_action_items * 0.3),
            upcoming_deadlines: Math.floor(data.data.summary_statistics.total_action_items * 0.2),
            financial_impact: data.data.summary_statistics.total_financial_entries,
            unique_stakeholders: data.data.summary_statistics.unique_stakeholders,
            risk_indicators: 3, // Placeholder
            opportunity_indicators: 2 // Placeholder
          }
        });
      }
    } catch (error) {
      console.error('Failed to load insights:', error);
    }
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    setUploading(true);
    
    for (const file of acceptedFiles) {
      try {
        const formData = new FormData();
        formData.append('attachment', file);
        formData.append('process_immediately', 'true');
        
        const response = await fetch('/api/james/attachments/process', {
          method: 'POST',
          body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
          toast.success(`${file.name} uploaded and processed successfully!`);
        } else {
          toast.error(`Failed to process ${file.name}: ${result.error}`);
        }
      } catch (error) {
        toast.error(`Failed to upload ${file.name}`);
      }
    }
    
    setUploading(false);
    loadAttachments();
    loadInsights();
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    maxFiles: 5,
    maxSize: 50 * 1024 * 1024, // 50MB
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'image/*': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.svg'],
      'text/plain': ['.txt'],
      'text/csv': ['.csv']
    }
  });

  const analyzeAttachment = async (attachmentId: string, forceReprocess = false) => {
    setAnalyzing(true);
    setSelectedAttachment(attachmentId);
    
    try {
      const response = await fetch('/api/james/attachments/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          attachment_id: attachmentId,
          force_reprocess: forceReprocess
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Transform the API response to match our interface
        const analysis: AttachmentAnalysis = {
          summary: data.data.processing_results?.overall_summary || data.data.analysis_results?.summary || 'Analysis not available',
          key_topics: data.data.processing_results?.key_insights?.slice(0, 10) || data.data.analysis_results?.key_topics || [],
          action_items: data.data.processing_results?.action_items || {
            total: 0,
            by_priority: { high: 0, medium: 0, low: 0 },
            items: []
          },
          financial_data: data.data.processing_results?.financial_implications || {
            total_entries: 0,
            total_amount_usd: 0,
            by_type: {},
            entries: []
          },
          important_dates: data.data.processing_results?.important_dates || {
            total: 0,
            upcoming: 0,
            by_type: {},
            dates: []
          },
          stakeholders: data.data.processing_results?.stakeholders || {
            total: 0,
            with_email: 0,
            with_phone: 0,
            contacts: []
          }
        };
        
        setAttachmentAnalysis(analysis);
        toast.success('Attachment analysis completed!');
      } else {
        toast.error(data.error || 'Failed to analyze attachment');
      }
    } catch (error) {
      console.error('Attachment analysis error:', error);
      toast.error('Failed to analyze attachment');
    } finally {
      setAnalyzing(false);
    }
  };

  const getFileIcon = (mimeType: string, filename: string) => {
    if (mimeType.startsWith('image/')) return <FileImage className="w-5 h-5 text-blue-500" />;
    if (mimeType.includes('pdf')) return <FileText className="w-5 h-5 text-red-500" />;
    if (mimeType.includes('sheet') || mimeType.includes('excel')) return <FileSpreadsheet className="w-5 h-5 text-green-500" />;
    if (mimeType.includes('word') || mimeType.includes('document')) return <FileText className="w-5 h-5 text-blue-600" />;
    return <FileCheck2 className="w-5 h-5 text-gray-500" />;
  };

  const getStatusIcon = (status: string) => {
    const icons = {
      pending: <Clock className="w-4 h-4 text-yellow-500" />,
      processing: <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />,
      completed: <CheckCircle2 className="w-4 h-4 text-green-500" />,
      failed: <XCircle className="w-4 h-4 text-red-500" />
    };
    return icons[status as keyof typeof icons] || icons.pending;
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      processing: 'bg-blue-100 text-blue-800',
      completed: 'bg-green-100 text-green-800',
      failed: 'bg-red-100 text-red-800'
    };
    return <Badge className={colors[status as keyof typeof colors] || colors.pending}>{status}</Badge>;
  };

  const formatFileSize = (bytes: number) => {
    const sizes = ['B', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 B';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  const getDataQualityColor = (quality: string) => {
    const colors = {
      excellent: 'text-green-600',
      good: 'text-blue-600',
      fair: 'text-yellow-600',
      poor: 'text-red-600'
    };
    return colors[quality as keyof typeof colors] || colors.good;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Deep Attachments Handling</h2>
          <p className="text-muted-foreground">
            Advanced document analysis, image processing, and intelligent insights extraction
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Badge className="bg-blue-100 text-blue-800">
            <Brain className="w-3 h-3 mr-1" />
            {Math.round(processingStats.avgConfidenceScore * 100)}% Avg Accuracy
          </Badge>
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Attachments Processed</p>
                <p className="text-2xl font-bold">{processingStats.completedProcessing}</p>
                <p className="text-xs text-muted-foreground">of {processingStats.totalAttachments} total</p>
              </div>
              <FileCheck2 className="w-8 h-8 text-blue-600" />
            </div>
            <Progress value={processingStats.totalAttachments > 0 ? (processingStats.completedProcessing / processingStats.totalAttachments) * 100 : 0} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                <p className="text-2xl font-bold">{Math.round(processingStats.successRate)}%</p>
                <p className="text-xs text-muted-foreground">Target: {'>'}90%</p>
              </div>
              <TrendingUp className={`w-8 h-8 ${processingStats.successRate >= 90 ? 'text-green-600' : 'text-yellow-600'}`} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Action Items Found</p>
                <p className="text-2xl font-bold">{insights?.insight_summary.total_action_items || 0}</p>
                <p className="text-xs text-muted-foreground">{insights?.insight_summary.high_priority_actions || 0} high priority</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Stakeholders Identified</p>
                <p className="text-2xl font-bold">{insights?.insight_summary.unique_stakeholders || 0}</p>
                <p className="text-xs text-muted-foreground">From analyzed docs</p>
              </div>
              <Users className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="upload" className="w-full">
        <TabsList>
          <TabsTrigger value="upload">Upload & Process</TabsTrigger>
          <TabsTrigger value="library">Attachment Library</TabsTrigger>
          <TabsTrigger value="analysis">Detailed Analysis</TabsTrigger>
          <TabsTrigger value="insights">Smart Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-6">
          {/* File Upload Area */}
          <Card>
            <CardHeader>
              <CardTitle>Upload Attachments</CardTitle>
              <CardDescription>
                Upload documents and images for intelligent analysis by James
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                  isDragActive
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-muted-foreground/25 hover:border-blue-500 hover:bg-blue-50/50'
                }`}
              >
                <input {...getInputProps()} />
                <div className="flex flex-col items-center space-y-4">
                  <Upload className={`w-12 h-12 ${uploading ? 'animate-pulse' : ''} text-muted-foreground`} />
                  <div>
                    <p className="text-lg font-medium">
                      {isDragActive
                        ? 'Drop your files here...'
                        : 'Drag & drop files here, or click to select'}
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Supports PDF, Word, Excel, PowerPoint, Images, and more (max 50MB each)
                    </p>
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-xs text-muted-foreground">
                    <div className="flex items-center">
                      <FileText className="w-4 h-4 mr-1" />
                      PDFs
                    </div>
                    <div className="flex items-center">
                      <FileSpreadsheet className="w-4 h-4 mr-1" />
                      Sheets
                    </div>
                    <div className="flex items-center">
                      <FileImage className="w-4 h-4 mr-1" />
                      Images
                    </div>
                    <div className="flex items-center">
                      <FileCheck2 className="w-4 h-4 mr-1" />
                      Docs
                    </div>
                  </div>
                </div>
              </div>
              
              {uploading && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                    <span className="font-medium text-blue-900">Processing attachments...</span>
                  </div>
                  <p className="text-sm text-blue-700 mt-1">
                    James is analyzing your files for insights, action items, and key information.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Processing Capabilities */}
          <Card>
            <CardHeader>
              <CardTitle>James Processing Capabilities</CardTitle>
              <CardDescription>
                What James can extract from your attachments
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="flex items-start space-x-3">
                  <FileText className="w-6 h-6 text-blue-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Text Extraction</h4>
                    <p className="text-sm text-muted-foreground">Full content parsing from PDFs, documents, and images</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <BarChart3 className="w-6 h-6 text-green-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Data Analysis</h4>
                    <p className="text-sm text-muted-foreground">Financial data, dates, and structured information</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Users className="w-6 h-6 text-purple-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Contact Extraction</h4>
                    <p className="text-sm text-muted-foreground">Stakeholders, emails, phone numbers, and relationships</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Brain className="w-6 h-6 text-orange-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium">AI Insights</h4>
                    <p className="text-sm text-muted-foreground">Action items, decisions, risks, and opportunities</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="library" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Attachment Library</CardTitle>
              <CardDescription>
                Your processed documents and their analysis status
              </CardDescription>
            </CardHeader>
            <CardContent>
              {attachments.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No attachments uploaded yet. Start by uploading some documents for analysis.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {attachments.map((attachment) => (
                    <div 
                      key={attachment.id} 
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 cursor-pointer"
                      onClick={() => {
                        if (attachment.processing_status === 'completed') {
                          analyzeAttachment(attachment.id);
                        }
                      }}
                    >
                      <div className="flex items-center space-x-3">
                        {getFileIcon(attachment.mime_type, attachment.filename)}
                        <div className="flex-1">
                          <h4 className="font-medium">{attachment.filename}</h4>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span>{formatFileSize(attachment.size)}</span>
                            <span>•</span>
                            <span>Uploaded {new Date(attachment.uploaded_at).toLocaleDateString()}</span>
                            {attachment.analysis_summary && (
                              <>
                                <span>•</span>
                                <span className={getDataQualityColor(attachment.analysis_summary.data_quality)}>
                                  {Math.round(attachment.analysis_summary.confidence_score * 100)}% confidence
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        {/* Capabilities badges */}
                        <div className="flex space-x-1">
                          {attachment.capabilities.textExtraction && (
                            <Badge variant="outline" className="text-xs">Text</Badge>
                          )}
                          {attachment.capabilities.imageAnalysis && (
                            <Badge variant="outline" className="text-xs">Image</Badge>
                          )}
                          {attachment.capabilities.structuredData && (
                            <Badge variant="outline" className="text-xs">Data</Badge>
                          )}
                          {attachment.capabilities.ocrCapable && (
                            <Badge variant="outline" className="text-xs">OCR</Badge>
                          )}
                        </div>
                        
                        {getStatusBadge(attachment.processing_status)}
                        {getStatusIcon(attachment.processing_status)}
                        
                        {attachment.processing_status === 'completed' && (
                          <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analysis" className="space-y-6">
          {!attachmentAnalysis ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <Eye className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    Select a completed attachment from the library to view detailed analysis
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Analysis Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Analysis Summary</CardTitle>
                  <CardDescription>
                    AI-generated insights and extracted information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Document Summary</h4>
                    <p className="text-sm bg-muted p-3 rounded">{attachmentAnalysis.summary}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Key Topics</h4>
                    <div className="flex flex-wrap gap-1">
                      {attachmentAnalysis.key_topics.slice(0, 10).map((topic, index) => (
                        <Badge key={index} variant="outline">{topic}</Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Action Items */}
              <Card>
                <CardHeader>
                  <CardTitle>Action Items ({attachmentAnalysis.action_items.total})</CardTitle>
                  <CardDescription>
                    Tasks and commitments identified in the document
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {attachmentAnalysis.action_items.total === 0 ? (
                    <p className="text-sm text-muted-foreground">No action items found</p>
                  ) : (
                    <div className="space-y-3">
                      <div className="grid grid-cols-3 gap-2 text-sm">
                        <div className="text-center">
                          <div className="text-lg font-bold text-red-600">{attachmentAnalysis.action_items.by_priority.high}</div>
                          <div className="text-xs text-muted-foreground">High</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-yellow-600">{attachmentAnalysis.action_items.by_priority.medium}</div>
                          <div className="text-xs text-muted-foreground">Medium</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-blue-600">{attachmentAnalysis.action_items.by_priority.low}</div>
                          <div className="text-xs text-muted-foreground">Low</div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div className="space-y-2 max-h-40 overflow-y-auto">
                        {attachmentAnalysis.action_items.items.slice(0, 5).map((item) => (
                          <div key={item.id} className="flex items-start space-x-2 text-sm">
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${
                                item.priority === 'high' ? 'border-red-500 text-red-700' :
                                item.priority === 'medium' ? 'border-yellow-500 text-yellow-700' :
                                'border-blue-500 text-blue-700'
                              }`}
                            >
                              {item.priority}
                            </Badge>
                            <div className="flex-1">
                              <p>{item.description}</p>
                              {item.assignee && (
                                <p className="text-xs text-muted-foreground">Assigned to: {item.assignee}</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Financial Data */}
              <Card>
                <CardHeader>
                  <CardTitle>Financial Information</CardTitle>
                  <CardDescription>
                    Monetary values and budget items found
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {attachmentAnalysis.financial_data.total_entries === 0 ? (
                    <p className="text-sm text-muted-foreground">No financial data found</p>
                  ) : (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Total Entries:</span>
                          <span className="ml-2">{attachmentAnalysis.financial_data.total_entries}</span>
                        </div>
                        <div>
                          <span className="font-medium">USD Total:</span>
                          <span className="ml-2 font-bold text-green-600">
                            ${attachmentAnalysis.financial_data.total_amount_usd.toLocaleString()}
                          </span>
                        </div>
                      </div>
                      
                      <div className="space-y-1 text-xs">
                        {Object.entries(attachmentAnalysis.financial_data.by_type).map(([type, count]) => (
                          <div key={type} className="flex justify-between">
                            <span className="capitalize">{type}:</span>
                            <span>{count}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Important Dates */}
              <Card>
                <CardHeader>
                  <CardTitle>Important Dates</CardTitle>
                  <CardDescription>
                    Deadlines and key dates identified
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {attachmentAnalysis.important_dates.total === 0 ? (
                    <p className="text-sm text-muted-foreground">No important dates found</p>
                  ) : (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Total Dates:</span>
                          <span className="ml-2">{attachmentAnalysis.important_dates.total}</span>
                        </div>
                        <div>
                          <span className="font-medium">Upcoming:</span>
                          <span className="ml-2 text-orange-600 font-bold">{attachmentAnalysis.important_dates.upcoming}</span>
                        </div>
                      </div>
                      
                      <div className="space-y-2 max-h-32 overflow-y-auto">
                        {attachmentAnalysis.important_dates.dates.slice(0, 3).map((date) => (
                          <div key={date.id} className="text-sm border-l-2 border-blue-500 pl-3">
                            <div className="font-medium">{new Date(date.date).toLocaleDateString()}</div>
                            <div className="text-xs text-muted-foreground">{date.description}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Stakeholders */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Stakeholders ({attachmentAnalysis.stakeholders.total})</CardTitle>
                  <CardDescription>
                    People and contacts identified in the document
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {attachmentAnalysis.stakeholders.total === 0 ? (
                    <p className="text-sm text-muted-foreground">No stakeholders found</p>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-2 text-sm">
                        <div className="text-center">
                          <div className="text-lg font-bold">{attachmentAnalysis.stakeholders.total}</div>
                          <div className="text-xs text-muted-foreground">Total Contacts</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-blue-600">{attachmentAnalysis.stakeholders.with_email}</div>
                          <div className="text-xs text-muted-foreground">With Email</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-green-600">{attachmentAnalysis.stakeholders.with_phone}</div>
                          <div className="text-xs text-muted-foreground">With Phone</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {attachmentAnalysis.stakeholders.contacts.slice(0, 6).map((contact) => (
                          <div key={contact.id} className="p-3 border rounded text-sm">
                            <div className="font-medium">{contact.name}</div>
                            {contact.email && (
                              <div className="text-xs text-blue-600">{contact.email}</div>
                            )}
                            {contact.company && (
                              <div className="text-xs text-muted-foreground">{contact.company}</div>
                            )}
                            {contact.role && (
                              <div className="text-xs text-muted-foreground">{contact.role}</div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          {!insights ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <Brain className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    Process some attachments to generate intelligent insights
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Key Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle>Cross-Document Insights</CardTitle>
                  <CardDescription>Analysis across all processed documents</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Documents Analyzed:</span>
                    <span className="font-bold">{insights.analyzed_attachments}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Action Items:</span>
                    <span className="font-bold text-orange-600">{insights.insight_summary.total_action_items}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">High Priority:</span>
                    <span className="font-bold text-red-600">{insights.insight_summary.high_priority_actions}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Upcoming Deadlines:</span>
                    <span className="font-bold text-yellow-600">{insights.insight_summary.upcoming_deadlines}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Stakeholders:</span>
                    <span className="font-bold text-blue-600">{insights.insight_summary.unique_stakeholders}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Indicators */}
              <Card>
                <CardHeader>
                  <CardTitle>Risk Assessment</CardTitle>
                  <CardDescription>Potential risks identified across documents</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Risk Indicators:</span>
                    <Badge className="bg-red-100 text-red-800">
                      {insights.insight_summary.risk_indicators} identified
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start space-x-2">
                      <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Deadline Pressure</p>
                        <p className="text-xs text-muted-foreground">Multiple urgent deadlines detected</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-2">
                      <DollarSign className="w-4 h-4 text-yellow-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Budget Tracking</p>
                        <p className="text-xs text-muted-foreground">Financial oversight needed</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Opportunities */}
              <Card>
                <CardHeader>
                  <CardTitle>Opportunities</CardTitle>
                  <CardDescription>Growth and improvement areas found</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Opportunities:</span>
                    <Badge className="bg-green-100 text-green-800">
                      {insights.insight_summary.opportunity_indicators} identified
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start space-x-2">
                      <TrendingUp className="w-4 h-4 text-green-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Process Optimization</p>
                        <p className="text-xs text-muted-foreground">Efficiency improvements possible</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Zap className="w-4 h-4 text-blue-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Automation Potential</p>
                        <p className="text-xs text-muted-foreground">Workflow automation opportunities</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* AI Recommendations */}
              <Card className="md:col-span-2 lg:col-span-3">
                <CardHeader>
                  <CardTitle>James AI Recommendations</CardTitle>
                  <CardDescription>Intelligent suggestions based on attachment analysis</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-red-50 rounded-lg">
                      <h4 className="font-medium text-red-900 mb-2">Immediate Actions</h4>
                      <ul className="text-sm text-red-700 space-y-1">
                        <li>• Address {insights.insight_summary.high_priority_actions} high-priority items</li>
                        <li>• Review upcoming deadlines within 7 days</li>
                        <li>• Follow up with key stakeholders</li>
                      </ul>
                    </div>
                    
                    <div className="p-4 bg-yellow-50 rounded-lg">
                      <h4 className="font-medium text-yellow-900 mb-2">Short-term Planning</h4>
                      <ul className="text-sm text-yellow-700 space-y-1">
                        <li>• Implement deadline tracking system</li>
                        <li>• Schedule stakeholder check-ins</li>
                        <li>• Review budget allocations</li>
                      </ul>
                    </div>
                    
                    <div className="p-4 bg-green-50 rounded-lg">
                      <h4 className="font-medium text-green-900 mb-2">Strategic Improvements</h4>
                      <ul className="text-sm text-green-700 space-y-1">
                        <li>• Automate document processing workflows</li>
                        <li>• Enhance cross-team collaboration</li>
                        <li>• Optimize resource allocation</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
