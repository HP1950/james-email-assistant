

'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Clock, User, Settings, Mic } from 'lucide-react';
import { PersonalizationModal } from './personalization-modal';
import { VoiceCommandInterface } from '@/components/voice/voice-command-interface';
import { appConfig } from '@/lib/config';

interface UserPreferences {
  preferredName: string;
  genderPreference: 'male' | 'female' | 'neutral';
  voiceType: 'professional' | 'friendly' | 'warm' | 'energetic';
  timeGreeting: boolean;
}

export function JamesGreeting() {
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [showPersonalization, setShowPersonalization] = useState(false);
  const [showVoiceCommands, setShowVoiceCommands] = useState(false);
  const [isFirstTime, setIsFirstTime] = useState(true);

  useEffect(() => {
    // Check if user has saved preferences
    const savedPreferences = localStorage.getItem('jamesPreferences');
    if (savedPreferences) {
      setPreferences(JSON.parse(savedPreferences));
      setIsFirstTime(false);
    } else {
      // First time user - show personalization modal
      setShowPersonalization(true);
    }
  }, []);

  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    if (hour < 21) return 'Good evening';
    return 'Good night';
  };

  const getPersonalizedGreeting = () => {
    if (!preferences) {
      return {
        greeting: "Hello!",
        introduction: "I'm James, your email assistant.",
        ready: "How can I help you today?"
      };
    }
    
    const timePrefix = preferences.timeGreeting ? `${getTimeOfDay()}, ` : 'Hello, ';
    const pronoun = preferences.genderPreference === 'male' ? 'He' : 
                   preferences.genderPreference === 'female' ? 'She' : 'They';
    
    const voiceAdjectives = {
      professional: 'efficient and reliable',
      friendly: 'approachable and helpful',
      warm: 'caring and understanding',
      energetic: 'enthusiastic and motivating'
    };

    if (isFirstTime) {
      return {
        greeting: `${timePrefix}${preferences.preferredName}!`,
        introduction: `I'm James, your ${voiceAdjectives[preferences.voiceType]} email assistant. ${pronoun} will help you manage your emails with emotional intelligence and cultural sensitivity.`,
        ready: "What would you like to accomplish today?"
      };
    } else {
      return {
        greeting: `${timePrefix}${preferences.preferredName}!`,
        introduction: `Welcome back! Ready to tackle your emails together?`,
        ready: "How can I assist you today?"
      };
    }
  };

  const handlePersonalizationComplete = (newPreferences: UserPreferences) => {
    setPreferences(newPreferences);
    setShowPersonalization(false);
    setIsFirstTime(true); // Show introduction for newly set up users
  };

  const resetPersonalization = () => {
    localStorage.removeItem('jamesPreferences');
    setPreferences(null);
    setIsFirstTime(true);
    setShowPersonalization(true);
  };

  if (!preferences) {
    return (
      <>
        <PersonalizationModal
          isOpen={showPersonalization}
          onComplete={handlePersonalizationComplete}
        />
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <Heart className="h-12 w-12 text-blue-500" />
              </div>
              <h2 className="text-2xl font-bold">Welcome to James</h2>
              <p className="text-gray-600">Setting up your personalized experience...</p>
            </div>
          </CardContent>
        </Card>
      </>
    );
  }

  const greeting = getPersonalizedGreeting();

  return (
    <>
      <PersonalizationModal
        isOpen={showPersonalization}
        onComplete={handlePersonalizationComplete}
      />
      
      <Card className="mb-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-500 text-white rounded-full">
                  <Heart className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">
                    {greeting.greeting}
                  </h2>
                  {preferences.timeGreeting && (
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      {new Date().toLocaleDateString('en-US', { 
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </div>
                  )}
                </div>
              </div>
              
              <Button 
                variant="ghost" 
                size="sm"
                onClick={resetPersonalization}
                className="text-gray-500 hover:text-gray-700"
              >
                <Settings className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-2">
              <p className="text-gray-700">
                {greeting.introduction}
              </p>
              <p className="text-blue-600 font-medium">
                {greeting.ready}
              </p>
            </div>

            <div className="flex flex-wrap gap-2 text-xs">
              <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                <User className="inline h-3 w-3 mr-1" />
                {preferences.genderPreference} assistant
              </span>
              <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full">
                {preferences.voiceType} tone
              </span>
              <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded-full">
                Emotional Intelligence
              </span>
              <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded-full">
                19 Languages
              </span>
              {appConfig.features.voiceCommands && (
                <span className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded-full">
                  Voice Commands Active
                </span>
              )}
            </div>

            {/* Voice Commands Section */}
            {appConfig.features.voiceCommands && (
              <div className="pt-3 border-t border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Voice Assistant</span>
                  <Button 
                    size="sm" 
                    variant={showVoiceCommands ? "secondary" : "outline"}
                    onClick={() => setShowVoiceCommands(!showVoiceCommands)}
                  >
                    <Mic className="mr-2 h-4 w-4" />
                    {showVoiceCommands ? 'Hide' : 'Try Voice'}
                  </Button>
                </div>
                {!showVoiceCommands && (
                  <p className="text-xs text-gray-500">
                    Click "Try Voice" to activate voice commands and speak with James
                  </p>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Voice Commands Interface */}
      {showVoiceCommands && appConfig.features.voiceCommands && (
        <VoiceCommandInterface 
          onCommand={(command, response) => {
            console.log('Voice command:', command, 'Response:', response);
          }}
        />
      )}
    </>
  );
}
