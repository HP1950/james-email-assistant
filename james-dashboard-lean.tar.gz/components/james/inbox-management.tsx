
/**
 * James Inbox Management Component
 * Block 1: Proactive Inbox Management Interface
 */

'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Mail, 
  RefreshCw, 
  Calendar, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle2,
  Clock,
  User,
  Filter,
  BarChart3
} from 'lucide-react';
import { toast } from 'sonner';

interface EmailAnalysis {
  id: string;
  from: string;
  subject: string;
  snippet: string;
  receivedAt: string;
  james_analysis: {
    priority_level: string;
    confidence_score: number;
    reasoning: string;
    suggested_action: string;
    category: string;
  };
}

interface DailySummary {
  date: string;
  total_emails: number;
  categories: {
    urgent: { count: number; emails: any[] };
    important: { count: number; emails: any[] };
    fyi: { count: number; emails: any[] };
    spam: { count: number; emails: any[] };
    archive: { count: number; emails: any[] };
  };
  insights: {
    busiest_hour: number;
    top_senders: string[];
    response_needed: number;
    processing_accuracy: number;
  };
}

export function InboxManagement() {
  const [emails, setEmails] = useState<EmailAnalysis[]>([]);
  const [summary, setSummary] = useState<DailySummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [syncLoading, setSyncLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState({
    last_sync: null,
    total_processed: 0,
    gmail_connected: false
  });

  useEffect(() => {
    loadSyncStatus();
  }, []);

  const loadSyncStatus = async () => {
    try {
      const response = await fetch('/api/james/inbox/sync');
      const data = await response.json();
      
      if (data.success) {
        setSyncStatus(data.data.sync_status);
      }
    } catch (error) {
      console.error('Failed to load sync status:', error);
    }
  };

  const syncInbox = async () => {
    setSyncLoading(true);
    
    try {
      const response = await fetch('/api/james/inbox/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ maxEmails: 20 })
      });

      const data = await response.json();
      
      if (data.success) {
        setEmails(data.data.emails);
        setSyncStatus({
          last_sync: data.data.sync_timestamp,
          total_processed: syncStatus.total_processed + data.data.emails_processed,
          gmail_connected: true
        });
        toast.success(`Synced ${data.data.emails_fetched} emails with James intelligence!`);
      } else {
        toast.error(data.error || 'Failed to sync inbox');
      }
    } catch (error) {
      console.error('Inbox sync error:', error);
      toast.error('Failed to sync inbox');
    } finally {
      setSyncLoading(false);
    }
  };

  const generateDailySummary = async () => {
    setLoading(true);
    
    try {
      const response = await fetch('/api/james/inbox/summary', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          date: new Date().toISOString(),
          includeMetrics: true 
        })
      });

      const data = await response.json();
      
      if (data.success) {
        setSummary(data.data.summary);
        toast.success('Daily summary generated!');
      } else {
        toast.error(data.error || 'Failed to generate summary');
      }
    } catch (error) {
      console.error('Summary generation error:', error);
      toast.error('Failed to generate daily summary');
    } finally {
      setLoading(false);
    }
  };

  const getPriorityBadge = (level: string) => {
    const config = {
      critical: { color: 'bg-red-500 text-white', label: 'Critical' },
      high: { color: 'bg-orange-500 text-white', label: 'High' },
      medium: { color: 'bg-yellow-500 text-black', label: 'Medium' },
      low: { color: 'bg-green-500 text-white', label: 'Low' }
    };
    
    const { color, label } = config[level as keyof typeof config] || config.medium;
    
    return <Badge className={color}>{label}</Badge>;
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      urgent: <AlertCircle className="w-4 h-4 text-red-500" />,
      important: <Clock className="w-4 h-4 text-orange-500" />,
      fyi: <Mail className="w-4 h-4 text-blue-500" />,
      spam: <Filter className="w-4 h-4 text-gray-500" />,
      archive: <CheckCircle2 className="w-4 h-4 text-green-500" />
    };
    
    return icons[category as keyof typeof icons] || <Mail className="w-4 h-4" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Proactive Inbox Management</h2>
          <p className="text-muted-foreground">
            James learns your email patterns and prioritizes your inbox intelligently
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button 
            onClick={generateDailySummary}
            disabled={loading}
            variant="outline"
          >
            <Calendar className="w-4 h-4 mr-2" />
            {loading ? 'Generating...' : 'Daily Summary'}
          </Button>
          
          <Button 
            onClick={syncInbox}
            disabled={syncLoading}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${syncLoading ? 'animate-spin' : ''}`} />
            {syncLoading ? 'Syncing...' : 'Sync Inbox'}
          </Button>
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Gmail Status</p>
                <p className="text-2xl font-bold">
                  {syncStatus.gmail_connected ? 'Connected' : 'Disconnected'}
                </p>
              </div>
              <div className={`p-2 rounded-full ${syncStatus.gmail_connected ? 'bg-green-100' : 'bg-red-100'}`}>
                {syncStatus.gmail_connected ? 
                  <CheckCircle2 className="w-6 h-6 text-green-600" /> :
                  <AlertCircle className="w-6 h-6 text-red-600" />
                }
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Emails Processed</p>
                <p className="text-2xl font-bold">{syncStatus.total_processed}</p>
              </div>
              <Mail className="w-6 h-6 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Last Sync</p>
                <p className="text-sm font-bold">
                  {syncStatus.last_sync ? 
                    new Date(syncStatus.last_sync).toLocaleString() : 
                    'Never'
                  }
                </p>
              </div>
              <Clock className="w-6 h-6 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Accuracy</p>
                <p className="text-2xl font-bold">87%</p>
                <p className="text-xs text-muted-foreground">Target: {'>'}90%</p>
              </div>
              <div className="flex flex-col items-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
                <Progress value={87} className="w-8 h-2 mt-1" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="emails" className="w-full">
        <TabsList>
          <TabsTrigger value="emails">Recent Emails</TabsTrigger>
          <TabsTrigger value="summary">Daily Summary</TabsTrigger>
          <TabsTrigger value="patterns">Learning Patterns</TabsTrigger>
        </TabsList>

        <TabsContent value="emails" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Prioritized Emails</CardTitle>
              <CardDescription>
                Emails analyzed by James with priority scoring and suggested actions
              </CardDescription>
            </CardHeader>
            <CardContent>
              {emails.length === 0 ? (
                <div className="text-center py-8">
                  <Mail className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No emails synced yet. Click "Sync Inbox" to get started.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {emails.map((email) => (
                    <div key={email.id} className="border rounded-lg p-4 hover:bg-muted/50">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            {getCategoryIcon(email.james_analysis?.category || 'fyi')}
                            <span className="font-semibold">{email.from}</span>
                            {getPriorityBadge(email.james_analysis?.priority_level || 'medium')}
                            <Badge variant="outline">
                              {Math.round((email.james_analysis?.confidence_score || 0) * 100)}% confident
                            </Badge>
                          </div>
                          
                          <h4 className="font-medium mb-2">{email.subject}</h4>
                          <p className="text-sm text-muted-foreground mb-2">{email.snippet}</p>
                          
                          {email.james_analysis?.reasoning && (
                            <div className="bg-blue-50 p-2 rounded text-sm">
                              <strong>James Analysis:</strong> {email.james_analysis.reasoning}
                            </div>
                          )}
                        </div>
                        
                        <div className="text-right text-sm text-muted-foreground">
                          {new Date(email.receivedAt).toLocaleString()}
                        </div>
                      </div>
                      
                      {email.james_analysis?.suggested_action && (
                        <div className="mt-3 pt-3 border-t">
                          <p className="text-sm">
                            <strong>Suggested Action:</strong> {email.james_analysis.suggested_action}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="summary" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Summary</CardTitle>
              <CardDescription>
                Intelligent summary of your email activity and patterns
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!summary ? (
                <div className="text-center py-8">
                  <BarChart3 className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No daily summary generated yet. Click "Daily Summary" to create one.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Summary Stats */}
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {Object.entries(summary.categories).map(([category, data]) => (
                      <div key={category} className="text-center p-3 border rounded-lg">
                        <div className="flex justify-center mb-2">
                          {getCategoryIcon(category)}
                        </div>
                        <p className="text-2xl font-bold">{data.count}</p>
                        <p className="text-sm text-muted-foreground capitalize">{category}</p>
                      </div>
                    ))}
                  </div>

                  {/* Insights */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="font-medium">Key Insights</h4>
                      <ul className="space-y-1 text-sm">
                        <li>Busiest hour: {summary.insights.busiest_hour}:00</li>
                        <li>Emails needing response: {summary.insights.response_needed}</li>
                        <li>Processing accuracy: {Math.round(summary.insights.processing_accuracy * 100)}%</li>
                      </ul>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="font-medium">Top Senders</h4>
                      <ul className="space-y-1 text-sm">
                        {summary.insights.top_senders.slice(0, 3).map((sender, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <User className="w-3 h-3" />
                            <span>{sender}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Learning Patterns</CardTitle>
              <CardDescription>
                How James is learning from your email behavior
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center py-8">
                  <TrendingUp className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    Pattern learning data will appear here as James processes more emails.
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    James needs at least 50 processed emails to show meaningful patterns.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
