
/**
 * James Dashboard Component
 * Main interface for the James Email Specialist
 */

'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, Brain, CheckCircle, Mail, MessageSquare, Settings, Target, TrendingUp } from 'lucide-react';
// Simplified version without complex dependencies

interface JamesStatus {
  agents: {
    priority_agent: boolean;
    tone_agent: boolean;
  };
  chains: {
    analysis_chain: boolean;
  };
  status: string;
}

interface AdapterHealth {
  adapter_id: string;
  adapter_name: string;
  healthy: boolean;
  capabilities: string[];
}

interface SuccessMetrics {
  categorization_accuracy: number;
  draft_acceptance_rate: number;
  context_recall_accuracy: number;
  attachment_task_extraction_accuracy: number;
}

export function JamesDashboard() {
  const [jamesStatus, setJamesStatus] = useState<JamesStatus | null>(null);
  const [inboxHealth, setInboxHealth] = useState<AdapterHealth | null>(null);
  const [toneHealth, setToneHealth] = useState<AdapterHealth | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  // Mock success metrics - in real implementation, these would come from analytics
  const [successMetrics] = useState<SuccessMetrics>({
    categorization_accuracy: 0.87, // Current: 87%, Target: >90%
    draft_acceptance_rate: 0.12, // Current: 12%, Target: <15%
    context_recall_accuracy: 0.83, // Current: 83%, Target: >85%
    attachment_task_extraction_accuracy: 0.92, // Current: 92%, Target: 95%
  });

  useEffect(() => {
    fetchJamesStatus();
  }, []);

  const fetchJamesStatus = async () => {
    setLoading(true);
    
    try {
      // Simulated data for demonstration
      setJamesStatus({
        agents: {
          priority_agent: true,
          tone_agent: true,
        },
        chains: {
          analysis_chain: true,
        },
        status: 'operational'
      });

      setInboxHealth({
        adapter_id: 'inbox-v1',
        adapter_name: 'Inbox Management',
        healthy: true,
        capabilities: ['categorization', 'priority_detection', 'auto_summary']
      });

      setToneHealth({
        adapter_id: 'tone-v1', 
        adapter_name: 'Adaptive Tone',
        healthy: true,
        capabilities: ['sentiment_analysis', 'style_adaptation', 'tone_matching']
      });

    } catch (error) {
      console.error('Failed to fetch James status:', error);
    } finally {
      setLoading(false);
    }
  };

  const testEmailAnalysis = async () => {
    // Simulated email analysis for demo
    try {
      // Simulate processing time
      setTimeout(() => {
        alert('Email analysis completed successfully! \n\nResults:\n- Priority: High\n- Sentiment: Professional/Urgent\n- Suggested Response: Schedule meeting within 24h\n- Tone: Match professional urgency');
        console.log('Email analysis test completed');
      }, 1000);

    } catch (error) {
      console.error('Email analysis test failed:', error);
    }
  };

  const getStatusBadge = (healthy: boolean, status?: string) => {
    if (healthy || status === 'operational') {
      return <Badge variant="secondary" className="text-green-700 bg-green-100"><CheckCircle className="w-3 h-3 mr-1" />Operational</Badge>;
    }
    return <Badge variant="destructive"><AlertTriangle className="w-3 h-3 mr-1" />Error</Badge>;
  };

  const getMetricStatus = (current: number, target: number, higherIsBetter: boolean = true) => {
    const isGood = higherIsBetter ? current >= target : current <= target;
    return {
      isGood,
      percentage: higherIsBetter ? (current / target) * 100 : (target / current) * 100,
      color: isGood ? 'text-green-600' : 'text-amber-600'
    };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Brain className="w-8 h-8 mx-auto mb-4 animate-pulse" />
          <p>Initializing James...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Brain className="w-8 h-8 text-blue-600" />
          <div>
            <h1 className="text-3xl font-bold">James Email Specialist</h1>
            <p className="text-muted-foreground">AI-powered email intelligence and automation</p>
          </div>
        </div>
        <Button onClick={fetchJamesStatus}>
          Refresh Status
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="inbox">Inbox Management</TabsTrigger>
          <TabsTrigger value="tone">Tone Drafting</TabsTrigger>
          <TabsTrigger value="context">Contextual Intelligence</TabsTrigger>
          <TabsTrigger value="attachments">Deep Attachments</TabsTrigger>
          <TabsTrigger value="capabilities">Capabilities</TabsTrigger>
          <TabsTrigger value="metrics">Performance</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* System Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="w-5 h-5 mr-2" />
                System Status
              </CardTitle>
              <CardDescription>
                Real-time status of James components and adapters
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Orchestrator Status */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">LangChain Orchestrator</span>
                    {getStatusBadge(true, jamesStatus?.status)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Priority Agent: {jamesStatus?.agents?.priority_agent ? '✓' : '✗'}<br />
                    Tone Agent: {jamesStatus?.agents?.tone_agent ? '✓' : '✗'}<br />
                    Analysis Chain: {jamesStatus?.chains?.analysis_chain ? '✓' : '✗'}
                  </div>
                </div>

                {/* Inbox Management */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Inbox Management</span>
                    {getStatusBadge(inboxHealth?.healthy || false)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Capabilities: {inboxHealth?.capabilities?.length || 0}<br />
                    Version: {inboxHealth?.adapter_id ? 'v1.0.0' : 'Not loaded'}
                  </div>
                </div>

                {/* Adaptive Tone */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Adaptive Tone</span>
                    {getStatusBadge(toneHealth?.healthy || false)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Capabilities: {toneHealth?.capabilities?.length || 0}<br />
                    Version: {toneHealth?.adapter_id ? 'v1.0.0' : 'Not loaded'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Quick Actions
              </CardTitle>
              <CardDescription>
                Test James capabilities and run diagnostics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button onClick={testEmailAnalysis} className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  Test Email Analysis
                </Button>
                <Button variant="outline" className="flex items-center">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Test Draft Generation
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inbox" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="w-5 h-5 mr-2" />
                Inbox Management
              </CardTitle>
              <CardDescription>
                AI-powered email prioritization and organization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Smart Categorization</h4>
                    <p className="text-sm text-muted-foreground">Automatically categorize emails by importance</p>
                  </div>
                  <Badge variant="secondary" className="text-green-700 bg-green-100">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Priority Detection</h4>
                    <p className="text-sm text-muted-foreground">Identify urgent emails requiring immediate attention</p>
                  </div>
                  <Badge variant="secondary" className="text-green-700 bg-green-100">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Daily Summaries</h4>
                    <p className="text-sm text-muted-foreground">Get intelligent summaries of your daily email activity</p>
                  </div>
                  <Badge variant="secondary" className="text-green-700 bg-green-100">Active</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tone" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="w-5 h-5 mr-2" />
                Adaptive Tone Drafting
              </CardTitle>
              <CardDescription>
                AI that learns your communication style and adapts accordingly
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Sentiment Analysis</h4>
                    <p className="text-sm text-muted-foreground">Understand the emotional context of incoming emails</p>
                  </div>
                  <Badge variant="secondary" className="text-green-700 bg-green-100">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Style Learning</h4>
                    <p className="text-sm text-muted-foreground">Learn from your sent emails to match your communication style</p>
                  </div>
                  <Badge variant="secondary" className="text-green-700 bg-green-100">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Draft Generation</h4>
                    <p className="text-sm text-muted-foreground">Generate contextually appropriate email responses</p>
                  </div>
                  <Badge variant="secondary" className="text-green-700 bg-green-100">Active</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="context" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="w-5 h-5 mr-2" />
                Contextual Intelligence
              </CardTitle>
              <CardDescription>
                Advanced context awareness for better email understanding
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Thread Analysis</h4>
                    <p className="text-sm text-muted-foreground">Understand email conversation history and context</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Document Recall</h4>
                    <p className="text-sm text-muted-foreground">Remember and reference previous documents and conversations</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Relationship Mapping</h4>
                    <p className="text-sm text-muted-foreground">Track communication patterns with different contacts</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attachments" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Deep Attachments Handling
              </CardTitle>
              <CardDescription>
                Intelligent processing of email attachments and documents
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">PDF Summarization</h4>
                    <p className="text-sm text-muted-foreground">Extract key insights from PDF documents</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Action Item Extraction</h4>
                    <p className="text-sm text-muted-foreground">Identify tasks and deadlines from attachments</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Content Analysis</h4>
                    <p className="text-sm text-muted-foreground">Understand document content and suggest responses</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="capabilities" className="space-y-6">
          {/* Priority Order Implementation */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Quick Wins */}
            <Card>
              <CardHeader>
                <CardTitle className="text-green-600">Quick Wins (Implemented)</CardTitle>
                <CardDescription>
                  Immediate value capabilities now active
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Proactive Inbox Management</h4>
                    <p className="text-sm text-muted-foreground">Learn priority patterns, daily summaries</p>
                  </div>
                  <Badge variant="secondary" className="text-green-700 bg-green-100">Active</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Adaptive Tone Drafting</h4>
                    <p className="text-sm text-muted-foreground">Sentiment analysis, style learning</p>
                  </div>
                  <Badge variant="secondary" className="text-green-700 bg-green-100">Active</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Mid-term Goals */}
            <Card>
              <CardHeader>
                <CardTitle className="text-amber-600">Mid-term Goals</CardTitle>
                <CardDescription>
                  Capabilities in development
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Contextual Intelligence</h4>
                    <p className="text-sm text-muted-foreground">Thread recall, relevant docs</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <div>
                    <h4 className="font-medium">Deep Attachments Handling</h4>
                    <p className="text-sm text-muted-foreground">PDF/Word summarization, action items</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Long-term Vision */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-blue-600">Long-term Vision</CardTitle>
                <CardDescription>
                  Advanced capabilities for maximum automation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Agent-to-Agent Protocols</h4>
                      <p className="text-sm text-muted-foreground">Structured email handling</p>
                    </div>
                    <Badge variant="outline" className="text-blue-600">Future</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Edge Neuromorphic Deployment</h4>
                      <p className="text-sm text-muted-foreground">Privacy-first local processing</p>
                    </div>
                    <Badge variant="outline" className="text-blue-600">Future</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-6">
          {/* Success Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                Success Metrics
              </CardTitle>
              <CardDescription>
                Track James performance against defined targets
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Categorization Accuracy */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Categorization Accuracy</span>
                  <div className="flex items-center space-x-2">
                    <span className={getMetricStatus(successMetrics.categorization_accuracy, 0.90).color}>
                      {(successMetrics.categorization_accuracy * 100).toFixed(1)}%
                    </span>
                    <span className="text-muted-foreground">Target: {'>'}90%</span>
                  </div>
                </div>
                <Progress 
                  value={getMetricStatus(successMetrics.categorization_accuracy, 0.90).percentage} 
                  className="h-2"
                />
              </div>

              {/* Draft Acceptance Rate */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Draft Acceptance Rate</span>
                  <div className="flex items-center space-x-2">
                    <span className={getMetricStatus(successMetrics.draft_acceptance_rate, 0.15, false).color}>
                      {(successMetrics.draft_acceptance_rate * 100).toFixed(1)}%
                    </span>
                    <span className="text-muted-foreground">Target: {'<'}15%</span>
                  </div>
                </div>
                <Progress 
                  value={getMetricStatus(successMetrics.draft_acceptance_rate, 0.15, false).percentage} 
                  className="h-2"
                />
              </div>

              {/* Context Recall Accuracy */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Context Recall Accuracy</span>
                  <div className="flex items-center space-x-2">
                    <span className={getMetricStatus(successMetrics.context_recall_accuracy, 0.85).color}>
                      {(successMetrics.context_recall_accuracy * 100).toFixed(1)}%
                    </span>
                    <span className="text-muted-foreground">Target: {'>'}85%</span>
                  </div>
                </div>
                <Progress 
                  value={getMetricStatus(successMetrics.context_recall_accuracy, 0.85).percentage} 
                  className="h-2"
                />
              </div>

              {/* Attachment Task Extraction */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Attachment Task Extraction</span>
                  <div className="flex items-center space-x-2">
                    <span className={getMetricStatus(successMetrics.attachment_task_extraction_accuracy, 0.95).color}>
                      {(successMetrics.attachment_task_extraction_accuracy * 100).toFixed(1)}%
                    </span>
                    <span className="text-muted-foreground">Target: 95%</span>
                  </div>
                </div>
                <Progress 
                  value={getMetricStatus(successMetrics.attachment_task_extraction_accuracy, 0.95).percentage} 
                  className="h-2"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>James Configuration</CardTitle>
              <CardDescription>
                Configure James behavior and preferences
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Mirror Mode</h4>
                    <p className="text-sm text-muted-foreground">Learn from your sent emails</p>
                  </div>
                  <Button variant="outline">
                    Enable
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Auto-Processing</h4>
                    <p className="text-sm text-muted-foreground">Background email analysis</p>
                  </div>
                  <Button variant="outline">
                    Configure
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Privacy Settings</h4>
                    <p className="text-sm text-muted-foreground">Local-first processing preferences</p>
                  </div>
                  <Button variant="outline">
                    Manage
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
