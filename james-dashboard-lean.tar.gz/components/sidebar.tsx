
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  MailCheck,
  Wand2,
  ListFilter,
  BarChart3,
  Settings,
  Mail,
  Menu,
  X,
  Circle,
  Brain
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';

const navigation = [
  {
    name: 'Dashboard',
    href: '/',
    icon: LayoutDashboard,
    badge: null,
  },
  {
    name: 'James AI Assistant',
    href: '/james',
    icon: Brain,
    badge: 'AI',
    description: 'AI-powered email specialist',
  },
  {
    name: 'Draft Approvals',
    href: '/drafts',
    icon: MailCheck,
    badge: '7',
  },
  {
    name: 'Automation Config',
    href: '/automation',
    icon: Wand2,
    badge: null,
  },
  {
    name: 'Custom Rules',
    href: '/rules',
    icon: ListFilter,
    badge: '3',
  },
  {
    name: 'Analytics & Logs',
    href: '/analytics',
    icon: BarChart3,
    badge: null,
  },
  {
    name: 'Settings',
    href: '/settings',
    icon: Settings,
    badge: null,
  },
  {
    name: 'Email Setup',
    href: '/email-setup',
    icon: Mail,
    badge: null,
  },
];

function SidebarContent({ onItemClick }: { onItemClick?: () => void }) {
  const pathname = usePathname();

  return (
    <div className="flex h-full flex-col bg-background">
      <div className="flex h-16 items-center border-b border-border px-6">
        <div className="flex items-center space-x-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Mail className="h-4 w-4 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-foreground">Gmail Assistant</span>
            <span className="text-xs text-muted-foreground">Email Dashboard</span>
          </div>
        </div>
      </div>
      <nav className="flex-1 space-y-1 p-4">
        {navigation.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              onClick={onItemClick}
              className={cn(
                'group flex items-center justify-between rounded-lg px-3 py-3 text-sm font-medium transition-all duration-200 touch-manipulation',
                isActive
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground active:bg-muted/50'
              )}
            >
              <div className="flex items-center">
                <item.icon className="mr-3 h-4 w-4 flex-shrink-0" />
                {item.name}
              </div>
              {item.badge && (
                <Badge variant={isActive ? "secondary" : "outline"} className="text-xs h-5 px-1.5">
                  {item.badge}
                </Badge>
              )}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-border p-4">
        <div className="flex items-center space-x-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-success relative">
            <Circle className="h-3 w-3 text-white fill-current" />
            <div className="absolute -top-1 -right-1 h-3 w-3 bg-success border-2 border-background rounded-full animate-pulse" />
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-medium text-foreground">System Status</span>
            <span className="text-xs text-success">All Systems Operational</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export function Sidebar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Mobile Menu Button */}
      <div className="lg:hidden fixed top-4 left-4 z-40">
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="h-10 w-10 p-0 bg-background/95 backdrop-blur-sm border-border shadow-sm"
            >
              <Menu className="h-4 w-4" />
              <span className="sr-only">Open navigation menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64">
            <SidebarContent onItemClick={() => setMobileOpen(false)} />
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden lg:flex h-full w-64 flex-col bg-background border-r border-border">
        <SidebarContent />
      </div>
    </>
  );
}
