
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Smile,
  Briefcase,
  Heart,
  Zap,
  Shield,
  MessageCircle,
  RotateCcw,
  Check,
  Sparkles
} from 'lucide-react';
import { cn } from '@/lib/utils';

export type ToneType = 'professional' | 'friendly' | 'casual' | 'formal' | 'empathetic' | 'direct';

interface ToneOption {
  type: ToneType;
  label: string;
  icon: React.ElementType;
  description: string;
  color: string;
}

interface ToneAdjusterProps {
  originalText: string;
  selectedTone?: ToneType;
  formality?: number; // 0-100
  enthusiasm?: number; // 0-100
  empathy?: number; // 0-100
  onToneChange?: (tone: ToneType) => void;
  onFormalityChange?: (level: number) => void;
  onEnthusiasmChange?: (level: number) => void;
  onEmpathyChange?: (level: number) => void;
  onApply?: () => void;
  onReset?: () => void;
  isLoading?: boolean;
  className?: string;
}

const toneOptions: ToneOption[] = [
  {
    type: 'professional',
    label: 'Professional',
    icon: Briefcase,
    description: 'Business-appropriate and polished',
    color: 'text-blue-600 bg-blue-50 border-blue-200',
  },
  {
    type: 'friendly',
    label: 'Friendly',
    icon: Smile,
    description: 'Warm and approachable',
    color: 'text-green-600 bg-green-50 border-green-200',
  },
  {
    type: 'casual',
    label: 'Casual',
    icon: MessageCircle,
    description: 'Relaxed and informal',
    color: 'text-purple-600 bg-purple-50 border-purple-200',
  },
  {
    type: 'formal',
    label: 'Formal',
    icon: Shield,
    description: 'Traditional and respectful',
    color: 'text-gray-600 bg-gray-50 border-gray-200',
  },
  {
    type: 'empathetic',
    label: 'Empathetic',
    icon: Heart,
    description: 'Understanding and supportive',
    color: 'text-pink-600 bg-pink-50 border-pink-200',
  },
  {
    type: 'direct',
    label: 'Direct',
    icon: Zap,
    description: 'Clear and to the point',
    color: 'text-orange-600 bg-orange-50 border-orange-200',
  },
];

export function ToneAdjuster({
  originalText,
  selectedTone = 'professional',
  formality = 70,
  enthusiasm = 50,
  empathy = 50,
  onToneChange,
  onFormalityChange,
  onEnthusiasmChange,
  onEmpathyChange,
  onApply,
  onReset,
  isLoading = false,
  className
}: ToneAdjusterProps) {
  const [localFormality, setLocalFormality] = useState(formality);
  const [localEnthusiasm, setLocalEnthusiasm] = useState(enthusiasm);
  const [localEmpathy, setLocalEmpathy] = useState(empathy);

  const handleFormalityChange = (value: number[]) => {
    setLocalFormality(value[0]);
    onFormalityChange?.(value[0]);
  };

  const handleEnthusiasmChange = (value: number[]) => {
    setLocalEnthusiasm(value[0]);
    onEnthusiasmChange?.(value[0]);
  };

  const handleEmpathyChange = (value: number[]) => {
    setLocalEmpathy(value[0]);
    onEmpathyChange?.(value[0]);
  };

  const handleReset = () => {
    setLocalFormality(70);
    setLocalEnthusiasm(50);
    setLocalEmpathy(50);
    onReset?.();
  };

  return (
    <Card className={cn('w-full', className)}>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="h-5 w-5 text-primary" />
          Tone Adjustment
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Adjust the tone and style of your response to match the context
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Tone Selection */}
        <div>
          <label className="text-sm font-medium mb-3 block">Tone Style</label>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
            {toneOptions.map((option) => {
              const Icon = option.icon;
              const isSelected = selectedTone === option.type;
              
              return (
                <button
                  key={option.type}
                  onClick={() => onToneChange?.(option.type)}
                  className={cn(
                    'p-3 rounded-lg border text-left transition-all duration-200 hover:shadow-sm',
                    isSelected 
                      ? option.color + ' border-current' 
                      : 'border-border hover:border-primary/30'
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Icon className={cn(
                      'h-4 w-4',
                      isSelected ? 'text-current' : 'text-muted-foreground'
                    )} />
                    <span className={cn(
                      'font-medium text-sm',
                      isSelected ? 'text-current' : 'text-foreground'
                    )}>
                      {option.label}
                    </span>
                    {isSelected && <Check className="h-3 w-3 ml-auto" />}
                  </div>
                  <p className={cn(
                    'text-xs',
                    isSelected ? 'text-current opacity-80' : 'text-muted-foreground'
                  )}>
                    {option.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tone Adjustments */}
        <div className="space-y-4">
          <div className="text-sm font-medium">Fine-tune Style</div>
          
          {/* Formality */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm text-muted-foreground">Formality</label>
              <Badge variant="outline" className="text-xs">
                {localFormality}%
              </Badge>
            </div>
            <Slider
              value={[localFormality]}
              onValueChange={handleFormalityChange}
              max={100}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Casual</span>
              <span>Very Formal</span>
            </div>
          </div>

          {/* Enthusiasm */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm text-muted-foreground">Enthusiasm</label>
              <Badge variant="outline" className="text-xs">
                {localEnthusiasm}%
              </Badge>
            </div>
            <Slider
              value={[localEnthusiasm]}
              onValueChange={handleEnthusiasmChange}
              max={100}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Reserved</span>
              <span>Very Enthusiastic</span>
            </div>
          </div>

          {/* Empathy */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm text-muted-foreground">Empathy</label>
              <Badge variant="outline" className="text-xs">
                {localEmpathy}%
              </Badge>
            </div>
            <Slider
              value={[localEmpathy]}
              onValueChange={handleEmpathyChange}
              max={100}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Direct</span>
              <span>Very Empathetic</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2 border-t">
          <Button 
            onClick={onApply}
            disabled={isLoading}
            className="flex-1"
            size="sm"
          >
            {isLoading ? (
              <>
                <Sparkles className="h-4 w-4 mr-2 animate-spin" />
                Applying...
              </>
            ) : (
              <>
                <Check className="h-4 w-4 mr-2" />
                Apply Changes
              </>
            )}
          </Button>
          <Button 
            variant="outline" 
            onClick={handleReset}
            size="sm"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
