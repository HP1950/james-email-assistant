
'use client';

import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  ArrowUp, 
  ArrowDown, 
  Minus,
  Star,
  AlertTriangle
} from 'lucide-react';
import { cn } from '@/lib/utils';

export type PriorityLevel = 'low' | 'medium' | 'high' | 'critical';

interface PriorityScoreProps {
  priority: PriorityLevel;
  score?: number; // 0-100
  showProgress?: boolean;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'badge' | 'full';
  className?: string;
}

const priorityConfig = {
  low: {
    label: 'Low Priority',
    icon: ArrowDown,
    color: 'bg-gray-500/10 text-gray-700 border-gray-200 dark:text-gray-400',
    iconColor: 'text-gray-500',
    progressColor: 'bg-gray-500',
    range: [0, 25],
  },
  medium: {
    label: 'Medium Priority',
    icon: Minus,
    color: 'bg-blue-500/10 text-blue-700 border-blue-200 dark:text-blue-400',
    iconColor: 'text-blue-500',
    progressColor: 'bg-blue-500',
    range: [25, 65],
  },
  high: {
    label: 'High Priority',
    icon: ArrowUp,
    color: 'bg-orange-500/10 text-orange-700 border-orange-200 dark:text-orange-400',
    iconColor: 'text-orange-500',
    progressColor: 'bg-orange-500',
    range: [65, 85],
  },
  critical: {
    label: 'Critical',
    icon: AlertTriangle,
    color: 'bg-red-500/10 text-red-700 border-red-200 dark:text-red-400',
    iconColor: 'text-red-500',
    progressColor: 'bg-red-500',
    range: [85, 100],
  },
};

export function PriorityScore({ 
  priority, 
  score,
  showProgress = false,
  size = 'md', 
  variant = 'badge',
  className 
}: PriorityScoreProps) {
  const config = priorityConfig[priority];
  const Icon = config.icon;
  
  const sizeClasses = {
    sm: 'text-xs px-1.5 py-0.5',
    md: 'text-xs px-2 py-1',
    lg: 'text-sm px-3 py-1.5',
  };
  
  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-3.5 w-3.5',
    lg: 'h-4 w-4',
  };

  if (variant === 'full' && score !== undefined) {
    return (
      <div className={cn('space-y-2', className)}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Icon className={cn(iconSizes[size], config.iconColor)} />
            <span className={cn('font-medium', size === 'sm' ? 'text-xs' : 'text-sm')}>
              {config.label}
            </span>
          </div>
          <span className={cn('font-bold', config.iconColor, size === 'sm' ? 'text-xs' : 'text-sm')}>
            {score}%
          </span>
        </div>
        {showProgress && (
          <div className="space-y-1">
            <Progress value={score} className="h-2" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Priority Score</span>
              <span>{score}/100</span>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <Badge 
      variant="outline" 
      className={cn(
        config.color,
        sizeClasses[size],
        'font-medium inline-flex items-center gap-1.5',
        className
      )}
    >
      <Icon className={cn(iconSizes[size], config.iconColor)} />
      <span>{priority === 'critical' ? 'Critical' : `${config.label.split(' ')[0]} Priority`}</span>
      {score !== undefined && (
        <span className="text-xs opacity-75">
          {score}%
        </span>
      )}
    </Badge>
  );
}
