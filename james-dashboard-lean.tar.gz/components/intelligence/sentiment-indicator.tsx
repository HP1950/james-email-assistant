
'use client';

import { Badge } from '@/components/ui/badge';
import { 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Heart,
  Zap,
  MessageCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

export type SentimentType = 'urgent' | 'positive' | 'neutral' | 'negative' | 'inquiry' | 'action_required';

interface SentimentIndicatorProps {
  sentiment: SentimentType;
  confidence?: number;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}

const sentimentConfig = {
  urgent: {
    label: 'Urgent',
    icon: AlertTriangle,
    color: 'bg-red-500/10 text-red-700 border-red-200 dark:text-red-400',
    iconColor: 'text-red-500',
  },
  positive: {
    label: 'Positive',
    icon: Heart,
    color: 'bg-green-500/10 text-green-700 border-green-200 dark:text-green-400',
    iconColor: 'text-green-500',
  },
  neutral: {
    label: 'Neutral',
    icon: MessageCircle,
    color: 'bg-gray-500/10 text-gray-700 border-gray-200 dark:text-gray-400',
    iconColor: 'text-gray-500',
  },
  negative: {
    label: 'Negative',
    icon: AlertTriangle,
    color: 'bg-orange-500/10 text-orange-700 border-orange-200 dark:text-orange-400',
    iconColor: 'text-orange-500',
  },
  inquiry: {
    label: 'Inquiry',
    icon: MessageCircle,
    color: 'bg-blue-500/10 text-blue-700 border-blue-200 dark:text-blue-400',
    iconColor: 'text-blue-500',
  },
  action_required: {
    label: 'Action Required',
    icon: Zap,
    color: 'bg-purple-500/10 text-purple-700 border-purple-200 dark:text-purple-400',
    iconColor: 'text-purple-500',
  },
};

export function SentimentIndicator({ 
  sentiment, 
  confidence, 
  size = 'md', 
  showLabel = true,
  className 
}: SentimentIndicatorProps) {
  const config = sentimentConfig[sentiment];
  const Icon = config.icon;
  
  const sizeClasses = {
    sm: 'text-xs px-1.5 py-0.5',
    md: 'text-xs px-2 py-1',
    lg: 'text-sm px-3 py-1.5',
  };
  
  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-3.5 w-3.5',
    lg: 'h-4 w-4',
  };

  return (
    <Badge 
      variant="outline" 
      className={cn(
        config.color,
        sizeClasses[size],
        'font-medium inline-flex items-center gap-1.5',
        className
      )}
    >
      <Icon className={cn(iconSizes[size], config.iconColor)} />
      {showLabel && (
        <>
          <span>{config.label}</span>
          {confidence && confidence > 0 && (
            <span className="text-xs opacity-75">
              ({Math.round(confidence * 100)}%)
            </span>
          )}
        </>
      )}
    </Badge>
  );
}
