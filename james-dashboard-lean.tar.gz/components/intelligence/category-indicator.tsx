
'use client';

import { Badge } from '@/components/ui/badge';
import { 
  Briefcase,
  Heart,
  ShoppingBag,
  Users,
  AlertTriangle,
  FileText,
  Calendar,
  CreditCard,
  Bell,
  MessageSquare
} from 'lucide-react';
import { cn } from '@/lib/utils';

export type EmailCategory = 
  | 'business' 
  | 'personal' 
  | 'promotional' 
  | 'social' 
  | 'spam'
  | 'newsletters'
  | 'events'
  | 'financial'
  | 'notifications'
  | 'other';

interface CategoryIndicatorProps {
  category: EmailCategory;
  confidence?: number;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'badge' | 'icon' | 'full';
  className?: string;
}

const categoryConfig = {
  business: {
    label: 'Business',
    icon: Briefcase,
    color: 'bg-blue-500/10 text-blue-700 border-blue-200 dark:text-blue-400',
    iconColor: 'text-blue-500',
  },
  personal: {
    label: 'Personal',
    icon: Heart,
    color: 'bg-pink-500/10 text-pink-700 border-pink-200 dark:text-pink-400',
    iconColor: 'text-pink-500',
  },
  promotional: {
    label: 'Promotional',
    icon: ShoppingBag,
    color: 'bg-green-500/10 text-green-700 border-green-200 dark:text-green-400',
    iconColor: 'text-green-500',
  },
  social: {
    label: 'Social',
    icon: Users,
    color: 'bg-purple-500/10 text-purple-700 border-purple-200 dark:text-purple-400',
    iconColor: 'text-purple-500',
  },
  spam: {
    label: 'Spam',
    icon: AlertTriangle,
    color: 'bg-red-500/10 text-red-700 border-red-200 dark:text-red-400',
    iconColor: 'text-red-500',
  },
  newsletters: {
    label: 'Newsletter',
    icon: FileText,
    color: 'bg-indigo-500/10 text-indigo-700 border-indigo-200 dark:text-indigo-400',
    iconColor: 'text-indigo-500',
  },
  events: {
    label: 'Events',
    icon: Calendar,
    color: 'bg-orange-500/10 text-orange-700 border-orange-200 dark:text-orange-400',
    iconColor: 'text-orange-500',
  },
  financial: {
    label: 'Financial',
    icon: CreditCard,
    color: 'bg-emerald-500/10 text-emerald-700 border-emerald-200 dark:text-emerald-400',
    iconColor: 'text-emerald-500',
  },
  notifications: {
    label: 'Notifications',
    icon: Bell,
    color: 'bg-yellow-500/10 text-yellow-700 border-yellow-200 dark:text-yellow-400',
    iconColor: 'text-yellow-500',
  },
  other: {
    label: 'Other',
    icon: MessageSquare,
    color: 'bg-gray-500/10 text-gray-700 border-gray-200 dark:text-gray-400',
    iconColor: 'text-gray-500',
  },
};

export function CategoryIndicator({ 
  category, 
  confidence,
  size = 'md', 
  variant = 'badge',
  className 
}: CategoryIndicatorProps) {
  const config = categoryConfig[category];
  const Icon = config.icon;
  
  const sizeClasses = {
    sm: 'text-xs px-1.5 py-0.5',
    md: 'text-xs px-2 py-1',
    lg: 'text-sm px-3 py-1.5',
  };
  
  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-3.5 w-3.5',
    lg: 'h-4 w-4',
  };

  if (variant === 'icon') {
    return (
      <Icon 
        className={cn(iconSizes[size], config.iconColor, className)}
      />
    );
  }

  if (variant === 'full') {
    return (
      <div className={cn('flex items-center gap-2', className)}>
        <Icon className={cn(iconSizes[size], config.iconColor)} />
        <span className={cn('font-medium', size === 'sm' ? 'text-xs' : 'text-sm')}>
          {config.label}
        </span>
        {confidence && confidence > 0 && (
          <span className="text-xs text-muted-foreground">
            ({Math.round(confidence * 100)}%)
          </span>
        )}
      </div>
    );
  }

  return (
    <Badge 
      variant="outline" 
      className={cn(
        config.color,
        sizeClasses[size],
        'font-medium inline-flex items-center gap-1.5',
        className
      )}
    >
      <Icon className={cn(iconSizes[size], config.iconColor)} />
      <span>{config.label}</span>
      {confidence && confidence > 0 && (
        <span className="text-xs opacity-75">
          {Math.round(confidence * 100)}%
        </span>
      )}
    </Badge>
  );
}
