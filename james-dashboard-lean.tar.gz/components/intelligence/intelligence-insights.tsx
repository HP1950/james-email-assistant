
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp,
  TrendingDown,
  Clock,
  Users,
  Mail,
  CheckCircle,
  AlertTriangle,
  Calendar,
  BarChart3,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface InsightMetric {
  label: string;
  value: number;
  change: number;
  changeType: 'positive' | 'negative' | 'neutral';
  unit?: string;
  icon: React.ElementType;
}

interface ProductivityPattern {
  timeSlot: string;
  activity: string;
  efficiency: number;
  recommendation?: string;
}

interface IntelligenceInsightsProps {
  metrics: InsightMetric[];
  patterns: ProductivityPattern[];
  weeklyTrends?: {
    emailsProcessed: number[];
    responseTime: number[];
    categories: Record<string, number>;
  };
  recommendations?: string[];
  className?: string;
}

export function IntelligenceInsights({
  metrics,
  patterns,
  weeklyTrends,
  recommendations = [],
  className
}: IntelligenceInsightsProps) {
  const formatChange = (change: number, changeType: string) => {
    const prefix = change > 0 ? '+' : '';
    const icon = changeType === 'positive' ? 
      <TrendingUp className="h-3 w-3" /> : 
      changeType === 'negative' ? 
        <TrendingDown className="h-3 w-3" /> : 
        <BarChart3 className="h-3 w-3" />;
    
    const colorClass = changeType === 'positive' ? 
      'text-green-600' : 
      changeType === 'negative' ? 
        'text-red-600' : 
        'text-gray-600';

    return (
      <div className={cn('flex items-center gap-1 text-xs', colorClass)}>
        {icon}
        <span>{prefix}{change}%</span>
      </div>
    );
  };

  return (
    <div className={cn('space-y-6', className)}>
      {/* Key Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Intelligence Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {metrics.map((metric, index) => {
              const Icon = metric.icon;
              return (
                <div key={index} className="p-4 bg-muted/30 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <Icon className="h-4 w-4 text-muted-foreground" />
                    {formatChange(metric.change, metric.changeType)}
                  </div>
                  <div className="text-2xl font-bold">
                    {metric.value}{metric.unit}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {metric.label}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Productivity Patterns */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Productivity Patterns
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            AI-identified patterns in your email activity
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {patterns.map((pattern, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <div className="font-medium text-sm">{pattern.timeSlot}</div>
                    <div className="text-sm text-muted-foreground">{pattern.activity}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <div className="text-sm font-medium">{pattern.efficiency}%</div>
                      <div className="text-xs text-muted-foreground">Efficiency</div>
                    </div>
                    <Progress value={pattern.efficiency} className="w-16 h-2" />
                  </div>
                </div>
                {pattern.recommendation && (
                  <div className="mt-2 p-2 bg-blue-50 text-blue-800 rounded text-xs">
                    💡 {pattern.recommendation}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Weekly Trends */}
      {weeklyTrends && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Weekly Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Email Categories */}
              <div>
                <h4 className="font-medium mb-3">Email Categories</h4>
                <div className="space-y-2">
                  {Object.entries(weeklyTrends.categories).map(([category, count]) => {
                    const total = Object.values(weeklyTrends.categories).reduce((a, b) => a + b, 0);
                    const percentage = Math.round((count / total) * 100);
                    
                    return (
                      <div key={category} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded bg-primary opacity-80" />
                          <span className="text-sm capitalize">{category}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">{count}</span>
                          <Badge variant="outline" className="text-xs">
                            {percentage}%
                          </Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Processing Stats */}
              <div>
                <h4 className="font-medium mb-3">Processing Stats</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-muted/30 rounded">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-blue-500" />
                      <span className="text-sm">Total Processed</span>
                    </div>
                    <span className="font-medium">
                      {weeklyTrends.emailsProcessed.reduce((a, b) => a + b, 0)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted/30 rounded">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Avg Response Time</span>
                    </div>
                    <span className="font-medium">
                      {Math.round(weeklyTrends.responseTime.reduce((a, b) => a + b, 0) / weeklyTrends.responseTime.length)}min
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* AI Recommendations */}
      {recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" />
              AI Recommendations
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Personalized suggestions to improve your email productivity
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recommendations.map((recommendation, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                  <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="text-sm leading-relaxed">{recommendation}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
