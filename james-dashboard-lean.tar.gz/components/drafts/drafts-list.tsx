
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { 
  Send, 
  Save, 
  Trash2, 
  Edit3, 
  Clock,
  User,
  MessageSquare,
  AlertCircle,
  CheckCircle,
  Sparkles
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { SentimentIndicator, type SentimentType } from '@/components/intelligence/sentiment-indicator';
import { PriorityScore, type PriorityLevel } from '@/components/intelligence/priority-score';
import { VIPBadge, type VIPLevel } from '@/components/intelligence/vip-badge';
import { CategoryIndicator, type EmailCategory } from '@/components/intelligence/category-indicator';
import { ToneAdjuster, type ToneType } from '@/components/intelligence/tone-adjuster';

interface EmailDraft {
  id: string;
  recipient: string;
  recipientName: string;
  subject: string;
  body: string;
  aiConfidence: number;
  category: EmailCategory;
  priority: PriorityLevel;
  sentiment: SentimentType;
  vipLevel?: VIPLevel;
  tone: ToneType;
  priorityScore: number;
  createdAt: Date;
  isEdited: boolean;
  originalEmailSentiment?: SentimentType;
}

export function DraftsList() {
  const [drafts, setDrafts] = useState<EmailDraft[]>([
    {
      id: '1',
      recipient: 'sarah.johnson@example.com',
      recipientName: 'Sarah Johnson',
      subject: 'Re: Product support inquiry',
      body: `Hi Sarah,

Thank you for reaching out about our product. I understand you're experiencing some difficulties with the setup process.

Based on your description, it seems like you might need to update your configuration settings. Here are the steps to resolve this:

1. Navigate to the settings panel
2. Check your API credentials
3. Verify the connection settings

If you continue to experience issues, please don't hesitate to reach out to our technical support team at support@company.com.

Best regards,
Customer Support Team`,
      aiConfidence: 0.92,
      category: 'business',
      priority: 'high',
      sentiment: 'action_required',
      vipLevel: 'client',
      tone: 'professional',
      priorityScore: 89,
      originalEmailSentiment: 'negative',
      createdAt: new Date(Date.now() - 15 * 60 * 1000),
      isEdited: false
    },
    {
      id: '2',
      recipient: 'team@partner.com',
      recipientName: 'Partnership Team',
      subject: 'Re: Meeting confirmation for next week',
      body: `Hello,

Thank you for your email regarding the meeting scheduled for next week.

I can confirm that we are available for the proposed time slot on Tuesday, January 16th at 2:00 PM EST. Our team will be ready to discuss the partnership opportunities and next steps.

Please let me know if you need any additional information or if there are any changes to the agenda.

Looking forward to our discussion.

Best regards,
Business Development Team`,
      aiConfidence: 0.88,
      category: 'business',
      priority: 'medium',
      sentiment: 'positive',
      vipLevel: 'important',
      tone: 'professional',
      priorityScore: 72,
      originalEmailSentiment: 'positive',
      createdAt: new Date(Date.now() - 45 * 60 * 1000),
      isEdited: false
    },
    {
      id: '3',
      recipient: 'contact@vendor.com',
      recipientName: 'Vendor Relations',
      subject: 'Re: Invoice inquiry',
      body: `Dear Vendor Relations Team,

Thank you for your inquiry regarding invoice #INV-2024-001.

I have reviewed the details and can confirm that the payment was processed on January 10th, 2024. The transaction reference number is TX-456789.

You should receive the payment within 3-5 business days. If you have any questions or don't receive the payment by the expected date, please contact our accounts payable department.

Best regards,
Finance Team`,
      aiConfidence: 0.85,
      category: 'financial',
      priority: 'low',
      sentiment: 'neutral',
      tone: 'formal',
      priorityScore: 45,
      originalEmailSentiment: 'inquiry',
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      isEdited: true
    },
    {
      id: '4',
      recipient: 'ceo@bigcorp.com',
      recipientName: 'Elena Rodriguez',
      subject: 'Re: Urgent contract revision needed',
      body: `Dear Ms. Rodriguez,

Thank you for your urgent request regarding the contract revision. I understand the time-sensitive nature of this matter and appreciate you bringing it to our attention.

I have immediately escalated this to our legal team and senior management. We will review the proposed changes and provide our response within 24 hours as requested.

In the meantime, please feel free to reach out directly if you have any additional concerns or clarifications needed.

Best regards,
Executive Team`,
      aiConfidence: 0.94,
      category: 'business',
      priority: 'critical',
      sentiment: 'urgent',
      vipLevel: 'vip',
      tone: 'professional',
      priorityScore: 95,
      originalEmailSentiment: 'urgent',
      createdAt: new Date(Date.now() - 5 * 60 * 1000),
      isEdited: false
    }
  ]);

  const [editingDraft, setEditingDraft] = useState<string | null>(null);
  const [editedBodies, setEditedBodies] = useState<Record<string, string>>({});
  const [showToneAdjuster, setShowToneAdjuster] = useState<string | null>(null);
  const [selectedTones, setSelectedTones] = useState<Record<string, ToneType>>({});

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-success';
    if (confidence >= 0.7) return 'text-warning';
    return 'text-destructive';
  };

  const handleToneChange = (draftId: string, tone: ToneType) => {
    setSelectedTones(prev => ({ ...prev, [draftId]: tone }));
  };

  const handleToneApply = (draftId: string) => {
    // In a real app, this would call an API to regenerate the email with the new tone
    console.log('Applying tone change for draft:', draftId, 'New tone:', selectedTones[draftId]);
    setShowToneAdjuster(null);
  };

  const handleEdit = (draftId: string, body: string) => {
    setEditingDraft(draftId);
    setEditedBodies(prev => ({ ...prev, [draftId]: body }));
  };

  const handleSave = (draftId: string) => {
    setDrafts(prev => prev.map(draft => 
      draft.id === draftId 
        ? { ...draft, body: editedBodies[draftId] || draft.body, isEdited: true }
        : draft
    ));
    setEditingDraft(null);
  };

  const handleApprove = (draftId: string) => {
    setDrafts(prev => prev.filter(draft => draft.id !== draftId));
    // In a real app, this would send the email
  };

  const handleReject = (draftId: string) => {
    setDrafts(prev => prev.filter(draft => draft.id !== draftId));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">
            {drafts.length} Drafts Pending Approval
          </h2>
          <p className="text-sm text-muted-foreground">
            Review AI-composed responses and approve or edit before sending
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {drafts.map((draft) => (
          <Card key={draft.id} className="bg-white border border-border hover:shadow-md transition-shadow">
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    {draft.vipLevel ? (
                      <VIPBadge 
                        level={draft.vipLevel}
                        senderName={draft.recipientName}
                        senderEmail={draft.recipient}
                        showName={true}
                        size="sm"
                      />
                    ) : (
                      <>
                        <span className="font-medium text-foreground">{draft.recipientName}</span>
                        <span className="text-sm text-muted-foreground">({draft.recipient})</span>
                      </>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium text-foreground">{draft.subject}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <SentimentIndicator 
                      sentiment={draft.sentiment} 
                      confidence={draft.aiConfidence}
                      size="sm"
                    />
                    {draft.originalEmailSentiment && draft.originalEmailSentiment !== draft.sentiment && (
                      <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                        <span>Responding to:</span>
                        <SentimentIndicator 
                          sentiment={draft.originalEmailSentiment} 
                          size="sm"
                          showLabel={false}
                        />
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-3">
                  <div className="flex items-center space-x-2">
                    <PriorityScore 
                      priority={draft.priority}
                      score={draft.priorityScore}
                      size="sm"
                    />
                    <CategoryIndicator 
                      category={draft.category}
                      confidence={draft.aiConfidence}
                      size="sm"
                    />
                  </div>
                  <div className="flex items-center space-x-1">
                    <Sparkles className={`h-3 w-3 ${getConfidenceColor(draft.aiConfidence)}`} />
                    <span className={`text-xs font-medium ${getConfidenceColor(draft.aiConfidence)}`}>
                      {Math.round(draft.aiConfidence * 100)}% AI confidence
                    </span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {draft.tone} tone
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-foreground">Email Body</label>
                  <div className="flex items-center space-x-2">
                    {draft.isEdited && (
                      <Badge variant="outline" className="text-xs">
                        <Edit3 className="h-3 w-3 mr-1" />
                        Edited
                      </Badge>
                    )}
                    <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {formatDistanceToNow(draft.createdAt, { addSuffix: true })}
                    </div>
                  </div>
                </div>
                {editingDraft === draft.id ? (
                  <Textarea
                    value={editedBodies[draft.id] || draft.body}
                    onChange={(e) => setEditedBodies(prev => ({ ...prev, [draft.id]: e.target.value }))}
                    rows={8}
                    className="font-mono text-sm"
                  />
                ) : (
                  <div className="bg-muted/30 border border-border rounded-lg p-4">
                    <pre className="whitespace-pre-wrap font-sans text-sm text-foreground">
                      {draft.body}
                    </pre>
                  </div>
                )}
              </div>

              {/* Tone Adjuster */}
              {showToneAdjuster === draft.id && (
                <div className="border-t pt-4">
                  <ToneAdjuster
                    originalText={draft.body}
                    selectedTone={selectedTones[draft.id] || draft.tone}
                    onToneChange={(tone) => handleToneChange(draft.id, tone)}
                    onApply={() => handleToneApply(draft.id)}
                    onReset={() => setShowToneAdjuster(null)}
                    className="mb-4"
                  />
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div className="flex items-center space-x-2">
                  {editingDraft === draft.id ? (
                    <>
                      <Button
                        onClick={() => handleSave(draft.id)}
                        size="sm"
                        className="bg-success hover:bg-success/90"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </Button>
                      <Button
                        onClick={() => setEditingDraft(null)}
                        variant="outline"
                        size="sm"
                      >
                        Cancel
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        onClick={() => handleEdit(draft.id, draft.body)}
                        variant="outline"
                        size="sm"
                      >
                        <Edit3 className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button
                        onClick={() => setShowToneAdjuster(showToneAdjuster === draft.id ? null : draft.id)}
                        variant="outline"
                        size="sm"
                      >
                        <Sparkles className="h-4 w-4 mr-2" />
                        Adjust Tone
                      </Button>
                    </>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    onClick={() => handleReject(draft.id)}
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Reject
                  </Button>
                  <Button
                    onClick={() => handleApprove(draft.id)}
                    size="sm"
                    disabled={editingDraft === draft.id || showToneAdjuster === draft.id}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Approve & Send
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {drafts.length === 0 && (
        <Card className="bg-white border border-border">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <CheckCircle className="h-12 w-12 text-success mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">All caught up!</h3>
            <p className="text-muted-foreground text-center">
              No drafts are currently pending your approval. New AI-composed emails will appear here.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
