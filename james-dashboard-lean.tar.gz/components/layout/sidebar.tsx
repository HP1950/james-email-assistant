
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import {
  Home,
  Mail,
  BarChart3,
  Users,
  Settings,
  Workflow,
  Brain,
  Zap,
  Target,
  TrendingUp,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';

const sidebarItems = [
  {
    title: 'Dashboard',
    href: '/dashboard',
    icon: Home,
  },
  {
    title: 'Email Marketing',
    icon: Target,
    expanded: false,
    subItems: [
      {
        title: 'Overview',
        href: '/marketing',
        icon: BarChart3,
      },
      {
        title: 'Lists',
        href: '/marketing?tab=lists',
        icon: Users,
      },
      {
        title: 'Campaigns',
        href: '/marketing?tab=campaigns',
        icon: Mail,
      },
      {
        title: 'Templates',
        href: '/marketing?tab=templates',
        icon: Mail,
      },
      {
        title: 'Automations',
        href: '/marketing?tab=automations',
        icon: Zap,
      },
    ],
  },
  {
    title: 'AI Assistant',
    href: '/ai',
    icon: Brain,
  },
  {
    title: 'Analytics',
    href: '/analytics',
    icon: TrendingUp,
  },
  {
    title: 'Workflows',
    href: '/workflows',
    icon: Workflow,
  },
  {
    title: 'Settings',
    href: '/settings',
    icon: Settings,
  },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [expandedItems, setExpandedItems] = useState<string[]>(['Email Marketing']);

  const toggleExpanded = (title: string) => {
    setExpandedItems(prev => 
      prev.includes(title) 
        ? prev.filter(item => item !== title)
        : [...prev, title]
    );
  };

  return (
    <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
      <div className="p-6">
        <Link href="/dashboard" className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Mail className="h-5 w-5 text-white" />
          </div>
          <span className="text-xl font-bold text-gray-900">Gmail Assistant</span>
        </Link>
      </div>
      
      <nav className="px-4 space-y-1">
        {sidebarItems.map((item) => {
          const isExpanded = expandedItems.includes(item.title);
          const isActive = item.href ? pathname === item.href : false;
          const hasActiveSubItem = item.subItems?.some(subItem => pathname === subItem.href || pathname.startsWith(subItem.href.split('?')[0]));

          if (item.subItems) {
            return (
              <div key={item.title}>
                <button
                  onClick={() => toggleExpanded(item.title)}
                  className={cn(
                    'w-full flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                    hasActiveSubItem || isExpanded
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                  )}
                >
                  <div className="flex items-center space-x-3">
                    <item.icon className="h-5 w-5" />
                    <span>{item.title}</span>
                  </div>
                  {isExpanded ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </button>
                
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="ml-4 mt-1 space-y-1"
                  >
                    {item.subItems.map((subItem) => {
                      const isSubActive = pathname === subItem.href || pathname.startsWith(subItem.href.split('?')[0]);
                      
                      return (
                        <Link
                          key={subItem.href}
                          href={subItem.href}
                          className={cn(
                            'flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                            isSubActive
                              ? 'bg-blue-100 text-blue-700'
                              : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                          )}
                        >
                          <subItem.icon className="h-4 w-4" />
                          <span>{subItem.title}</span>
                        </Link>
                      );
                    })}
                  </motion.div>
                )}
              </div>
            );
          }

          return (
            <Link
              key={item.href}
              href={item.href!}
              className={cn(
                'flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                isActive
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
              )}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.title}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
