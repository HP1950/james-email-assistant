
'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Bell, 
  Mic, 
  MicOff, 
  Settings, 
  Moon, 
  Sun,
  Zap,
  Brain,
  Activity
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  sidebarCollapsed: boolean;
}

export function Header({ sidebarCollapsed }: HeaderProps) {
  const { data: session } = useSession();
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications] = useState(3); // Mock notification count

  const toggleVoice = () => {
    setIsVoiceActive(!isVoiceActive);
    // TODO: Implement voice activation logic
  };

  return (
    <header className={cn(
      "sticky top-0 z-50 border-b border-slate-700 bg-slate-900/95 backdrop-blur supports-[backdrop-filter]:bg-slate-900/60",
      "transition-all duration-300",
      sidebarCollapsed ? "ml-16" : "ml-64"
    )}>
      <div className="flex items-center justify-between px-6 py-4">
        {/* Left Section - Search */}
        <div className="flex items-center space-x-4 flex-1 max-w-2xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              type="text"
              placeholder="Search emails, contacts, tasks... (Ctrl+K)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 bg-slate-800 border-slate-600 text-white placeholder:text-slate-400 focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          
          <Button
            variant="outline"
            size="icon"
            onClick={toggleVoice}
            className={cn(
              "border-slate-600 transition-all duration-200",
              isVoiceActive 
                ? "bg-red-600 border-red-600 text-white hover:bg-red-700" 
                : "text-slate-400 hover:text-white hover:bg-slate-700"
            )}
          >
            {isVoiceActive ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
        </div>

        {/* Right Section - Status & Actions */}
        <div className="flex items-center space-x-4">
          {/* AI Status Indicator */}
          <div className="hidden md:flex items-center space-x-2 px-3 py-1 bg-slate-800 rounded-full border border-slate-600">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-xs text-slate-300">AI Active</span>
            <Brain className="h-3 w-3 text-indigo-400" />
          </div>

          {/* Performance Indicator */}
          <div className="hidden lg:flex items-center space-x-2 px-3 py-1 bg-slate-800 rounded-full border border-slate-600">
            <Activity className="h-3 w-3 text-green-400" />
            <span className="text-xs text-slate-300">99.9%</span>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="icon"
              className="relative border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <Bell className="h-4 w-4" />
              {notifications > 0 && (
                <span className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                  {notifications}
                </span>
              )}
            </Button>
            
            <Button
              variant="outline"
              size="icon"
              className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>

          {/* User Info */}
          {session?.user && (
            <div className="hidden md:flex items-center space-x-2 px-3 py-1 bg-slate-800 rounded-full border border-slate-600">
              <div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-medium">
                  {session.user.name?.charAt(0) || session.user.email?.charAt(0) || 'U'}
                </span>
              </div>
              <span className="text-sm text-slate-300 max-w-32 truncate">
                {session.user.name || session.user.email}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Voice Feedback Bar */}
      {isVoiceActive && (
        <div className="border-t border-slate-700 bg-red-600/10 px-6 py-2">
          <div className="flex items-center justify-center space-x-2">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-red-400">Listening for voice commands...</span>
            <div className="flex space-x-1">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="w-1 bg-red-500 rounded-full animate-pulse"
                  style={{
                    height: Math.random() * 20 + 10,
                    animationDelay: `${i * 0.1}s`
                  }}
                ></div>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
