

'use client';

import { useSession } from 'next-auth/react';
import { usePathname } from 'next/navigation';
import { Sidebar } from '@/components/sidebar';
import { Toaster } from '@/components/ui/toaster';
import { appConfig } from '@/lib/config';

interface AuthenticatedLayoutProps {
  children: React.ReactNode;
}

export function AuthenticatedLayout({ children }: AuthenticatedLayoutProps) {
  const { data: session, status } = useSession() || {};
  const pathname = usePathname();

  // Public pages that don't need layout wrapping
  const isEntryPage = pathname === '/';
  const isAuthPage = pathname?.startsWith('/auth/');
  const isLandingPage = pathname === '/landing';
  
  // Dashboard pages that need sidebar
  const isDashboardPage = pathname?.startsWith('/dashboard') || 
                         pathname?.startsWith('/inbox') ||
                         pathname?.startsWith('/compose') ||
                         pathname?.startsWith('/analytics') ||
                         pathname?.startsWith('/rules') ||
                         pathname?.startsWith('/settings') ||
                         pathname?.startsWith('/automation') ||
                         pathname?.startsWith('/drafts') ||
                         pathname?.startsWith('/james');

  // If auth is disabled, show appropriate layout based on page type
  if (!appConfig.requireAuth) {
    // Entry page gets full-width layout
    if (isEntryPage || isAuthPage || isLandingPage) {
      return (
        <>
          {children}
          <Toaster />
        </>
      );
    }
    
    // Dashboard pages get sidebar layout
    if (isDashboardPage) {
      return (
        <>
          <div className="flex h-screen bg-background">
            <Sidebar />
            <main className="flex-1 overflow-auto lg:ml-0">
              <div className="container max-w-7xl mx-auto p-3 sm:p-6 pt-16 lg:pt-6">
                {children}
              </div>
            </main>
          </div>
          <Toaster />
        </>
      );
    }
  }

  // If auth is enabled, use original logic
  if (appConfig.requireAuth) {
    // Show loading state
    if (status === 'loading') {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      );
    }

    // For authenticated users or public pages, show appropriate layout
    if (session || isEntryPage || isAuthPage) {
      // If user is authenticated and on dashboard pages, show sidebar layout
      if (session && isDashboardPage) {
        return (
          <>
            <div className="flex h-screen bg-background">
              <Sidebar />
              <main className="flex-1 overflow-auto lg:ml-0">
                <div className="container max-w-7xl mx-auto p-3 sm:p-6 pt-16 lg:pt-6">
                  {children}
                </div>
              </main>
            </div>
            <Toaster />
          </>
        );
      }

      // For entry/auth pages, show full-width layout
      return (
        <>
          {children}
          <Toaster />
        </>
      );
    }
  }

  // Default: full-width layout
  return (
    <>
      {children}
      <Toaster />
    </>
  );
}
