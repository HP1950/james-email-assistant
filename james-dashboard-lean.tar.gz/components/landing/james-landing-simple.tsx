

'use client';

import { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { 
  ArrowRight, 
  Brain, 
  Globe, 
  Heart, 
  Mail, 
  MessageSquare, 
  Mic, 
  Shield, 
  Sparkles,
  Users,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function JamesLandingSimple() {
  const router = useRouter();

  const features = [
    {
      icon: <Heart className="h-6 w-6" />,
      title: "Emotional Intelligence",
      description: "Understands sentiment and emotion in every email"
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: "Cultural Sensitivity", 
      description: "Adapts to 19 languages with cultural awareness"
    },
    {
      icon: <Mic className="h-6 w-6" />,
      title: "Voice Command",
      description: "Natural voice interaction with emotional context"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Privacy First",
      description: "100% offline processing, SMTP/IMAP compatible"
    },
    {
      icon: <Brain className="h-6 w-6" />,
      title: "Relationship Intelligence",
      description: "Learns sender patterns and detects anomalies"
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "DOC Loop Processing",
      description: "DO → OBSERVE → CRITICIZE → APPROVE workflow"
    }
  ];

  const stats = [
    { number: "23", label: "Emotion Types", description: "From professional to personal" },
    { number: "19", label: "Languages", description: "With cultural intelligence" },
    { number: "100%", label: "Privacy", description: "Offline processing" },
    { number: "∞", label: "Scalability", description: "Personal to Enterprise" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-amber-500/10" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="secondary" className="text-sm font-medium">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Emotionally Intelligent AI Assistant
                </Badge>
                
                <h1 className="text-4xl lg:text-6xl font-bold bg-gradient-to-r from-slate-900 via-blue-900 to-amber-600 bg-clip-text text-transparent leading-tight">
                  Meet James
                  <span className="block text-2xl lg:text-3xl text-slate-600 font-normal mt-2">
                    Your Email Assistant
                  </span>
                </h1>
                
                <p className="text-xl text-slate-600 leading-relaxed">
                  <span className="font-semibold text-slate-800">They Write.</span>{" "}
                  <span className="font-semibold text-amber-600">James Answers.</span>
                  <br />
                  With emotional intelligence, cultural sensitivity, and complete privacy.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => router.push('/dashboard')}
                >
                  Enter Dashboard
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-slate-300"
                  onClick={() => {
                    const featuresSection = document.getElementById('features');
                    featuresSection?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  <MessageSquare className="mr-2 h-5 w-5" />
                  View Features
                </Button>
              </div>

              <div className="flex items-center space-x-6 text-sm text-slate-500">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse" />
                  Running on schulenberg.tech
                </div>
                <div className="flex items-center">
                  <Shield className="h-4 w-4 mr-2" />
                  Privacy-First Architecture
                </div>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative">
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                <Image
                  src="/james-branding.jpg"
                  alt="James - Your Email Assistant"
                  fill
                  className="object-cover"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              </div>
              
              {/* Floating Elements */}
              <div className="absolute -top-4 -right-4 bg-white rounded-full p-4 shadow-lg">
                <Heart className="h-6 w-6 text-red-500" />
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-white rounded-full p-4 shadow-lg">
                <Brain className="h-6 w-6 text-blue-500" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-slate-900 mb-2">
                  {stat.number}
                </div>
                <div className="text-sm font-semibold text-slate-700 mb-1">
                  {stat.label}
                </div>
                <div className="text-xs text-slate-500">
                  {stat.description}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
              Emotionally Intelligent Email Assistant
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              James combines advanced AI with emotional intelligence to understand context, 
              cultural nuances, and relationship dynamics in every email interaction.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-slate-200 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="p-3 bg-blue-500 text-white rounded-lg">
                      {feature.icon}
                    </div>
                    <CardTitle className="text-xl">
                      {feature.title}
                    </CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-700 leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* DOC Loop Section */}
      <section className="py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              The DOC Loop Process
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Every email goes through our intelligent workflow to ensure emotionally appropriate, 
              culturally sensitive responses.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "DO",
                title: "Capture",
                icon: <Mic className="h-8 w-8" />,
                description: "Voice + Email + Context",
                color: "from-green-500 to-emerald-600"
              },
              {
                step: "OBSERVE",
                title: "Analyze", 
                icon: <Brain className="h-8 w-8" />,
                description: "Emotion + Culture + Relationships",
                color: "from-blue-500 to-cyan-600"
              },
              {
                step: "CRITICIZE",
                title: "Generate",
                icon: <Sparkles className="h-8 w-8" />,
                description: "AI + Intelligence + Context",
                color: "from-purple-500 to-violet-600"
              },
              {
                step: "APPROVE", 
                title: "Review",
                icon: <Users className="h-8 w-8" />,
                description: "Human + Guidance + Send",
                color: "from-amber-500 to-orange-600"
              }
            ].map((phase, index) => (
              <Card key={phase.step} className="bg-slate-800 border-slate-700 text-center">
                <CardHeader>
                  <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${phase.color} flex items-center justify-center text-white mb-4`}>
                    {phase.icon}
                  </div>
                  <CardTitle className="text-white text-xl">
                    {phase.step}: {phase.title}
                  </CardTitle>
                  <CardDescription className="text-slate-300">
                    {phase.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-amber-500">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            <h2 className="text-3xl lg:text-4xl font-bold text-white">
              Ready to Experience Emotional Intelligence?
            </h2>
            <p className="text-xl text-white/90">
              Transform your email communication with James - the only assistant that truly understands.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-blue-600 hover:bg-blue-50"
                onClick={() => router.push('/dashboard')}
              >
                <Mail className="mr-2 h-5 w-5" />
                Launch Dashboard
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="border-white text-white hover:bg-white/10"
                onClick={() => router.push('/automation')}
              >
                <MessageSquare className="mr-2 h-5 w-5" />
                Try Voice Command
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center">
              <Mail className="h-4 w-4 text-white" />
            </div>
            <span className="text-xl font-bold text-white">James</span>
          </div>
          <p className="text-sm">
            Powered by schulenberg.tech • Privacy-First • Emotionally Intelligent • Built to Last
          </p>
        </div>
      </footer>
    </div>
  );
}
