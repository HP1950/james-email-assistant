

'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  MessageSquare,
  Loader2,
  AlertCircle,
  CheckCircle,
  Brain,
  Zap
} from 'lucide-react';
import { useVoiceRecognition } from '@/hooks/use-voice-recognition';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';
import { appConfig } from '@/lib/config';

interface UserPreferences {
  preferredName: string;
  genderPreference: 'male' | 'female' | 'neutral';
  voiceType: 'professional' | 'friendly' | 'warm' | 'energetic';
  timeGreeting: boolean;
}

interface VoiceCommandInterfaceProps {
  onCommand?: (command: string, response: string) => void;
  className?: string;
}

export function VoiceCommandInterface({ onCommand, className = '' }: VoiceCommandInterfaceProps) {
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastCommand, setLastCommand] = useState('');
  const [lastResponse, setLastResponse] = useState('');
  const [commandHistory, setCommandHistory] = useState<Array<{command: string, response: string, timestamp: Date}>>([]);

  // Load user preferences
  useEffect(() => {
    const savedPreferences = localStorage.getItem('jamesPreferences');
    if (savedPreferences) {
      setPreferences(JSON.parse(savedPreferences));
    }
  }, []);

  const { speak, stop: stopSpeaking, isSpeaking, getVoiceByType } = useTextToSpeech({
    rate: preferences?.voiceType === 'energetic' ? 1.1 : 
          preferences?.voiceType === 'warm' ? 0.9 : 1.0,
    pitch: preferences?.voiceType === 'friendly' ? 1.1 : 
           preferences?.voiceType === 'professional' ? 0.9 : 1.0
  });

  const processVoiceCommand = useCallback(async (transcript: string) => {
    if (!transcript.trim()) return;

    setIsProcessing(true);
    setLastCommand(transcript);

    try {
      // Process the command and generate response
      const response = await generateJamesResponse(transcript, preferences);
      setLastResponse(response);

      // Add to history
      setCommandHistory(prev => [
        { command: transcript, response, timestamp: new Date() },
        ...prev.slice(0, 9) // Keep only last 10 commands
      ]);

      // Speak the response using appropriate voice
      const voice = getVoiceByType(preferences?.genderPreference);
      speak(response, { voice });

      // Notify parent component
      if (onCommand) {
        onCommand(transcript, response);
      }

    } catch (error) {
      const errorResponse = "I'm sorry, I couldn't process that command. Please try again.";
      setLastResponse(errorResponse);
      speak(errorResponse);
    } finally {
      setIsProcessing(false);
    }
  }, [preferences, speak, getVoiceByType, onCommand]);

  const {
    isSupported,
    isListening,
    transcript,
    interimTranscript,
    error,
    startListening,
    stopListening,
    resetTranscript
  } = useVoiceRecognition({
    continuous: false,
    interimResults: true,
    lang: 'en-US',
    onResult: (finalTranscript, isFinal) => {
      if (isFinal && finalTranscript.trim()) {
        processVoiceCommand(finalTranscript);
        resetTranscript();
      }
    }
  });

  const handleToggleListening = () => {
    if (isListening) {
      stopListening();
    } else {
      if (isSpeaking) {
        stopSpeaking();
      }
      startListening();
    }
  };

  const handleStopSpeaking = () => {
    stopSpeaking();
  };

  if (!appConfig.features.voiceCommands) {
    return (
      <Card className={`border-dashed ${className}`}>
        <CardContent className="pt-6 text-center">
          <MicOff className="h-8 w-8 text-gray-400 mx-auto mb-2" />
          <p className="text-sm text-gray-500">Voice commands are currently disabled</p>
        </CardContent>
      </Card>
    );
  }

  if (!isSupported) {
    return (
      <Card className={`border-red-200 bg-red-50 ${className}`}>
        <CardContent className="pt-6 text-center">
          <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-2" />
          <p className="text-sm text-red-600">Voice commands are not supported in this browser</p>
          <p className="text-xs text-red-500 mt-1">Try Chrome, Edge, or Safari</p>
        </CardContent>
      </Card>
    );
  }

  const getGreeting = () => {
    if (!preferences) return "Hello! I'm James, your voice assistant.";
    
    const timeOfDay = new Date().getHours() < 12 ? 'morning' : 
                     new Date().getHours() < 17 ? 'afternoon' : 
                     new Date().getHours() < 21 ? 'evening' : 'night';
    
    const greeting = preferences.timeGreeting ? 
      `Good ${timeOfDay}, ${preferences.preferredName}!` : 
      `Hello, ${preferences.preferredName}!`;
      
    return `${greeting} Ready for voice commands.`;
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Main Voice Interface */}
      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-blue-600" />
            <span>James Voice Assistant</span>
            {preferences && (
              <Badge variant="outline" className="ml-auto">
                {preferences.voiceType} • {preferences.genderPreference}
              </Badge>
            )}
          </CardTitle>
          <p className="text-sm text-gray-600">{getGreeting()}</p>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Voice Controls */}
          <div className="flex items-center justify-center space-x-4">
            <Button
              onClick={handleToggleListening}
              size="lg"
              variant={isListening ? "destructive" : "default"}
              className={`${
                isListening 
                  ? 'bg-red-600 hover:bg-red-700 animate-pulse' 
                  : 'bg-blue-600 hover:bg-blue-700'
              } transition-all duration-200`}
              disabled={isProcessing}
            >
              {isListening ? (
                <>
                  <MicOff className="mr-2 h-4 w-4" />
                  Stop Listening
                </>
              ) : (
                <>
                  <Mic className="mr-2 h-4 w-4" />
                  Start Voice Command
                </>
              )}
            </Button>

            {isSpeaking && (
              <Button
                onClick={handleStopSpeaking}
                variant="outline"
                size="lg"
              >
                <VolumeX className="mr-2 h-4 w-4" />
                Stop Speaking
              </Button>
            )}
          </div>

          {/* Status Display */}
          <div className="space-y-2">
            {isListening && (
              <div className="p-3 bg-green-100 border border-green-200 rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm font-medium text-green-700">Listening...</span>
                </div>
                {(transcript || interimTranscript) && (
                  <p className="text-sm text-green-600 mt-1">
                    "{transcript || interimTranscript}"
                  </p>
                )}
              </div>
            )}

            {isProcessing && (
              <div className="p-3 bg-blue-100 border border-blue-200 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Loader2 className="h-4 w-4 text-blue-600 animate-spin" />
                  <span className="text-sm font-medium text-blue-700">James is thinking...</span>
                </div>
                {lastCommand && (
                  <p className="text-sm text-blue-600 mt-1">Processing: "{lastCommand}"</p>
                )}
              </div>
            )}

            {isSpeaking && (
              <div className="p-3 bg-purple-100 border border-purple-200 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Volume2 className="h-4 w-4 text-purple-600 animate-pulse" />
                  <span className="text-sm font-medium text-purple-700">James is speaking...</span>
                </div>
                {lastResponse && (
                  <p className="text-sm text-purple-600 mt-1">"{lastResponse}"</p>
                )}
              </div>
            )}

            {error && (
              <div className="p-3 bg-red-100 border border-red-200 rounded-lg">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <span className="text-sm font-medium text-red-700">Error</span>
                </div>
                <p className="text-sm text-red-600 mt-1">{error}</p>
              </div>
            )}
          </div>

          {/* Command Examples */}
          <div className="pt-2 border-t border-gray-200">
            <p className="text-xs font-medium text-gray-500 mb-2">Try saying:</p>
            <div className="flex flex-wrap gap-1">
              {[
                "Check my emails",
                "Compose a new email", 
                "Show me unread messages",
                "What's my email status?",
                "Help me with automation"
              ].map((example, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  "{example}"
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Commands History */}
      {commandHistory.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center space-x-2">
              <MessageSquare className="h-4 w-4" />
              <span>Recent Voice Commands</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {commandHistory.slice(0, 3).map((entry, index) => (
                <div key={index} className="p-2 bg-gray-50 rounded text-xs">
                  <div className="font-medium text-gray-700">You: "{entry.command}"</div>
                  <div className="text-gray-600 mt-1">James: "{entry.response}"</div>
                  <div className="text-gray-400 text-xs mt-1">
                    {entry.timestamp.toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// James AI Response Generator
async function generateJamesResponse(command: string, preferences: UserPreferences | null): Promise<string> {
  const normalizedCommand = command.toLowerCase();
  
  // Get personalized greeting components
  const name = preferences?.preferredName || 'there';
  const voiceStyle = getVoiceStyleResponse(preferences?.voiceType || 'professional');
  
  // Email-related commands
  if (normalizedCommand.includes('email') || normalizedCommand.includes('mail')) {
    if (normalizedCommand.includes('check') || normalizedCommand.includes('show')) {
      return `${voiceStyle.acknowledgment} ${name}! Let me check your emails. I found 23 unread messages, with 3 requiring your attention. Would you like me to read the important ones?`;
    }
    if (normalizedCommand.includes('compose') || normalizedCommand.includes('write')) {
      return `${voiceStyle.task} I'll help you compose an email, ${name}. Who would you like to send it to?`;
    }
    if (normalizedCommand.includes('unread')) {
      return `You have 23 unread emails, ${name}. ${voiceStyle.detail} 3 are marked as important, 15 are newsletters, and 5 are regular messages.`;
    }
  }
  
  // Status commands  
  if (normalizedCommand.includes('status') || normalizedCommand.includes('summary')) {
    return `${voiceStyle.greeting} ${name}! Today you've processed 45 emails with 98% accuracy. ${voiceStyle.detail} Everything is running smoothly!`;
  }
  
  // Help commands
  if (normalizedCommand.includes('help') || normalizedCommand.includes('what can')) {
    return `${voiceStyle.helpful} I can help you with emails, ${name}! ${voiceStyle.detail} Try saying "check my emails", "compose a message", or "show me unread mail". I understand natural language, so speak naturally!`;
  }
  
  // Automation commands
  if (normalizedCommand.includes('automat') || normalizedCommand.includes('rule')) {
    return `${voiceStyle.task} I'll open your automation settings, ${name}. You can configure rules for sorting, auto-responses, and spam detection there.`;
  }
  
  // Greeting responses
  if (normalizedCommand.includes('hello') || normalizedCommand.includes('hi') || normalizedCommand.includes('hey')) {
    const timeOfDay = new Date().getHours() < 12 ? 'morning' : 
                     new Date().getHours() < 17 ? 'afternoon' : 'evening';
    return `${voiceStyle.greeting} Good ${timeOfDay}, ${name}! ${voiceStyle.detail} How can I help you with your emails today?`;
  }
  
  // Default response
  return `${voiceStyle.clarify} I didn't quite catch that, ${name}. ${voiceStyle.helpful} Could you try saying something like "check my emails" or "help me compose a message"?`;
}

function getVoiceStyleResponse(voiceType: string) {
  switch (voiceType) {
    case 'professional':
      return {
        greeting: 'Good day!',
        acknowledgment: 'Certainly,',
        task: 'I will assist you with that.',
        detail: 'Here are the details:',
        helpful: 'I am here to help.',
        clarify: 'I apologize for the confusion.'
      };
    case 'friendly':
      return {
        greeting: 'Hey there!',
        acknowledgment: 'Sure thing,',
        task: 'I\'d be happy to help with that!',
        detail: 'Here\'s what I found:',
        helpful: 'I\'m here to help you out!',
        clarify: 'Hmm, I\'m not sure about that.'
      };
    case 'warm':
      return {
        greeting: 'Hello, dear!',
        acknowledgment: 'Of course,',
        task: 'I\'d love to help you with that.',
        detail: 'Let me share what I discovered:',
        helpful: 'I care about helping you succeed.',
        clarify: 'I want to make sure I understand you correctly.'
      };
    case 'energetic':
      return {
        greeting: 'Hey there, awesome!',
        acknowledgment: 'Absolutely,',
        task: 'Let\'s get that done right now!',
        detail: 'Check this out:',
        helpful: 'I\'m excited to help you achieve great things!',
        clarify: 'Oops! Let\'s try that again!'
      };
    default:
      return {
        greeting: 'Hello!',
        acknowledgment: 'Okay,',
        task: 'I can help you with that.',
        detail: 'Here is the information:',
        helpful: 'I am available to assist.',
        clarify: 'I did not understand that.'
      };
  }
}
