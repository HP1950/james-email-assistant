
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Shield, 
  Clock, 
  Zap, 
  Mail, 
  Settings,
  Save,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

interface AutomationConfig {
  // Spam Detection
  spamDetectionEnabled: boolean;
  spamDetectionSensitivity: 'low' | 'medium' | 'high';
  
  // Unsubscribe Automation
  unsubscribeAutomationEnabled: boolean;
  
  // Auto Response
  autoResponseEnabled: boolean;
  
  // Scheduling
  processingSchedule: 'continuous' | 'hourly' | 'daily';
  quietHoursStart: string;
  quietHoursEnd: string;
  timezone: string;
  
  // Limits
  maxDraftsPerDay: number;
  maxProcessingTime: number;
}

export function AutomationSettings() {
  const [config, setConfig] = useState<AutomationConfig>({
    spamDetectionEnabled: true,
    spamDetectionSensitivity: 'medium',
    unsubscribeAutomationEnabled: true,
    autoResponseEnabled: false,
    processingSchedule: 'continuous',
    quietHoursStart: '22:00',
    quietHoursEnd: '08:00',
    timezone: 'UTC',
    maxDraftsPerDay: 50,
    maxProcessingTime: 30
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsSaving(false);
    setSaved(true);
    
    setTimeout(() => setSaved(false), 3000);
  };

  const getSensitivityDescription = (level: string) => {
    switch (level) {
      case 'low':
        return 'Conservative filtering - may let some spam through';
      case 'medium':
        return 'Balanced approach - recommended for most users';
      case 'high':
        return 'Aggressive filtering - may flag legitimate emails';
      default:
        return '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Spam Detection Section */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-primary" />
            <span>Spam Detection</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-sm font-medium">Enable Spam Detection</Label>
              <p className="text-xs text-muted-foreground">
                Automatically identify and handle spam emails
              </p>
            </div>
            <Switch
              checked={config.spamDetectionEnabled}
              onCheckedChange={(checked) => 
                setConfig(prev => ({ ...prev, spamDetectionEnabled: checked }))
              }
            />
          </div>

          {config.spamDetectionEnabled && (
            <div className="space-y-4 pl-4 border-l-2 border-primary/20">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Detection Sensitivity</Label>
                <Select
                  value={config.spamDetectionSensitivity}
                  onValueChange={(value: 'low' | 'medium' | 'high') =>
                    setConfig(prev => ({ ...prev, spamDetectionSensitivity: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {getSensitivityDescription(config.spamDetectionSensitivity)}
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Unsubscribe Automation Section */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Mail className="h-5 w-5 text-primary" />
            <span>Unsubscribe Automation</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-sm font-medium">Auto-Unsubscribe</Label>
              <p className="text-xs text-muted-foreground">
                Automatically unsubscribe from unwanted mailing lists
              </p>
            </div>
            <Switch
              checked={config.unsubscribeAutomationEnabled}
              onCheckedChange={(checked) => 
                setConfig(prev => ({ ...prev, unsubscribeAutomationEnabled: checked }))
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Auto Response Section */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-primary" />
            <span>Auto Response</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-sm font-medium">Enable Auto Response</Label>
              <p className="text-xs text-muted-foreground">
                Generate and send automatic replies to emails (requires approval)
              </p>
            </div>
            <Switch
              checked={config.autoResponseEnabled}
              onCheckedChange={(checked) => 
                setConfig(prev => ({ ...prev, autoResponseEnabled: checked }))
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Scheduling Section */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-primary" />
            <span>Scheduling Preferences</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label className="text-sm font-medium">Processing Schedule</Label>
            <Select
              value={config.processingSchedule}
              onValueChange={(value: 'continuous' | 'hourly' | 'daily') =>
                setConfig(prev => ({ ...prev, processingSchedule: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="continuous">Continuous</SelectItem>
                <SelectItem value="hourly">Every Hour</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              How frequently the system should process new emails
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium">Quiet Hours Start</Label>
              <Input
                type="time"
                value={config.quietHoursStart}
                onChange={(e) => 
                  setConfig(prev => ({ ...prev, quietHoursStart: e.target.value }))
                }
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">Quiet Hours End</Label>
              <Input
                type="time"
                value={config.quietHoursEnd}
                onChange={(e) => 
                  setConfig(prev => ({ ...prev, quietHoursEnd: e.target.value }))
                }
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            No email processing will occur during quiet hours
          </p>
        </CardContent>
      </Card>

      {/* Processing Limits Section */}
      <Card className="bg-white border border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5 text-primary" />
            <span>Processing Limits</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium">
                Max Drafts Per Day: {config.maxDraftsPerDay}
              </Label>
              <Slider
                value={[config.maxDraftsPerDay]}
                onValueChange={(value) => 
                  setConfig(prev => ({ ...prev, maxDraftsPerDay: value[0] }))
                }
                max={200}
                min={10}
                step={10}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">
                Maximum number of email drafts to generate per day
              </p>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium">
                Max Processing Time: {config.maxProcessingTime} minutes
              </Label>
              <Slider
                value={[config.maxProcessingTime]}
                onValueChange={(value) => 
                  setConfig(prev => ({ ...prev, maxProcessingTime: value[0] }))
                }
                max={120}
                min={5}
                step={5}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">
                Maximum time to spend processing emails in a single session
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex items-center justify-end space-x-4">
        {saved && (
          <div className="flex items-center space-x-2 text-success">
            <CheckCircle className="h-4 w-4" />
            <span className="text-sm">Settings saved successfully</span>
          </div>
        )}
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? 'Saving...' : 'Save Configuration'}
        </Button>
      </div>
    </div>
  );
}
