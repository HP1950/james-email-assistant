(function() {
    // TalkBot Website Widget
    const TALKBOT_API_BASE = window.location.origin + '/api';
    
    // Create widget styles
    const widgetStyles = `
        #talkbot-widget {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 10000;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        #talkbot-toggle {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            transition: all 0.3s ease;
        }
        
        #talkbot-toggle:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        
        #talkbot-chat {
            position: absolute;
            bottom: 80px;
            right: 0;
            width: 350px;
            height: 500px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            display: none;
            flex-direction: column;
            overflow: hidden;
        }
        
        #talkbot-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px;
            text-align: center;
            font-weight: 600;
        }
        
        #talkbot-messages {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            background: #f8f9fa;
        }
        
        .talkbot-message {
            margin-bottom: 15px;
            max-width: 80%;
        }
        
        .talkbot-message.user {
            margin-left: auto;
        }
        
        .talkbot-message.user .message-content {
            background: #667eea;
            color: white;
            border-radius: 15px 15px 5px 15px;
        }
        
        .talkbot-message.bot .message-content {
            background: white;
            color: #333;
            border-radius: 15px 15px 15px 5px;
            border: 1px solid #e9ecef;
        }
        
        .message-content {
            padding: 10px 15px;
            font-size: 14px;
            line-height: 1.4;
        }
        
        #talkbot-input-area {
            padding: 15px;
            border-top: 1px solid #e9ecef;
            background: white;
        }
        
        #talkbot-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #e9ecef;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
        }
        
        #talkbot-input:focus {
            border-color: #667eea;
        }
        
        .typing-indicator {
            display: none;
            padding: 10px 15px;
            font-style: italic;
            color: #666;
            font-size: 12px;
        }
        
        @media (max-width: 480px) {
            #talkbot-chat {
                width: 300px;
                height: 400px;
            }
        }
    `;
    
    // Inject styles
    const styleSheet = document.createElement('style');
    styleSheet.textContent = widgetStyles;
    document.head.appendChild(styleSheet);
    
    // Create widget HTML
    const widgetHTML = `
        <button id="talkbot-toggle">💬</button>
        <div id="talkbot-chat">
            <div id="talkbot-header">
                🤖 TalkBot Assistant
            </div>
            <div id="talkbot-messages">
                <div class="talkbot-message bot">
                    <div class="message-content">
                        Hi! I'm your TalkBot assistant. Ask me anything about the content I've been trained on!
                    </div>
                </div>
            </div>
            <div class="typing-indicator">TalkBot is typing...</div>
            <div id="talkbot-input-area">
                <input type="text" id="talkbot-input" placeholder="Type your message..." />
            </div>
        </div>
    `;
    
    // Initialize widget
    function initWidget() {
        const widgetContainer = document.getElementById('talkbot-widget');
        if (!widgetContainer) {
            console.error('TalkBot: Widget container not found. Please add <div id="talkbot-widget"></div> to your page.');
            return;
        }
        
        widgetContainer.innerHTML = widgetHTML;
        
        const toggle = document.getElementById('talkbot-toggle');
        const chat = document.getElementById('talkbot-chat');
        const input = document.getElementById('talkbot-input');
        const messages = document.getElementById('talkbot-messages');
        const typingIndicator = document.querySelector('.typing-indicator');
        
        let isOpen = false;
        
        // Toggle chat
        toggle.addEventListener('click', function() {
            isOpen = !isOpen;
            chat.style.display = isOpen ? 'flex' : 'none';
            toggle.textContent = isOpen ? '✕' : '💬';
            
            if (isOpen) {
                input.focus();
            }
        });
        
        // Send message on Enter
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && input.value.trim()) {
                sendMessage(input.value.trim());
                input.value = '';
            }
        });
        
        // Add message to chat
        function addMessage(content, isUser = false) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `talkbot-message ${isUser ? 'user' : 'bot'}`;
            messageDiv.innerHTML = `<div class="message-content">${content}</div>`;
            messages.appendChild(messageDiv);
            messages.scrollTop = messages.scrollHeight;
        }
        
        // Send message to TalkBot API
        async function sendMessage(message) {
            addMessage(message, true);
            
            // Show typing indicator
            typingIndicator.style.display = 'block';
            messages.scrollTop = messages.scrollHeight;
            
            try {
                const response = await fetch(`${TALKBOT_API_BASE}/social/simulate-comment`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        comment: message,
                        platform: 'website'
                    })
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    const botResponse = data.response.response_content;
                    addMessage(botResponse);
                } else {
                    addMessage('Sorry, I encountered an error. Please try again later.');
                }
            } catch (error) {
                console.error('TalkBot API Error:', error);
                addMessage('Sorry, I\'m having trouble connecting right now. Please try again later.');
            } finally {
                // Hide typing indicator
                typingIndicator.style.display = 'none';
            }
        }
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initWidget);
    } else {
        initWidget();
    }
})();

