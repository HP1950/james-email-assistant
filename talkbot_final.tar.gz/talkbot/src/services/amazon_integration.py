import requests
import json
import hashlib
import hmac
import base64
from datetime import datetime, timezone
from urllib.parse import quote
import os

class AmazonSPAPIClient:
    """
    Amazon Selling Partner API (SP-API) client for accessing reviews and feedback
    """
    
    def __init__(self):
        # SP-API Configuration (use environment variables in production)
        self.client_id = os.getenv('AMAZON_CLIENT_ID', 'your_client_id')
        self.client_secret = os.getenv('AMAZON_CLIENT_SECRET', 'your_client_secret')
        self.refresh_token = os.getenv('AMAZON_REFRESH_TOKEN', 'your_refresh_token')
        self.access_key_id = os.getenv('AMAZON_ACCESS_KEY_ID', 'your_access_key')
        self.secret_access_key = os.getenv('AMAZON_SECRET_ACCESS_KEY', 'your_secret_key')
        self.role_arn = os.getenv('AMAZON_ROLE_ARN', 'your_role_arn')
        
        # SP-API Endpoints
        self.base_url = 'https://sellingpartnerapi-na.amazon.com'  # North America
        self.token_url = 'https://api.amazon.com/auth/o2/token'
        
        self.access_token = None
        self.token_expires_at = None
    
    def get_access_token(self):
        """Get LWA (Login with Amazon) access token"""
        try:
            if self.access_token and self.token_expires_at:
                if datetime.now(timezone.utc) < self.token_expires_at:
                    return self.access_token
            
            # Request new access token
            data = {
                'grant_type': 'refresh_token',
                'refresh_token': self.refresh_token,
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            response = requests.post(self.token_url, data=data)
            response.raise_for_status()
            
            token_data = response.json()
            self.access_token = token_data['access_token']
            expires_in = token_data.get('expires_in', 3600)
            self.token_expires_at = datetime.now(timezone.utc).timestamp() + expires_in
            
            return self.access_token
            
        except Exception as e:
            print(f"Error getting access token: {e}")
            return None
    
    def sign_request(self, method, url, headers, payload=''):
        """Sign request using AWS Signature Version 4"""
        try:
            # This is a simplified version - in production, use boto3 or aws-requests-auth
            # For now, return headers without signing
            return headers
        except Exception as e:
            print(f"Error signing request: {e}")
            return headers
    
    def make_api_request(self, endpoint, method='GET', params=None, data=None):
        """Make authenticated request to SP-API"""
        try:
            access_token = self.get_access_token()
            if not access_token:
                return None
            
            url = f"{self.base_url}{endpoint}"
            
            headers = {
                'Authorization': f'Bearer {access_token}',
                'Content-Type': 'application/json',
                'x-amz-access-token': access_token
            }
            
            # Sign the request (simplified for demo)
            headers = self.sign_request(method, url, headers, data or '')
            
            if method == 'GET':
                response = requests.get(url, headers=headers, params=params)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            print(f"API request error: {e}")
            return None
    
    def get_customer_feedback(self, marketplace_id='ATVPDKIKX0DER'):
        """Get customer feedback using Customer Feedback API"""
        try:
            endpoint = f"/customer-feedback/2023-05-01/feedback"
            params = {
                'marketplaceIds': marketplace_id
            }
            
            return self.make_api_request(endpoint, params=params)
            
        except Exception as e:
            print(f"Error getting customer feedback: {e}")
            return None
    
    def get_solicitations(self, marketplace_id='ATVPDKIKX0DER'):
        """Get solicitation requests for reviews"""
        try:
            endpoint = f"/solicitations/v1/orders"
            params = {
                'marketplaceIds': marketplace_id
            }
            
            return self.make_api_request(endpoint, params=params)
            
        except Exception as e:
            print(f"Error getting solicitations: {e}")
            return None

class AmazonProductReviewsClient:
    """
    Client for accessing Amazon product reviews (using web scraping as fallback)
    Note: Amazon doesn't provide a public API for product reviews
    """
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def get_product_reviews(self, asin, max_reviews=50):
        """
        Get product reviews for a given ASIN
        Note: This is a simplified example - in production, consider using:
        1. Amazon Product Advertising API (limited review data)
        2. Third-party services like Rainforest API
        3. Web scraping with proper rate limiting and compliance
        """
        try:
            reviews = []
            
            # Simulate review data for demo purposes
            # In production, implement proper review fetching
            sample_reviews = [
                {
                    'review_id': f'R{asin}001',
                    'asin': asin,
                    'reviewer_name': 'Amazon Customer',
                    'rating': 5,
                    'title': 'Great product!',
                    'content': 'This product exceeded my expectations. Highly recommend!',
                    'date': '2024-01-15',
                    'verified_purchase': True
                },
                {
                    'review_id': f'R{asin}002',
                    'asin': asin,
                    'reviewer_name': 'Verified Buyer',
                    'rating': 4,
                    'title': 'Good value for money',
                    'content': 'Works as described. Good quality for the price.',
                    'date': '2024-01-10',
                    'verified_purchase': True
                }
            ]
            
            return sample_reviews[:max_reviews]
            
        except Exception as e:
            print(f"Error getting product reviews: {e}")
            return []
    
    def monitor_new_reviews(self, asin_list):
        """Monitor for new reviews on specified products"""
        try:
            new_reviews = []
            
            for asin in asin_list:
                reviews = self.get_product_reviews(asin, max_reviews=10)
                # In production, compare with stored reviews to find new ones
                new_reviews.extend(reviews)
            
            return new_reviews
            
        except Exception as e:
            print(f"Error monitoring reviews: {e}")
            return []

class AmazonIntegrationService:
    """
    Main service for Amazon integration combining SP-API and review monitoring
    """
    
    def __init__(self):
        self.sp_api = AmazonSPAPIClient()
        self.reviews_client = AmazonProductReviewsClient()
    
    def get_all_feedback(self, marketplace_id='ATVPDKIKX0DER'):
        """Get all customer feedback from SP-API"""
        try:
            feedback = self.sp_api.get_customer_feedback(marketplace_id)
            
            if feedback:
                return {
                    'success': True,
                    'feedback': feedback,
                    'source': 'sp_api'
                }
            else:
                return {
                    'success': False,
                    'error': 'Failed to fetch feedback from SP-API'
                }
                
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_product_reviews_data(self, asin):
        """Get product reviews for specific ASIN"""
        try:
            reviews = self.reviews_client.get_product_reviews(asin)
            
            return {
                'success': True,
                'reviews': reviews,
                'asin': asin,
                'total_reviews': len(reviews)
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def process_amazon_comment(self, comment_data):
        """Process Amazon review/comment for bot response"""
        try:
            # Extract relevant information
            comment_text = comment_data.get('content', '')
            rating = comment_data.get('rating', 0)
            reviewer_name = comment_data.get('reviewer_name', 'Customer')
            
            # Determine response strategy based on rating
            if rating >= 4:
                response_tone = 'grateful'
            elif rating == 3:
                response_tone = 'neutral'
            else:
                response_tone = 'helpful'
            
            return {
                'comment': comment_text,
                'rating': rating,
                'reviewer': reviewer_name,
                'response_tone': response_tone,
                'platform': 'amazon'
            }
            
        except Exception as e:
            return {
                'error': str(e)
            }
    
    def generate_amazon_response(self, processed_comment, knowledge_base):
        """Generate appropriate response for Amazon review/comment"""
        try:
            comment = processed_comment.get('comment', '')
            rating = processed_comment.get('rating', 0)
            tone = processed_comment.get('response_tone', 'neutral')
            
            # Create context for response generation
            context = {
                'platform': 'amazon',
                'comment': comment,
                'rating': rating,
                'tone': tone,
                'knowledge_base': knowledge_base
            }
            
            # In production, integrate with your existing response generation system
            # For now, return a template response
            if rating >= 4:
                response_template = f"Thank you for your positive review! We're thrilled that you're happy with your purchase. If you have any questions about our products, feel free to ask!"
            elif rating == 3:
                response_template = f"Thank you for your feedback. We appreciate your honest review and are always looking to improve. Is there anything specific we can help you with?"
            else:
                response_template = f"Thank you for your feedback. We're sorry to hear about your experience. We'd love to help make this right. Please let us know how we can assist you better."
            
            return {
                'success': True,
                'response': response_template,
                'context': context
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

# Configuration helper
def get_amazon_config():
    """Get Amazon integration configuration"""
    return {
        'sp_api': {
            'client_id': os.getenv('AMAZON_CLIENT_ID'),
            'client_secret': os.getenv('AMAZON_CLIENT_SECRET'),
            'refresh_token': os.getenv('AMAZON_REFRESH_TOKEN'),
            'access_key_id': os.getenv('AMAZON_ACCESS_KEY_ID'),
            'secret_access_key': os.getenv('AMAZON_SECRET_ACCESS_KEY'),
            'role_arn': os.getenv('AMAZON_ROLE_ARN')
        },
        'marketplaces': {
            'US': 'ATVPDKIKX0DER',
            'CA': 'A2EUQ1WTGCTBG2',
            'UK': 'A1F83G8C2ARO7P',
            'DE': 'A1PA6795UKMFR9',
            'FR': 'A13V1IB3VIYZZH',
            'IT': 'APJ6JRA9NG5V4',
            'ES': 'A1RKKUPIHCS9HS'
        }
    }

