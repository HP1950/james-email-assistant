"""
Platform integration services for Facebook/Instagram, YouTube, LinkedIn, and X (Twitter)
"""
import requests
import json
import os
from typing import List, Dict, Optional
from datetime import datetime

class PlatformIntegration:
    """Base class for social media platform integrations"""
    
    def __init__(self, access_token: str = None):
        self.access_token = access_token
    
    def get_comments(self, post_id: str) -> List[Dict]:
        """Get comments for a specific post"""
        raise NotImplementedError
    
    def post_reply(self, comment_id: str, reply_text: str) -> bool:
        """Post a reply to a comment"""
        raise NotImplementedError

class FacebookInstagramIntegration(PlatformIntegration):
    """Facebook and Instagram integration using Meta Graph API"""
    
    def __init__(self, access_token: str = None, page_id: str = None):
        super().__init__(access_token)
        self.page_id = page_id
        self.base_url = "https://graph.facebook.com/v18.0"
    
    def get_comments(self, post_id: str) -> List[Dict]:
        """Get comments from Facebook/Instagram post"""
        if not self.access_token:
            return []
        
        url = f"{self.base_url}/{post_id}/comments"
        params = {
            'access_token': self.access_token,
            'fields': 'id,message,from,created_time'
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            comments = []
            for comment in data.get('data', []):
                comments.append({
                    'id': comment['id'],
                    'content': comment.get('message', ''),
                    'author': comment.get('from', {}).get('name', 'Unknown'),
                    'created_at': comment.get('created_time'),
                    'platform': 'facebook' if 'facebook' in post_id else 'instagram'
                })
            
            return comments
        except requests.RequestException as e:
            print(f"Error fetching Facebook/Instagram comments: {e}")
            return []
    
    def post_reply(self, comment_id: str, reply_text: str) -> bool:
        """Reply to a Facebook/Instagram comment"""
        if not self.access_token:
            return False
        
        url = f"{self.base_url}/{comment_id}/comments"
        data = {
            'access_token': self.access_token,
            'message': reply_text
        }
        
        try:
            response = requests.post(url, data=data)
            response.raise_for_status()
            return True
        except requests.RequestException as e:
            print(f"Error posting Facebook/Instagram reply: {e}")
            return False

class YouTubeIntegration(PlatformIntegration):
    """YouTube integration using YouTube Data API v3"""
    
    def __init__(self, api_key: str = None):
        super().__init__(api_key)
        self.base_url = "https://www.googleapis.com/youtube/v3"
    
    def get_comments(self, video_id: str) -> List[Dict]:
        """Get comments from YouTube video"""
        if not self.access_token:  # API key in this case
            return []
        
        url = f"{self.base_url}/commentThreads"
        params = {
            'key': self.access_token,
            'videoId': video_id,
            'part': 'snippet',
            'maxResults': 100
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            comments = []
            for item in data.get('items', []):
                comment = item['snippet']['topLevelComment']['snippet']
                comments.append({
                    'id': item['id'],
                    'content': comment.get('textDisplay', ''),
                    'author': comment.get('authorDisplayName', 'Unknown'),
                    'created_at': comment.get('publishedAt'),
                    'platform': 'youtube'
                })
            
            return comments
        except requests.RequestException as e:
            print(f"Error fetching YouTube comments: {e}")
            return []
    
    def post_reply(self, comment_id: str, reply_text: str) -> bool:
        """Reply to a YouTube comment (requires OAuth)"""
        # Note: This requires OAuth authentication and additional setup
        # For now, return False as this needs proper OAuth flow
        print("YouTube reply posting requires OAuth authentication")
        return False

class LinkedInIntegration(PlatformIntegration):
    """LinkedIn integration using LinkedIn API"""
    
    def __init__(self, access_token: str = None):
        super().__init__(access_token)
        self.base_url = "https://api.linkedin.com/v2"
    
    def get_comments(self, post_id: str) -> List[Dict]:
        """Get comments from LinkedIn post"""
        if not self.access_token:
            return []
        
        # LinkedIn API endpoint for comments
        url = f"{self.base_url}/socialActions/{post_id}/comments"
        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'X-Restli-Protocol-Version': '2.0.0'
        }
        
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            comments = []
            for comment in data.get('elements', []):
                comments.append({
                    'id': comment.get('id'),
                    'content': comment.get('message', {}).get('text', ''),
                    'author': 'LinkedIn User',  # Would need additional API call for user details
                    'created_at': comment.get('created', {}).get('time'),
                    'platform': 'linkedin'
                })
            
            return comments
        except requests.RequestException as e:
            print(f"Error fetching LinkedIn comments: {e}")
            return []
    
    def post_reply(self, comment_id: str, reply_text: str) -> bool:
        """Reply to a LinkedIn comment"""
        if not self.access_token:
            return False
        
        # LinkedIn comment reply endpoint
        url = f"{self.base_url}/socialActions/{comment_id}/comments"
        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json',
            'X-Restli-Protocol-Version': '2.0.0'
        }
        
        data = {
            'message': {
                'text': reply_text
            }
        }
        
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            return True
        except requests.RequestException as e:
            print(f"Error posting LinkedIn reply: {e}")
            return False

class XTwitterIntegration(PlatformIntegration):
    """X (Twitter) integration using Twitter API v2"""
    
    def __init__(self, bearer_token: str = None):
        super().__init__(bearer_token)
        self.base_url = "https://api.twitter.com/2"
    
    def get_comments(self, tweet_id: str) -> List[Dict]:
        """Get replies to a Twitter/X tweet"""
        if not self.access_token:
            return []
        
        # Search for replies to the tweet
        url = f"{self.base_url}/tweets/search/recent"
        headers = {
            'Authorization': f'Bearer {self.access_token}'
        }
        params = {
            'query': f'conversation_id:{tweet_id}',
            'tweet.fields': 'created_at,author_id,conversation_id',
            'user.fields': 'username',
            'expansions': 'author_id'
        }
        
        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            data = response.json()
            
            comments = []
            users = {user['id']: user for user in data.get('includes', {}).get('users', [])}
            
            for tweet in data.get('data', []):
                author = users.get(tweet['author_id'], {})
                comments.append({
                    'id': tweet['id'],
                    'content': tweet.get('text', ''),
                    'author': author.get('username', 'Unknown'),
                    'created_at': tweet.get('created_at'),
                    'platform': 'twitter'
                })
            
            return comments
        except requests.RequestException as e:
            print(f"Error fetching Twitter comments: {e}")
            return []
    
    def post_reply(self, tweet_id: str, reply_text: str) -> bool:
        """Reply to a Twitter/X tweet"""
        if not self.access_token:
            return False
        
        url = f"{self.base_url}/tweets"
        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'text': reply_text,
            'reply': {
                'in_reply_to_tweet_id': tweet_id
            }
        }
        
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            return True
        except requests.RequestException as e:
            print(f"Error posting Twitter reply: {e}")
            return False

class PlatformManager:
    """Manager class to handle all platform integrations"""
    
    def __init__(self):
        self.platforms = {
            'facebook': FacebookInstagramIntegration(),
            'instagram': FacebookInstagramIntegration(),
            'youtube': YouTubeIntegration(),
            'linkedin': LinkedInIntegration(),
            'twitter': XTwitterIntegration()
        }
    
    def configure_platform(self, platform: str, **credentials):
        """Configure credentials for a specific platform"""
        if platform in ['facebook', 'instagram']:
            self.platforms[platform] = FacebookInstagramIntegration(
                access_token=credentials.get('access_token'),
                page_id=credentials.get('page_id')
            )
        elif platform == 'youtube':
            self.platforms[platform] = YouTubeIntegration(
                api_key=credentials.get('api_key')
            )
        elif platform == 'linkedin':
            self.platforms[platform] = LinkedInIntegration(
                access_token=credentials.get('access_token')
            )
        elif platform == 'twitter':
            self.platforms[platform] = XTwitterIntegration(
                bearer_token=credentials.get('bearer_token')
            )
    
    def get_platform_comments(self, platform: str, post_id: str) -> List[Dict]:
        """Get comments from a specific platform"""
        if platform in self.platforms:
            return self.platforms[platform].get_comments(post_id)
        return []
    
    def post_platform_reply(self, platform: str, comment_id: str, reply_text: str) -> bool:
        """Post a reply on a specific platform"""
        if platform in self.platforms:
            return self.platforms[platform].post_reply(comment_id, reply_text)
        return False

