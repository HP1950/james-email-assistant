from flask import Blueprint, request, jsonify, session
import os
import uuid
from datetime import datetime, timedelta
from src.models.auth import User, UserSession
from src.models.user import db

payments_bp = Blueprint('payments', __name__)

# Square API configuration (use environment variables in production)
SQUARE_APPLICATION_ID = os.getenv('SQUARE_APPLICATION_ID', 'sandbox-sq0idb-YOUR_APPLICATION_ID')
SQUARE_ACCESS_TOKEN = os.getenv('SQUARE_ACCESS_TOKEN', 'sandbox-sq0atb-YOUR_ACCESS_TOKEN')
SQUARE_LOCATION_ID = os.getenv('SQUARE_LOCATION_ID', 'sandbox-sq0idp-YOUR_LOCATION_ID')
SQUARE_ENVIRONMENT = os.getenv('SQUARE_ENVIRONMENT', 'sandbox')  # 'sandbox' or 'production'

# Plan pricing (in cents)
PLAN_PRICES = {
    'starter': 2900,      # $29.00
    'professional': 7900,  # $79.00
    'enterprise': 19900    # $199.00
}

@payments_bp.route('/process', methods=['POST'])
def process_payment():
    """Process Square payment for subscription"""
    try:
        data = request.get_json()
        
        # Extract payment data
        token = data.get('token')
        plan = data.get('plan', 'starter')
        email = data.get('email')
        amount = data.get('amount')  # Amount in cents
        
        # Validation
        if not all([token, plan, email, amount]):
            return jsonify({'error': 'Missing required payment information'}), 400
        
        if plan not in PLAN_PRICES:
            return jsonify({'error': 'Invalid plan selected'}), 400
        
        if amount != PLAN_PRICES[plan]:
            return jsonify({'error': 'Invalid payment amount'}), 400
        
        # Find user
        user = User.find_by_email(email)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # For now, simulate successful payment processing
        # In production, you would integrate with Square's Payments API
        payment_result = simulate_square_payment(token, amount, plan, user)
        
        if payment_result['success']:
            # Update user's plan and payment status
            user.plan = plan
            user.updated_at = datetime.utcnow()
            db.session.commit()
            
            # Create payment record
            create_payment_record(user.id, plan, amount, payment_result['transaction_id'])
            
            return jsonify({
                'message': 'Payment processed successfully',
                'transaction_id': payment_result['transaction_id'],
                'plan': plan,
                'amount': amount / 100  # Convert back to dollars for display
            }), 200
        else:
            return jsonify({'error': payment_result['error']}), 400
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Payment processing failed'}), 500

def simulate_square_payment(token, amount, plan, user):
    """
    Simulate Square payment processing
    In production, replace this with actual Square API calls
    """
    try:
        # Simulate payment processing delay
        import time
        time.sleep(1)
        
        # Generate a mock transaction ID
        transaction_id = f"txn_{uuid.uuid4().hex[:12]}"
        
        # Simulate successful payment (90% success rate for demo)
        import random
        if random.random() < 0.9:
            return {
                'success': True,
                'transaction_id': transaction_id,
                'amount': amount,
                'plan': plan
            }
        else:
            return {
                'success': False,
                'error': 'Payment declined by card issuer'
            }
            
    except Exception as e:
        return {
            'success': False,
            'error': 'Payment processing error'
        }

def create_payment_record(user_id, plan, amount, transaction_id):
    """Create a payment record in the database"""
    try:
        # Create payment record (you might want to create a Payment model)
        payment_data = {
            'user_id': user_id,
            'plan': plan,
            'amount': amount,
            'transaction_id': transaction_id,
            'status': 'completed',
            'created_at': datetime.utcnow()
        }
        
        # For now, just log the payment
        print(f"Payment recorded: {payment_data}")
        
        # In production, save to Payment model:
        # payment = Payment(**payment_data)
        # db.session.add(payment)
        # db.session.commit()
        
    except Exception as e:
        print(f"Failed to create payment record: {e}")

@payments_bp.route('/plans', methods=['GET'])
def get_plans():
    """Get available subscription plans"""
    try:
        plans = {
            'starter': {
                'name': 'Starter Plan',
                'price': PLAN_PRICES['starter'] / 100,  # Convert to dollars
                'features': [
                    'Basic bot responses',
                    'Up to 1,000 responses/month',
                    'Email support',
                    'Basic analytics'
                ]
            },
            'professional': {
                'name': 'Professional Plan',
                'price': PLAN_PRICES['professional'] / 100,
                'features': [
                    'Advanced AI responses',
                    'Up to 10,000 responses/month',
                    'Priority support',
                    'Advanced analytics',
                    'Custom integrations'
                ]
            },
            'enterprise': {
                'name': 'Enterprise Plan',
                'price': PLAN_PRICES['enterprise'] / 100,
                'features': [
                    'Premium AI responses',
                    'Unlimited responses',
                    '24/7 phone support',
                    'Full analytics suite',
                    'Custom integrations',
                    'Dedicated account manager'
                ]
            }
        }
        
        return jsonify({'plans': plans}), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to fetch plans'}), 500

@payments_bp.route('/subscription', methods=['GET'])
def get_subscription():
    """Get current user's subscription details"""
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        plan_info = {
            'plan': user.plan,
            'price': PLAN_PRICES.get(user.plan, 0) / 100,
            'status': 'active' if user.is_active else 'inactive',
            'created_at': user.created_at.isoformat() if user.created_at else None
        }
        
        return jsonify({'subscription': plan_info}), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to fetch subscription'}), 500

@payments_bp.route('/webhook', methods=['POST'])
def square_webhook():
    """Handle Square webhook notifications"""
    try:
        # In production, verify webhook signature
        data = request.get_json()
        
        # Handle different webhook events
        event_type = data.get('type')
        
        if event_type == 'payment.created':
            # Handle successful payment
            payment_data = data.get('data', {}).get('object', {})
            # Process payment confirmation
            pass
        elif event_type == 'payment.failed':
            # Handle failed payment
            payment_data = data.get('data', {}).get('object', {})
            # Process payment failure
            pass
        
        return jsonify({'status': 'received'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Webhook processing failed'}), 500

