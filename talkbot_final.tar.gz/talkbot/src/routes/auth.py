from flask import Blueprint, request, jsonify, session
from datetime import datetime, timedelta
import secrets
import re
from src.models.auth import User, UserSession
from src.models.user import db

auth_bp = Blueprint('auth', __name__)

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_password(password):
    """Validate password strength"""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not re.search(r'[A-Za-z]', password):
        return False, "Password must contain at least one letter"
    
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number"
    
    return True, "Password is valid"

@auth_bp.route('/signup', methods=['POST'])
def signup():
    """Handle user registration"""
    try:
        data = request.get_json()
        
        # Extract and validate required fields
        first_name = data.get('firstName', '').strip()
        last_name = data.get('lastName', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '')
        company = data.get('company', '').strip() or None
        plan = data.get('plan', 'starter')
        
        # Validation
        if not all([first_name, last_name, email, password]):
            return jsonify({'error': 'All required fields must be provided'}), 400
        
        if not validate_email(email):
            return jsonify({'error': 'Invalid email format'}), 400
        
        is_valid_password, password_message = validate_password(password)
        if not is_valid_password:
            return jsonify({'error': password_message}), 400
        
        if plan not in ['starter', 'professional', 'enterprise']:
            return jsonify({'error': 'Invalid plan selected'}), 400
        
        # Check if user already exists
        existing_user = User.find_by_email(email)
        if existing_user:
            return jsonify({'error': 'An account with this email already exists'}), 409
        
        # Create new user
        try:
            user = User.create_user(
                first_name=first_name,
                last_name=last_name,
                email=email,
                password=password,
                company=company,
                plan=plan
            )
            
            # Create session for the new user
            session_token = secrets.token_urlsafe(32)
            expires_at = datetime.utcnow() + timedelta(days=30)  # 30-day session
            
            UserSession.create_session(user.id, session_token, expires_at)
            
            # Set session data
            session['user_id'] = user.id
            session['session_token'] = session_token
            
            return jsonify({
                'message': 'Account created successfully',
                'user': user.to_dict(),
                'session_token': session_token
            }), 201
            
        except ValueError as e:
            return jsonify({'error': str(e)}), 400
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'An error occurred during registration'}), 500

@auth_bp.route('/signin', methods=['POST'])
def signin():
    """Handle user login"""
    try:
        data = request.get_json()
        
        email = data.get('email', '').strip()
        password = data.get('password', '')
        
        # Validation
        if not email or not password:
            return jsonify({'error': 'Email and password are required'}), 400
        
        if not validate_email(email):
            return jsonify({'error': 'Invalid email format'}), 400
        
        # Find user
        user = User.find_by_email(email)
        if not user:
            return jsonify({'error': 'Invalid email or password'}), 401
        
        # Check if user is active
        if not user.is_active:
            return jsonify({'error': 'Account is deactivated. Please contact support.'}), 401
        
        # Verify password
        if not user.check_password(password):
            return jsonify({'error': 'Invalid email or password'}), 401
        
        # Update last login
        user.update_last_login()
        
        # Create new session
        session_token = secrets.token_urlsafe(32)
        expires_at = datetime.utcnow() + timedelta(days=30)  # 30-day session
        
        UserSession.create_session(user.id, session_token, expires_at)
        
        # Set session data
        session['user_id'] = user.id
        session['session_token'] = session_token
        
        return jsonify({
            'message': 'Sign in successful',
            'user': user.to_dict(),
            'session_token': session_token
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'An error occurred during sign in'}), 500

@auth_bp.route('/signout', methods=['POST'])
def signout():
    """Handle user logout"""
    try:
        session_token = session.get('session_token')
        
        if session_token:
            # Deactivate the session
            user_session = UserSession.find_by_token(session_token)
            if user_session:
                user_session.deactivate()
        
        # Clear session data
        session.clear()
        
        return jsonify({'message': 'Signed out successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'An error occurred during sign out'}), 500

@auth_bp.route('/profile', methods=['GET'])
def get_profile():
    """Get current user profile"""
    try:
        user_id = session.get('user_id')
        session_token = session.get('session_token')
        
        if not user_id or not session_token:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Verify session
        user_session = UserSession.find_by_token(session_token)
        if not user_session or user_session.user_id != user_id:
            return jsonify({'error': 'Invalid session'}), 401
        
        # Check if session is expired
        if user_session.expires_at < datetime.utcnow():
            user_session.deactivate()
            session.clear()
            return jsonify({'error': 'Session expired'}), 401
        
        # Get user
        user = User.query.get(user_id)
        if not user or not user.is_active:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify({
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'An error occurred while fetching profile'}), 500

@auth_bp.route('/change-password', methods=['POST'])
def change_password():
    """Change user password"""
    try:
        user_id = session.get('user_id')
        session_token = session.get('session_token')
        
        if not user_id or not session_token:
            return jsonify({'error': 'Not authenticated'}), 401
        
        data = request.get_json()
        current_password = data.get('currentPassword', '')
        new_password = data.get('newPassword', '')
        
        if not current_password or not new_password:
            return jsonify({'error': 'Current password and new password are required'}), 400
        
        # Validate new password
        is_valid_password, password_message = validate_password(new_password)
        if not is_valid_password:
            return jsonify({'error': password_message}), 400
        
        # Get user
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Verify current password
        if not user.check_password(current_password):
            return jsonify({'error': 'Current password is incorrect'}), 401
        
        # Update password
        user.set_password(new_password)
        db.session.commit()
        
        return jsonify({'message': 'Password changed successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'An error occurred while changing password'}), 500

@auth_bp.route('/users', methods=['GET'])
def list_users():
    """List all users (admin functionality)"""
    try:
        users = User.query.all()
        return jsonify({
            'users': [user.to_dict() for user in users],
            'total': len(users)
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'An error occurred while fetching users'}), 500

