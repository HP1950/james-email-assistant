from flask import Blueprint, jsonify, request
from src.models.knowledge_base import KnowledgeBase, db
import json
from PyPDF2 import PdfReader
import io

knowledge_bp = Blueprint("knowledge", __name__)

@knowledge_bp.route("/knowledge", methods=["GET"])
def get_knowledge_entries():
    """Get all knowledge base entries"""
    entries = KnowledgeBase.query.all()
    return jsonify([entry.to_dict() for entry in entries])

@knowledge_bp.route("/knowledge", methods=["POST"])
def create_knowledge_entry():
    """Create a new knowledge base entry"""
    data = request.json
    
    # Convert keywords list to comma-separated string
    keywords = ",".join(data.get("keywords", [])) if data.get("keywords") else None
    
    entry = KnowledgeBase(
        title=data["title"],
        content=data["content"],
        category=data.get("category"),
        keywords=keywords
    )
    
    db.session.add(entry)
    db.session.commit()
    return jsonify(entry.to_dict()), 201

@knowledge_bp.route("/knowledge/<int:entry_id>", methods=["GET"])
def get_knowledge_entry(entry_id):
    """Get a specific knowledge base entry"""
    entry = KnowledgeBase.query.get_or_404(entry_id)
    return jsonify(entry.to_dict())

@knowledge_bp.route("/knowledge/<int:entry_id>", methods=["PUT"])
def update_knowledge_entry(entry_id):
    """Update a knowledge base entry"""
    entry = KnowledgeBase.query.get_or_404(entry_id)
    data = request.json
    
    entry.title = data.get("title", entry.title)
    entry.content = data.get("content", entry.content)
    entry.category = data.get("category", entry.category)
    
    # Handle keywords update
    if "keywords" in data:
        entry.keywords = ",".join(data["keywords"]) if data["keywords"] else None
    
    db.session.commit()
    return jsonify(entry.to_dict())

@knowledge_bp.route("/knowledge/<int:entry_id>", methods=["DELETE"])
def delete_knowledge_entry(entry_id):
    """Delete a knowledge base entry"""
    entry = KnowledgeBase.query.get_or_404(entry_id)
    db.session.delete(entry)
    db.session.commit()
    return "", 204

@knowledge_bp.route("/knowledge/search", methods=["POST"])
def search_knowledge():
    """Search knowledge base entries"""
    data = request.json
    query = data.get("query", "").lower()
    
    if not query:
        return jsonify([])
    
    # Simple text search across title, content, and keywords
    results = KnowledgeBase.query.filter(
        db.or_(
            KnowledgeBase.title.contains(query),
            KnowledgeBase.content.contains(query),
            KnowledgeBase.keywords.contains(query)
        )
    ).all()
    
    return jsonify([result.to_dict() for result in results])

@knowledge_bp.route("/knowledge/bulk-upload", methods=["POST"])
def bulk_upload_knowledge():
    """Bulk upload knowledge base entries from text content"""
    data = request.json
    content = data.get("content", "")
    title = data.get("title", "Bulk Upload")
    category = data.get("category", "Book Content")
    
    # Split content into chunks (simple approach - split by paragraphs)
    paragraphs = [p.strip() for p in content.split("\n\n") if p.strip()]
    
    entries_created = []
    for i, paragraph in enumerate(paragraphs):
        if len(paragraph) > 50:  # Only create entries for substantial paragraphs
            entry = KnowledgeBase(
                title=f"{title} - Part {i+1}",
                content=paragraph,
                category=category,
                keywords=None  # Could be enhanced with automatic keyword extraction
            )
            db.session.add(entry)
            entries_created.append(entry)
    
    db.session.commit()
    return jsonify({
        "message": f"Created {len(entries_created)} knowledge base entries",
        "entries": [entry.to_dict() for entry in entries_created]
    }), 201

@knowledge_bp.route("/knowledge/upload-file", methods=["POST"])
def upload_knowledge_file():
    """Upload a file (e.g., PDF) and extract text for knowledge base"""
    if "file" not in request.files:
        return jsonify({"error": "No file part in the request"}), 400
    
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400
    
    if file and file.filename.endswith(".pdf"):
        try:
            reader = PdfReader(io.BytesIO(file.read()))
            text = ""
            for page in reader.pages:
                text += page.extract_text() or ""
            
            # Now process the extracted text as bulk upload
            title = request.form.get("title", file.filename.replace(".pdf", ""))
            category = request.form.get("category", "Uploaded Document")
            
            # Split content into chunks (simple approach - split by paragraphs)
            paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
            
            entries_created = []
            for i, paragraph in enumerate(paragraphs):
                if len(paragraph) > 50:  # Only create entries for substantial paragraphs
                    entry = KnowledgeBase(
                        title=f"{title} - Part {i+1}",
                        content=paragraph,
                        category=category,
                        keywords=None  # Could be enhanced with automatic keyword extraction
                    )
                    db.session.add(entry)
                    entries_created.append(entry)
            
            db.session.commit()
            return jsonify({
                "message": f"Created {len(entries_created)} knowledge base entries from PDF",
                "entries": [entry.to_dict() for entry in entries_created]
            }), 201
            
        except Exception as e:
            return jsonify({"error": f"Error processing PDF: {str(e)}"}), 500
    else:
        return jsonify({"error": "Unsupported file type. Only PDF is supported for now."}), 400

