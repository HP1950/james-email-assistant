from flask import Blueprint, request, jsonify
from src.models.knowledge_base import SocialMediaPost, BotResponse, KnowledgeBase, db
from src.services.platform_integrations import PlatformManager
from src.services.amazon_integration import AmazonIntegrationService
import json
import openai
import os

social_bp = Blueprint('social', __name__)

# Initialize OpenAI client
openai.api_key = os.getenv('OPENAI_API_KEY')
openai.api_base = os.getenv('OPENAI_API_BASE')

# Initialize platform manager
platform_manager = PlatformManager()

# Initialize Amazon integration
amazon_service = AmazonIntegrationService()

@social_bp.route('/social/posts', methods=['GET'])
def get_social_posts():
    """Get all social media posts"""
    posts = SocialMediaPost.query.all()
    return jsonify([post.to_dict() for post in posts])

@social_bp.route('/social/posts', methods=['POST'])
def create_social_post():
    """Create a new social media post entry"""
    data = request.json
    
    post = SocialMediaPost(
        platform=data['platform'],
        post_id=data['post_id'],
        content=data['content'],
        author=data.get('author')
    )
    
    db.session.add(post)
    db.session.commit()
    return jsonify(post.to_dict()), 201

@social_bp.route('/social/posts/<int:post_id>/respond', methods=['POST'])
def generate_response(post_id):
    """Generate a response to a social media post using knowledge base"""
    post = SocialMediaPost.query.get_or_404(post_id)
    
    # Search for relevant knowledge base entries
    query = post.content.lower()
    relevant_entries = KnowledgeBase.query.filter(
        db.or_(
            KnowledgeBase.title.contains(query),
            KnowledgeBase.content.contains(query),
            KnowledgeBase.keywords.contains(query)
        )
    ).limit(3).all()  # Get top 3 relevant entries
    
    # Prepare context from knowledge base
    context = ""
    knowledge_sources = []
    for entry in relevant_entries:
        context += f"Title: {entry.title}\nContent: {entry.content}\n\n"
        knowledge_sources.append(entry.id)
    
    # Generate response using OpenAI
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": f"""You are a helpful assistant that responds to social media comments based on book content. 
                    Use the following knowledge base content to answer the user's comment or question:
                    
                    {context}
                    
                    Guidelines:
                    - Be friendly and conversational
                    - Keep responses concise (under 280 characters for Twitter)
                    - Only use information from the provided knowledge base
                    - If you can't answer based on the knowledge base, politely say so
                    - Don't make up information not in the knowledge base"""
                },
                {
                    "role": "user",
                    "content": post.content
                }
            ],
            max_tokens=150,
            temperature=0.7
        )
        
        response_content = response.choices[0].message.content.strip()
        
        # Create bot response record
        bot_response = BotResponse(
            original_post_id=post.id,
            response_content=response_content,
            knowledge_sources=json.dumps(knowledge_sources),
            confidence_score=0.8  # Could be enhanced with actual confidence scoring
        )
        
        db.session.add(bot_response)
        db.session.commit()
        
        return jsonify({
            'response': bot_response.to_dict(),
            'knowledge_sources_used': len(knowledge_sources)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@social_bp.route('/social/responses', methods=['GET'])
def get_responses():
    """Get all bot responses"""
    responses = BotResponse.query.all()
    return jsonify([response.to_dict() for response in responses])

@social_bp.route('/social/responses/<int:response_id>/post', methods=['POST'])
def mark_response_posted(response_id):
    """Mark a response as posted to social media"""
    response = BotResponse.query.get_or_404(response_id)
    response.posted = True
    db.session.commit()
    return jsonify(response.to_dict())

@social_bp.route('/social/simulate-comment', methods=['POST'])
def simulate_comment():
    """Simulate receiving a social media comment for testing"""
    data = request.json
    comment = data.get('comment', '')
    platform = data.get('platform', 'twitter')
    
    # Create a simulated post
    post = SocialMediaPost(
        platform=platform,
        post_id=f"sim_{len(SocialMediaPost.query.all()) + 1}",
        content=comment,
        author="test_user"
    )
    
    db.session.add(post)
    db.session.commit()
    
    # Generate response immediately
    return generate_response(post.id)



@social_bp.route('/social/platforms/configure', methods=['POST'])
def configure_platform():
    """Configure API credentials for a social media platform"""
    data = request.json
    platform = data.get('platform')
    credentials = data.get('credentials', {})
    
    if platform not in ['facebook', 'instagram', 'youtube', 'linkedin', 'twitter']:
        return jsonify({'error': 'Unsupported platform'}), 400
    
    try:
        platform_manager.configure_platform(platform, **credentials)
        return jsonify({'message': f'{platform.title()} configured successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@social_bp.route('/social/platforms/<platform>/comments/<post_id>', methods=['GET'])
def fetch_platform_comments(platform, post_id):
    """Fetch comments from a specific platform and post"""
    try:
        comments = platform_manager.get_platform_comments(platform, post_id)
        
        # Store comments in database
        for comment_data in comments:
            existing_post = SocialMediaPost.query.filter_by(
                platform=comment_data['platform'],
                post_id=comment_data['id']
            ).first()
            
            if not existing_post:
                post = SocialMediaPost(
                    platform=comment_data['platform'],
                    post_id=comment_data['id'],
                    content=comment_data['content'],
                    author=comment_data['author']
                )
                db.session.add(post)
        
        db.session.commit()
        return jsonify({
            'comments_fetched': len(comments),
            'comments': comments
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@social_bp.route('/social/platforms/<platform>/reply', methods=['POST'])
def post_platform_reply(platform):
    """Post a reply to a comment on a specific platform"""
    data = request.json
    comment_id = data.get('comment_id')
    reply_text = data.get('reply_text')
    
    if not comment_id or not reply_text:
        return jsonify({'error': 'comment_id and reply_text are required'}), 400
    
    try:
        success = platform_manager.post_platform_reply(platform, comment_id, reply_text)
        if success:
            return jsonify({'message': 'Reply posted successfully'})
        else:
            return jsonify({'error': 'Failed to post reply'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@social_bp.route('/social/auto-respond', methods=['POST'])
def auto_respond_to_comments():
    """Automatically respond to unprocessed comments using knowledge base"""
    data = request.json
    platform = data.get('platform')
    post_id = data.get('post_id')
    
    try:
        # Fetch comments from the platform
        comments = platform_manager.get_platform_comments(platform, post_id)
        responses_generated = 0
        
        for comment_data in comments:
            # Check if we already have this comment in our database
            existing_post = SocialMediaPost.query.filter_by(
                platform=comment_data['platform'],
                post_id=comment_data['id']
            ).first()
            
            if not existing_post:
                # Create new post entry
                post = SocialMediaPost(
                    platform=comment_data['platform'],
                    post_id=comment_data['id'],
                    content=comment_data['content'],
                    author=comment_data['author']
                )
                db.session.add(post)
                db.session.commit()
                
                # Generate response
                response_result = generate_response(post.id)
                if response_result[1] == 200:  # Success
                    responses_generated += 1
        
        return jsonify({
            'message': f'Generated {responses_generated} responses',
            'comments_processed': len(comments)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Amazon-specific endpoints

@social_bp.route('/amazon/feedback', methods=['GET'])
def get_amazon_feedback():
    """Get customer feedback from Amazon SP-API"""
    try:
        marketplace_id = request.args.get('marketplace_id', 'ATVPDKIKX0DER')  # Default to US
        
        feedback_result = amazon_service.get_all_feedback(marketplace_id)
        
        if feedback_result['success']:
            return jsonify({
                'feedback': feedback_result['feedback'],
                'source': feedback_result['source']
            })
        else:
            return jsonify({'error': feedback_result['error']}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@social_bp.route('/amazon/reviews/<asin>', methods=['GET'])
def get_amazon_product_reviews(asin):
    """Get product reviews for a specific ASIN"""
    try:
        reviews_result = amazon_service.get_product_reviews_data(asin)
        
        if reviews_result['success']:
            return jsonify({
                'asin': asin,
                'reviews': reviews_result['reviews'],
                'total_reviews': reviews_result['total_reviews']
            })
        else:
            return jsonify({'error': reviews_result['error']}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@social_bp.route('/amazon/respond', methods=['POST'])
def respond_to_amazon_review():
    """Generate response to Amazon review/comment"""
    try:
        data = request.json
        
        # Process the Amazon comment/review
        processed_comment = amazon_service.process_amazon_comment(data)
        
        if 'error' in processed_comment:
            return jsonify({'error': processed_comment['error']}), 400
        
        # Get relevant knowledge base content
        query = processed_comment.get('comment', '')
        relevant_entries = KnowledgeBase.query.filter(
            db.or_(
                KnowledgeBase.title.contains(query),
                KnowledgeBase.content.contains(query),
                KnowledgeBase.keywords.contains(query)
            )
        ).limit(3).all()
        
        knowledge_context = '\n'.join([entry.content for entry in relevant_entries])
        
        # Generate response using Amazon service
        response_result = amazon_service.generate_amazon_response(
            processed_comment, 
            knowledge_context
        )
        
        if response_result['success']:
            # Save the interaction to database
            post = SocialMediaPost(
                platform='amazon',
                post_id=data.get('review_id', 'unknown'),
                content=processed_comment.get('comment', ''),
                author=processed_comment.get('reviewer', 'Amazon Customer')
            )
            db.session.add(post)
            db.session.flush()
            
            bot_response = BotResponse(
                post_id=post.id,
                response_content=response_result['response'],
                confidence_score=0.85,  # Default confidence for Amazon responses
                knowledge_base_used=', '.join([str(entry.id) for entry in relevant_entries])
            )
            db.session.add(bot_response)
            db.session.commit()
            
            return jsonify({
                'response': response_result['response'],
                'context': response_result['context'],
                'confidence': 0.85,
                'platform': 'amazon'
            })
        else:
            return jsonify({'error': response_result['error']}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@social_bp.route('/amazon/monitor', methods=['POST'])
def monitor_amazon_products():
    """Monitor Amazon products for new reviews"""
    try:
        data = request.json
        asin_list = data.get('asins', [])
        
        if not asin_list:
            return jsonify({'error': 'No ASINs provided'}), 400
        
        new_reviews = amazon_service.reviews_client.monitor_new_reviews(asin_list)
        
        responses_generated = 0
        for review in new_reviews:
            # Process each new review
            processed_review = amazon_service.process_amazon_comment(review)
            
            if 'error' not in processed_review:
                # Generate automatic response if enabled
                auto_respond = data.get('auto_respond', False)
                if auto_respond:
                    # Get knowledge base context
                    query = processed_review.get('comment', '')
                    relevant_entries = KnowledgeBase.query.filter(
                        db.or_(
                            KnowledgeBase.title.contains(query),
                            KnowledgeBase.content.contains(query)
                        )
                    ).limit(2).all()
                    
                    knowledge_context = '\n'.join([entry.content for entry in relevant_entries])
                    
                    # Generate response
                    response_result = amazon_service.generate_amazon_response(
                        processed_review, 
                        knowledge_context
                    )
                    
                    if response_result['success']:
                        responses_generated += 1
        
        return jsonify({
            'message': f'Monitored {len(asin_list)} products',
            'new_reviews_found': len(new_reviews),
            'responses_generated': responses_generated
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@social_bp.route('/amazon/configure', methods=['POST'])
def configure_amazon_integration():
    """Configure Amazon SP-API credentials"""
    try:
        data = request.json
        
        # In production, securely store these credentials
        config = {
            'client_id': data.get('client_id'),
            'client_secret': data.get('client_secret'),
            'refresh_token': data.get('refresh_token'),
            'access_key_id': data.get('access_key_id'),
            'secret_access_key': data.get('secret_access_key'),
            'role_arn': data.get('role_arn'),
            'marketplace_id': data.get('marketplace_id', 'ATVPDKIKX0DER')
        }
        
        # Validate configuration by testing API access
        test_result = amazon_service.get_all_feedback(config['marketplace_id'])
        
        if test_result['success']:
            return jsonify({
                'message': 'Amazon integration configured successfully',
                'marketplace_id': config['marketplace_id']
            })
        else:
            return jsonify({
                'error': 'Configuration test failed',
                'details': test_result['error']
            }), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

