from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class KnowledgeBase(db.Model):
    __tablename__ = 'knowledge_base'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    content = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=True)
    keywords = db.Column(db.Text, nullable=True)  # Comma-separated keywords for search
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'category': self.category,
            'keywords': self.keywords.split(',') if self.keywords else [],
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    def __repr__(self):
        return f'<KnowledgeBase {self.title}>'

class SocialMediaPost(db.Model):
    __tablename__ = 'social_media_posts'
    
    id = db.Column(db.Integer, primary_key=True)
    platform = db.Column(db.String(50), nullable=False)  # twitter, facebook, instagram, etc.
    post_id = db.Column(db.String(255), nullable=False)  # Platform-specific post ID
    content = db.Column(db.Text, nullable=False)
    author = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed = db.Column(db.Boolean, default=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'platform': self.platform,
            'post_id': self.post_id,
            'content': self.content,
            'author': self.author,
            'created_at': self.created_at.isoformat(),
            'processed': self.processed
        }
    
    def __repr__(self):
        return f'<SocialMediaPost {self.platform}:{self.post_id}>'

class BotResponse(db.Model):
    __tablename__ = 'bot_responses'
    
    id = db.Column(db.Integer, primary_key=True)
    original_post_id = db.Column(db.Integer, db.ForeignKey('social_media_posts.id'), nullable=False)
    response_content = db.Column(db.Text, nullable=False)
    knowledge_sources = db.Column(db.Text, nullable=True)  # JSON string of knowledge base IDs used
    confidence_score = db.Column(db.Float, nullable=True)
    posted = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    original_post = db.relationship('SocialMediaPost', backref=db.backref('responses', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'original_post_id': self.original_post_id,
            'response_content': self.response_content,
            'knowledge_sources': self.knowledge_sources,
            'confidence_score': self.confidence_score,
            'posted': self.posted,
            'created_at': self.created_at.isoformat()
        }
    
    def __repr__(self):
        return f'<BotResponse {self.id}>'

