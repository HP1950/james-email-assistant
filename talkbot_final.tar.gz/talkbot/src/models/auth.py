from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from src.models.user import db

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    company = db.Column(db.String(100), nullable=True)
    password_hash = db.Column(db.String(255), nullable=False)
    plan = db.Column(db.String(20), nullable=False, default='starter')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    
    def __init__(self, first_name, last_name, email, password, company=None, plan='starter'):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email.lower()  # Store email in lowercase
        self.company = company
        self.plan = plan
        self.set_password(password)
    
    def set_password(self, password):
        """Hash and set the user's password"""
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)
    
    def check_password(self, password):
        """Check if the provided password matches the stored hash"""
        return check_password_hash(self.password_hash, password)
    
    def get_full_name(self):
        """Return the user's full name"""
        return f"{self.first_name} {self.last_name}"
    
    def to_dict(self):
        """Convert user object to dictionary (excluding sensitive data)"""
        return {
            'id': self.id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'email': self.email,
            'company': self.company,
            'plan': self.plan,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
    
    @staticmethod
    def find_by_email(email):
        """Find a user by email address"""
        return User.query.filter_by(email=email.lower()).first()
    
    @staticmethod
    def create_user(first_name, last_name, email, password, company=None, plan='starter'):
        """Create a new user with validation"""
        # Check if user already exists
        existing_user = User.find_by_email(email)
        if existing_user:
            raise ValueError("User with this email already exists")
        
        # Validate password strength
        if len(password) < 8:
            raise ValueError("Password must be at least 8 characters long")
        
        # Create new user
        user = User(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=password,
            company=company,
            plan=plan
        )
        
        db.session.add(user)
        db.session.commit()
        
        return user
    
    def update_last_login(self):
        """Update the user's last login timestamp"""
        self.last_login = datetime.utcnow()
        db.session.commit()

class UserSession(db.Model):
    __tablename__ = 'user_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    session_token = db.Column(db.String(255), unique=True, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    
    user = db.relationship('User', backref=db.backref('sessions', lazy=True))
    
    def __init__(self, user_id, session_token, expires_at):
        self.user_id = user_id
        self.session_token = session_token
        self.expires_at = expires_at
    
    @staticmethod
    def create_session(user_id, session_token, expires_at):
        """Create a new user session"""
        session = UserSession(user_id, session_token, expires_at)
        db.session.add(session)
        db.session.commit()
        return session
    
    @staticmethod
    def find_by_token(session_token):
        """Find an active session by token"""
        return UserSession.query.filter_by(
            session_token=session_token,
            is_active=True
        ).first()
    
    def deactivate(self):
        """Deactivate the session"""
        self.is_active = False
        db.session.commit()

