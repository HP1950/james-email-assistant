# TalkBot Flask Application Deployment Guide

This guide provides step-by-step instructions for deploying your TalkBot Flask application (with static HTML/CSS/JS frontend) to your VPS at `Talkbot.schulenberg.tech`.

## Project Structure Overview

Your TalkBot project is a **Python Flask application** that serves:
- **Backend API**: RESTful endpoints for bot functionality
- **Static Frontend**: HTML/CSS/JavaScript files served by Flask
- **Database**: SQLite database for user data and knowledge base

```
talkbot/
├── src/
│   ├── main.py                 # Flask application entry point
│   ├── models/                 # Database models
│   ├── routes/                 # API endpoints
│   ├── services/               # Business logic
│   └── static/                 # Frontend files (HTML/CSS/JS)
│       ├── index.html          # Landing page
│       ├── dashboard.html      # Main dashboard
│       ├── signin.html         # Sign in page
│       ├── signup.html         # Sign up page
│       └── payment.html        # Payment page
├── venv/                       # Python virtual environment
├── requirements.txt            # Python dependencies
└── README.md                   # Documentation
```

## Prerequisites

### On Your VPS
- Ubuntu 20.04+ or similar Linux distribution
- Python 3.8+ installed
- Nginx installed
- Domain `Talkbot.schulenberg.tech` pointing to your VPS IP
- SSL certificate (Let's Encrypt recommended)

### Required Packages
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv nginx supervisor
```

## Step 1: Upload and Extract Application

### 1.1 Upload the Application
Upload `talkbot_complete.tar.gz` to your VPS:
```bash
# On your local machine
scp talkbot_complete.tar.gz user@your-vps-ip:/home/user/

# On your VPS
cd /home/user
tar -xzf talkbot_complete.tar.gz
```

### 1.2 Move to Production Directory
```bash
sudo mv talkbot /var/www/
sudo chown -R www-data:www-data /var/www/talkbot
sudo chmod -R 755 /var/www/talkbot
```

## Step 2: Set Up Python Environment

### 2.1 Create Virtual Environment
```bash
cd /var/www/talkbot
sudo -u www-data python3 -m venv venv
sudo -u www-data ./venv/bin/pip install --upgrade pip
```

### 2.2 Install Dependencies
```bash
sudo -u www-data ./venv/bin/pip install -r requirements.txt
sudo -u www-data ./venv/bin/pip install gunicorn
```

## Step 3: Configure Environment Variables

### 3.1 Create Environment File
```bash
sudo nano /var/www/talkbot/.env
```

### 3.2 Add Configuration
```bash
# Flask Configuration
FLASK_ENV=production
SECRET_KEY=your-super-secret-key-here

# OpenAI Configuration
OPENAI_API_KEY=your-openai-api-key
OPENAI_API_BASE=https://api.openai.com/v1

# Square Payment Configuration
SQUARE_ENVIRONMENT=production  # or 'sandbox' for testing
SQUARE_APPLICATION_ID=your-square-app-id
SQUARE_ACCESS_TOKEN=your-square-access-token
SQUARE_LOCATION_ID=your-square-location-id

# Amazon Integration (Optional)
AMAZON_CLIENT_ID=your-amazon-client-id
AMAZON_CLIENT_SECRET=your-amazon-client-secret
AMAZON_REFRESH_TOKEN=your-amazon-refresh-token
AMAZON_ACCESS_KEY_ID=your-aws-access-key
AMAZON_SECRET_ACCESS_KEY=your-aws-secret-key
AMAZON_ROLE_ARN=your-amazon-role-arn

# Database Configuration
DATABASE_URL=sqlite:///var/www/talkbot/src/database/app.db
```

### 3.3 Secure Environment File
```bash
sudo chmod 600 /var/www/talkbot/.env
sudo chown www-data:www-data /var/www/talkbot/.env
```

## Step 4: Set Up Database

### 4.1 Create Database Directory
```bash
sudo mkdir -p /var/www/talkbot/src/database
sudo chown www-data:www-data /var/www/talkbot/src/database
sudo chmod 755 /var/www/talkbot/src/database
```

### 4.2 Initialize Database
```bash
cd /var/www/talkbot
sudo -u www-data ./venv/bin/python -c "
from src.main import app, db
with app.app_context():
    db.create_all()
    print('Database initialized successfully')
"
```

## Step 5: Create Gunicorn Configuration

### 5.1 Create Gunicorn Config File
```bash
sudo nano /var/www/talkbot/gunicorn.conf.py
```

### 5.2 Add Configuration
```python
# Gunicorn configuration file
bind = "127.0.0.1:8000"
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2
max_requests = 1000
max_requests_jitter = 100
preload_app = True
reload = False

# Logging
accesslog = "/var/log/talkbot/access.log"
errorlog = "/var/log/talkbot/error.log"
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

# Process naming
proc_name = "talkbot"

# Server mechanics
daemon = False
pidfile = "/var/run/talkbot/talkbot.pid"
user = "www-data"
group = "www-data"
tmp_upload_dir = None

# SSL (if needed)
# keyfile = "/path/to/keyfile"
# certfile = "/path/to/certfile"
```

### 5.3 Create Log Directory
```bash
sudo mkdir -p /var/log/talkbot
sudo mkdir -p /var/run/talkbot
sudo chown www-data:www-data /var/log/talkbot
sudo chown www-data:www-data /var/run/talkbot
```

## Step 6: Create Systemd Service

### 6.1 Create Service File
```bash
sudo nano /etc/systemd/system/talkbot.service
```

### 6.2 Add Service Configuration
```ini
[Unit]
Description=TalkBot Flask Application
After=network.target

[Service]
Type=notify
User=www-data
Group=www-data
RuntimeDirectory=talkbot
WorkingDirectory=/var/www/talkbot
Environment=PATH=/var/www/talkbot/venv/bin
EnvironmentFile=/var/www/talkbot/.env
ExecStart=/var/www/talkbot/venv/bin/gunicorn --config gunicorn.conf.py src.main:app
ExecReload=/bin/kill -s HUP $MAINPID
KillMode=mixed
TimeoutStopSec=5
PrivateTmp=true
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### 6.3 Enable and Start Service
```bash
sudo systemctl daemon-reload
sudo systemctl enable talkbot
sudo systemctl start talkbot
sudo systemctl status talkbot
```

## Step 7: Configure Nginx

### 7.1 Create Nginx Configuration
```bash
sudo nano /etc/nginx/sites-available/talkbot.schulenberg.tech
```

### 7.2 Add Nginx Configuration
```nginx
server {
    listen 80;
    server_name talkbot.schulenberg.tech;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name talkbot.schulenberg.tech;
    
    # SSL Configuration (update paths to your certificates)
    ssl_certificate /etc/letsencrypt/live/talkbot.schulenberg.tech/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/talkbot.schulenberg.tech/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/javascript;
    
    # Main location - proxy to Flask app
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $server_name;
        proxy_redirect off;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # Buffer settings
        proxy_buffering on;
        proxy_buffer_size 128k;
        proxy_buffers 4 256k;
        proxy_busy_buffers_size 256k;
    }
    
    # Static files (served directly by Nginx for better performance)
    location /static/ {
        alias /var/www/talkbot/src/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
    
    # API endpoints (ensure they go to Flask)
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $server_name;
        proxy_redirect off;
    }
    
    # File upload size limit
    client_max_body_size 50M;
    
    # Logging
    access_log /var/log/nginx/talkbot_access.log;
    error_log /var/log/nginx/talkbot_error.log;
}
```

### 7.3 Enable Site and Restart Nginx
```bash
sudo ln -s /etc/nginx/sites-available/talkbot.schulenberg.tech /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## Step 8: Set Up SSL Certificate

### 8.1 Install Certbot
```bash
sudo apt install certbot python3-certbot-nginx
```

### 8.2 Obtain SSL Certificate
```bash
sudo certbot --nginx -d talkbot.schulenberg.tech
```

### 8.3 Set Up Auto-Renewal
```bash
sudo crontab -e
# Add this line:
0 12 * * * /usr/bin/certbot renew --quiet
```

## Step 9: Configure Firewall

### 9.1 Set Up UFW
```bash
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

## Step 10: Test Deployment

### 10.1 Check Service Status
```bash
sudo systemctl status talkbot
sudo systemctl status nginx
```

### 10.2 Check Logs
```bash
# TalkBot application logs
sudo journalctl -u talkbot -f

# Nginx logs
sudo tail -f /var/log/nginx/talkbot_access.log
sudo tail -f /var/log/nginx/talkbot_error.log

# Gunicorn logs
sudo tail -f /var/log/talkbot/access.log
sudo tail -f /var/log/talkbot/error.log
```

### 10.3 Test Application
1. Visit `https://talkbot.schulenberg.tech`
2. Test landing page functionality
3. Test sign up/sign in process
4. Test dashboard features
5. Test payment processing (in sandbox mode first)

## Step 11: Monitoring and Maintenance

### 11.1 Set Up Log Rotation
```bash
sudo nano /etc/logrotate.d/talkbot
```

```
/var/log/talkbot/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    postrotate
        systemctl reload talkbot
    endscript
}
```

### 11.2 Database Backup Script
```bash
sudo nano /usr/local/bin/backup-talkbot.sh
```

```bash
#!/bin/bash
BACKUP_DIR="/var/backups/talkbot"
DATE=$(date +%Y%m%d_%H%M%S)
DB_PATH="/var/www/talkbot/src/database/app.db"

mkdir -p $BACKUP_DIR
cp $DB_PATH $BACKUP_DIR/talkbot_db_$DATE.db
find $BACKUP_DIR -name "talkbot_db_*.db" -mtime +30 -delete
```

```bash
sudo chmod +x /usr/local/bin/backup-talkbot.sh
sudo crontab -e
# Add daily backup at 2 AM:
0 2 * * * /usr/local/bin/backup-talkbot.sh
```

## Step 12: Production Checklist

### Security
- [ ] Environment variables properly secured
- [ ] SSL certificate installed and working
- [ ] Firewall configured
- [ ] Database file permissions set correctly
- [ ] Secret keys are strong and unique

### Performance
- [ ] Gunicorn workers configured appropriately
- [ ] Nginx gzip compression enabled
- [ ] Static files served by Nginx
- [ ] Log rotation configured

### Functionality
- [ ] All pages load correctly
- [ ] User registration/login works
- [ ] Payment processing works (test in sandbox first)
- [ ] Knowledge base upload works
- [ ] Bot response generation works
- [ ] All API endpoints respond correctly

### Monitoring
- [ ] Application logs are being written
- [ ] Database backups are working
- [ ] SSL certificate auto-renewal is set up
- [ ] Service auto-restart on failure is working

## Troubleshooting

### Common Issues

1. **Service won't start**
   ```bash
   sudo journalctl -u talkbot -n 50
   ```

2. **Permission errors**
   ```bash
   sudo chown -R www-data:www-data /var/www/talkbot
   sudo chmod -R 755 /var/www/talkbot
   ```

3. **Database errors**
   ```bash
   sudo -u www-data /var/www/talkbot/venv/bin/python -c "
   from src.main import app, db
   with app.app_context():
       db.create_all()
   "
   ```

4. **Nginx errors**
   ```bash
   sudo nginx -t
   sudo tail -f /var/log/nginx/error.log
   ```

### Useful Commands

```bash
# Restart services
sudo systemctl restart talkbot
sudo systemctl restart nginx

# View logs
sudo journalctl -u talkbot -f
sudo tail -f /var/log/nginx/talkbot_error.log

# Check service status
sudo systemctl status talkbot
sudo systemctl status nginx

# Test configuration
sudo nginx -t
/var/www/talkbot/venv/bin/gunicorn --check-config src.main:app
```

## Support

For deployment issues:
- Check logs first: `sudo journalctl -u talkbot -f`
- Verify all environment variables are set
- Ensure all dependencies are installed
- Check file permissions

For application issues:
- Review the application logs
- Test API endpoints individually
- Verify database connectivity
- Check OpenAI API key validity

---

*TalkBot Flask Deployment Guide - Schulenberg.Tech*

