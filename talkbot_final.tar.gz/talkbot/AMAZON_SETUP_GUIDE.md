# Amazon Integration Setup Guide

This guide will help you configure Amazon integration for your TalkBot SaaS platform to respond to product reviews and customer feedback.

## Overview

Amazon integration in TalkBot supports two main functionalities:
1. **Amazon Selling Partner API (SP-API)** - For sellers to access customer feedback and reviews
2. **Product Review Monitoring** - For monitoring and responding to product reviews

## Prerequisites

### For Amazon Sellers (SP-API)
1. Amazon Seller Central account
2. Active selling status on Amazon
3. Developer account with Amazon
4. AWS IAM user with appropriate permissions

### For Product Review Monitoring
1. Product ASINs you want to monitor
2. Basic setup (no special permissions required)

## Step 1: Amazon Selling Partner API Setup

### 1.1 Create Developer Account
1. Go to [Amazon Developer Console](https://developer.amazon.com/)
2. Sign in with your Amazon account
3. Navigate to "Selling Partner API"
4. Create a new application

### 1.2 Register Your Application
1. In Seller Central, go to "Apps & Services" > "Develop apps"
2. Click "Create new app"
3. Fill in application details:
   - **App Name**: TalkBot Integration
   - **Description**: AI-powered response bot for customer engagement
   - **Privacy Policy URL**: Your privacy policy URL
   - **App Type**: Private (for your own use) or Public (for multiple sellers)

### 1.3 Get Your Credentials
After approval, you'll receive:
- **Client ID**: Your application identifier
- **Client Secret**: Your application secret
- **Refresh Token**: For obtaining access tokens

### 1.4 Set Up AWS IAM
1. Create an IAM user in AWS Console
2. Attach the following policy:
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "execute-api:Invoke"
            ],
            "Resource": "arn:aws:execute-api:*:*:*"
        }
    ]
}
```
3. Note down:
   - **Access Key ID**
   - **Secret Access Key**

### 1.5 Create IAM Role
1. Create an IAM role for SP-API access
2. Trust policy:
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::437568002678:root"
            },
            "Action": "sts:AssumeRole",
            "Condition": {
                "StringEquals": {
                    "sts:ExternalId": "your-external-id"
                }
            }
        }
    ]
}
```
3. Note the **Role ARN**

## Step 2: Configure Environment Variables

Create or update your `.env` file:

```bash
# Amazon SP-API Configuration
AMAZON_CLIENT_ID=your_client_id_here
AMAZON_CLIENT_SECRET=your_client_secret_here
AMAZON_REFRESH_TOKEN=your_refresh_token_here
AMAZON_ACCESS_KEY_ID=your_aws_access_key_id
AMAZON_SECRET_ACCESS_KEY=your_aws_secret_access_key
AMAZON_ROLE_ARN=arn:aws:iam::your-account:role/your-role-name

# Amazon Marketplace IDs (choose your region)
AMAZON_MARKETPLACE_US=ATVPDKIKX0DER
AMAZON_MARKETPLACE_CA=A2EUQ1WTGCTBG2
AMAZON_MARKETPLACE_UK=A1F83G8C2ARO7P
AMAZON_MARKETPLACE_DE=A1PA6795UKMFR9
```

## Step 3: Test Your Integration

### 3.1 Test SP-API Connection
1. Open TalkBot dashboard
2. Go to "Platform Settings"
3. Select "Amazon" from dropdown
4. Enter your credentials
5. Click "Configure Platform"
6. Verify successful connection

### 3.2 Test Review Monitoring
1. Go to "Test Comment Response"
2. Select "Amazon" as platform
3. Enter a sample review text
4. Click "Generate Response"
5. Verify appropriate response is generated

## Step 4: Available Amazon Features

### 4.1 Customer Feedback API
- Access customer feedback from Seller Central
- Monitor feedback ratings and comments
- Generate appropriate responses

**Endpoint**: `GET /api/amazon/feedback`

### 4.2 Product Reviews Monitoring
- Monitor specific products by ASIN
- Track new reviews automatically
- Generate responses based on review sentiment

**Endpoint**: `GET /api/amazon/reviews/{asin}`

### 4.3 Automated Response Generation
- AI-powered responses based on review rating
- Contextual responses using your knowledge base
- Platform-appropriate formatting

**Endpoint**: `POST /api/amazon/respond`

### 4.4 Bulk Product Monitoring
- Monitor multiple products simultaneously
- Automated response generation
- Batch processing capabilities

**Endpoint**: `POST /api/amazon/monitor`

## Step 5: Response Strategies

### 5.1 Positive Reviews (4-5 Stars)
- Express gratitude
- Encourage further engagement
- Highlight product benefits mentioned

### 5.2 Neutral Reviews (3 Stars)
- Acknowledge feedback
- Offer assistance
- Provide additional information

### 5.3 Negative Reviews (1-2 Stars)
- Apologize for poor experience
- Offer solutions or support
- Provide contact information for resolution

## Step 6: Best Practices

### 6.1 Response Timing
- Respond within 24-48 hours
- Monitor during business hours
- Set up automated monitoring for faster response

### 6.2 Response Quality
- Keep responses professional and helpful
- Personalize when possible
- Use your knowledge base for accurate information

### 6.3 Compliance
- Follow Amazon's communication guidelines
- Avoid promotional content in responses
- Respect customer privacy

### 6.4 Monitoring
- Track response effectiveness
- Monitor customer satisfaction
- Adjust response strategies based on feedback

## Step 7: Troubleshooting

### Common Issues

1. **"Invalid credentials" error**
   - Verify all credentials are correct
   - Check if refresh token is still valid
   - Ensure IAM permissions are properly set

2. **"Access denied" error**
   - Verify IAM role permissions
   - Check if application is approved by Amazon
   - Ensure marketplace ID is correct

3. **"Rate limit exceeded" error**
   - Implement proper rate limiting
   - Use exponential backoff for retries
   - Monitor API usage quotas

4. **No reviews found**
   - Verify ASIN is correct
   - Check if product has reviews
   - Ensure marketplace ID matches product region

### Debug Mode

Enable debug logging by setting:
```bash
AMAZON_DEBUG=true
```

This will provide detailed logs for troubleshooting.

## Step 8: Advanced Configuration

### 8.1 Multiple Marketplaces
Configure multiple Amazon marketplaces:
```bash
AMAZON_MARKETPLACES=US,CA,UK,DE,FR,IT,ES
```

### 8.2 Custom Response Templates
Create custom response templates for different scenarios:
- High-value customers
- Repeat customers
- Product-specific responses
- Seasonal responses

### 8.3 Integration with CRM
- Export customer interactions
- Sync with customer support systems
- Track customer journey

## Support Resources

- [Amazon SP-API Documentation](https://developer-docs.amazon.com/sp-api/)
- [Amazon Seller Central Help](https://sellercentral.amazon.com/help)
- [AWS IAM Documentation](https://docs.aws.amazon.com/iam/)
- [TalkBot Support](mailto:support@schulenberg.tech)

## Security Notes

1. **Never expose credentials** in client-side code
2. **Use environment variables** for all sensitive data
3. **Implement proper access controls** for API endpoints
4. **Monitor API usage** for unusual activity
5. **Regularly rotate credentials** for security

## Contact

For technical support with Amazon integration:
- Email: support@schulenberg.tech
- Documentation: [TalkBot Docs](https://docs.schulenberg.tech)

---

*Amazon Integration Guide - Part of TalkBot SaaS Platform by Schulenberg.Tech*

