# Square Payment Setup Guide

This guide will help you configure Square payment processing for your TalkBot SaaS platform.

## Prerequisites

1. Square Developer Account
2. Square Application created in Square Developer Dashboard
3. Business verification completed (for production)

## Step 1: Create Square Application

1. Go to [Square Developer Dashboard](https://developer.squareup.com/apps)
2. Click "Create App"
3. Choose "Build on Square" 
4. Enter your app name: "TalkBot SaaS"
5. Select your business location

## Step 2: Get Your Credentials

### Sandbox Credentials (for testing)
1. In your Square app dashboard, go to "Credentials"
2. Copy the following from the "Sandbox" section:
   - Application ID
   - Access Token
   - Location ID

### Production Credentials (for live payments)
1. Complete business verification in Square Dashboard
2. In your Square app dashboard, go to "Credentials"
3. Copy the following from the "Production" section:
   - Application ID
   - Access Token
   - Location ID

## Step 3: Configure Environment Variables

Create a `.env` file in your project root with your Square credentials:

```bash
# Square Configuration
SQUARE_ENVIRONMENT=sandbox  # Change to 'production' for live payments
SQUARE_APPLICATION_ID=your_application_id_here
SQUARE_ACCESS_TOKEN=your_access_token_here
SQUARE_LOCATION_ID=your_location_id_here
```

## Step 4: Update Payment Configuration

1. Open `src/static/payment.html`
2. Replace the placeholder in the Square initialization:

```javascript
// Replace this line:
payments = Square.payments('sandbox-sq0idb-YOUR_APPLICATION_ID', 'sandbox-sq0idp-YOUR_LOCATION_ID');

// With your actual credentials:
payments = Square.payments('YOUR_ACTUAL_APPLICATION_ID', 'YOUR_ACTUAL_LOCATION_ID');
```

3. For production, change the Square script URL from:
```html
<script src="https://sandbox.web.squarecdn.com/v1/square.js"></script>
```
To:
```html
<script src="https://web.squarecdn.com/v1/square.js"></script>
```

## Step 5: Update Backend Configuration

1. Open `src/routes/payments.py`
2. Update the Square configuration variables at the top of the file with your actual credentials
3. For production payments, replace the `simulate_square_payment` function with actual Square API calls

## Step 6: Set Up Webhooks (Optional but Recommended)

1. In Square Developer Dashboard, go to "Webhooks"
2. Add webhook endpoint: `https://yourdomain.com/api/payments/webhook`
3. Subscribe to these events:
   - `payment.created`
   - `payment.failed`
   - `payment.updated`

## Step 7: Test Your Integration

### Sandbox Testing
1. Use Square's test card numbers:
   - Visa: `4111 1111 1111 1111`
   - Mastercard: `5555 5555 5555 4444`
   - Any future expiry date
   - Any 3-digit CVV

### Production Testing
1. Start with small test transactions
2. Verify payments appear in your Square Dashboard
3. Test refund functionality

## Security Best Practices

1. **Never expose your Access Token** in client-side code
2. **Use HTTPS** for all payment pages in production
3. **Validate all payments** on the server side
4. **Store sensitive data securely** (use environment variables)
5. **Implement proper error handling** for failed payments
6. **Log payment activities** for audit purposes

## Going Live Checklist

- [ ] Business verification completed in Square
- [ ] Production credentials obtained
- [ ] Environment variables updated
- [ ] Payment form updated with production Application ID
- [ ] Square script URL updated for production
- [ ] HTTPS enabled on your domain
- [ ] Webhook endpoints configured
- [ ] Test transactions completed successfully
- [ ] Error handling tested
- [ ] Payment confirmation emails set up

## Troubleshooting

### Common Issues

1. **"Application not found" error**
   - Check your Application ID is correct
   - Ensure you're using the right environment (sandbox vs production)

2. **"Location not found" error**
   - Verify your Location ID
   - Ensure the location is active in your Square account

3. **Payment tokenization fails**
   - Check card details are valid
   - Ensure proper form validation
   - Verify Square.js is loaded correctly

4. **Webhook not receiving events**
   - Check webhook URL is accessible
   - Verify webhook signature validation
   - Check Square Dashboard for webhook delivery status

## Support Resources

- [Square Developer Documentation](https://developer.squareup.com/docs)
- [Square Web Payments SDK Guide](https://developer.squareup.com/docs/web-payments/overview)
- [Square API Reference](https://developer.squareup.com/reference/square)
- [Square Developer Community](https://developer.squareup.com/forums)

## Contact

For technical support with your TalkBot integration, contact Schulenberg.Tech support.

