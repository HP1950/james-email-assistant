# TalkBot - Your AI Responder SaaS Platform

TalkBot is a comprehensive SaaS platform that automatically responds to comments on social media and provides information based on your content knowledge base. Perfect for authors, content creators, and businesses who want to engage with their audience 24/7.

## 🚀 Features

### Core Functionality
- **Multi-Platform Support**: Facebook, Instagram, YouTube, LinkedIn, X (Twitter), and websites
- **Knowledge Base Management**: Upload PDFs or text content to train your bot
- **Intelligent Responses**: AI-powered responses using OpenAI GPT models
- **Website Chat Widget**: Embeddable chat widget for your website
- **Real-time Testing**: Test bot responses before going live

### SaaS Platform Features
- **User Authentication**: Secure sign up/sign in with password hashing
- **Subscription Plans**: Starter ($29), Professional ($79), Enterprise ($199)
- **Payment Processing**: Integrated with Square for secure payments
- **User Dashboard**: Comprehensive management interface
- **API Integration**: RESTful API for all functionality

### Security & Compliance
- **Secure Password Storage**: PBKDF2 hashing with salt
- **Session Management**: Secure token-based sessions
- **Payment Security**: PCI-compliant payment processing via Square
- **Data Protection**: Encrypted data storage and transmission

## 🛠 Installation & Setup

### Prerequisites
- Python 3.11+
- Flask
- SQLite (included)
- Square Developer Account (for payments)

### Quick Start
1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Set up Square payment credentials (see SQUARE_SETUP_GUIDE.md)
4. Run the application: `python src/main.py`
5. Access at `http://localhost:5000`

### Environment Configuration
Create a `.env` file with your configuration:
```bash
SQUARE_ENVIRONMENT=sandbox
SQUARE_APPLICATION_ID=your_app_id
SQUARE_ACCESS_TOKEN=your_access_token
SQUARE_LOCATION_ID=your_location_id
OPENAI_API_KEY=your_openai_key
```

## 📱 Platform Integration

### Social Media APIs
- **Facebook/Instagram**: Graph API integration
- **YouTube**: YouTube Data API v3
- **LinkedIn**: LinkedIn API v2
- **X (Twitter)**: Twitter API v2
- **Website**: JavaScript widget integration

### Knowledge Base
- **Text Input**: Direct text content upload
- **PDF Upload**: Automatic text extraction from PDF files
- **Content Processing**: Intelligent chunking and indexing
- **Search & Retrieval**: Fast content lookup for responses

## 💳 Payment Integration

TalkBot uses Square for secure payment processing:

### Subscription Plans
- **Starter Plan** ($29/month): Basic bot features, 1K responses
- **Professional Plan** ($79/month): Advanced features, 10K responses  
- **Enterprise Plan** ($199/month): Premium features, unlimited responses

### Payment Features
- Secure credit card processing
- PCI-compliant tokenization
- Automatic subscription management
- Webhook support for real-time updates

See `SQUARE_SETUP_GUIDE.md` for detailed payment setup instructions.

## 🔧 API Documentation

### Authentication Endpoints
- `POST /api/auth/signup` - User registration
- `POST /api/auth/signin` - User login
- `POST /api/auth/signout` - User logout
- `GET /api/auth/profile` - Get user profile

### Knowledge Base Endpoints
- `GET /api/knowledge` - List knowledge entries
- `POST /api/knowledge` - Add knowledge content
- `POST /api/knowledge/upload` - Upload PDF files
- `DELETE /api/knowledge/{id}` - Delete knowledge entry

### Social Media Endpoints
- `POST /api/social/respond` - Generate response to comment
- `GET /api/social/platforms` - List supported platforms
- `POST /api/social/configure` - Configure platform settings

### Payment Endpoints
- `POST /api/payments/process` - Process payment
- `GET /api/payments/plans` - Get subscription plans
- `GET /api/payments/subscription` - Get user subscription

## 🎨 User Interface

### Landing Page
Beautiful, professional landing page showcasing TalkBot features with:
- Animated sound waves background
- Platform integration badges
- Clear value proposition
- Call-to-action buttons

### Dashboard
Comprehensive management interface featuring:
- Knowledge base management
- Response testing
- Platform configuration
- Analytics and statistics
- User account settings

### Authentication Pages
Professional sign up/sign in pages with:
- Plan selection during registration
- Secure password requirements
- Automatic payment flow integration
- User-friendly error handling

## 🚀 Deployment

### Development
```bash
python src/main.py
```

### Production
1. Set up production environment variables
2. Configure Square production credentials
3. Enable HTTPS
4. Use production WSGI server (gunicorn, uWSGI)
5. Set up database backups
6. Configure monitoring and logging

See `DEPLOYMENT_GUIDE.md` for detailed deployment instructions.

## 🔒 Security

### Data Protection
- All passwords hashed with PBKDF2 + salt
- Secure session management with expiration
- SQL injection protection via SQLAlchemy ORM
- XSS protection with proper input sanitization

### Payment Security
- PCI-compliant payment processing
- Credit card tokenization (no card data stored)
- Secure webhook signature verification
- HTTPS enforcement for payment pages

## 📊 Analytics & Monitoring

### Built-in Analytics
- Response generation statistics
- User engagement metrics
- Platform performance tracking
- Payment and subscription analytics

### Monitoring
- Real-time error tracking
- Performance monitoring
- User activity logging
- Payment transaction logging

## 🤝 Support

### Documentation
- Complete API documentation
- Setup and configuration guides
- Troubleshooting resources
- Best practices documentation

### Technical Support
- Email support for all plans
- Priority support for Professional+ plans
- 24/7 phone support for Enterprise plans
- Dedicated account manager for Enterprise

## 📄 License

This project is proprietary software owned by Schulenberg.Tech. All rights reserved.

## 🏢 About

TalkBot is developed by Schulenberg.Tech, specializing in AI-powered business automation solutions.

**Contact**: support@schulenberg.tech
**Website**: https://schulenberg.tech

---

*TalkBot - Automate your social media engagement with intelligent AI responses.*

