# TalkBot Deployment Guide

## Overview

This guide will help you deploy your TalkBot to a production environment where it can automatically respond to comments on your social media platforms and website.

## Pre-Deployment Checklist

### ✅ Requirements
- [ ] Python 3.11 or higher
- [ ] OpenAI API key
- [ ] Social media platform API credentials
- [ ] Domain name (for production deployment)
- [ ] SSL certificate (recommended)

### ✅ Testing
- [ ] Test knowledge base upload functionality
- [ ] Test bot response generation
- [ ] Test social media platform integrations
- [ ] Test website widget functionality
- [ ] Verify all API endpoints work correctly

## Deployment Options

### Option 1: Cloud Platform Deployment (Recommended)

#### Heroku Deployment

1. **Prepare for Heroku**:
```bash
# Create Procfile
echo "web: gunicorn -w 4 -b 0.0.0.0:\$PORT src.main:app" > Procfile

# Create runtime.txt
echo "python-3.11.0" > runtime.txt

# Install Heroku CLI and login
heroku login
```

2. **Create Heroku App**:
```bash
heroku create your-talkbot-name
```

3. **Set Environment Variables**:
```bash
heroku config:set OPENAI_API_KEY="your-openai-key"
heroku config:set OPENAI_API_BASE="https://api.openai.com/v1"
heroku config:set FLASK_ENV="production"
```

4. **Deploy**:
```bash
git init
git add .
git commit -m "Initial TalkBot deployment"
heroku git:remote -a your-talkbot-name
git push heroku main
```

#### DigitalOcean App Platform

1. **Create app.yaml**:
```yaml
name: talkbot
services:
- name: web
  source_dir: /
  github:
    repo: your-username/talkbot
    branch: main
  run_command: gunicorn -w 4 -b 0.0.0.0:8080 src.main:app
  environment_slug: python
  instance_count: 1
  instance_size_slug: basic-xxs
  envs:
  - key: OPENAI_API_KEY
    value: your-openai-key
  - key: OPENAI_API_BASE
    value: https://api.openai.com/v1
  - key: FLASK_ENV
    value: production
```

2. **Deploy via DigitalOcean Console**:
   - Upload your code to GitHub
   - Create new App in DigitalOcean
   - Connect to your GitHub repository
   - Configure environment variables
   - Deploy

### Option 2: VPS Deployment

#### Ubuntu Server Setup

1. **Server Preparation**:
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and dependencies
sudo apt install python3.11 python3.11-venv python3-pip nginx supervisor -y

# Create application user
sudo useradd -m -s /bin/bash talkbot
sudo su - talkbot
```

2. **Application Setup**:
```bash
# Clone/upload your TalkBot files
cd /home/talkbot
# ... upload your files here ...

# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
pip install gunicorn
```

3. **Environment Configuration**:
```bash
# Create environment file
cat > /home/talkbot/.env << EOF
OPENAI_API_KEY=your-openai-key
OPENAI_API_BASE=https://api.openai.com/v1
FLASK_ENV=production
EOF

# Set permissions
chmod 600 /home/talkbot/.env
```

4. **Supervisor Configuration**:
```bash
sudo cat > /etc/supervisor/conf.d/talkbot.conf << EOF
[program:talkbot]
command=/home/talkbot/venv/bin/gunicorn -w 4 -b 127.0.0.1:5000 src.main:app
directory=/home/talkbot
user=talkbot
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/var/log/talkbot.log
environment=PATH="/home/talkbot/venv/bin"
EOF

# Start supervisor
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start talkbot
```

5. **Nginx Configuration**:
```bash
sudo cat > /etc/nginx/sites-available/talkbot << EOF
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_redirect off;
    }
    
    # Static files
    location /static/ {
        alias /home/talkbot/src/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Widget.js with proper CORS headers
    location /widget.js {
        alias /home/talkbot/src/static/widget.js;
        add_header Access-Control-Allow-Origin *;
        add_header Access-Control-Allow-Methods "GET, OPTIONS";
        add_header Access-Control-Allow-Headers "Content-Type";
    }
}
EOF

# Enable site
sudo ln -s /etc/nginx/sites-available/talkbot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

6. **SSL Certificate (Let's Encrypt)**:
```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d your-domain.com -d www.your-domain.com
```

## Social Media Platform Configuration

### Facebook & Instagram Setup

1. **Create Facebook App**:
   - Go to https://developers.facebook.com/
   - Create new app → Business → Continue
   - Add Facebook Login and Instagram Basic Display products

2. **Get Page Access Token**:
   - Go to Graph API Explorer
   - Select your app and page
   - Generate long-lived page access token
   - Test with: `GET /me/accounts`

3. **Configure Webhooks** (Optional for real-time):
```bash
# Add webhook endpoint to your TalkBot
# Webhook URL: https://your-domain.com/api/webhooks/facebook
# Verify Token: your-custom-verify-token
```

### YouTube Setup

1. **Google Cloud Console**:
   - Create new project
   - Enable YouTube Data API v3
   - Create API key credentials
   - Restrict API key to YouTube Data API

2. **Test API Access**:
```bash
curl "https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&videoId=VIDEO_ID&key=YOUR_API_KEY"
```

### LinkedIn Setup

1. **Create LinkedIn App**:
   - Go to https://www.linkedin.com/developers/
   - Create new app
   - Add "Sign In with LinkedIn" product
   - Get OAuth 2.0 credentials

2. **Generate Access Token**:
   - Use OAuth 2.0 flow to get access token
   - Scope: `r_liteprofile`, `r_emailaddress`, `w_member_social`

### X (Twitter) Setup

1. **Twitter Developer Account**:
   - Apply at https://developer.twitter.com/
   - Create new app
   - Generate Bearer Token for API v2

2. **Test API Access**:
```bash
curl -H "Authorization: Bearer YOUR_BEARER_TOKEN" \
  "https://api.twitter.com/2/tweets/search/recent?query=hello"
```

## Website Widget Integration

### Basic Integration

Add to your website's HTML:
```html
<!-- Before closing </body> tag -->
<div id="talkbot-widget"></div>
<script>
  (function() {
    var script = document.createElement('script');
    script.src = 'https://your-domain.com/widget.js';
    document.head.appendChild(script);
  })();
</script>
```

### WordPress Integration

1. **Add to functions.php**:
```php
function add_talkbot_widget() {
    ?>
    <div id="talkbot-widget"></div>
    <script>
      (function() {
        var script = document.createElement('script');
        script.src = 'https://your-domain.com/widget.js';
        document.head.appendChild(script);
      })();
    </script>
    <?php
}
add_action('wp_footer', 'add_talkbot_widget');
```

### Shopify Integration

1. **Edit theme.liquid**:
```liquid
<!-- Before closing </body> tag -->
<div id="talkbot-widget"></div>
<script>
  (function() {
    var script = document.createElement('script');
    script.src = 'https://your-domain.com/widget.js';
    document.head.appendChild(script);
  })();
</script>
```

## Monitoring and Maintenance

### Log Monitoring

1. **Application Logs**:
```bash
# View supervisor logs
sudo tail -f /var/log/talkbot.log

# View nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

2. **Log Rotation**:
```bash
sudo cat > /etc/logrotate.d/talkbot << EOF
/var/log/talkbot.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 talkbot talkbot
    postrotate
        supervisorctl restart talkbot
    endscript
}
EOF
```

### Health Monitoring

1. **Create Health Check Endpoint**:
```python
@app.route('/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    })
```

2. **Monitor with Uptime Robot**:
   - Add your domain/health endpoint
   - Set up alerts for downtime

### Database Backup

```bash
# Create backup script
cat > /home/talkbot/backup.sh << EOF
#!/bin/bash
DATE=\$(date +%Y%m%d_%H%M%S)
cp /home/talkbot/src/database/app.db /home/talkbot/backups/app_\$DATE.db
find /home/talkbot/backups -name "app_*.db" -mtime +7 -delete
EOF

chmod +x /home/talkbot/backup.sh

# Add to crontab
echo "0 2 * * * /home/talkbot/backup.sh" | crontab -
```

## Security Best Practices

### 1. Environment Variables
- Never commit API keys to version control
- Use environment variables for all secrets
- Rotate API keys regularly

### 2. Network Security
```bash
# Configure firewall
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### 3. Application Security
- Enable HTTPS only
- Implement rate limiting
- Validate all inputs
- Use CORS properly

### 4. Regular Updates
```bash
# Create update script
cat > /home/talkbot/update.sh << EOF
#!/bin/bash
cd /home/talkbot
source venv/bin/activate
pip install --upgrade -r requirements.txt
sudo supervisorctl restart talkbot
EOF
```

## Scaling Considerations

### Horizontal Scaling

1. **Load Balancer Setup**:
```nginx
upstream talkbot_backend {
    server 127.0.0.1:5000;
    server 127.0.0.1:5001;
    server 127.0.0.1:5002;
}

server {
    location / {
        proxy_pass http://talkbot_backend;
    }
}
```

2. **Database Scaling**:
   - Consider PostgreSQL for production
   - Implement connection pooling
   - Use read replicas for heavy read workloads

### Performance Optimization

1. **Caching**:
```python
from flask_caching import Cache

cache = Cache(app, config={'CACHE_TYPE': 'redis'})

@cache.memoize(timeout=300)
def search_knowledge_base(query):
    # Cached knowledge base search
    pass
```

2. **Background Tasks**:
```python
from celery import Celery

celery = Celery('talkbot')

@celery.task
def process_social_media_comments():
    # Background processing
    pass
```

## Troubleshooting

### Common Issues

1. **502 Bad Gateway**:
   - Check if gunicorn is running: `sudo supervisorctl status`
   - Check logs: `sudo tail -f /var/log/talkbot.log`
   - Restart service: `sudo supervisorctl restart talkbot`

2. **Database Locked**:
   - Check file permissions: `ls -la src/database/`
   - Ensure single writer access
   - Consider PostgreSQL for production

3. **API Rate Limits**:
   - Implement exponential backoff
   - Cache responses when possible
   - Monitor API usage

4. **Memory Issues**:
   - Monitor with `htop`
   - Adjust gunicorn worker count
   - Implement memory profiling

### Emergency Procedures

1. **Quick Restart**:
```bash
sudo supervisorctl restart talkbot
sudo systemctl reload nginx
```

2. **Rollback Deployment**:
```bash
cd /home/talkbot
git checkout previous-working-commit
sudo supervisorctl restart talkbot
```

3. **Database Recovery**:
```bash
# Restore from backup
cp /home/talkbot/backups/app_YYYYMMDD_HHMMSS.db /home/talkbot/src/database/app.db
sudo supervisorctl restart talkbot
```

## Support and Maintenance

### Regular Maintenance Tasks

1. **Weekly**:
   - Check application logs
   - Monitor API usage
   - Review bot response quality

2. **Monthly**:
   - Update dependencies
   - Rotate API keys
   - Review security logs
   - Update knowledge base content

3. **Quarterly**:
   - Performance review
   - Security audit
   - Backup testing
   - Capacity planning

This deployment guide should help you successfully deploy and maintain your TalkBot in a production environment. Remember to test thoroughly before going live and monitor your deployment closely in the first few weeks.

