# TalkBot - Intelligent Social Media & Website Response Bot

## Overview

TalkBot is an intelligent response bot designed to automatically answer comments and questions on social media platforms (Facebook, Instagram, YouTube, LinkedIn, X/Twitter) and websites. The bot uses your book content or knowledge base to provide accurate, contextual responses that match your expertise and tone.

## Features

### 🤖 Multi-Platform Support
- **Facebook & Instagram**: Respond to comments and messages
- **YouTube**: Reply to video comments
- **LinkedIn**: Engage with post comments
- **X (Twitter)**: Reply to tweets and mentions
- **Website Integration**: Embeddable chat widget

### 📚 Knowledge Base Management
- Upload book content in bulk
- Automatic content chunking and indexing
- Keyword-based search and retrieval
- Easy content updates and additions

### 🧠 Intelligent Response Generation
- OpenAI-powered natural language processing
- Context-aware responses based on your knowledge base
- Platform-specific response formatting
- Confidence scoring for response quality

### 🌐 Website Chat Widget
- Easy-to-embed JavaScript widget
- Responsive design for all devices
- Real-time chat interface
- Seamless integration with your knowledge base

## Quick Start

### 1. Installation

```bash
# Clone or extract the TalkBot files
cd talkbot

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Environment Setup

Make sure you have the following environment variables set:
```bash
export OPENAI_API_KEY="your-openai-api-key"
export OPENAI_API_BASE="https://api.openai.com/v1"
```

### 3. Run the Application

```bash
# Start the Flask server
python src/main.py
```

The application will be available at `http://localhost:5000`

## Configuration

### Social Media Platform Setup

#### Facebook & Instagram
1. Create a Facebook App at https://developers.facebook.com/
2. Get your Page Access Token
3. Configure in TalkBot dashboard:
   - Platform: Facebook/Instagram
   - API Token: Your Page Access Token

#### YouTube
1. Create a project in Google Cloud Console
2. Enable YouTube Data API v3
3. Create API credentials
4. Configure in TalkBot dashboard:
   - Platform: YouTube
   - API Key: Your YouTube API Key

#### LinkedIn
1. Create a LinkedIn App at https://www.linkedin.com/developers/
2. Get OAuth 2.0 access token
3. Configure in TalkBot dashboard:
   - Platform: LinkedIn
   - API Token: Your LinkedIn Access Token

#### X (Twitter)
1. Create a Twitter App at https://developer.twitter.com/
2. Get Bearer Token for API v2
3. Configure in TalkBot dashboard:
   - Platform: Twitter
   - API Token: Your Bearer Token

### Knowledge Base Setup

1. **Upload Content**: Use the web interface to upload your book content
2. **Bulk Upload**: Paste large amounts of text for automatic chunking
3. **Individual Entries**: Add specific knowledge entries manually
4. **Keywords**: Add relevant keywords for better search results

## Website Integration

### Embed Chat Widget

Add this code to your website to enable the TalkBot chat widget:

```html
<!-- TalkBot Widget -->
<div id="talkbot-widget"></div>
<script>
  (function() {
    var script = document.createElement('script');
    script.src = 'YOUR_TALKBOT_URL/widget.js';
    document.head.appendChild(script);
  })();
</script>
```

Replace `YOUR_TALKBOT_URL` with your TalkBot deployment URL.

### Widget Customization

The widget automatically adapts to your website's design. You can customize it by modifying the CSS variables in `widget.js`:

- `--talkbot-primary-color`: Main brand color
- `--talkbot-secondary-color`: Secondary accent color
- `--talkbot-border-radius`: Border radius for rounded corners

## API Documentation

### Knowledge Base Endpoints

#### GET /api/knowledge
Get all knowledge base entries

#### POST /api/knowledge
Create a new knowledge entry
```json
{
  "title": "Entry Title",
  "content": "Entry content...",
  "category": "Book Content",
  "keywords": ["keyword1", "keyword2"]
}
```

#### POST /api/knowledge/bulk-upload
Bulk upload content with automatic chunking
```json
{
  "content": "Large text content...",
  "title": "Book Title",
  "category": "Book Content"
}
```

#### POST /api/knowledge/search
Search knowledge base
```json
{
  "query": "search terms"
}
```

### Social Media Endpoints

#### POST /api/social/simulate-comment
Test bot response generation
```json
{
  "comment": "Test comment or question",
  "platform": "facebook"
}
```

#### POST /api/social/platforms/configure
Configure platform credentials
```json
{
  "platform": "facebook",
  "credentials": {
    "access_token": "your-token"
  }
}
```

#### GET /api/social/platforms/{platform}/comments/{post_id}
Fetch comments from a specific platform and post

#### POST /api/social/platforms/{platform}/reply
Post a reply to a comment
```json
{
  "comment_id": "comment-id",
  "reply_text": "Bot response"
}
```

## Deployment

### Local Development
```bash
python src/main.py
```

### Production Deployment

1. **Using Gunicorn**:
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

2. **Using Docker**:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "src.main:app"]
```

3. **Environment Variables**:
```bash
OPENAI_API_KEY=your-openai-key
OPENAI_API_BASE=https://api.openai.com/v1
FLASK_ENV=production
```

### Reverse Proxy Setup (Nginx)

```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## Usage Examples

### 1. Upload Book Content
```python
import requests

response = requests.post('http://localhost:5000/api/knowledge/bulk-upload', json={
    'content': 'Your book content here...',
    'title': 'My Book',
    'category': 'Book Content'
})
```

### 2. Test Bot Response
```python
response = requests.post('http://localhost:5000/api/social/simulate-comment', json={
    'comment': 'What is the main theme of your book?',
    'platform': 'facebook'
})
print(response.json()['response']['response_content'])
```

### 3. Configure Platform
```python
requests.post('http://localhost:5000/api/social/platforms/configure', json={
    'platform': 'facebook',
    'credentials': {
        'access_token': 'your-facebook-token'
    }
})
```

## Troubleshooting

### Common Issues

1. **OpenAI API Errors**
   - Verify your API key is correct
   - Check your OpenAI account has sufficient credits
   - Ensure OPENAI_API_KEY environment variable is set

2. **Social Media API Errors**
   - Verify platform credentials are correct
   - Check API rate limits
   - Ensure proper permissions are granted

3. **Database Issues**
   - Check if SQLite database file exists
   - Verify write permissions in the database directory
   - Run database migrations if needed

4. **Widget Not Loading**
   - Check if widget.js is accessible
   - Verify CORS settings allow your domain
   - Check browser console for JavaScript errors

### Debug Mode

Enable debug mode for detailed error messages:
```bash
export FLASK_ENV=development
python src/main.py
```

## Security Considerations

1. **API Keys**: Never expose API keys in client-side code
2. **CORS**: Configure CORS properly for production
3. **Rate Limiting**: Implement rate limiting for API endpoints
4. **Input Validation**: All user inputs are validated and sanitized
5. **HTTPS**: Always use HTTPS in production

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License. See LICENSE file for details.

## Support

For support and questions:
- Check the troubleshooting section
- Review API documentation
- Test with the built-in simulation tools

## Changelog

### Version 1.0.0
- Initial release
- Multi-platform social media integration
- Knowledge base management
- Website chat widget
- OpenAI-powered response generation
- Web-based management interface

